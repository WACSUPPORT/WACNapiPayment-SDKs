/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android.phonegap;

import static net.wacapps.napi.android.phonegap.Constants.TAG;
import static net.wacapps.napi.util.LocalizationHelper.getMessage;

import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.wacapps.napi.android.AndroidWacPaymentService;
import net.wacapps.napi.android.WacNapiContext;
import net.wacapps.napi.api.NapiException;
import net.wacapps.napi.api.Util;
import net.wacapps.napi.api.WacPaymentService;
import net.wacapps.napi.api.WacRestApi;
import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.Oauth2AccessToken;
import net.wacapps.napi.resource.jaxb.ReservedTransaction;
import net.wacapps.napi.util.NapiLog;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.phonegap.api.PluginResult;

/**
 * The helper class for Napi Phone Gap Plugin
 * 
 * @author vikas.kumar
 * 
 */
public class NapiPhoneGapPluginHelper {

	/**
	 * Gets the access token from the URL being passed.
	 * 
	 * @param url
	 *            The URL.
	 * @param itemId
	 * @return
	 * @throws NapiException
	 */
	public static String[] getAccessToken(String url, String itemId) throws NapiException {
		debug("Entering getAccessToken");
		AndroidWacPaymentService mService = WacNapiContext.getInstance().getPaymentService();
		String accessToken = null;
		String serverReferenceCode = null;
		Map<String, List<String>> params = null;
		if ("token".equals(mService.getTokenMode())) {
			try {
				params = Util.getUrlParameters(url, "#");
			} catch (UnsupportedEncodingException e) {
				error("Error reading the parameters from URL : " + e.getMessage(), e);
			}
			debug("Processing implicit grant results");
			try {
				accessToken = params.get("access_token").get(0);
				if (WacNapiContext.getInstance().getPaymentService().getAPIVersion() == WacPaymentService.APIDOT2)
					serverReferenceCode = params.get("server_reference_code").get(0);
				debug("token is " + accessToken);
			} catch (Exception e1) {
				throw new NapiException(getMessage("AUTHENTICATION_FAILED"));
			}
		} else if ("code".equals(mService.getTokenMode())) {
			try {
				params = Util.getUrlParameters(url, "\\?");
				debug("Processing code grant results");
				String code = params.get("code").get(0);
				Oauth2AccessToken token = WacRestApi.getOAuth2AccessToken(mService.getOperator(), mService.getProductItem(itemId), mService.getCredential(), mService.getSecret(), code, Constants.PROP_REDIRECTURL);
				accessToken = token.getAccessToken();
				serverReferenceCode = token.getServerReferenceCode();
			} catch (UnsupportedEncodingException e) {
				error("Error reading the parameters from URL : " + e.getMessage(), e);
			} catch (Exception ee) {
				throw new NapiException(getMessage("AUTHENTICATION_FAILED"));
			}
		}
		debug("Exiting getAccessToken with accessToken = " + (accessToken == null ? "" : accessToken) + ", serverReferenceCode = " + (serverReferenceCode == null ? "" : serverReferenceCode));
		return new String[] { accessToken, serverReferenceCode };
	}

	/**
	 * Add the url to the processedURLs hashset.
	 * 
	 * @param processedUrls
	 *            The hash set where all the URL are stored.
	 * @param url
	 *            The URL to be added to the hash set.
	 * @return Whether successfully added the URL or not.
	 */
	public synchronized static boolean addToProcessedUrls(HashSet<String> processedUrls, String url) {
		boolean retVal = processedUrls.add(url);
		debug("adding url " + retVal + " - " + url);
		return retVal;
	}

	/**
	 * Check whether the URL is already present in the passed hash set or not.
	 * 
	 * @param processedUrls
	 *            The hash set where to check for the URL.
	 * @param url
	 *            The URL to be checked.
	 * @return Whether the URL is present in the hash set or not.
	 */
	public synchronized static boolean isUrlProcessed(HashSet<String> processedUrls, String url) {
		boolean retVal = processedUrls.contains(url);
		debug("checking for url " + retVal + " - " + url);
		return retVal;
	}

	/**
	 * The method forms the {@link ReservedTransaction} object from the json
	 * string being passed.
	 * 
	 * @param jsonString
	 *            The JSon String for {@link ReservedTransaction} object
	 * @return The {@link ReservedTransaction} object.
	 */
	public static ReservedTransaction getReserveTransaction(String jsonString) {
		debug("Entering getReserveTransaction with jsonString " + jsonString);
		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		ReservedTransaction reserve = null;
		try {
			JSONObject j = new JSONObject(jsonString);
			reserve = gson.fromJson(j.toString(), ReservedTransaction.class);
		} catch (JSONException e) {
			error("Error creating the json object for ReservedTransaction " + e.getMessage(), e);
		}
		debug("Exiting reserve with getServerReferenceCode = " + reserve.getServerReferenceCode());
		return reserve;
	}

	/**
	 * The method gets the value of the key being passed from the plugin result.
	 * 
	 * @param watchResult
	 *            The {@link PluginResult} instance where to check for the key.
	 * @param key
	 *            The key as string.
	 * @return The value as string.
	 */
	public static String getResultValue(PluginResult watchResult, String key) {
		return getResultValue(watchResult, key, true);
	}

	/**
	 * The method gets the value of the key being passed from the plugin result.
	 * 
	 * @param watchResult
	 *            The {@link PluginResult} instance where to check for the key.
	 * @param key
	 *            The key as string.
	 * @param emitLogs
	 *            Whether to emit logs contained in the method or not.
	 * @return The value as string.
	 */
	public static String getResultValue(PluginResult watchResult, String value, boolean emitLogs) {
		if (emitLogs)
			debug("Entering getResultValue with search value = " + value);
		JSONObject r;
		String returnValue = null;
		try {
			r = new JSONObject(watchResult.getMessage());

			returnValue = r.getString(value);
			if (emitLogs) {
				boolean dummyFound = false;
				for (@SuppressWarnings("unchecked")
				Iterator<String> iterator = r.keys(); iterator.hasNext();) {
					String key = (String) iterator.next();
					if (Constants.DUMMY.equalsIgnoreCase(key)) {
						dummyFound = true;
					}
				}

				if (!dummyFound) {
					debug("The plugin result being checked is " + watchResult.getMessage());
				}
			}
		} catch (JSONException e) {
			returnValue = null;
		}

		if (emitLogs)
			debug("Exiting getResultValue with returnValue as " + (returnValue == null ? "" : returnValue));
		return returnValue;
	}

	/**
	 * Gets the {@link Item} value from the {@link ReservedTransaction} object.
	 * 
	 * @param trans
	 *            The {@link ReservedTransaction} object.
	 * @return The {@link Item} object.
	 */
	public static Item getItemFromReservedTransaction(ReservedTransaction trans) {
		debug("Entering getItemFromReservedTransaction with itemId = " + ((trans == null || trans.getItemId() == null) ? "" : trans.getItemId()));
		Item item = new Item();
		item.setCurrency(trans.getItemCurrency());
		item.setDescription(trans.getItemDesc());
		item.setItemId(trans.getItemId());
		item.setPrice(trans.getItemPrice());
		debug("Exiting getItemFromReservedTransaction");
		return item;
	}

	/**
	 * Logs at debug level.
	 * 
	 * @param message
	 *            The message to be logged.
	 */
	public static void debug(String message) {
		NapiLog.d(TAG, message);
	}

	/**
	 * Logs at error level.
	 * 
	 * @param message
	 *            The message to be logged.
	 * @param t
	 *            The throwable instance to get the stack trace.
	 */
	public static void error(String message, Throwable t) {
		Log.e(TAG, message, t);
	}

}
