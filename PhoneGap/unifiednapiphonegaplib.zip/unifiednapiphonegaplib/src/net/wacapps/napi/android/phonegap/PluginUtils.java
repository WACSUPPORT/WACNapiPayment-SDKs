/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android.phonegap;

import static net.wacapps.napi.android.phonegap.Constants.TAG;

import java.lang.reflect.Type;

import net.wacapps.napi.util.NapiLog;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.phonegap.api.PluginResult;
import com.phonegap.api.PluginResult.Status;

/**
 * The utility class for the Napi Phonegap plugin.
 * 
 * @author vikas.kumar
 * 
 */
public class PluginUtils {

	/**
	 * Checks whether the string is null or empty.
	 * 
	 * @param str
	 *            The string to be checked.
	 * @return Whether the string is empty or not.
	 */
	public static boolean isEmpty(String str) {
		return isEmpty(str, true);
	}

	/**
	 * Checks whether the string is null or empty.
	 * 
	 * @param str
	 *            The string to be checked.
	 * @param emitLogs
	 *            Whether to emits the logs to the logger or not.
	 * 
	 * @return Whether the string is empty or not.
	 */
	public static boolean isEmpty(String str, boolean emitLogs) {
		if (emitLogs)
			NapiLog.d(TAG, "Checking isEmpty for " + str);
		boolean result = false;
		if (str != null) {
			result = str.trim().length() == 0 ? true : false;
		} else {
			result = true;
		}
		if (emitLogs)
			NapiLog.d(TAG, "result of isEmpty = " + result);
		return result;
	}

	/**
	 * Creates a dummy result so that the client program does not throw Null
	 * Pointers.
	 * 
	 * @return The {@link PluginResult} instance.
	 */
	public static PluginResult getDummyResult() {
		PluginResult result;
		JSONObject jobj = new JSONObject();
		try {
			jobj.put(Constants.DUMMY, Constants.DUMMY);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		result = new PluginResult(Status.OK, jobj);
		return result;
	}

	/**
	 * The method converts an object {@code obj} of type {@code type} to a
	 * {@link JSONObject} instance.
	 * 
	 * @param obj
	 *            The object to be converted.
	 * @param type
	 *            The {@link Type} of {@code obj}.
	 * @return The {@link JSONObject} instance
	 */
	public static JSONObject toJSONObject(Object obj, Type type) {
		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		String str = gson.toJson(obj, type);
		JSONObject json = null;
		try {
			json = new JSONObject(str);
		} catch (JSONException e) {
			Log.e(TAG, "Error converting to JSON object.", e);
		}
		NapiLog.d(TAG, "The result of toJSONObject is " + json.toString());
		return json;
	}

	/**
	 * The method converts a JSONObject {@code jsonObj} of Class {@code clazz}
	 * to an instance of Class {@code clazz}
	 * 
	 * @param jsonObj
	 *            The {@link JSONObject} instance to be converted.
	 * @param clazz
	 *            The type of the object {@code jsonObj}
	 * @return The instance of type {@code clazz}
	 */
	public static <T> T toObject(JSONObject jsonObj, Class<T> clazz) {
		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		return gson.fromJson(jsonObj.toString(), clazz);
	}

}
