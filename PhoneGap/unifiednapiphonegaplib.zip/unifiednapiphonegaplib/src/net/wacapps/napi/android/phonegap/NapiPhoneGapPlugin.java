/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android.phonegap;

import static net.wacapps.napi.android.phonegap.Constants.TAG;
import static net.wacapps.napi.api.Util.oEncode;
import static net.wacapps.napi.util.LocalizationHelper.getMessage;
import static net.wacapps.napi.util.LocalizationHelper.getMessageTranslationForMessage;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import net.wacapps.napi.android.AndroidWacPaymentService;
import net.wacapps.napi.android.WacNapiContext;
import net.wacapps.napi.api.NapiException;
import net.wacapps.napi.api.OSPair;
import net.wacapps.napi.api.SKSV;
import net.wacapps.napi.api.Util;
import net.wacapps.napi.api.WacEndpoints;
import net.wacapps.napi.api.WacPaymentService;
import net.wacapps.napi.api.WacRestApi;
import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.Operator;
import net.wacapps.napi.resource.jaxb.Product;
import net.wacapps.napi.resource.jaxb.ReservedTransaction;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionList;
import net.wacapps.napi.util.LocalizationHelper;
import net.wacapps.napi.util.NapiHttpHelper;
import net.wacapps.napi.util.NapiLog;
import net.wacapps.napi.util.crypto.DeviceTransactionStorage;
import net.wacapps.napi.util.crypto.SecureDeviceTransactionDatabase;
import net.wacapps.napi.xdo.applications.Application;
import net.wacapps.napi.xdo.applications.Credential;
import net.wacapps.napi.xdo.developer.Developer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.util.Log;

import com.phonegap.api.Plugin;
import com.phonegap.api.PluginResult;
import com.phonegap.api.PluginResult.Status;

/**
 * The NapiPhoneGapPlugin contains implementation for all the API's used for
 * payment and transaction related functions.
 */
public class NapiPhoneGapPlugin extends Plugin {

	private static Properties mProps = null;
	private AndroidWacPaymentService mService = null;
	private List<Item> mItemList = null;
	private Item mSelectedItem = null;
	private String mRequestToken = null;
	private String mOauthSecret = null;
	private HashSet<String> mProcessedUrls;
	private String mPaymentMethod = "oauth20rev13";
	private String mRefCode = null;
	private boolean mShowPage = false;
	private PluginResult mResult = null;
	private boolean connectedFirstTime = false;
	private ProgressDialog pd;
	// @SuppressWarnings("unused")
	private static LocalizationHelper localizationHelperInstance;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.phonegap.api.Plugin#execute(java.lang.String,
	 * org.json.JSONArray, java.lang.String)
	 */
	@Override
	public PluginResult execute(String action, JSONArray args, String callbackId) {
		debug("Plugin called for action " + action);
		debug("Arguments in execute method - " + args.toString());

		// Check the value of action. The action defines which method is being
		// called from wac.js.
		PluginMethod method = PluginMethod.valueOf(action);
		debug("The plugin method being called is " + method.toString());
		try {
			switch (method) {
			case initializeNapi:
				debug("Going to call " + PluginMethod.initializeNapi);
				mResult = initializeNapi(args);
				break;
			case checkBillingAvailability:
				debug("Going to call " + PluginMethod.checkBillingAvailability);
				mResult = checkBillingAvailability();
				break;
			case setSpoofIP:
				debug("Going to call " + PluginMethod.setSpoofIP);
				mResult = setSpoofIP(args);
				break;
			case setDebugEnabled:
				debug("Going to call " + PluginMethod.setDebugEnabled);
				mResult = setDebugEnabled(args);
				break;
			case setEndPoint:
				debug("Going to call " + PluginMethod.setEndPoint);
				mResult = setEndPoint(args);
				break;
			case productList:
				debug("Going to call " + PluginMethod.productList);
				mResult = productList();
				break;
			case chargePayment:
				debug("Going to call " + PluginMethod.chargePayment);
				connectedFirstTime = true;
				chargePayment(args, AndroidWacPaymentService.CHARGE_PAYMENT);
				break;
			case reservePayment:
				debug("Going to call " + PluginMethod.reservePayment);
				connectedFirstTime = true;
				reservePayment(args);
				break;
			case capturePayment:
				debug("Going to call " + PluginMethod.capturePayment);
				capturePayment(args);
				break;
			case transactionList:
				debug("Going to call " + PluginMethod.transactionList);
				connectedFirstTime = true;
				transactionList();
				break;
			case checkTransaction:
				debug("Going to call " + PluginMethod.checkTransaction);
				connectedFirstTime = true;
				checkTransaction(args);
				break;
			default:
				debug("In the default block. No conditions satisfied.");
				break;
			}
		} catch (Exception e) {
			error("Exception " + e.getMessage(), e);
			StackTraceElement[] stackTrace = e.getStackTrace();
			StringBuffer s = new StringBuffer();
			s.append(e.toString() + " : ");
			for (int i = 0; i < stackTrace.length; i++) {
				s.append(stackTrace[i].toString());
			}
			mResult = new PluginResult(Status.ERROR, s.toString());
			error("Error occurred for action " + action + " = " + s.toString(), e);
		}
		debug("Plugin result for action " + action + " = " + mResult.getMessage());
		return mResult;
	}

	/**
	 * Reserve the funds for making a payment later. This call is used together
	 * with capturePayment
	 * 
	 * @param args
	 *            The javascript function arguments passed.
	 * @throws JSONException
	 */
	private void reservePayment(JSONArray args) throws JSONException {
		debug("Entering reservePayment with parameters " + ((args == null) ? "" : args.toString()));
		int mode = AndroidWacPaymentService.RESERVE_PAYMENT;
		debug("Calling chargePayment with mode as " + mode);
		chargePayment(args, mode);
		debug("Exiting reservePayment");
	}

	/**
	 * Verifies the validity of a transaction is a transaction ID is provided
	 * 
	 * @param args
	 *            The javascript function arguments passed.
	 * @throws JSONException
	 */
	private void checkTransaction(JSONArray args) throws JSONException {
		debug("Entering checkTransaction with parameters " + ((args == null) ? "" : args.toString()));
		JSONObject argsMap = args.getJSONObject(0);
		debug("The inputs to checktransation method are " + argsMap.toString());
		PluginResult tempResult1 = getCheckTransactionResult(argsMap.getString("serverReferenceCode"), argsMap.getString("itemId"));
		debug("The result of checkTransaction call is " + tempResult1.getMessage());
		String key1 = NapiPhoneGapPluginHelper.getResultValue(tempResult1, Constants.KEY);
		debug("The value of the key found is " + key1);
		if (key1 != null) {
			if (key1.equalsIgnoreCase(Constants.URL)) {
				debug("Creating a child browser.");
				NapiBrowser nb = new NapiBrowser(ctx) {

					@Override
					public void onLocationChange(String url) {
						debug("onLocationChange called. Loading URL = " + url);
						showConnectingToWACDialog();
						if (url.indexOf(getProperty(Constants.PROP_REDIRECTURL)) == 0) {
							debug("Closing the Napi Browser.");
							this.close();
							mShowPage = true;
							debug("showPage = " + mShowPage);
						}
						debug("Calling watchTrnxDetailsURL method.");
						PluginResult tempResult = watchTrnxDetailsURL(url);
						if (NapiPhoneGapPluginHelper.getResultValue(tempResult, Constants.DUMMY, false) == null) {
							debug("Result found. Ending the watchTrnxDetailsURL process.");
							debug("The result being set is " + tempResult.getMessage());
							debug("Calling notifyForResults");
							mResult = tempResult;
							notifyForResults();
						}
					}

				};
				nb.showWebPage(NapiPhoneGapPluginHelper.getResultValue(tempResult1, Constants.VALUE), new JSONObject().put(Constants.SHOW_LOCATION_BAR, false));
				debug("Waiting for results from the Napi Browser.");
				nb.waitForResults();
				debug("Main thread continuing after notification by Napi Browser.");
			} else if (key1.equalsIgnoreCase(Constants.ERROR)) {
				debug("There occurred an error. Propagating the error - " + tempResult1.getMessage());
				mResult = tempResult1;
			} else {
				debug("Got the transaction details from the local storage with result as " + tempResult1.getMessage());
				mResult = tempResult1;
			}
		}

		debug("Exiting checkTransaction");
	}

	/**
	 * Fetches the transaction list for the user.
	 * 
	 * @throws JSONException
	 */
	private void transactionList() throws JSONException {
		debug("Entering transactionList");
		PluginResult tempResult = getTransactionListResult();
		debug("Result of transactionList method call is  " + tempResult.getMessage());
		String key = NapiPhoneGapPluginHelper.getResultValue(tempResult, Constants.KEY);

		if (Constants.TRANSACTION_LIST.equalsIgnoreCase(key)) {
			debug("Getting the transaction list from local storage.");
			mResult = tempResult;
		} else if (Constants.URL.equalsIgnoreCase(key)) {
			debug("Transaction list to be retrieved from a URL hit." + NapiPhoneGapPluginHelper.getResultValue(tempResult, Constants.VALUE));
			debug("Creating a Napi Browser.");
			NapiBrowser nb = new NapiBrowser(ctx) {

				@Override
				public void onLocationChange(String url) {
					debug("onLocationChange called. Loading URL = " + url);
					showConnectingToWACDialog();
					if (url.indexOf(getProperty(Constants.PROP_REDIRECTURL)) == 0) {
						debug("Closing the Napi Browser");
						this.close();
						mShowPage = true;
						debug("showPage = " + mShowPage);
					}

					debug("Calling watchTrnxListURL method.");
					PluginResult tempResult = watchTrnxListURL(url);
					if (NapiPhoneGapPluginHelper.getResultValue(tempResult, Constants.DUMMY, false) == null) {
						debug("Result found. Ending the watchTrnxListURL process.");
						mResult = tempResult;
						debug("The result being set is " + tempResult.getMessage());
						debug("Calling notifyForResults");
						notifyForResults();
					}
				}

			};
			nb.showWebPage(NapiPhoneGapPluginHelper.getResultValue(tempResult, Constants.VALUE), new JSONObject().put(Constants.SHOW_LOCATION_BAR, false));
			debug("Waiting for results from the Napi Browser.");
			nb.waitForResults();
			debug("Main thread continuing after notification by Napi Browser.");
		} else if (Constants.ERROR.equalsIgnoreCase(key)) {
			debug("There occurred an error. Propagating the error - " + tempResult.getMessage());
			mResult = tempResult;
		}
		debug("Exiting transactionList");
	}
	
	/**
	 * The method checks whether the billing is available or not.
	 * @return The result.
	 */
	private PluginResult checkBillingAvailability(){
		debug("Entering checkBillingAvailability");
		PluginResult result = null;
		try {
			OSPair osPair = getProductList();
			debug("The result of ProductList call is " + ((osPair == null) ? "null" : osPair.toString()));
			// Prepare the result
			JSONObject itemList = new JSONObject();
			debug("Setting isBillingAvailable to true.");
			itemList.put("isBillingAvailable", true);
			result = new PluginResult(Status.OK, itemList);
		} catch (Exception e) {
			error("Error occurred while checking the availability of the billing.", e);
			JSONObject itemList = new JSONObject();
			try {
				debug("Setting isBillingAvailable to false.");
				itemList.put("isBillingAvailable", false);
			} catch (JSONException e1) {
				// Cannot do much. Just log it.
				error("Error occurred while creating the result json object.", e);
			}
			result = new PluginResult(Status.OK, itemList);
		}
		debug("Exiting checkBillingAvailability with result " + result.getMessage());
		return result;
	}

	/**
	 * Capture the funds, usually called after successful content delivery. Use
	 * the data from reserve payment call to make a payment.
	 * 
	 * @param args
	 *            The javascript function arguments passed.
	 * @throws JSONException
	 */
	private void capturePayment(JSONArray args) throws JSONException {
		debug("Entering capturePayment with parameters " + ((args == null) ? "" : args.toString()));
		JSONObject param = args.getJSONObject(0);

		ReservedTransaction trans = PluginUtils.toObject(param, ReservedTransaction.class);
		debug("Reserved transaction object is  " + param.toString());
		int apiVersion = WacNapiContext.getInstance().getPaymentService().getAPIVersion();
		if (apiVersion == WacPaymentService.APIDOT2) {
			debug("Doing 0.2 capture payment.");
			mResult = doOAuth2CapturePayment(trans.getAccessToken(), trans.getServerReferenceCode(), NapiPhoneGapPluginHelper.getItemFromReservedTransaction(trans), trans.getRefCode(), trans.getApiVersion(), trans.getPaymentUri(), null, null);
		} else {
			debug("Doing 0.1 capture payment.");
			if ("oauth20rev13".equals(mPaymentMethod)) {
				debug("Doing 0.1 - oauth20rev13 capture payment.");
				mResult = doOAuth2CapturePayment(trans.getAccessToken(), trans.getServerReferenceCode(), NapiPhoneGapPluginHelper.getItemFromReservedTransaction(trans), trans.getRefCode(), trans.getApiVersion(), trans.getPaymentUri(), mService.getOperator().getMcc(), mService.getOperator().getMnc());
			} else {
				debug("Doing 0.1 - oauth10a capture payment.");
				mResult = doOAuth1CapturePayment(trans.getVerifier(), trans.getItemPrice(), trans.getItemDesc(), trans.getItemCurrency(), trans.getOperatorMcc(), trans.getOperatorMnc(), trans.getAccessToken(), trans.getOAuthSecret(), trans.getServiceSecret(), trans.getServiceCredential(), trans.getPaymentUri(), trans.getRefCode());
			}
		}
		debug("The result id set to " + mResult.getMessage());
		debug("Exiting capturePayment");
	}

	/**
	 * The charge Payment method. The method loads a Napi browser where the
	 * gateway processing is done and returns the transaction details to the
	 * client.
	 * 
	 * @param args
	 *            The method arguments
	 * @param mode
	 *            The Payment Mode - either
	 *            AndroidWacPaymentService.CHARGE_PAYMENT or
	 *            AndroidWacPaymentService.RESERVE_PAYMENT
	 * @throws JSONException
	 */
	private void chargePayment(JSONArray args, final Integer mode) throws JSONException {
		debug("Entering chargePayment with parameters args = " + ((args == null) ? "" : args.toString()) + ", mode = " + (mode == null ? "" : mode));
		String url = WacNapiContext.getInstance().getEndPoints().getAuthorizationChargePath() + "?client_id=" + getProperty(Constants.PROP_CREDENTIAL) + "&scope=" + URLEncoder.encode(WacRestApi.GET_POST_SCOPE + "?code=" + args.getString(0)) + "&response_type=" + "token" + "&redirect_uri=" + getProperty(Constants.PROP_REDIRECTURL);
		mSelectedItem = new Item();
		mSelectedItem.setItemId(args.getString(0));
		debug("The selected item's id found is " + mSelectedItem.getItemId());
		debug("URL going to be hit is " + url);
		debug("Going to call loadbrowser method.");
		loadBrowser(mode, url);
		debug("Exiting chargePayment");
	}

	/**
	 * Creates and loads a new Napi Browser with the specified URL.
	 * 
	 * @param mode
	 *            The payment mode either
	 *            AndroidWacPaymentService.CHARGE_PAYMENT or
	 *            AndroidWacPaymentService.RESERVE_PAYMENT
	 * @param url
	 *            The URL to be loaded.
	 * @throws JSONException
	 */
	private void loadBrowser(final Integer mode, String url) throws JSONException {
		debug("Entering loadBrowser with parameters args = " + ((url == null) ? "" : url) + ", mode = " + (mode == null ? "" : mode));
		debug("Creating a new Napi Browser.");
		NapiBrowser b = new NapiBrowser(ctx) {

			@Override
			public void onLocationChange(String url) {
				debug("onLocationChange called. Loading URL = " + url);
				showConnectingToWACDialog();
				if (url.startsWith(getProperty(Constants.PROP_REDIRECTURL))) {
					debug("Closing browser");
					this.close();
					mShowPage = true;
					debug("showPage = " + mShowPage);
					if (url.indexOf("oauth_token") != -1) {
						debug("URL contains oauth_token");
					}
				}

				debug("Calling WatchURL method.");
				PluginResult watchResult = watchURL(url, mode);
				if (NapiPhoneGapPluginHelper.getResultValue(watchResult, Constants.KEY) != null || NapiPhoneGapPluginHelper.getResultValue(watchResult, Constants.ERROR) != null) {
					debug("The result being set is " + watchResult.getMessage());
					mResult = watchResult;
					debug("Calling notifyForResults");
					notifyForResults();
					return;
				}
				String dummy = NapiPhoneGapPluginHelper.getResultValue(watchResult, Constants.DUMMY, false);
				if (PluginUtils.isEmpty(dummy, false)) {
					debug("showPage = " + mShowPage);
					if (mShowPage) {
						debug("setting showPage = false");
						mShowPage = false;
						try {
							String str = watchResult.getMessage().replace("\\", "").replace("\"", "");
							debug("Loading browser with Url: " + str);
							this.showWebPage(str, new JSONObject().put(Constants.SHOW_LOCATION_BAR, false));
						} catch (JSONException e) {
							error("Error creating the json object.", e);
						}
					}
				}
			}
		};
		b.showWebPage(url, new JSONObject().put(Constants.SHOW_LOCATION_BAR, false));
		debug("Waiting for results from the Napi Browser.");
		b.waitForResults();
		debug("Main thread continuing after notification by Napi Browser.");
		debug("Exiting loadBrowser");
	}

	/**
	 * The method watches Transaction list URLs for results.
	 * 
	 * @param url
	 *            The URL to be loaded.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult watchTrnxListURL(String url) {
		debug("Entering watchTrnxListURL with parameter URL = " + url);
		PluginResult result = null;
		if (url.startsWith(getProperty(Constants.PROP_REDIRECTURL))) {
			if (!NapiPhoneGapPluginHelper.isUrlProcessed(mProcessedUrls, url)) {
				debug("Processing URL " + url);
				NapiPhoneGapPluginHelper.addToProcessedUrls(mProcessedUrls, url);
				debug("paymentMethod found is " + mPaymentMethod);
				if ("oauth20rev13".equalsIgnoreCase(mPaymentMethod)) {
					debug("Going to call processOAuth2ListTransactionsResult");
					result = processOAuth2ListTransactionsResult(url);
				} else if ("oauth10a".equalsIgnoreCase(mPaymentMethod)) {
					debug("Going to call processOAuth1ListTransactionsResult");
					result = processOAuth1ListTransactionsResult(url);
				}
			} else {
				debug("In watchTrnxListURL, url already processed, ignoring");
			}
		}
		if (result == null) {
			result = PluginUtils.getDummyResult();
			debug("Continuing processing URLs");
		}

		debug("Exiting watchTrnxListURL.");
		return result;
	}

	/**
	 * The method watches Transaction Details URLs for results.
	 * 
	 * @param url
	 *            The URL to be loaded.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult watchTrnxDetailsURL(String url) {
		debug("Entering watchTrnxDetailsURL with parameter URL = " + url);
		PluginResult result = null;
		if (url.startsWith(getProperty(Constants.PROP_REDIRECTURL))) {
			if (!NapiPhoneGapPluginHelper.isUrlProcessed(mProcessedUrls, url)) {
				debug("Processing URL " + url);
				NapiPhoneGapPluginHelper.addToProcessedUrls(mProcessedUrls, url);
				debug("paymentMethod found is " + mPaymentMethod);
				if ("oauth20rev13".equalsIgnoreCase(mPaymentMethod)) {
					debug("Going to call processOAuth2CheckTransactionsResult");
					result = processOAuth2CheckTransactionsResult(url);
				} else if ("oauth10a".equalsIgnoreCase(mPaymentMethod)) {
					debug("Going to call processOAuth1CheckTransactionsResult");
					result = processOAuth1CheckTransactionsResult(url);
				}
			} else {
				debug("In watchTrnxDetailsURL, url already processed, ignoring");
			}
		}
		if (result == null) {
			result = PluginUtils.getDummyResult();
			debug("Continuing processing URLs");
		}
		debug("Exiting watchTrnxDetailsURL");
		return result;
	}

	/**
	 * Gets the result of OAuth 1 processing for check transaction.
	 * 
	 * @param url
	 *            The URL to be processed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult processOAuth1CheckTransactionsResult(String url) {
		debug("Entering processOAuth1CheckTransactionsResult with URL = " + url);
		Map<String, List<String>> params;
		String verifier = null;
		PluginResult result = null;
		OSPair op = null;
		boolean hasError = false;
		JSONObject jobj = new JSONObject();
		try {
			params = Util.getUrlParameters(url, "\\?");
			verifier = params.get("oauth_verifier").get(0);
			debug("Verifier found is " + verifier);
		} catch (UnsupportedEncodingException e) {
			error("Error getting the verifier from the URL ", e);
		}

		HashMap<String, String> accessResultMap = WacRestApi.getOAuth1AccessToken(verifier, mRequestToken, mService.getOperator(), mService.getCredential(), mService.getSecret(), mOauthSecret);

		debug("The result of WacRestApi.getOAuth1AccessToken call is " + accessResultMap);
		debug("The oauth_token found is " + accessResultMap.get("oauth_token"));

		try {
			debug("refCode being passed to WacRestApi.doAOauth1CheckTransaction is " + mRefCode);
			op = WacRestApi.doAOauth1CheckTransaction(accessResultMap.get("oauth_token"), verifier, accessResultMap.get("oauth_token_secret"), mService.getSecret(), mService.getCredential(), mService.getOperator(), mRefCode);
			jobj.put(Constants.KEY, "transactionDetails");
			jobj.put(Constants.VALUE, new JSONObject(op.s));
			debug("The transaction details returned by WacRestApi.doAOauth1CheckTransaction call is " + op.s);
		} catch (Exception e) {
			error(e.getMessage(), e);
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error creating the JSON object : ";
				error(message + e1.getMessage(), e1);
			}
			hasError = true;
		}
		result = hasError ? new PluginResult(Status.ERROR, jobj) : new PluginResult(Status.OK, jobj);
		debug("Exiting processOAuth1CheckTransactionsResult with result = " + result.getMessage());
		return result;
	}

	/**
	 * Gets the result of OAuth 2 processing for check transaction.
	 * 
	 * @param url
	 *            The URL to be processed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult processOAuth2CheckTransactionsResult(String url) {
		debug("Entering processOAuth2CheckTransactionsResult with url " + url);

		PluginResult result = null;
		OSPair op = null;
		boolean hasError = false;
		JSONObject jobj = new JSONObject();
		try {
			debug("Selected Item's id is " + mSelectedItem.getItemId());
			String accessToken = NapiPhoneGapPluginHelper.getAccessToken(url, mSelectedItem.getItemId())[0];
			debug("refCode being passed to WacRestApi.doAOauth2CheckTransaction is " + mRefCode);
			debug("Access token found is " + accessToken);
			op = WacRestApi.doAOauth2CheckTransaction(accessToken, mService.getOperator(), mRefCode);
			jobj.put(Constants.KEY, "transactionDetails");
			jobj.put(Constants.VALUE, new JSONObject(op.s));
			debug("Transaction details returned by WacRestApi.doAOauth2CheckTransaction call is " + op.s);
		} catch (NapiException e) {
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error in creating the JSON object : ";
				error(message + e1.getMessage(), e1);
			}
			hasError = false;
		} catch (Exception e) {
			error(e.getMessage(), e);
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error in creating the JSON object : ";
				error(message + e1.getMessage(), e1);
			}
			hasError = true;
		}
		result = hasError ? new PluginResult(Status.ERROR, jobj) : new PluginResult(Status.OK, jobj);
		debug("Exiting processOAuth2CheckTransactionsResult with result = " + result.getMessage());
		return result;
	}

	/**
	 * Gets the result of OAuth 1 processing for list transaction.
	 * 
	 * @param url
	 *            The URL to be processed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult processOAuth1ListTransactionsResult(String url) {
		debug("Entering processOAuth1ListTransactionsResult with URL = " + url);
		Map<String, List<String>> params;
		String verifier = null;
		PluginResult result = null;
		OSPair op = null;
		boolean hasError = false;
		JSONObject jobj = new JSONObject();
		try {
			params = Util.getUrlParameters(url, "\\?");
			verifier = params.get("oauth_verifier").get(0);
			debug("Verifier found is " + verifier);
		} catch (UnsupportedEncodingException e) {
			error("Error getting the verifier from the URL ", e);
		}

		HashMap<String, String> accessResultMap = WacRestApi.getOAuth1AccessToken(verifier, mRequestToken, mService.getOperator(), mService.getCredential(), mService.getSecret(), mOauthSecret);
		debug("The result of WacRestApi.getOAuth1AccessToken call is " + accessResultMap);
		debug("The oauth_token found is " + accessResultMap.get("oauth_token"));

		try {
			op = WacRestApi.doAOauth1ListTransactions(accessResultMap.get("oauth_token"), verifier, accessResultMap.get("oauth_token_secret"), mService.getSecret(), mService.getCredential(), mService.getOperator());
			jobj.put(Constants.KEY, Constants.TRANSACTION_LIST);
			jobj.put(Constants.VALUE, new JSONObject(op.s));
			debug("The transaction details returned by WacRestApi.doAOauth1ListTransactions call is " + op.s);
		} catch (Exception e) {
			error(e.getMessage(), e);
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error in creating the JSON object : ";
				error(message + e1.getMessage(), e1);
			}
			hasError = true;
		}
		result = hasError ? new PluginResult(Status.ERROR, jobj) : new PluginResult(Status.OK, jobj);
		debug("Exiting processOAuth1ListTransactionsResult with result = " + result.getMessage());
		return result;
	}

	/**
	 * Gets the result of OAuth 2 processing for check transaction.
	 * 
	 * @param url
	 *            The URL to be processed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult processOAuth2ListTransactionsResult(String url) {
		debug("processOAuth2ListTransactionsResult with url " + url);
		PluginResult result = null;
		OSPair op = null;
		boolean hasError = false;
		JSONObject jobj = new JSONObject();
		try {
			debug("Selected Item's id is " + mSelectedItem.getItemId());
			String accessToken = NapiPhoneGapPluginHelper.getAccessToken(url, mSelectedItem.getItemId())[0];
			debug("Access token found is " + accessToken);
			op = WacRestApi.doAOauth2ListTransactions(accessToken, mService.getOperator());
			jobj.put(Constants.KEY, Constants.TRANSACTION_LIST);
			jobj.put(Constants.VALUE, new JSONObject(op.s));
			debug("Transaction details returned by WacRestApi.doAOauth2ListTransactions call is " + op.s);
		} catch (NapiException e) {
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error in creating the JSON object : ";
				error(message + e1.getMessage(), e1);
			}
			hasError = false;
		} catch (Exception e) {
			error(e.getMessage(), e);
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error in creating the JSON object.";
				error(message + e1.getMessage(), e1);
			}
			hasError = true;
		}
		result = hasError ? new PluginResult(Status.ERROR, jobj) : new PluginResult(Status.OK, jobj);
		debug("Exiting processOAuth2ListTransactionsResult with result = " + result.getMessage());
		return result;
	}

	/**
	 * Gets the transaction list values. If it is 0.2 then it will get the list
	 * from the local storage else it will get the URL to be hit on the gateway
	 * to retrieve the transaction list.
	 * 
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult getTransactionListResult() {
		debug("Entering getTransactionListResult");
		JSONObject jobj = new JSONObject();
		PluginResult result = null;
		boolean hasError = false;
		debug("mService.getAPIVersion() is " + mService.getAPIVersion());
		try {
			if (mService.getAPIVersion() == AndroidWacPaymentService.APIDOT2) {
				debug("Getting the transaction list from local storage.");
				DeviceTransactionStorage pdb = getTransactionStorage();
				if (pdb == null)
					debug("DeviceTransactionStorage object found null.");
				try {
					TransactionList list = pdb.getTransactionList();
					if (list != null) {
						list.setFromLocalTransactionStorage(true);
						jobj.put(Constants.KEY, Constants.TRANSACTION_LIST);
						jobj.put(Constants.VALUE, PluginUtils.toJSONObject(list, TransactionList.class));
						debug("Retrieved locally stored Tx : " + jobj.toString());
					} else {
						debug("No transactions found");
						jobj.put(Constants.KEY, Constants.ERROR);
						jobj.put(Constants.VALUE, "No transactions found!!!");
					}
				} finally {
					if (pdb != null) {
						debug("Closing the local storage.");
						pdb.close();
					}

				}
			} else if (mService.getAPIVersion() == AndroidWacPaymentService.APIDOT1) {
				debug("Doing 0.1 processing for transaction list.");
				String operatorType = mService.getOperator().getApis().getAuthorization().getType();
				debug("Operator type is " + operatorType);
				if ("oauth10a".equalsIgnoreCase(operatorType)) {
					// oauth1 list payment business
					debug("List Payment - oAuth1");
					HashMap<String, String> resultMap = WacRestApi.getOAuth1RequestToken(mService.getOperator(), null, mService.getCredential(), mService.getSecret(), getProperty(Constants.PROP_REDIRECTURL), WacRestApi.GET_SCOPE);
					mRequestToken = resultMap.get("oauth_token");
					mOauthSecret = resultMap.get("oauth_token_secret");
					debug("The result of WacRestApi.getOAuth1RequestToken is " + resultMap);
					String urlStr = WacRestApi.formUrlStringForOAuth1(mRequestToken, mService.getOperator(), mService.getOperator().getApis().getAuthorization().getUris().getAuthorize());
					debug("Opening webview for url : " + urlStr);
					jobj.put(Constants.KEY, Constants.URL);
					jobj.put(Constants.VALUE, urlStr);
				} else if ("oauth20rev13".equalsIgnoreCase(operatorType)) {
					debug("List Payment - oAuth2");
					Map<String, String> parameters = new HashMap<String, String>();
					parameters.put("client_id", mService.getCredential());
					parameters.put("redirect_uri", Util.oEncode(getProperty(Constants.PROP_REDIRECTURL)));
					parameters.put("response_type", mService.getTokenMode());
					parameters.put("scope", oEncode(WacRestApi.GET_SCOPE));
					parameters.put("x-mcc", mService.getOperator().getMcc());
					parameters.put("x-mnc", mService.getOperator().getMnc());
					debug("Parameters being passed to NapiHttpHelper.formUrlString is " + parameters);
					String urlStr = NapiHttpHelper.formUrlString(mService.getOperator().getApis().getAuthorization().getUris().getAuthorize(), parameters);
					debug("Opening webview for url : " + urlStr);
					jobj.put(Constants.KEY, Constants.URL);
					jobj.put(Constants.VALUE, urlStr);
				}
			}
		} catch (Exception e) {
			error(e.getMessage(), e);
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error in creating the JSON object.";
				error(message + e1.getMessage(), e1);
			}
			hasError = true;
		}
		result = hasError ? new PluginResult(Status.ERROR, jobj) : new PluginResult(Status.OK, jobj);
		debug("Exiting getTransactionListResult with result = " + result.getMessage());
		return result;

	}

	/**
	 * Gets the transaction details. If it is 0.2 then it will get the
	 * transaction details from the local storage else it will get the URL to be
	 * hit on the gateway to retrieve the transaction details.
	 * 
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult getCheckTransactionResult(String refCode, String itemId) {
		debug("Entering getCheckTransactionResult with refCode = " + (refCode == null ? "" : refCode) + ", itemId = " + (itemId == null ? "" : itemId));
		JSONObject jobj = new JSONObject();
		Item item = new Item();

		if (!PluginUtils.isEmpty(itemId))
			item.setItemId(itemId);
		boolean hasError = false;
		PluginResult result = null;
		this.mRefCode = refCode;
		try {
			if (mService.getAPIVersion() == AndroidWacPaymentService.APIDOT2) {
				debug("Check Transaction - Local - with RefCode : " + refCode);
				DeviceTransactionStorage pdb = getTransactionStorage();
				try {
					SKSV sksv = pdb.getTransaction(refCode);
					if (sksv != null) {
						debug("Retrieved locally stored Tx : " + sksv.value);
						jobj.put(Constants.KEY, sksv.key);
						jobj.put(Constants.VALUE, new JSONObject(sksv.value));

					} else {
						debug("Invalid transaction Id.");
						jobj.put(Constants.KEY, Constants.ERROR);
						jobj.put(Constants.VALUE, "No matching transactions!!!");
					}
				} finally {
					if (pdb != null) {
						debug("Closing the local storage.");
						pdb.close();
					}
				}
			} else if (mService.getAPIVersion() == AndroidWacPaymentService.APIDOT1) {
				debug("Doing 0.1 processing for transaction check.");
				String operatorType = mService.getOperator().getApis().getAuthorization().getType();
				debug("The operator type found is " + operatorType);
				if ("oauth10a".equalsIgnoreCase(operatorType)) {
					debug("Check Payment - oAuth1");
					debug("The item id is " + item.getItemId());
					HashMap<String, String> resultMap = WacRestApi.getOAuth1RequestToken(mService.getOperator(), item, mService.getCredential(), mService.getSecret(), getProperty(Constants.PROP_REDIRECTURL), WacRestApi.GET_SCOPE);
					mRequestToken = resultMap.get("oauth_token");
					mOauthSecret = resultMap.get("oauth_token_secret");
					debug("The result of WacRestApi.getOAuth1RequestToken is " + resultMap);
					String urlStr = WacRestApi.formUrlStringForOAuth1(mRequestToken, mService.getOperator(), mService.getOperator().getApis().getAuthorization().getUris().getAuthorize());
					debug("Opening webview for url : " + urlStr);
					jobj.put(Constants.KEY, Constants.URL);
					jobj.put(Constants.VALUE, urlStr);
				} else if ("oauth20rev13".equalsIgnoreCase(operatorType)) {
					debug("Check Payment - oAuth2");
					Map<String, String> parameters = new HashMap<String, String>();
					parameters.put("client_id", mService.getCredential());
					parameters.put("redirect_uri", Util.oEncode(getProperty(Constants.PROP_REDIRECTURL)));
					parameters.put("response_type", mService.getTokenMode());
					parameters.put("scope", oEncode(WacRestApi.GET_SCOPE));
					parameters.put("x-mcc", mService.getOperator().getMcc());
					parameters.put("x-mnc", mService.getOperator().getMnc());
					String urlStr = NapiHttpHelper.formUrlString(mService.getOperator().getApis().getAuthorization().getUris().getAuthorize(), parameters);
					debug("Url is : " + urlStr);
					jobj.put(Constants.KEY, Constants.URL);
					jobj.put(Constants.VALUE, urlStr);
				}
			}
		} catch (JSONException e) {
			error(e.getMessage(), e);
			try {
				jobj.put(Constants.KEY, Constants.ERROR);
				jobj.put(Constants.VALUE, e.getMessage());
			} catch (JSONException e1) {
				String message = "Error in creating the JSON object : ";
				error(message + e1.getMessage(), e1);
			}
			hasError = true;
		}
		result = hasError ? new PluginResult(Status.ERROR, jobj) : new PluginResult(Status.OK, jobj);
		debug("Exiting getCheckTransactionResult with result = " + result.getMessage());
		return result;
	}

	/**
	 * The method is used to watch the URL for tokens to know which type of
	 * payment to do. If unrecognized operator is found then it will switch over
	 * to 0.1 flow else it will do the 0.2 payment.
	 * 
	 * @param url
	 *            The URL to watch.
	 * @param mode
	 *            The Payment Mode - either
	 *            AndroidWacPaymentService.CHARGE_PAYMENT or
	 *            AndroidWacPaymentService.RESERVE_PAYMENT
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult watchURL(String url, final Integer mode) {
		debug("Entering watchURL method with URL = " + (url == null ? "" : url) + ", mode = " + (mode == null ? "" : mode));
		PluginResult result = new PluginResult(Status.OK);
		if (url.startsWith(getProperty(Constants.PROP_REDIRECTURL))) {
			debug("Redirect URL hit");
			mProcessedUrls.add(url);
		} else {
			debug("return without processing");
			return PluginUtils.getDummyResult();
		}

		debug("Continue!");

		Map<String, List<String>> parameters = null;
		try {
			if (url.contains("error=") || url.contains("oauth_verifier=")) {
				debug("oauth_verifier found!");
				parameters = Util.getUrlParameters(url, "\\?");
			} else {
				debug("vague stuff found!");
				parameters = Util.getUrlParameters(url, "#");
			}
		} catch (UnsupportedEncodingException e2) {
			error("Error reading the parameters from the URL : " + e2.getMessage(), e2);
		}

		boolean hasAccessToken = false;
		boolean hasError = false;
		boolean hasVerifier = false;
		String accessToken = null;
		String verifier = null;

		String serverReferenceCode = null;
		debug("The parameter map from the URL = " + parameters);
		for (Iterator<Map.Entry<String, List<String>>> iterator = parameters.entrySet().iterator(); iterator.hasNext();) {
			Map.Entry<String, List<String>> nameValuePair = iterator.next();
			String key = nameValuePair.getKey();
			if ("access_token".equalsIgnoreCase(key)) {
				hasAccessToken = true;
				accessToken = nameValuePair.getValue().get(0);
			}
			if ("oauth_verifier".equalsIgnoreCase(key)) {
				hasVerifier = true;
				verifier = nameValuePair.getValue().get(0);
				debug("verifier = " + verifier);
			}
			if (Constants.ERROR.equalsIgnoreCase(key)) {
				hasError = true;
			}
			if ("server_reference_code".equalsIgnoreCase(key)) {
				serverReferenceCode = nameValuePair.getValue().get(0);
			}
		}
		DeviceTransactionStorage pdb = null;

		if (hasAccessToken) {
			debug("URL has access token.");
			try {
				String id = mSelectedItem.getItemId();
				debug("Selected Item is " + id);
				Item item = null;
				for (Iterator<Item> iterator = this.mItemList.iterator(); iterator.hasNext();) {
					item = iterator.next();
					if (item.getItemId().equalsIgnoreCase(id)) {
						mSelectedItem = item;
						break;
					}
				}
				this.mItemList = null;

				String refCode = UUID.randomUUID().toString().substring(0, 32);
				debug("refCode is " + refCode);

				int apiVersion = WacNapiContext.getInstance().getPaymentService().getAPIVersion();
				String paymentUri = (apiVersion == WacPaymentService.APIDOT2) ? WacNapiContext.getInstance().getEndPoints().getChargePaymentPath() : mService.getOperator().getApis().getPayment().getUri();
				debug("Payment URI is " + paymentUri);
				debug("mode is " + mode);
				if (mode == AndroidWacPaymentService.RESERVE_PAYMENT) {
					debug("Only doing the reservation of the payment.");
					ReservedTransaction reserve = new ReservedTransaction();
					reserve.setOperationMode(mode);
					reserve.setAccessToken(accessToken);
					reserve.setRefCode(refCode);
					reserve.setServerReferenceCode(serverReferenceCode);
					reserve.setItemId(item.getItemId());
					reserve.setItemPrice(item.getPrice());
					reserve.setItemCurrency(item.getCurrency());
					reserve.setItemDesc(item.getDescription());
					reserve.setOperatorMcc(null);
					reserve.setOperatorMnc(null);
					reserve.setPaymentUri(paymentUri);
					reserve.setApiVersion(apiVersion);
					reserve.setPaymentMethod(mPaymentMethod);
					reserve.setAppId(getProperty(Constants.PROP_APPID));
					JSONObject jobj = new JSONObject();
					jobj.put(Constants.KEY, Constants.RESERVED_TRANSACTION);
					jobj.put(Constants.VALUE, PluginUtils.toJSONObject(reserve, ReservedTransaction.class));

					// Add the result to the PluginResult object.
					result = new PluginResult(Status.OK, jobj);
					debug("Result being set to " + result.getMessage());
				} else {
					debug("Doing the actual payment.");
					String mcc1 = null;
					String mnc1 = null;
					if (mService.getOperator() != null) {
						mcc1 = mService.getOperator().getMcc();
						mnc1 = mService.getOperator().getMnc();
					}
					result = doOAuth2CapturePayment(accessToken, serverReferenceCode, item, refCode, apiVersion, paymentUri, mcc1, mnc1);
					debug("Result being set to " + result.getMessage());
				}
				// Add the result to the PluginResult object.
				// result = new PluginResult(Status.OK, jobj);
			} catch (JSONException e) {
				error("Got JSONException in " + PluginMethod.chargePayment + " : " + e.getMessage(), e);
				result = new PluginResult(Status.ERROR, e.getMessage());
			} finally {
				if (pdb != null) {
					debug("Closing the local storage.");
					pdb.close();
				}
			}
		} else if (hasError) {
			debug("The URL has error token.");
			String error = (parameters.get(Constants.ERROR) != null && parameters.get(Constants.ERROR).size() > 0) ? parameters.get(Constants.ERROR).get(0) : "";
			String errorDescription = (parameters.get("error_description") != null && parameters.get("error_description").size() > 0) ? parameters.get("error_description").get(0) : error;
			debug("break in auth flow for url " + url);
			debug("error = " + error);
			debug("description = " + errorDescription);
			// Check if error is Unrecognized operator and mnc and mcc are
			// available.
			//
			if (("unrecognized_operator".equalsIgnoreCase(error) && "0.1 operator network".equalsIgnoreCase(errorDescription))) {
				String mcc = (parameters.get("x-mcc") != null && parameters.get("x-mcc").size() > 0) ? parameters.get("x-mcc").get(0) : null;
				String mnc = (parameters.get("x-mnc") != null && parameters.get("x-mnc").size() > 0) ? parameters.get("x-mnc").get(0) : null;
				if (mcc == null || mnc == null) {
				}
				// mcc = mnc = "001";
				debug("Identified mcc + mnc = " + mcc + " : " + mnc);
				Operator o = new Operator();
				o.setMcc(mcc);
				o.setMnc(mnc);
				Application app = new Application();
				app.setApplicationIdentifier(getProperty(Constants.PROP_APPID));

				try {
					// TODO since the php app is configured in pro1, manually we
					// are pointing to pro1 gateway.
					OSPair op = WacRestApi.doDiscoveryForOperator(app, o);
					mService.setOperator((Operator) op.o);
					// mOuth2mode = mService.getTokenMode();
					mPaymentMethod = mService.getOperator().getApis().getAuthorization().getType();
					debug("Payment algorithm now set to " + mPaymentMethod);
				} catch (NapiException e) {
					error("Error occurred while doing the discovery for operator " + e.getMessage(), e);
				}
				mService.setAPIVersion(WacPaymentService.APIDOT1);
				debug("Setting the API version to 0.1");
				debug("Item id for payment id " + mSelectedItem.getItemId());
				if ("oauth20rev13".equals(mPaymentMethod)) {
					debug("Doing the Oauth 2 payment.");
					return doPaymentOauth2(mSelectedItem.getItemId());
				} else {
					debug("Doing the Oauth 1 payment.");
					return doPaymentOauth1(mSelectedItem.getItemId());
				}
			} else {
				debug("An error other than unrecognized_operator occurred.");
				try {
					JSONObject jobj = new JSONObject();
					String errorDescriptionStr = getLocalizedMessage(error, errorDescription);
					debug("ErrorDescription's Localized value is " + errorDescriptionStr);
					jobj.put(Constants.ERROR, error);
					jobj.put("errorDescription", errorDescriptionStr);
					result = new PluginResult(Status.OK, jobj);
				} catch (JSONException e) {
					error("Error creating the JSON object for error condition " + e.getMessage(), e);
				}
			}
		} else if (hasVerifier) {
			debug("The URL has a verifier.");
			debug("The verifier found is " + verifier);
			HashMap<String, String> accessResultMap = WacRestApi.getOAuth1AccessToken(verifier, mRequestToken, mService.getOperator(), mService.getCredential(), mService.getSecret(), mOauthSecret);
			debug("The result of the WacRestApi.getOAuth1AccessToken call is " + accessResultMap);
			String id = mSelectedItem.getItemId();
			Item item = null;
			for (Iterator<Item> iterator = this.mItemList.iterator(); iterator.hasNext();) {
				item = iterator.next();
				if (item.getItemId().equalsIgnoreCase(id)) {
					mSelectedItem = item;
					break;
				}
			}

			debug("Selected Item is " + mSelectedItem.getItemId());
			double itemPrice = mSelectedItem.getPrice();
			String itemDesc = mSelectedItem.getDescription();
			String itemCurrency = mSelectedItem.getCurrency();
			String mcc = mService.getOperator().getMcc();
			String mnc = mService.getOperator().getMnc();
			String accessTokenStr = accessResultMap.get("oauth_token");
			String oAuthsecret = accessResultMap.get("oauth_token_secret");
			String serviceSecret = mService.getSecret();
			String serviceCredential = mService.getCredential();
			String paymentUri = mService.getOperator().getApis().getPayment().getUri();
			String refCode = UUID.randomUUID().toString().substring(0, 32);
			debug("RefCode is " + refCode);
			debug("Mode is " + mode);
			if (mode == AndroidWacPaymentService.RESERVE_PAYMENT) {
				debug("Only doing the reservation of the payment.");
				ReservedTransaction reserve = new ReservedTransaction();
				reserve.setVerifier(verifier);
				reserve.setItemPrice(itemPrice);
				reserve.setItemDesc(itemDesc);
				reserve.setItemCurrency(itemCurrency);
				reserve.setOperatorMcc(mcc);
				reserve.setOperatorMnc(mnc);
				reserve.setAccessToken(accessTokenStr);
				reserve.setOAuthSecret(oAuthsecret);
				reserve.setServiceSecret(serviceSecret);
				reserve.setServiceCredential(serviceCredential);
				reserve.setOperationMode(mode);
				reserve.setRefCode(refCode);
				reserve.setServerReferenceCode(serverReferenceCode);
				reserve.setPaymentUri(paymentUri);
				reserve.setPaymentMethod(mPaymentMethod);
				reserve.setAppId(getProperty(Constants.PROP_APPID));
				JSONObject jobj = new JSONObject();
				try {
					jobj.put(Constants.KEY, Constants.RESERVED_TRANSACTION);
					jobj.put(Constants.VALUE, PluginUtils.toJSONObject(reserve, ReservedTransaction.class));
				} catch (JSONException e) {
					error("Error converting ReservedTransaction object to JSON : " + e.getMessage(), e);
				}

				// Add the result to the PluginResult object.
				result = new PluginResult(Status.OK, jobj);
				debug("Result being set to " + result.getMessage());
			} else {
				debug("Doing the actual payment.");
				result = doOAuth1CapturePayment(verifier, itemPrice, itemDesc, itemCurrency, mcc, mnc, accessTokenStr, oAuthsecret, serviceSecret, serviceCredential, paymentUri, refCode);
				debug("Result being set to " + result.getMessage());
			}
		} else {
			result = PluginUtils.getDummyResult();
			debug("Continuing processing URLs");
		}
		debug("Exiting watchURL with result " + result.getMessage());
		return result;
	}

	/**
	 * Gets the localized messages for the server errors being returned.
	 * 
	 * @param errorCode
	 *            The error Code.
	 * @param errorDecription
	 *            The decsription of the error.
	 * @return localized messages for the server errors.
	 */
	private static String getLocalizedMessage(String errorCode, String errorDecription) {
		if ("access_denied".equalsIgnoreCase(errorCode)) {
			return getMessage(Constants.TRANSACTION_CANCELLED);
		}
		return getMessageTranslationForMessage(errorDecription);
	}

	/**
	 * Does the capture payment for OAuth1 payment.
	 * 
	 * @param verifier
	 * @param itemPrice
	 * @param itemDesc
	 * @param itemCurrency
	 * @param mcc
	 * @param mnc
	 * @param accessTokenStr
	 * @param oAuthsecret
	 * @param serviceSecret
	 * @param serviceCredential
	 * @param paymentUri
	 * @param refCode
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult doOAuth1CapturePayment(String verifier, double itemPrice, String itemDesc, String itemCurrency, String mcc, String mnc, String accessTokenStr, String oAuthsecret, String serviceSecret, String serviceCredential, String paymentUri, String refCode) {
		debug("Entering doOAuth1CapturePayment");
		PluginResult results = null;
		OSPair op;
		try {
			op = WacRestApi.doAOauth1Payment(accessTokenStr, verifier, oAuthsecret, serviceSecret, serviceCredential, refCode, mSelectedItem.getItemId(), itemDesc, itemCurrency, itemPrice, mcc, mnc, paymentUri);
			Transaction trns = (Transaction) op.o;
			JSONObject jobj = new JSONObject();
			jobj.put(Constants.KEY, Constants.TRANSACTION_DETAILS);
			jobj.put(Constants.VALUE, PluginUtils.toJSONObject(trns, Transaction.class));
			// Add the result to the PluginResult object.
			results = new PluginResult(Status.OK, jobj);
		} catch (Exception e) {
			error(e.getLocalizedMessage(), e);
			throw new RuntimeException(e.getLocalizedMessage());
		}

		debug("Exiting doOAuth1CapturePayment with Result " + results.getMessage());
		return results;
	}

	/**
	 * Does the capture payment for OAuth2 payment.
	 * 
	 * @param accessToken
	 * @param serverReferenceCode
	 * @param item
	 * @param refCode
	 * @param apiVersion
	 * @param paymentUri
	 * @param mcc
	 * @param mnc
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult doOAuth2CapturePayment(String accessToken, String serverReferenceCode, Item item, String refCode, int apiVersion, String paymentUri, String mcc, String mnc) {
		debug("Entering doOAuth2CapturePayment");
		PluginResult result = null;
		// Do the payment.
		try {
			final OSPair os = WacRestApi.doAOauth2Payment(accessToken, refCode, serverReferenceCode, item.getItemId(), item.getDescription(), item.getCurrency(), item.getPrice(), mcc, mnc, paymentUri, apiVersion);
			Transaction trns = (Transaction) os.o;
			final String servRef = trns.getAmountTransaction().getServerReferenceCode();
			final String s = os.s;
			final DeviceTransactionStorage pdb = getTransactionStorage();

			Runnable runnable = new Runnable() {
				@Override
				public void run() {
					try {
						pdb.insert(servRef, s);
					} catch (Exception e) {
						error(e.getLocalizedMessage(), e);
						throw new RuntimeException(e.getLocalizedMessage());
					} finally {
						if (pdb != null) {
							debug("closing the local storage.");
							pdb.close();
						}
					}
				}
			};
			this.ctx.runOnUiThread(runnable);
			// pdb.getTransactionList();

			JSONObject jobj = new JSONObject();
			jobj.put(Constants.KEY, Constants.TRANSACTION_DETAILS);
			jobj.put(Constants.VALUE, PluginUtils.toJSONObject(trns, Transaction.class));

			// Add the result to the PluginResult object.
			result = new PluginResult(Status.OK, jobj);
		} catch (Exception e) {
			error(e.getLocalizedMessage(), e);
			throw new RuntimeException(e.getLocalizedMessage());
		}
		debug("Exiting doOAuth2CapturePayment with Result " + result.getMessage());
		return result;
	}

	/**
	 * Returns the URL to do OAuth1 payment.
	 * 
	 * @param itemId
	 *            The item Id for Item being purchased.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult doPaymentOauth1(String itemId) {
		debug("Entering doPaymentOauth1 with item Id = " + itemId);
		HashMap<String, String> resultMap = WacRestApi.getOAuth1RequestToken(mService.getOperator(), mService.getProductItem(itemId), mService.getCredential(), mService.getSecret(), getProperty(Constants.PROP_REDIRECTURL), WacRestApi.POST_SCOPE);
		mRequestToken = resultMap.get("oauth_token");
		mOauthSecret = resultMap.get("oauth_token_secret");
		debug("The result of WacRestApi.getOAuth1RequestToken found is " + resultMap);
		String urlStr = WacRestApi.formUrlStringForOAuth1(mRequestToken, mService.getOperator(), mService.getOperator().getApis().getAuthorization().getUris().getAuthorize());
		debug("Opening webview for url : " + urlStr);
		// load browser
		debug("Exiting doPaymentOauth1");
		return new PluginResult(Status.OK, urlStr);
	}

	/**
	 * Returns the URL to do OAuth2 payment.
	 * 
	 * @param itemId
	 *            The item Id for Item being purchased.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 */
	private PluginResult doPaymentOauth2(String itemId) {
		debug("Entering doPaymentOauth2 with item Id = " + itemId);
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("client_id", mService.getCredential());
		parameters.put("redirect_uri", Util.oEncode(getProperty(Constants.PROP_REDIRECTURL)));
		parameters.put("response_type", mService.getTokenMode());
		parameters.put("scope", oEncode(WacRestApi.POST_SCOPE + "?code=" + itemId));
		parameters.put("x-mcc", mService.getOperator().getMcc());
		parameters.put("x-mnc", mService.getOperator().getMnc());

		debug("The request parameters found is " + parameters);
		String urlStr = NapiHttpHelper.formUrlString(mService.getOperator().getApis().getAuthorization().getUris().getAuthorize(), parameters);
		debug("Opening webview for url : " + urlStr);
		debug("Exiting doPaymentOauth2");
		return new PluginResult(Status.OK, urlStr);
	}

	/**
	 * Gets the product list.
	 * 
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 * @throws JSONException
	 */
	private PluginResult productList() throws JSONException {
		debug("Entering productList");
		// by the operator selected.
		PluginResult result = null;
		try {
			OSPair queryOS = getProductList();

			Product product = (Product) queryOS.o;
			mService.setProduct(product);
			this.mItemList = product.getItems();
			// Prepare the result by using the item list.
			JSONObject itemList = new JSONObject();
			JSONArray array = new JSONArray();
			for (Iterator<Item> iterator = this.mItemList.iterator(); iterator.hasNext();) {
				JSONObject itemObj = new JSONObject();
				Item item = iterator.next();
				itemObj.put("itemDesc", item.getDescription());
				itemObj.put("itemId", item.getItemId());
				itemObj.put("price", item.getPrice());
				itemObj.put("currency", item.getCurrency());
				array.put(itemObj);
			}
			itemList.put("itemList", array);
			result = new PluginResult(Status.OK, itemList);
		} catch (NapiException e) {
			error("Got Napi Exception in " + PluginMethod.productList + " : " + e.getMessage(), e);
			result = new PluginResult(Status.ERROR, e.getMessage());
		}
		debug("Exiting productList with result " + result.getMessage());
		return result;
	}

	/**
	 * Gets the product list from the WAC rest API.
	 * @return
	 * @throws NapiException
	 */
	private OSPair getProductList() throws NapiException {
		// Prepare the application object.
		Application app = new Application();
		app.setApplicationIdentifier(getProperty(Constants.PROP_APPID));
		Credential cred = new Credential();
		cred.setKey(getProperty(Constants.PROP_CREDENTIAL));

		Developer dev = new Developer();
		dev.setUserName(getProperty(Constants.PROP_DEVNAME));
		OSPair queryOS = null;
		mService.setCredential(getProperty(Constants.PROP_CREDENTIAL));
		mService.setSecret(getProperty(Constants.PROP_SECRET));

		// Get the product list by doing a REST call for doQuery.
		queryOS = WacRestApi.doQuery(app, null, cred, dev, getProperty(Constants.PROP_SECRET));
		return queryOS;
	}

	/**
	 * Initializes the Napi service apis.
	 * 
	 * @param args
	 *            The javascript function arguments passed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 * @throws NapiException
	 * @throws JSONException
	 */
	private PluginResult initializeNapi(JSONArray args) throws NapiException, JSONException {
		debug("Entering initializeNapi with args = " + (args == null ? "" : args.toString()));
		// Read from the assets directory

		if (WacNapiContext.getInstance().getEndPoints() == null) {
			debug("Endpoints found null, setting to PRODUCTION.");
			WacNapiContext.getInstance().setEndPoints(new WacEndpoints(WacEndpoints.PRODUCTION));
		} else {
			debug("Endpoints already set. Not setting it.");
		}

		if (args != null && args.getJSONObject(0) != null) {
			JSONObject argsMap = args.getJSONObject(0);
			String appId = argsMap.getString("appId");
			String credential = argsMap.getString("credential");
			String secret = argsMap.getString("secret");
			String devname = argsMap.getString("devname");
			String redirectOAuthURI = argsMap.getString("redirectOAuthURI");
			if (PluginUtils.isEmpty(appId) || PluginUtils.isEmpty(credential) || PluginUtils.isEmpty(secret) || PluginUtils.isEmpty(devname) || PluginUtils.isEmpty(redirectOAuthURI)) {
				throw new NapiException("One of the arguments of initializeNapi method is null or empty as in " + argsMap.toString());
			} else {
				mProps = new Properties();
				mProps.put(Constants.PROP_APPID, appId);
				debug("App Id being set is " + appId);
				mProps.put(Constants.PROP_CREDENTIAL, credential);
				debug("Credential being set is " + credential);
				mProps.put(Constants.PROP_SECRET, secret);
				debug("Secret is being set");
				mProps.put(Constants.PROP_DEVNAME, devname);
				debug("Dev Name being set is " + devname);
				mProps.put(Constants.PROP_REDIRECTURL, redirectOAuthURI);
				debug("Redirect OAuth URI being set is " + redirectOAuthURI);
				mProcessedUrls = new HashSet<String>();
				// Initialize WAC NAPI API
				if (WacNapiContext.getInstance().getPaymentService() == null) {
					mService = new AndroidWacPaymentService();
					WacNapiContext.getInstance().setPaymentService(mService);
					debug("Setting the mService to Wac Napi Context.");
					debug("Setting localization helper.");
					localizationHelperInstance = new LocalizationHelper();
				} else {
					mService = WacNapiContext.getInstance().getPaymentService();
				}
			}
		} else {
			throw new NapiException("Arguments in initializeNapi method found null thus will not be able to initialize Napi.");
		}

		debug("Exiting initializeNapi");
		return new PluginResult(Status.OK);
	}

	/**
	 * Sets the spoofIP to the WacNapiContext.
	 * 
	 * @param arg
	 *            The javascript function arguments passed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 * @throws NapiException
	 */
	public PluginResult setSpoofIP(JSONArray arg) throws NapiException {
		String spoofIP;
		try {
			if (arg != null && !PluginUtils.isEmpty(arg.getString(0))) {
				spoofIP = arg.getString(0);
				WacEndpoints.setSpoofedDiscoverySourceIPForStaging(spoofIP);
				debug("Spoofing with IP " + spoofIP);
			} else {
				debug("Spoofing IP not being set.");
			}
		} catch (JSONException e) {
			String message = "Error reading spoofing IP from the arguments " + arg.toString();
			error(message, e);
			return new PluginResult(Status.ERROR, message);
		}
		return new PluginResult(Status.OK);
	}

	/**
	 * Sets the debug level to the WacNapiContext.
	 * 
	 * @param arg
	 *            The javascript function arguments passed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 * @throws NapiException
	 */
	public PluginResult setDebugEnabled(JSONArray arg) throws NapiException {
		try {
			if (arg != null && !PluginUtils.isEmpty(arg.getString(0)) && Boolean.valueOf(arg.getString(0)).booleanValue()) {
				AndroidWacPaymentService.setDebug(true);
				debug("Debug level set to true.");
			} else {
				AndroidWacPaymentService.setDebug(false);
				debug("Debug level set to false.");
			}
		} catch (JSONException e) {
			String message = "Error reading Debug level value from the arguments " + arg.toString();
			error(message, e);
			return new PluginResult(Status.ERROR, message);
		}
		return new PluginResult(Status.OK);
	}

	/**
	 * Sets the end point to the WacNapiContext.
	 * 
	 * @param arg
	 *            The javascript function arguments passed.
	 * @return The Plugin Result to be passed to the callback function of the
	 *         javascript caller function.
	 * @throws NapiException
	 */
	public PluginResult setEndPoint(JSONArray arg) throws NapiException {
		WacEndpoints wacEndpoints = null;
		try {
			if (arg != null && !PluginUtils.isEmpty(arg.getString(0)) && Constants.STAGING.equalsIgnoreCase(arg.getString(0))) {
				wacEndpoints = new WacEndpoints(WacEndpoints.STAGING);
				debug("WAC Endpoint is set to " + Constants.STAGING);
			} else {
				wacEndpoints = new WacEndpoints(WacEndpoints.PRODUCTION);
				debug("Setting WAC Endpoint to default value " + Constants.PRODUCTION);
			}

			WacNapiContext.getInstance().setEndPoints(wacEndpoints);
		} catch (JSONException e) {
			String message = "Error reading End Point value from the arguments " + arg.toString();
			error(message, e);
			return new PluginResult(Status.ERROR, message);
		}
		return new PluginResult(Status.OK);
	}

	/**
	 * Gets the property value from the values passed by the developer.
	 * 
	 * @param key
	 *            The key to search for.
	 * @return The value corresponding to the key passed.
	 */
	private static String getProperty(String key) {
		if (mProps != null) {
			return mProps.getProperty(key);
		}
		return null;
	}

	/**
	 * Logs at debug level.
	 * 
	 * @param message
	 *            The message to be logged.
	 */
	private static void debug(String message) {
		NapiLog.d(TAG, message);
	}

	/**
	 * Logs at error level.
	 * 
	 * @param message
	 *            The message to be logged.
	 * @param t
	 *            The throwable instance to get the stack trace.
	 */
	private static void error(String message, Throwable t) {
		Log.e(TAG, message, t);
	}

	/**
	 * Gets the secured transaction storage handle.
	 * 
	 * @return the transaction storage
	 */
	private DeviceTransactionStorage getTransactionStorage() {
		debug("Calling getTransactionStorage with " + getProperty(Constants.PROP_APPID));
		return new SecureDeviceTransactionDatabase(ctx, getProperty(Constants.PROP_APPID));
	}

	/**
	 * The method show connecting to WAC Servers dialog on the first request to the server.
	 */
	private void showConnectingToWACDialog() {
		if(connectedFirstTime) {
			pd = ProgressDialog.show(ctx, getMessage("WORKING"), getMessage("CONNECT_SERVER"), true, false);
			debug("Connecting to WAC servers... dialog shown.");
		} else {
			if(pd != null){
				pd.dismiss();
				debug("Connecting to WAC servers... dialog dismissed.");
				pd = null;
			}
		}
		// change the value to false so that the next time the progress dialog is not shown.		
		connectedFirstTime = false;
	}

}
