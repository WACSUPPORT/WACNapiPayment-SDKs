/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android.phonegap;

/**
 * The enum for plugin methods available in the Napi Phonegap plugin.
 * 
 * @author vikas.kumar
 * 
 */

public enum PluginMethod {
	setSpoofIP, setDebugEnabled, setEndPoint, initializeNapi, checkBillingAvailability, productList, reservePayment, chargePayment, capturePayment, checkTransaction, transactionList;
}
