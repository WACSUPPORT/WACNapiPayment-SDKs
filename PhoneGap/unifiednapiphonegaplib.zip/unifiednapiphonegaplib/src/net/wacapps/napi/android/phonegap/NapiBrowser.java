/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android.phonegap;

import static net.wacapps.napi.util.LocalizationHelper.getMessage;

import java.io.IOException;
import java.io.InputStream;

import net.wacapps.napi.android.WacNapiPayment;
import net.wacapps.napi.api.Util;
import net.wacapps.napi.util.NapiLog;
import net.wacapps.napi.util.ProxySettings;

import org.apache.http.HttpHost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.RenderPriority;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

import com.phonegap.api.PhonegapActivity;

/**
 * NapiBrowser has the set of utilities required for handling browser for
 * controlling and displaying authorization web pages
 * 
 */
public abstract class NapiBrowser {

	private Dialog dialog;
	private WebView webview;
	private EditText edittext;
	private boolean showLocationBar = true;
	private PhonegapActivity ctx;
	private boolean resultObtained = false;
	private static final String TAG = Constants.TAG;
	private HttpHost httpProxyHost = null;
	private CookieManager cookieManager = null;
	final static DefaultHttpClient client = WacNapiPayment.getClient();

	/**
	 * The constructor of {@link NapiBrowser}.
	 * 
	 * @param context
	 *            The Phonegap activity context.
	 */
	public NapiBrowser(PhonegapActivity context) {
		NapiLog.d(TAG, "Creating new Napi Browser.");
		this.ctx = context;
		CookieSyncManager.createInstance(this.ctx);
		cookieManager = CookieManager.getInstance();
	}

	/**
	 * Go back in the browser history
	 */
	private void goBack() {
		if (this.webview.canGoBack()) {
			NapiLog.d(TAG, "Moving one page back.");
			this.webview.goBack();
		}
	}

	/**
	 * Checks to see if it is possible to go forward one page in history, then
	 * does so.
	 */
	private void goForward() {
		if (this.webview.canGoForward()) {
			NapiLog.d(TAG, "Moving one page forward.");
			this.webview.goForward();
		}
	}

	/**
	 * Closes the browser
	 */
	public void close() {
		if (dialog != null) {
			this.webview.stopLoading();
			NapiLog.d(TAG, "Closing the browser.");
			dialog.dismiss();
		}
	}

	/**
	 * Returns an object of NapiBrowserClient for handling the redirect URL's
	 * launched in NapiBrowser
	 */
	private NapiBrowserClient getNapiBrowserClient() {
		return new NapiBrowserClient(ctx, edittext, this);
	}

	/**
	 * The method checks whether the result has been obtained or not.
	 * 
	 * @return Whether the result has been obtained or not.
	 */
	private synchronized boolean isResultObtained() {
		return this.resultObtained;
	}

	/**
	 * Set that the result has been obtained or not.
	 * 
	 * @param resultObtained
	 *            True or false.
	 */
	private void setResultObtained(boolean resultObtained) {
		NapiLog.d(TAG, "Setting the resultObtained to " + resultObtained);
		this.resultObtained = resultObtained;
	}

	/**
	 * Notify to the originating thread that the results has been obtained.
	 */
	public synchronized void notifyForResults() {
		NapiLog.d(TAG, "Setting the resultObtained to true.");
		setResultObtained(true);
	}

	/**
	 * Puts the browser originating thread in wait state for getting the
	 * results.
	 */
	public void waitForResults() {
		NapiLog.d(TAG, "Entering waitForResults");
		while (!isResultObtained()) {
			// Polling for result... what to do?
		}
		NapiLog.d(TAG, "Setting the resultObtained to false.");
		resultObtained = false;
		NapiLog.d(TAG, "Exiting waitForResults");
	}

	/**
	 * Displays the web page content of the URL in NapiBrowser
	 * 
	 * @param url
	 *            the url to be displayed in the browser
	 * 
	 * @param options
	 *            options for controlling the browser display
	 * 
	 */
	public String showWebPage(final String url, JSONObject options) {
		NapiLog.d(TAG, "Entering showWebPage with URL = " + url + " and Options = " + (options == null ? "" : options.toString()));
		// Determine if we should hide the location bar.
		if (options != null) {
			showLocationBar = options.optBoolean("showLocationBar", true);
		}

		NapiLog.d(TAG, "Creating a new thread for running it as a new browser.");
		// Create dialog in new thread
		Runnable runnable = new Runnable() {
			public void run() {

				NapiLog.d(TAG, "Browser thread stated running.");
				dialog = new Dialog(ctx) {
					@Override
					public void onBackPressed() {
						NapiLog.d(TAG, "Back button pressed.");
						if (webview.canGoBack()) {
							NapiLog.d(TAG, "Moving one page back.");
							webview.goBack();
						} else {
							super.onBackPressed();
							NapiLog.d(TAG, "Calling onBackPressed for the Dialog class.");
						}
					}
				};
			
				dialog.requestWindowFeature(Window.FEATURE_PROGRESS);
				dialog.setCancelable(true);
				dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
					public void onDismiss(DialogInterface dialog) {
					}
				});

				LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
				LinearLayout.LayoutParams forwardParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
				LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, 1.0f);
				LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
				LinearLayout.LayoutParams wvParams = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT, 1);

				LinearLayout main = new LinearLayout(ctx);
				main.setOrientation(LinearLayout.VERTICAL);

				LinearLayout toolbar = new LinearLayout(ctx);
				toolbar.setOrientation(LinearLayout.HORIZONTAL);

				ImageButton back = new ImageButton(ctx);
				back.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						goBack();
					}
				});
				back.setId(1);
				try {
					back.setImageBitmap(loadDrawable("www/images/icon_arrow_left.png"));
				} catch (IOException e) {
					Log.e(TAG, e.getMessage(), e);
				}
				back.setLayoutParams(backParams);

				ImageButton forward = new ImageButton(ctx);
				forward.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						goForward();
					}
				});
				forward.setId(2);
				try {
					forward.setImageBitmap(loadDrawable("www/images/icon_arrow_right.png"));
				} catch (IOException e) {
					Log.e(TAG, e.getMessage(), e);
				}
				forward.setLayoutParams(forwardParams);

				edittext = new EditText(ctx);
				edittext.setOnKeyListener(new View.OnKeyListener() {
					public boolean onKey(View v, int keyCode, KeyEvent event) {
						// If the event is a key-down event on the "enter"
						// button
						if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
							// navigate(edittext.getText().toString());
							return true;
						}
						return false;
					}
				});
				edittext.setId(3);
				edittext.setSingleLine(true);
				edittext.setText(url);
				edittext.setLayoutParams(editParams);

				ImageButton close = new ImageButton(ctx);
				close.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						// closeDialog();
					}
				});
				close.setId(4);
				try {
					close.setImageBitmap(loadDrawable("www/images/icon_close.png"));
				} catch (IOException e) {
					Log.e(TAG, e.getMessage(), e);
				}
				close.setLayoutParams(closeParams);

				webview = new WebView(ctx);
				createProgressDialog();
				webview.getSettings().setJavaScriptEnabled(true);
				webview.getSettings().setDomStorageEnabled(true);
				webview.getSettings().setBuiltInZoomControls(true);
				webview.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
				webview.getSettings().setPluginsEnabled(false);
				webview.getSettings().setRenderPriority(RenderPriority.HIGH);
				webview.getSettings().setAppCacheEnabled(true);				
				WebViewClient client = getNapiBrowserClient();
				webview.setWebViewClient(client);

				showWebView(url);
				String urlStr = url;
				webview.loadUrl(urlStr);

				webview.setId(5);				
				webview.getSettings().setUseWideViewPort(true);				
				webview.setLayoutParams(wvParams);
				webview.setInitialScale(75);
				webview.requestFocus();
				webview.requestFocusFromTouch();

				toolbar.addView(back);
				toolbar.addView(forward);
				toolbar.addView(edittext);
				toolbar.addView(close);

				if (getShowLocationBar()) {
					main.addView(toolbar);
				}
				main.addView(webview);

				WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
				lp.copyFrom(dialog.getWindow().getAttributes());
				lp.width = WindowManager.LayoutParams.FILL_PARENT;
				lp.height = WindowManager.LayoutParams.FILL_PARENT;
				dialog.setContentView(main);
				dialog.show();
				dialog.getWindow().setAttributes(lp);
			}

			/**
			 * Creates a progress dialog on the top of the window.
			 */
			private void createProgressDialog() {
				
				webview.setWebChromeClient(new WebChromeClient() {
					public void onProgressChanged(WebView view, int progress) {
						dialog.getWindow().setFeatureInt(Window.FEATURE_PROGRESS, progress * 100);
						dialog.getWindow().setTitle(getMessage("LOADING"));
						
						if (progress == 100) {
							NapiLog.d(TAG, "Page load 100%");
							dialog.getWindow().setTitle("");
						}
					}
				});
			}

			private Bitmap loadDrawable(String filename) throws java.io.IOException {
				InputStream input = ctx.getAssets().open(filename);
				return BitmapFactory.decodeStream(input);
			}
		};
		NapiLog.d(TAG, "The thread going to be run on UI thread.");
		this.ctx.runOnUiThread(runnable);
		return "";
	}

	/**
	 * Show the web view by using apn proxy.
	 * 
	 * @param url
	 *            The URL to be show.
	 */
	private void showWebView(String url) {
		ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (Util.isConnected(cm)) {
			if (Util.isOnMobileData(cm)) {
				NapiLog.d(TAG, "On mobile data, trying find and set APN proxy");
				httpProxyHost = Util.setAPNProxy(ctx);
			} else {
				NapiLog.d(TAG, "Not using mobile data, not using APN proxies");
				try {
					ProxySettings.resetProxy(ctx);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			NapiLog.d(TAG, "No active mobile data or wifi connections, not processing payment request");
			return;
		}

		NapiLog.d(TAG, "Url is : " + url);
	}

	/**
	 * Whether {@code showLocationBar} is true or false.
	 * 
	 * @return
	 */
	private boolean getShowLocationBar() {
		NapiLog.d(TAG, "showLocationBar = " + showLocationBar);
		return this.showLocationBar;
	}

	/**
	 * The Class NapiBrowserClient, used to handle redirect urls launched in
	 * NapiBrowser
	 */
	public static class NapiBrowserClient extends WebViewClient {
		NapiBrowser browser;
		PhonegapActivity ctx;
		EditText edittext;

		/**
		 * Constructor.
		 * 
		 * @param mContext
		 * @param edittext
		 */
		public NapiBrowserClient(PhonegapActivity mContext, EditText mEditText, NapiBrowser browser) {
			NapiLog.d(TAG, "Creating a new NapiBrowser Client.");
			this.ctx = mContext;
			this.edittext = mEditText;
			this.browser = browser;
		}

		/**
		 * Notify the host application that a page has started loading.
		 * 
		 * @param view
		 *            The webview initiating the callback.
		 * @param url
		 *            The url of the page.
		 */
		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			super.onPageStarted(view, url, favicon);
			String newloc;
			if (url.startsWith("http:") || url.startsWith("https:")) {
				newloc = url;
			} else {
				newloc = "http://" + url;
			}

			if (!newloc.equals(edittext.getText().toString())) {
				edittext.setText(newloc);
			}
			NapiLog.d(TAG, "OnLocationChange going to be called.");
			browser.onLocationChange(url);
		}
		
		@Override
		public void onPageFinished(WebView view, String url){
			browser.onPageFinished(url);
			super.onPageFinished(view, url);
		}
		
	}

	/**
	 * Implement this method to track the URL being loaded in the Napi Browser.
	 * The method gets called when there is a location change in the Napi
	 * Browser.
	 * 
	 * @param url
	 */
	public abstract void onLocationChange(String url);
	
	/**
	 * Override this method to do something on Page Finish.
	 * @param url The URL which was requested.
	 */
	public void onPageFinished(String url){
		// do nothing.
	}
}
