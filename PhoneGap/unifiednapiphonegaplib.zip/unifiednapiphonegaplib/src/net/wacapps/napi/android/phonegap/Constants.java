/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android.phonegap;

/**
 * The constants used across the Napi Phone Gap Plugin
 * 
 * @author vikas.kumar
 * 
 */
public class Constants {
	public static final String URL = "URL";
	public static final String KEY = "key";
	public static final String TRANSACTION_LIST = "transactionList";
	public static final String TRANSACTION_DETAILS = "transactionDetails";
	public static final String RESERVED_TRANSACTION = "reservedTransaction";
	public static final String VALUE = "value";
	public static final String ERROR = "error";
	public static final String DUMMY = "dummy";
	public static final String SHOW_LOCATION_BAR = "showLocationBar";
	public static final String TRANSACTION_CANCELLED = "TRANSACTION_CANCELLED";
	/**
	 * The production mode is used to connect to the wac production payment
	 * gateway
	 */
	public static final String PRODUCTION = "PRODUCTION";
	/**
	 * The staging mode is used to connect to the wac staging/test payment
	 * gateway
	 */
	public static final String STAGING = "STAGING";
	public static final String OAUTH_URL_KEY = "OAuthURL";
	/**
	 * The application Id key
	 */
	public static final String PROP_APPID = "wac.appid";
	/**
	 * The credential key
	 */
	public static final String PROP_CREDENTIAL = "wac.credential";
	/**
	 * The secret key
	 */
	public static final String PROP_SECRET = "wac.secret";
	/**
	 * The developer name key
	 */
	public static final String PROP_DEVNAME = "wac.devname";
	/**
	 * The redirect URL key
	 */
	public static final String PROP_REDIRECTURL = "wac.redirectUriOAuth";
	/**
	 * The mode key in
	 */
	public static final String PROP_MODE = "wac.mode";
	/**
	 * The spoofing IP key
	 */
	public static final String PROP_SPOOFING = "wac.spoofing";
	/**
	 * The log tag is used for identifying the log messages in android log cat
	 */
	public static final String TAG = "Wac";
}
