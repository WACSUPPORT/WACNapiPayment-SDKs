*************************************
Phonegap Android SDK for WAC Payments
*************************************

About the Phonegap Android SDK for WAC REST API
***********************************************
The WAC's Phonegap Android Developer Kit (SDK) makes the process of integrating WAC's payment services into Phonegap Android applications easy.

This software is intended for use by Phonegap application developers.

******************************
Developer Portal Prerequisites
******************************
1. Register with WAC as a developer: http://www.wacapps.net/register
2. Create Applications: http://www.wacapps.net/napi-application
3. Manage Applications: http://www.wacapps.net/manage-payment-api

*********************************************
WAC API Integration with Android applications
*********************************************

Release Notes
*************
What's new NAPI SDK beta 1.0 ?

* Support for In band and out of band transactions.
* Improved End user identification flow for out of band transaction.
* Fast in band transactions
* Query prices based on country
* Support for reserve and capture model for payments, in additions to quick pay.
* SQLite based and encrypted Android data store for storing previous transactions.
* Support for APN proxies
* Basic authorization support
* User friendly error messages
* Localization support for all major markets and locales.

Whats new in NAPI SDK beta 1.0.1 ?

* New checkBillingAvailability() API has been added to check if Wac billing is available.
* Bug fixes related to callback functions

Required Software
*****************
Android PhoneGap - https://github.com/phonegap/phonegap-plugins/tree/master/Android
J2SE 1.6.x SDK - http://www.oracle.com/technetwork/java/javase/downloads/jdk-6u30-download-1377139.html
Apache Ant 1.8.2 - http://ant.apache.org/bindownload.cgi
Eclipse Classic (recommended) // As in Android spec - http://eclipse.org/downloads/
Android SDK - version >= 2.2 - http://developer.android.com/sdk/index.html
Android plugin for eclipse - http://developer.android.com/sdk/eclipse-adt.html#downloading

Downloading and updating
************************
http://www.wacapps.net/sdks

Import the application as an android application.  Run the application as Android application in eclipse.

Getting started guide
*********************
http://www.wacapps.net/getting-started

Known Issues
************

FAQs
****
http://www.wacapps.net/payment-api-faqs

Feed Back
*********
If you have feedback on this document, or any other developer related issues, please get in touch via support@wacapps.net

Integrating WAC in-application payments/billing API
***************************************************
Steps to integrate the WAC NapiPayment with android application.
1. Make your application a Phonegap Android application.
	- Follow the instructions at http://phonegap.com/start/#android to make your project an Android PhoneGap project. If your application is already a PhoneGap application, then skip this step.
1. Modify workspace to include the WAC Phonegap SDK files.
   -Copy assets/www/ files of WAC Phonegap SDK into your project's assets/www/ directory
   -Copy wacphonegap.jar and wac-1.0.1.jar to the projects "lib" folder
                 
2. Include wacphonegap.jar and wac-1.0.1.jar in libs folder in build path. To do this in Eclipse, follow the steps below.
	-Select project in package explorer and choose Refresh from the context menu.
	-The newly extracted library files and resource files will be visible within the package explorer.
	-Open Project Properties. Select "Java Build Path" and the "Libraries" tab.
	-Now click on "Add JARs" button. In the pop up, select the newly added JARs under the libs subfolder.
	-Click OK to apply changes.

3. Add required permissions to AndroidManifest.xml file.
   - Make sure your AndroidManifest.xml includes a superset of the permissions shown below.
   - The following permission needs to be added to the manifest element. The INTERNET permission is used by payment methods.
		<uses-permission android:name="android.permission.INTERNET" />
		
   - The following permissions if provided will allow the SDK to make intelligent choices.
		<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
		<uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />
		<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>

4. Registering Napi PhoneGap plugin.
	- Open your res/xml/plugins.xml file add the following line:
	<plugin name="NapiPhoneGapPlugin" value="net.wacapps.napi.android.phonegap.NapiPhoneGapPlugin"/>

5. Add two android Activities NapiPhoneGapApp and WacNapiPayment
	- Add the following activities in the application tag of your AndroidManifest.xml file
		<activity
            android:name=".NapiPhoneGapApp"
            android:configChanges="orientation|keyboardHidden"
            android:label="@string/app_name" >
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <activity
            android:name="net.wacapps.napi.android.WacNapiPayment"
            android:theme="@android:style/Theme.Translucent.NoTitleBar"
            android:configChanges="orientation|keyboardHidden"
            android:label="@string/app_name" >
            <intent-filter>
            </intent-filter>
        </activity> 

6. Adding wac.js in your application.
	- Include a reference to it in your index.html file (or whichever the page your application is loading first.) after phonegap-{version}.js as below.
		<script type="text/javascript" charset="utf-8" src="phonegap-{version}.js"></script>
		<script type="text/javascript" charset="utf-8" src="wac.js"></script>
	- Make sure the phonegap-{version}.js filename in index.html matches the filename in your www directory.

***********************************************
Phone Gap Plugin Interface Details
***********************************************
- Wac.js provides the interfaces to perform the following processes at the WAC Payment gateways.

Check WAC billing availability
******************************
	- Call NapiPayment.checkBillingAvailability(checkBillingAvailabilityCallback) to check if WAC billing is available.
		NapiPayment.checkBillingAvailability(checkBillingAvailabilityCallback);

	- The callback method after checking the availability of the server.
		var checkBillingAvailabilityCallback = function(r){
			hide('payment_option_loading');
			show('WAC_payment_option');
			if(!r.isBillingAvailable){
				document.getElementById('WAC_payment').onclick = null;
				show('billing_not_available');
			}
			
		}

Limitations of this method: At the point of calling this method WAC have not yet checked the individual user. 
In the case the user is out-of-band (e.g. WiFi), we have not yet identified the operator either because we want to avoid having to ask the user for their phone number when this method is called. This means that this method behaves as follows:
	� In-band flow, app not LIVE or not published to this operator: will return "false"
	� Out-of-band flow, app not LIVE or not published in the country of the access point IP address: will return "false"
	� Out-of-band flow, app published in the country of the access point IP address but not the operator of the user: will return "true"
	� Individual user can't use WAC even if other users of this operator can, e.g. user blacklisted, user doesn't have enough credit etc.: will return "false"
	� App is LIVE, published to this operator and individual user can use WAC: will return "true"

Initialize the payment service
******************************
	- Create a function onPageLoad in your applications js file.
		function onPageLoad() {
			document.addEventListener("deviceready", onDeviceReady,false);
		}

	- Add another function onDeviceReady in js file of your application.
		function onDeviceReady() { 
			// Initalize Napi  
			var appId = '<APP_ID>';
			var credential = '<CREDENTIAL>';
			var secret = '<SECRET>';
			var devname = '<USER_ID>';
			var redirectOAuthURI = '<REDIRECT_OAUTH_URI>';
			var endPoint = 'PRODUCTION';
			//var isDebugEnabled = true;
			//NapiPayment.setDebugEnabled(isDebugEnabled);
			NapiPayment.setEndPoint(endPoint);
			//NapiPayment.setSpoofIP(spoofIPStr);
			NapiPayment.initializeNapi(appId, credential, secret, devname, redirectOAuthURI, initializeNapiCallback);
		}
		
	- Call NapiPayment.setEndPoint() and NapiPayment.initializeNapi() api in onDeviceReady function to initialize Napi as shown above.
	- Replace the values with <XXX> with the values provided to you.
	- Call onPageLoad method on the page load of index.html page of your application as shown below. If required you can choose your own ways to call NapiPayment.initializeNapi, not necessarily on the page load.
	   <body onload="onPageLoad();">
				.
				.
				.
	   </body>
	- Create a function initializeNapiCallback if you want to capture the callback of NapiPayment.initializeNapi() call. Here r is a json object.
	var initializeNapiCallback = function(r){
		// Do your stuff here if required.
	}

Get the Product List
****************************************
	- Call NapiPayment.productList() to get the products available as shown below.
		
		NapiPayment.productList(productListCallback);
		
	- Capture the product list by creating a function named productListCallback as shown below.
		var productListCallback = function(r) {
			for (i = 0; i < r.itemList.length;i++) {		
				// Here we have the access to all the products found in the variable r.itemList[i] 			
				// The Item details you can get are r.itemList[i].itemId, r.itemList[i].itemDesc, r.itemList[i].price r.itemList[i].currency
			}
		}


****************************************
***********Payment Methods**************
****************************************
Making a payment.
	Reserve and capture (2 phase payment)
		During authorization, initiate the reserve amount transaction and reserve fund with the operator.
        To capture the previously reserved fund, developer can invoke capturePayment after fulfillment of purchase (service or content) is successful. 

Reserve and capture Payment (2 phase payment)
****************************************
	- Call the Reserve Payment API as below to initiate the payment process.
		
		NapiPayment.reservePayment(itemId, reservePaymentCallback);
		
	- Capture the result of the reserve Payment call in a function reservePaymentCallback. Create this function as below.
		var reservePaymentCallback = function(r){
			if(r.key != undefined && r.key != ''){
				if(r.key == 'reservedTransaction'){
					// Add your stuff here to do the processes like downloading the files etc and immidiately on success, call the capturePayment API.
					NapiPayment.capturePayment(r.value, capturePaymentCallback);
				}
			} else if(r.error != undefined && r.error != ''){
				// The transaction failed. Add your stuff here.
			}
		}
	- Capture the result of the capture Payment call in a function capturePaymentCallback. Create this function as below.
		var capturePaymentCallback = function(r){
			if(r.key != undefined && r.key != ''){
				if(r.key == 'transactionDetails'){
					// The transaction succedded. Add your stuff here.
				}
			} else if(r.error != undefined && r.error != ''){
				// The transaction failed. Add your stuff here.
			}
		}

View Transaction List
****************************************
	-The transaction list show all the products bought in the past. To view the details call NapiPayment.transactionList() as shown below.
		
		NapiPayment.transactionList(transactionListCallback);
			
	- Capture the result of the transaction list call in a function transactionListCallback. Create this function as below.
		function transactionListCallback(r){
			if(r.dummy == undefined) {
				if(r.key == 'transactionList'){
					var transactionsList = r.value;
					if(!isEmpty(transactionsList.paymentTransactionList)){
						for (var i = 0; i < transactions.length; i++) {
							// The object transactions[i] has access to all the details of the transaction. Do your stuff there to read them.
						}
					}
				}
			}
		}
	
Check Transaction
****************************************
	- In Check transaction we can get the status of a payment whether it was successful or not. Call the NapiPayment.checkTransaction() API as shown below.
		
		NapiPayment.checkTransaction(serverRef,itemId, checkTransactionCallback);
		
	- Here you can get the Server Reference Code and Item Id from the results of View Transaction List.
	- Capture the result of the check transaction call in a function checkTransactionCallback. Create this function as below.
		function checkTransactionCallback(r){
			if(r.value != undefined){
				if(r.value.amountTransaction != undefined){
					// Here you have the access to the transaction status in the object r.value.amountTransaction.transactionOperationStatus. Process it as desired.
				} 
			}
		}

Configuring the sample application to work with a different test environment
****************************************************************************
The sample app is currently configured to work with the WAC Sandbox environment.
Testing against an operator endpoint can be done but will require approval from both WAC and the operator in question.

Sandbox Availability
********************
While WAC Operations and Support works hard to keep the Developer Sandbox available 24 hours a day, 7 days a week, occasional system downtime may occur. 
To check the real-time status of the sandbox at any time, just click here - http://status.watchmouse.com/19627/228798/0.2-Payment-API-Service---Dev-Sandbox

Dependency Jar files
********************
gson-2.1.jar is a Java library that can be used to convert Java Objects into their JSON representation.
It can also be used to convert a JSON string to an equivalent Java object. Gson can work with arbitrary.
This is packaged with sample application or can be downloaded from http://code.google.com/p/google-gson/downloads/detail?name=google-gson-2.1-release.zip&can=2&q= 
