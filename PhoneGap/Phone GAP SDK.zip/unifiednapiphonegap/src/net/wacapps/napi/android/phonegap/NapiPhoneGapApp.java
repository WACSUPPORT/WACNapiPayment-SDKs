/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android.phonegap;

import android.os.Bundle;

import com.phonegap.DroidGap;

/**
 *	The android Phone Gap Application.
 */
public class NapiPhoneGapApp extends DroidGap {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.init();
        // Load the home page of the application.
        super.loadUrl("file:///android_asset/www/index.html");
    }
}