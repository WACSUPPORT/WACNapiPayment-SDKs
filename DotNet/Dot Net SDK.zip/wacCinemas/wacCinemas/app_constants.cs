﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace wacCinemas
{
    public static class app_constants
    {
        public static string secret = "868cc983b4932fd122f7a2a8fa7364be7ea976c4";
        public static string appID = "wac-7ec9ccc2-4669-4d76-a584-6a42894016d0";
        public static string devName = "developer1";
        public static string clientID = "wac-df399a375f03a71189d2a5033d2adfc855f22e8b";
        public static string redirectURI = "http://localhost:65123/Callback.aspx";
    }
}