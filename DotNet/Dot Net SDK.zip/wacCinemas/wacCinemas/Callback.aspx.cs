﻿using System;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using wacNapi;

namespace wacCinemas
{
    public partial class About : System.Web.UI.Page
    {
        // Initialize an object to handle SDK APIs
        wac wac = new wac();

        _Default def = new _Default();
        string appProductKey;
        string refCode;

        protected void Page_Load(object sender, EventArgs e)
        {
            string operation = "Pay";
            string itemID = def.getCookie("WAC_PRODUCT_KEY");
            string payFunc = def.getCookie("PayFunc");
            string referenceCode = def.getCookie("refCode");

            appProductKey = string.IsNullOrEmpty(itemID) ? string.Empty : itemID;
            operation = string.IsNullOrEmpty(payFunc) ? string.Empty : payFunc;
            refCode = string.IsNullOrEmpty(referenceCode) ? string.Empty : referenceCode;

            wac.initService(wacCinemas.app_constants.secret, wacCinemas.app_constants.appID, wacCinemas.app_constants.devName, wacCinemas.app_constants.clientID, wacCinemas.app_constants.redirectURI);

            switch (operation)
            {
                case "Pay":

                    //string payResult = wac.chargePayment("kishore", appProductKey);

                    string reserved = wac.reservePayment();
                    string payResult = wac.capturePayment(reserved, "kishore", appProductKey);

                    Label1.Text = "Make Payment";
                    HeadLabel1.Text = printJson(payResult);
                    break;

                case "Check":

                    string checkResult = wac.checkTransactions(refCode, "kishore");

                    Label1.Text = "Check Transactions";
                    HeadLabel1.Text = printJson(checkResult);
                    break;

                case "List":

                    string listResult = wac.listTransactions("kishore");

                    Label1.Text = "List Transactions";
                    HeadLabel1.Text = printJsonForList(listResult);
                    break;

                default:
                    wac.logger("Please choose one of either Check, List or Pay");
                    break;

            }
        }

        static string printJson(string json)
        {
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(PaymentJSONObject));
            MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(json));
            PaymentJSONObject result = serializer.ReadObject(ms) as PaymentJSONObject;

            return "<br />" +
            "End User Id: " + result.amountTransaction.endUserId + "<br />" +
            "Amount: " + result.amountTransaction.paymentAmount.chargingInformation.amount + "<br />" +
            "Item Id: " + result.amountTransaction.paymentAmount.chargingInformation.code + "<br />" +
            "Currency: " + result.amountTransaction.paymentAmount.chargingInformation.currency + "<br />" +
            "Description: " + result.amountTransaction.paymentAmount.chargingInformation.description + "<br />" +
            "Total Amount Charged: " + result.amountTransaction.paymentAmount.totalAmountCharged + "<br />" +
            "Reference Code: " + result.amountTransaction.referenceCode + "<br />" +
            "Resource URL: " + result.amountTransaction.resourceURL + "<br />" +
            "Server Reference Code: " + result.amountTransaction.serverReferenceCode + "<br />" +
            "Transaction Operation Status: " + result.amountTransaction.transactionOperationStatus;
        }

        static string printJsonForList(string json)
        {
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(listResponse));
            MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(json));
            listResponse result = serializer.ReadObject(ms) as listResponse;

            string response = "";
            for (int i = 0; i < result.paymentTransactionList.amountTransaction.Count; i++)
            {
                int a = i + 1;
                response = response + "<div style=\"weight: bolder;\">Transaction " + a +
                " is : </div> <br /> End User Id: " + result.paymentTransactionList.amountTransaction[i].endUserId + "<br />" +
                "Amount: " + result.paymentTransactionList.amountTransaction[i].paymentAmount.chargingInformation.amount + "<br />" +
                "Item Id: " + result.paymentTransactionList.amountTransaction[i].paymentAmount.chargingInformation.code + "<br />" +
                "Currency: " + result.paymentTransactionList.amountTransaction[i].paymentAmount.chargingInformation.currency + "<br />" +
                "Description: " + result.paymentTransactionList.amountTransaction[i].paymentAmount.chargingInformation.description + "<br />" +
                "Total Amount Charged: " + result.paymentTransactionList.amountTransaction[i].paymentAmount.totalAmountCharged + "<br />" +
                "Reference Code: " + result.paymentTransactionList.amountTransaction[i].referenceCode + "<br />" +
                "Resource URL: " + result.paymentTransactionList.amountTransaction[i].resourceURL + "<br />" +
                "Server Reference Code: " + result.paymentTransactionList.amountTransaction[i].serverReferenceCode + "<br />" +
                "Transaction Operation Status: " + result.paymentTransactionList.amountTransaction[i].transactionOperationStatus + "<br /> <br /> <hr />";

            }
            return response;
        }

    }
}
