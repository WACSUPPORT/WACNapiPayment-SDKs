﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wacCinemas
{
    [Serializable]
    public class listChargingInformation
    {
        public string amount;
        public string code;
        public string currency;
        public string description;

        public string getamount()
        {
            return this.amount;
        }

        public void setamount(string amount)
        {
            this.amount = amount;
        }

        public string getcode()
        {
            return this.code;
        }

        public void setcode(string code)
        {
            this.code = code;
        }

        public string getcurrency()
        {
            return this.currency;
        }

        public void setcurrency(string currency)
        {
            this.currency = currency;
        }

        public string getdescription()
        {
            return this.description;
        }

        public void setdescription(string description)
        {
            this.description = description;
        }
    }

    [Serializable]
    public class listPaymentAmount
    {
        public listChargingInformation chargingInformation = new listChargingInformation();
        public string totalAmountCharged;

        public listChargingInformation getchargingInformation()
        {
            return this.chargingInformation;
        }

        public void setchargingInformation(listChargingInformation chargingInformation)
        {
            this.chargingInformation = chargingInformation;
        }

        public string gettotalAmountCharged()
        {
            return this.totalAmountCharged;
        }

        public void settotalAmountCharged(string totalAmountCharged)
        {
            this.totalAmountCharged = totalAmountCharged;
        }
    }

    [Serializable]
    public class listAmountTransaction
    {
        public string endUserId;
        public listPaymentAmount paymentAmount = new listPaymentAmount();
        public string referenceCode;
        public string resourceURL;
        public string serverReferenceCode;
        public string transactionOperationStatus;

        public string getendUserId()
        {
            return this.endUserId;
        }

        public void setendUserId(string endUserId)
        {
            this.endUserId = endUserId;
        }

        public listPaymentAmount getPaymentAmount()
        {
            return this.paymentAmount;
        }

        public void setPaymentAmount(listPaymentAmount PaymentAmount)
        {
            this.paymentAmount = PaymentAmount;
        }

        public string getreferenceCode()
        {
            return this.referenceCode;
        }

        public void setreferenceCode(string referenceCode)
        {
            this.referenceCode = referenceCode;
        }

        public string getresourceURL()
        {
            return this.resourceURL;
        }

        public void setresourceURL(string resourceURL)
        {
            this.resourceURL = resourceURL;
        }

        public string getserverReferenceCode()
        {
            return this.serverReferenceCode;
        }

        public void setserverReferenceCode(string serverReferenceCode)
        {
            this.serverReferenceCode = serverReferenceCode;
        }

        public string gettransactionOperationStatus()
        {
            return this.transactionOperationStatus;
        }

        public void settransactionOperationStatus(string transactionOperationStatus)
        {
            this.transactionOperationStatus = transactionOperationStatus;
        }
    }

    [Serializable]
    public class PaymentTransactionList
    {
        public List<listAmountTransaction> amountTransaction = new List<listAmountTransaction>();
        public string resourceURL;

        public List<listAmountTransaction> getamountTransaction()
        {
            return this.amountTransaction;
        }

        public void setamountTransaction(List<listAmountTransaction> amountTransaction)
        {
            this.amountTransaction = amountTransaction;
        }

        public string getresourceURL()
        {
            return this.resourceURL;
        }

        public void setresourceURL(string resourceURL)
        {
            this.resourceURL = resourceURL;
        }
    }

    [Serializable]
    public class listResponse
    {
        public PaymentTransactionList paymentTransactionList = new PaymentTransactionList();

        public PaymentTransactionList getpaymentTransactionList()
        {
            return this.paymentTransactionList;
        }

        public void setpaymentTransactionList(PaymentTransactionList paymentTransactionList)
        {
            this.paymentTransactionList = paymentTransactionList;
        }
    }
}
