﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Runtime.Serialization;

namespace wacCinemas
{
    [DataContract]
    public class ChargingInformation
    {
        [DataMember(Name = "amount")]
        public string amount;
        [DataMember(Name = "code")]
        public string code;
        [DataMember(Name = "currency")]
        public string currency;
        [DataMember(Name = "description")]
        public string description;
    }

    [DataContract]
    public class PaymentAmount
    {
        [DataMember(Name = "chargingInformation")]
        public ChargingInformation chargingInformation;
        [DataMember(Name = "totalAmountCharged")]
        public string totalAmountCharged;
    }

    [DataContract]
    public class AmountTransaction
    {
        [DataMember(Name = "endUserId")]
        public string endUserId;
        [DataMember(Name = "paymentAmount")]
        public PaymentAmount paymentAmount;
        [DataMember(Name = "referenceCode")]
        public string referenceCode;
        [DataMember(Name = "resourceURL")]
        public string resourceURL;
        [DataMember(Name = "serverReferenceCode")]
        public string serverReferenceCode;
        [DataMember(Name = "transactionOperationStatus")]
        public string transactionOperationStatus;
    }

    [DataContract]
    public class PaymentJSONObject
    {
        [DataMember(Name = "amountTransaction")]
        public AmountTransaction amountTransaction;
    }
}