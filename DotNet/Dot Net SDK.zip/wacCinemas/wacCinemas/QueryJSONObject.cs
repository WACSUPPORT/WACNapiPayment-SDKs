﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Runtime.Serialization;

namespace wacCinemas
{
    [DataContract]
    public class Item
    {
        [DataMember(Name = "item-id")]
        public string itemID;
        [DataMember(Name = "price")]
        public string price;
        [DataMember(Name = "description")]
        public string description;
        [DataMember(Name = "billing-receipt")]
        public string billingReceipt;
        [DataMember(Name = "currency")]
        public string currency;
    }

    [DataContract]
    public class Product
    {
        [DataMember(Name = "approximate-price")]
        public string approximatePrice;
        [DataMember(Name = "items")]
        public List<Item> items = new List<Item>();
        [DataMember(Name = "application-id")]
        public string applicationID;
    }

    [DataContract]
    public class Response
    {
        [DataMember(Name = "product")]
        public Product product;
    }

    [DataContract]
    public class QueryJSONObject
    {
        [DataMember(Name = "response")]
        public Response response;
        [DataMember(Name = "code")]
        public string code;
    }
}