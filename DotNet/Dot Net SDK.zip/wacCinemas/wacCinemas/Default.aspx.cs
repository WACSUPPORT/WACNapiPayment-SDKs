﻿using System;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using wacNapi;

namespace wacCinemas
{
    public partial class _Default : System.Web.UI.Page
    {
        // Initialize an object to handle SDK APIs
        wac wac = new wac();
        string appProductKey;
        string refCode;

        protected void Page_Load(object sender, EventArgs e)
        {
            var c = HttpContext.Current;
            if (!string.IsNullOrEmpty(c.Request["ListOfProducts"]))
            {
                appProductKey = c.Request["ListOfProducts"];
                setCookie("WAC_PRODUCT_KEY", appProductKey);
            }
            if (!string.IsNullOrEmpty(c.Request["checkTransRefCode"]))
            {
                refCode = c.Request["checkTransRefCode"];                
            }
            else {
                refCode = string.Empty;
            }
            setCookie("refCode", refCode);

            wac.setSpoofedIP("12.207.19.228");
            wac.setLocale("de_DE");

            wac.initService(wacCinemas.app_constants.secret, wacCinemas.app_constants.appID, wacCinemas.app_constants.devName, wacCinemas.app_constants.clientID, wacCinemas.app_constants.redirectURI);

            string queryJson = wac.queryProduct();

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(QueryJSONObject));
            MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(queryJson));
            QueryJSONObject result = serializer.ReadObject(ms) as QueryJSONObject;

            for (int i = 0; i < result.response.product.items.Count; i++)
            {
                ListOfProducts.Items.Add(new ListItem(result.response.product.items[i].description, result.response.product.items[i].itemID));
            }

            WacHomeMView.ActiveViewIndex = 0;

            CheckPayLButton.BackColor = System.Drawing.Color.Maroon;
            CheckPayLButton.ForeColor = System.Drawing.Color.White;
            ListTransactionLButton.BackColor = System.Drawing.Color.Maroon;
            ListTransactionLButton.ForeColor = System.Drawing.Color.White;
        }

        public void makePay(object sender, EventArgs e)
        {
            setCookie("PayFunc", "Pay");

            wac.initPayment(appProductKey);
        }

        public void checkTrans(object sender, EventArgs e)
        {
            setCookie("PayFunc", "Check");

            wac.initCheckTransactions();
        }

        public void listTrans(object sender, EventArgs e)
        {
            setCookie("PayFunc", "List");

            wac.initListTransactions();
        }

        public void setCookie(string name, string value)
        {
            HttpCookie myCookie = new HttpCookie(name);
            myCookie.Value = value;
            Response.Cookies.Add(myCookie);
        }

        public string getCookie(string name)
        {
            var c = HttpContext.Current;
            HttpCookie myCookie = new HttpCookie(name);
            try
            {
                myCookie = c.Request.Cookies[name];
                return myCookie.Value;
            }
            catch
            {
                return string.Empty;
            }
        }


        protected void MakePayLButton_Click(object sender, EventArgs e)
        {
            WacHomeMView.ActiveViewIndex = 0;

            MakePayLButton.BackColor = System.Drawing.Color.Gray;
            MakePayLButton.ForeColor = System.Drawing.Color.Black;
            CheckPayLButton.BackColor = System.Drawing.Color.Maroon;
            CheckPayLButton.ForeColor = System.Drawing.Color.White;
            ListTransactionLButton.BackColor = System.Drawing.Color.Maroon;
            ListTransactionLButton.ForeColor = System.Drawing.Color.White;
        }

        protected void CheckPayLButton_Click(object sender, EventArgs e)
        {
            WacHomeMView.ActiveViewIndex = 1;

            CheckPayLButton.BackColor = System.Drawing.Color.Gray;
            CheckPayLButton.ForeColor = System.Drawing.Color.Black;
            MakePayLButton.BackColor = System.Drawing.Color.Maroon;
            MakePayLButton.ForeColor = System.Drawing.Color.White;
            ListTransactionLButton.BackColor = System.Drawing.Color.Maroon;
            ListTransactionLButton.ForeColor = System.Drawing.Color.White;

        }

        protected void ListTransactionLButton_Click(object sender, EventArgs e)
        {
            WacHomeMView.ActiveViewIndex = 2;

            ListTransactionLButton.BackColor = System.Drawing.Color.Gray;
            ListTransactionLButton.ForeColor = System.Drawing.Color.Black;
            MakePayLButton.BackColor = System.Drawing.Color.Maroon;
            MakePayLButton.ForeColor = System.Drawing.Color.White;
            CheckPayLButton.BackColor = System.Drawing.Color.Maroon;
            CheckPayLButton.ForeColor = System.Drawing.Color.White;

            listTrans(sender, e);
        }
    }
}



