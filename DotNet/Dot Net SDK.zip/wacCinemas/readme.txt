************************
.Net SDK for WAC Payments:
************************

**********************************
About the .Net SDK for WAC NAPI:
**********************************
The WAC's .Net Software Developer Kit (SDK) makes the process of integrating WAC's payment services into .Net application easy.
This software is intended for use by .Net application developers.

************
Prerequisite:
************
1. Register with WAC as a developer: http://www.wacapps.net/register
2. Create Applications: http://www.wacapps.net/napi-application
3. Manage Applications: http://www.wacapps.net/manage-payment-api
4. Cookies must be enabled on browser to run the sample application.

*****************************************
WAC API Integration with .Net applications:
*****************************************
Whats new in NAPI SDK beta 1.0 ?

* Support for In band and out of band transactions.
* Improved End user identification flow for out of band transaction.
* Fast in band transactions
* Query prices based on country
* Support for reserve and capture model for payments.
* SQLCE based and encrypted .Net data store for storing previous transactions.
* Basic authorization support
* User friendly error messages.
* Added new API for checking the WAC billing availability  �checkBillingAvailability�

*****************
Required Software:
*****************
Microsoft .NET Framework 4
Visual Web Developer 2010
IIS 7.5

******************************
Running the sample application:
******************************
- Unzip the sample application which contains a project folder (wacCinemas).
- The folder contains a solution file which can be used to open the project in Visual Studio. 
- Build the wacCinemas project ( Debug->Build wacCinemas )
- To debug/run the Application in ASP.net Development server, Run the Application (Default.aspx)
- The sample application redirect URL is provisioned as "http://localhost:65123/Callback.aspx". Hence, the usage of the mentioned URL with port number 65123 (http://localhost:65123/) is mandatory for running the sample application. This is specified in "app_constants.cs". 
- The credentials in "app_constants.cs" can be replaced by the developer after obtaining the credentials from WAC for testing purpose.

**********************************************************************
Running the sample application using the credentials obtained from WAC:
**********************************************************************
- Unzip the given package which contains a project folder (wacCinemas)
- Open the wacCinemas.sln file to open the project
- Replace the application credentials in "app_constants.cs" obtained from WAC after registration.
- "redirectURI" in "app_constants.cs" should be same as that the redirect URI specified during registration with WAC.
- Build the wacCinemas project ( Debug->Build wacCinemas )
- To run the Application in ASP.net Development server, Run the Application in debug mode ( Debug->Start Debugging )

***************************************************
Integrating WAC in-application payments/billing API:
***************************************************
1. Add an Assembly reference, wacNapi.dll in your workspace:
       The WAC .Net APIs are compiled into wacNapi.dll and Hence, to access these APIs, import this assembly reference in your project workspace.

2. Include Assembly references in your c# code :
       In Application file where .Net APIs are used, include the following statement to include the wacNapi Assembly.
           - using wacNapi;

3. Modify application code to initialize an object for library class "wac" which contains all the API's for making payment and other related tasks
	   - The details are similar to the steps explained in "WAC .Net-SDK Sample application" section 

******************************
WAC .Net-SDK Sample application:
******************************
The sample application demonstrates the usage of WAC in-application payment. 
Usage of WAC-SDK in sample application is as follows:

The following APIs are exposed by .Net-SDK for NAPI interaction:

*******************************
Initializing wacNapi (wac):
*******************************
To access WAC .Net-SDK, 
Initialize "wac" in the file where you have included "wacNapi".

// Create a wac instance
wac wac = new wac();

// Initiates the application credentials to process the payment ( consumerSecret, appID, developeName, clientID, redirectURI).
// This data is obtained when the application is registered with WAC.

// <param name="isecret"> Consumer Secret </param>
// <param name="iappID"> Application ID </param>
// <param name="idevName"> Developer Name </param>
// <param name="iclientID"> Client ID </param>
// <param name="iredirectURI"> Redirect URI </param>
wac.initService(wacCinemas.app_constants.secret, wacCinemas.app_constants.appID, wacCinemas.app_constants.devName, wacCinemas.app_constants.clientID, wacCinemas.app_constants.redirectURI);

Get List of Products for a particular application ID:
*****************************************************
// Fetch the list of products and their details for an Application in the form of a JSON.
//This data needs to be stored by the application. ProductId is required for making a payment.
    	string queryJson = wac.queryProduct();

***********************
Initializing functions:
***********************

Payment Initialization
**********************
To start the authorization process for various functions, please initialize.

		// Initialize WAC payment process with redirection
		// <param name="appProductKey"> Item ID of the product selected by the user</param>
        wac.initPayment(appProductKey);      

 // Initialize the Check Transaction process

        // Initialize check transaction
        wac.initCheckTransactions();
 
 // Initialize the List Transaction process
        
        // Initialize List Transactions
        wac.initListTransactions();
	
*******************
Handling callbacks:
*******************
The authorization flow will call back the redirect URI provided while registering the application with WAC.
Callbacks are handled in Callback.aspx, for payment/check/list transactions in sample application
Sample code for payment callback:

Make Payment
************
Reserve and capture payment
	After authorization, reserve the payment using reservePayment(). This returns a serialized string with complete details required to make a payment which can be used later to make the actual payment.
	Example:
    // Reserve the payment
        string reserved = wac.reservePayment();

	To capture the previously reserved fund, developer can invoke capturePayment after fulfillment of purchase (service or content delivery) is successful.
    // Capture the reserved payment
	// <param name="reserved"> string of serialized class </param>
    // <param name="userID"> User ID </param>
    // <param name="appProductKey"> Product ID for which the Item is to be billed </param>
    // <returns></returns>
		string payResult = wac.capturePayment(reserved, "userID", appProductKey);

Check Transaction
*****************
// Check Transactions
// <param name="refCode"> Server Referenc Code</param>
// <param name="userID"> User ID </param>
	string checkResult = wac.checkTransactions(refCode, "kishore");

List Transaction
****************
// List Transactions
// <param name="userID"> User ID </param>
// <returns></returns>
    string listResult = wac.listTransactions("kishore");

*********
Utilities
*********

Get product details for a particular product ID
***********************************************
// Get detail of a particular ItemID
ProductDetails query = wac.queryForProductDetails("wac-c05ae102-7dd6-4942-a26d-c9dbbae9df8a");

WAC Billing Availability
************************
This API can be used to check if WAC Billing service is available.
It returns true if WAC billing is available else returns false.

// Check if WAC Billing facility is available
// <param name="csecret"> Consumer Secret </param>
// <param name="cappID"> Application ID </param>
// <param name="cdevName"> Developer Name </param>
// <param name="cclientID">Client ID </param>
// <returns> Boolean </returns>
    bool status = wac.checkBillingAvailability(string csecret, string cappID, string cdevName, string cclientID)

Limitations of this method: At the point of calling this method WAC have not yet checked the individual user. In the case the user is out-of-band (e.g. WiFi), we have not yet identified the operator either because we want to avoid having to ask the user for their phone number when this method is called. This means that this method behaves as follows:
� In-band flow, app not LIVE or not published to this operator: will return "false"
� Out-of-band flow, app not LIVE or not published in the country of the access point IP address: will return "false"
� Out-of-band flow, app published in the country of the access point IP address but not the operator of the user: will return "true"
� Individual user can't use WAC even if other users of this operator can, e.g. user blacklisted, user doesn't have enough credit etc.: will return "false"
� App is LIVE, published to this operator and individual user can use WAC: will return "true"

*******************
Transaction Storage
*******************
Transaction data is stored on the server in SQLCE.
User ID is passed as a parameter to the API's (chargePayment, capturePayment, checkTransactions and listTransactions) is used for unique identification of the user to store and retrieve transaction data.

*****************************************************************************
Configuring the sample application to work with a different test environment:
*****************************************************************************
The sample app is currently configured to work with the WAC Production environment.  
Testing against an operator endpoint can be done but will require approval from both WAC and the operator in question.

Sandbox Availability
********************
While WAC Operations and Support works hard to keep the Developer Sandbox available 24 hours a day, 7 days a week, occasional system downtime may occur. 
To check the real-time status of the sandbox at any time, just click here - http://status.wacapps.net/19627/228798/0.2-Payment-API-Service---Dev-Sandbox
