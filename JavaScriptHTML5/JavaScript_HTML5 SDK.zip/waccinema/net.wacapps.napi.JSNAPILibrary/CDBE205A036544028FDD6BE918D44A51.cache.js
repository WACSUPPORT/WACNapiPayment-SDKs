(function(){
var $gwt_version = "2.4.0";
var $wnd = window;
var $doc = $wnd.document;
var $moduleName, $moduleBase;
var $strongName = 'CDBE205A036544028FDD6BE918D44A51';
var $stats = $wnd.__gwtStatsEvent ? function(a) {return $wnd.__gwtStatsEvent(a);} : null;
var $sessionId = $wnd.__gwtStatsSessionId ? $wnd.__gwtStatsSessionId : null;
$stats && $stats({moduleName:'net.wacapps.napi.JSNAPILibrary',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalStart'});
var _, N81_longLit = {l:4194175, m:4194303, h:1048575}, P0_longLit = {l:0, m:0, h:0}, P1_longLit = {l:1, m:0, h:0}, P40_longLit = {l:64, m:0, h:0}, P80_longLit = {l:128, m:0, h:0}, Pff_longLit = {l:255, m:0, h:0}, P3e8_longLit = {l:1000, m:0, h:0}, Q$Object = 0, Q$String = 1, Q$JavaScriptException = 2, Q$EventHandler = 3, Q$JSONArray = 4, Q$JSONBoolean = 5, Q$JSONNull = 6, Q$JSONNumber = 7, Q$JSONObject = 8, Q$JSONString = 9, Q$LongLibBase$LongEmul = 10, Q$Timer = 11, Q$SimpleEventBus$Command = 12, Q$UmbrellaException = 13, Q$MessageDigestSpi = 14, Q$NoSuchAlgorithmException = 15, Q$Provider = 16, Q$Provider$Service = 17, Q$MacSpi = 18, Q$SecretKeySpec = 19, Q$JsonSerializable = 20, Q$ObjectSerializer = 21, Q$Serializable = 22, Q$Serializable_$1 = 23, Q$Boolean = 24, Q$CharSequence = 25, Q$CharSequence_$1 = 26, Q$Class = 27, Q$Comparable = 28, Q$Comparable_$1 = 29, Q$Double = 30, Q$Enum = 31, Q$Exception = 32, Q$Integer = 33, Q$Long = 34, Q$Number = 35, Q$NumberFormatException = 36, Q$Object_$1 = 37, Q$RuntimeException = 38, Q$StackTraceElement = 39, Q$String_$1 = 40, Q$Throwable = 41, Q$Throwable_$1 = 42, Q$Collection = 43, Q$LinkedHashMap$ChainEntry = 44, Q$List = 45, Q$Map = 46, Q$Map$Entry = 47, Q$Set = 48, Q$TreeMap$Node = 49, Q$TreeMap$SubMapType = 50, Q$NameValuePair = 51, Q$AmountTransaction = 52, Q$Apis = 53, Q$AuthorizationApi = 54, Q$AuthorizationUris = 55, Q$ChargingInformation = 56, Q$CustomerReference = 57, Q$GatewayError = 58, Q$GatewayResponse = 59, Q$GenericError = 60, Q$InvalidRequestError = 61, Q$Item = 62, Q$MessageBody = 63, Q$Oauth1Authorization = 64, Q$Oauth1AuthorizationProxyToken = 65, Q$Oauth1AuthorizationToken = 66, Q$Oauth1AuthorizationVerifier = 67, Q$Oauth1Token = 68, Q$Oauth2AccessToken = 69, Q$Oauth2AuthenticationToken = 70, Q$Oauth2Authorization = 71, Q$Oauth2AuthorizationProxyToken = 72, Q$Oauth2AuthorizationToken = 73, Q$Oauth2ProtectedAuthorizationToken = 74, Q$Operator = 75, Q$Payment = 76, Q$PaymentAmount = 77, Q$PaymentApi = 78, Q$PrepareAuthenticationIdentifier = 79, Q$Product = 80, Q$QueryApi = 81, Q$RequestError = 82, Q$ReservedTransaction = 83, Q$Response = 84, Q$ServiceException = 85, Q$Transaction = 86, Q$TransactionArray = 87, Q$TransactionList = 88, Q$SecretKeySpec_0 = 89, Q$Exportable = 90;
function makeCastMap(a){
  var result = {};
  for (var i_0 = 0, c = a.length; i_0 < c; ++i_0) {
    result[a[i_0]] = 1;
  }
  return result;
}

function nullMethod(){
}

function Object_0(){
}

_ = Object_0.prototype = {};
_.equals$ = function equals(other){
  return this === other;
}
;
_.getClass$ = function getClass_0(){
  return Ljava_lang_Object_2_classLit;
}
;
_.hashCode$ = function hashCode_0(){
  return getHashCode(this);
}
;
_.toString$ = function toString_0(){
  return this.getClass$().typeName + '@' + toPowerOfTwoString(this.hashCode$());
}
;
_.toString = function(){
  return this.toString$();
}
;
_.typeMarker$ = nullMethod;
_.castableTypeMap$ = {};
function $expiresIn(this$static, req){
  var val;
  val = this$static.tokenStore.get(req.clientId_0 + '-----' + $scopesToString(req, null));
  return val == null?-Infinity:(new Double_0(__parseAndValidateDouble(fromString(val).expires))).value - currentTimeMillis();
}

function $finish(this$static, hash){
  var error, errorDesc, errorUri, expiresIn, idx, info, key, nextAmp, nextEq, val;
  info = new Auth$TokenInfo_0;
  error = null;
  errorDesc = '';
  errorUri = '';
  idx = 1;
  while (idx < hash.length - 1) {
    nextEq = $indexOf(hash, fromCodePoint(61), idx);
    if (nextEq < 0) {
      break;
    }
    key = hash.substr(idx, nextEq - idx);
    nextAmp = $indexOf(hash, fromCodePoint(38), nextEq);
    nextAmp = nextAmp < 0?hash.length:nextAmp;
    val = hash.substr(nextEq + 1, nextAmp - (nextEq + 1));
    idx = nextAmp + 1;
    if ($equals(key, 'access_token')) {
      info.accessToken = val;
    }
     else if ($equals(key, 'expires_in')) {
      expiresIn = new Double_0((new Double_0(__parseAndValidateDouble(val))).value * 1000);
      info.expires = '' + (currentTimeMillis() + expiresIn.value);
    }
     else 
      $equals(key, 'error')?(error = val):$equals(key, 'error_description')?(errorDesc = ' (' + val + ')'):$equals(key, 'error_uri')?(errorUri = '; see: ' + val):$equals(key, 'server_reference_code') && (info.serverReferenceCode = val);
  }
  if (error != null) {
    this$static.lastCallback.onFailure_0(new RuntimeException_0('Error from provider: ' + error + errorDesc + errorUri));
  }
   else if (info.accessToken == null) {
    this$static.lastCallback.onFailure_0(new RuntimeException_0('Could not find access_token in hash ' + hash));
  }
   else {
    $setToken(this$static, this$static.lastRequest, info);
    this$static.lastCallback.onSuccess_0(info.accessToken);
  }
}

function $login(this$static, req, callback){
  var authUrl, info, tokenStr;
  this$static.lastRequest = req;
  this$static.lastCallback = callback;
  authUrl = $toUrl(req, this$static.urlCodex) + '&redirect_uri=' + $encode(this$static.oauthWindowUrl);
  info = (tokenStr = this$static.tokenStore.get(req.clientId_0 + '-----' + $scopesToString(req, null)) , tokenStr != null?fromString(tokenStr):null);
  !info || info.expires == null || (new Double_0(__parseAndValidateDouble(info.expires))).value < currentTimeMillis() + 600000?$doLogin(this$static, authUrl, callback):$scheduleDeferred(this$static.scheduler, new Auth$1_0(callback, info));
}

function $setToken(this$static, req, info){
  this$static.tokenStore.set(req.clientId_0 + '-----' + $scopesToString(req, null), info.accessToken + '-----' + (info.expires == null?'':info.expires) + (info.serverReferenceCode == null?'':'-----' + info.serverReferenceCode));
}

function Auth_0(tokenStore, urlCodex, scheduler, oauthWindowUrl){
  this.tokenStore = tokenStore;
  this.urlCodex = urlCodex;
  this.scheduler = scheduler;
  this.oauthWindowUrl = oauthWindowUrl;
}

function export_$(){
  !$wnd.oauth2 && ($wnd.oauth2 = {});
  $wnd.oauth2.login = $entry(function(req, success, failure){
    $login(($clinit_AuthImpl() , INSTANCE), $withScopeDelimiter($withScopes(new AuthRequest_0(req.authUrl, req.clientId), $getScopes(req)), req.scopeDelimiter || ' '), new Auth$CallbackWrapper_0(success, failure));
  }
  );
  $wnd.oauth2.expiresIn = $entry(function(req){
    return $expiresIn(($clinit_AuthImpl() , INSTANCE), $withScopeDelimiter($withScopes(new AuthRequest_0(req.authUrl, req.clientId), $getScopes(req)), req.scopeDelimiter || ' '));
  }
  );
}

function Auth(){
}

_ = Auth.prototype = new Object_0;
_.finish = function finish(hash){
  $finish(this, hash);
}
;
_.getClass$ = function getClass_1(){
  return Lcom_google_api_gwt_oauth2_client_Auth_2_classLit;
}
;
_.lastCallback = null;
_.lastRequest = null;
_.oauthWindowUrl = null;
_.scheduler = null;
_.tokenStore = null;
_.urlCodex = null;
function Auth$1_0(val$callback, val$info){
  this.val$callback = val$callback;
  this.val$info = val$info;
}

function Auth$1(){
}

_ = Auth$1_0.prototype = Auth$1.prototype = new Object_0;
_.getClass$ = function getClass_2(){
  return Lcom_google_api_gwt_oauth2_client_Auth$1_2_classLit;
}
;
_.val$callback = null;
_.val$info = null;
function equals__devirtual$(this$static, other){
  var maybeJsoInvocation;
  return maybeJsoInvocation = this$static , isJavaObject(maybeJsoInvocation)?maybeJsoInvocation.equals$(other):maybeJsoInvocation === other;
}

function getClass__devirtual$(this$static){
  var maybeJsoInvocation;
  return maybeJsoInvocation = this$static , isJavaObject(maybeJsoInvocation)?maybeJsoInvocation.getClass$():Lcom_google_gwt_core_client_JavaScriptObject_2_classLit;
}

function hashCode__devirtual$(this$static){
  var maybeJsoInvocation;
  return maybeJsoInvocation = this$static , isJavaObject(maybeJsoInvocation)?maybeJsoInvocation.hashCode$():getHashCode(maybeJsoInvocation);
}

function $getScopes(this$static){
  var arr, i_0, jsa;
  jsa = this$static.scopes || [];
  arr = initDim(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, jsa.length, 0);
  for (i_0 = 0; i_0 < jsa.length; ++i_0) {
    arr[i_0] = jsa[i_0];
  }
  return arr;
}

function Auth$CallbackWrapper_0(success, failure){
  this.success = success;
  this.failure = failure;
}

function Auth$CallbackWrapper(){
}

_ = Auth$CallbackWrapper_0.prototype = Auth$CallbackWrapper.prototype = new Object_0;
_.getClass$ = function getClass_3(){
  return Lcom_google_api_gwt_oauth2_client_Auth$CallbackWrapper_2_classLit;
}
;
_.onFailure_0 = function onFailure(reason){
  !!this.failure && (this.failure(reason.getMessage()) , undefined);
}
;
_.onSuccess_0 = function onSuccess(result){
  !!this.success && (this.success(result) , undefined);
}
;
_.failure = null;
_.success = null;
function Auth$TokenInfo_0(){
}

function fromString(val){
  var info, parts;
  parts = $split(val, '-----', 0);
  info = new Auth$TokenInfo_0;
  info.accessToken = parts[0];
  info.expires = parts.length > 1?parts[1]:null;
  info.serverReferenceCode = parts.length > 2?parts[2]:null;
  return info;
}

function Auth$TokenInfo(){
}

_ = Auth$TokenInfo_0.prototype = Auth$TokenInfo.prototype = new Object_0;
_.getClass$ = function getClass_4(){
  return Lcom_google_api_gwt_oauth2_client_Auth$TokenInfo_2_classLit;
}
;
_.accessToken = null;
_.expires = null;
_.serverReferenceCode = null;
function $clinit_AuthImpl(){
  $clinit_AuthImpl = nullMethod;
  INSTANCE = new AuthImpl_0;
}

function $doLogin(this$static, authUrl, callback){
  if (!!this$static.window_0 && !this$static.window_0.closed) {
    callback.onFailure_0(new IllegalStateException_0('Authentication in progress'));
  }
   else {
    this$static.window_0 = $wnd.open(authUrl, 'popupWindow', 'width=800,height=600');
    !this$static.window_0 && callback.onFailure_0(new RuntimeException_0('The authentication popup window appears to have been blocked'));
  }
}

function $register(this$static){
  var self_0 = this$static;
  !$wnd.oauth2 && ($wnd.oauth2 = {});
  $wnd.oauth2.__doLogin = $entry(function(hash){
    self_0.finish(hash);
  }
  );
}

function AuthImpl_0(){
  Auth_0.call(this, (!supportDetectorImpl && (supportDetectorImpl = new Storage$StorageSupportDetector_0) , supportDetectorImpl.isLocalStorageSupported?new TokenStoreImpl_0:new CookieStoreImpl_0), new AuthImpl$RealUrlCodex_0, ($clinit_SchedulerImpl() , INSTANCE_0), $moduleBase + 'oauthWindow.html');
  $register(this);
}

function AuthImpl(){
}

_ = AuthImpl_0.prototype = AuthImpl.prototype = new Auth;
_.finish = function finish_0(hash){
  !!this.window_0 && !this.window_0.closed && (this.window_0.close() , undefined);
  $finish(this, hash);
}
;
_.getClass$ = function getClass_5(){
  return Lcom_google_api_gwt_oauth2_client_AuthImpl_2_classLit;
}
;
_.window_0 = null;
var INSTANCE;
function $encode(url){
  var regexp = /%20/g;
  return encodeURIComponent(url).replace(regexp, '+');
}

function AuthImpl$RealUrlCodex_0(){
}

function AuthImpl$RealUrlCodex(){
}

_ = AuthImpl$RealUrlCodex_0.prototype = AuthImpl$RealUrlCodex.prototype = new Object_0;
_.getClass$ = function getClass_6(){
  return Lcom_google_api_gwt_oauth2_client_AuthImpl$RealUrlCodex_2_classLit;
}
;
function $scopesToString(this$static, urlCodex){
  var needsSeparator, sb, scope, scope$array, scope$index, scope$max;
  if (this$static.scopes_0 == null || this$static.scopes_0.length == 0) {
    return '';
  }
  sb = new StringBuilder_0;
  needsSeparator = false;
  for (scope$array = this$static.scopes_0 , scope$index = 0 , scope$max = scope$array.length; scope$index < scope$max; ++scope$index) {
    scope = scope$array[scope$index];
    needsSeparator && $append_4(sb, this$static.scopeDelimiter_0);
    needsSeparator = true;
    $append_4(sb, !urlCodex?scope:$encode(scope));
  }
  return sb.impl.string;
}

function $toUrl(this$static, urlCodex){
  return $append_4($append_4($append_4($append_4($append_4($append_4($append_4($append_4($append_4($append_4($append_4($append_4(new StringBuilder_1(this$static.authUrl_0), this$static.authUrl_0.indexOf('?') != -1?'&':'?'), 'client_id'), '='), $encode(this$static.clientId_0)), '&'), 'response_type'), '='), 'token'), '&'), 'scope'), '='), $scopesToString(this$static, urlCodex)).impl.string;
}

function $withScopeDelimiter(this$static, scopeDelimiter){
  this$static.scopeDelimiter_0 = scopeDelimiter;
  return this$static;
}

function $withScopes(this$static, scopes){
  this$static.scopes_0 = scopes;
  return this$static;
}

function AuthRequest_0(authUrl, clientId){
  this.authUrl_0 = authUrl;
  this.clientId_0 = clientId;
}

function AuthRequest(){
}

_ = AuthRequest_0.prototype = AuthRequest.prototype = new Object_0;
_.getClass$ = function getClass_7(){
  return Lcom_google_api_gwt_oauth2_client_AuthRequest_2_classLit;
}
;
_.authUrl_0 = null;
_.clientId_0 = null;
_.scopeDelimiter_0 = ' ';
_.scopes_0 = null;
function $clinit_TokenStoreImpl(){
  $clinit_TokenStoreImpl = nullMethod;
  STORAGE = getLocalStorageIfSupported();
  if (!STORAGE) {
    throw new NullPointerException_1('Storage is null');
  }
}

function TokenStoreImpl_0(){
  $clinit_TokenStoreImpl();
}

function TokenStoreImpl(){
}

_ = TokenStoreImpl_0.prototype = TokenStoreImpl.prototype = new Object_0;
_.get = function get(key){
  return $getItem(STORAGE, key);
}
;
_.getClass$ = function getClass_8(){
  return Lcom_google_api_gwt_oauth2_client_TokenStoreImpl_2_classLit;
}
;
_.set = function set(key, value){
  $setItem(STORAGE, key, value);
}
;
var STORAGE;
function CookieStoreImpl_0(){
  $clinit_TokenStoreImpl();
}

function ensureCookies(){
  (!cachedCookies || needsRefresh()) && loadCookies();
  return cachedCookies;
}

function loadCookies(){
  cachedCookies = {};
  var docCookie = $doc.cookie;
  if (docCookie && docCookie != '') {
    var crumbs = docCookie.split('; ');
    for (var i_0 = 0; i_0 < crumbs.length; ++i_0) {
      var name_0, value;
      var eqIdx = crumbs[i_0].indexOf('=');
      if (eqIdx == -1) {
        name_0 = crumbs[i_0];
        value = '';
      }
       else {
        name_0 = crumbs[i_0].substring(0, eqIdx);
        value = crumbs[i_0].substring(eqIdx + 1);
      }
      try {
        name_0 = decodeURIComponent(name_0);
      }
       catch (e) {
      }
      try {
        value = decodeURIComponent(value);
      }
       catch (e) {
      }
      cachedCookies[name_0] = value;
    }
  }
}

function needsRefresh(){
  var docCookie = $doc.cookie;
  if (docCookie != rawCookies) {
    rawCookies = docCookie;
    return true;
  }
   else {
    return false;
  }
}

function CookieStoreImpl(){
}

_ = CookieStoreImpl_0.prototype = CookieStoreImpl.prototype = new TokenStoreImpl;
_.get = function get_0(key){
  var m_0 = ensureCookies;
  return m_0['gwt-oauth2-' + key];
}
;
_.getClass$ = function getClass_9(){
  return Lcom_google_api_gwt_oauth2_client_CookieStoreImpl_2_classLit;
}
;
_.set = function set_0(key, value){
  $doc.cookie = 'gwt-oauth2-' + encodeURIComponent(name) + '=' + encodeURIComponent(value);
}
;
var cachedCookies = null;
function currentTimeMillis(){
  return (new Date).getTime();
}

function $initCause(this$static, cause){
  if (this$static.cause) {
    throw new IllegalStateException_0("Can't overwrite cause");
  }
  if (cause == this$static) {
    throw new IllegalArgumentException_1('Self-causation not permitted');
  }
  this$static.cause = cause;
  return this$static;
}

function $printStackTrace(this$static){
  var causeMessage, currentCause, msg;
  msg = new StringBuffer_0;
  currentCause = this$static;
  while (currentCause) {
    causeMessage = currentCause.getMessage();
    currentCause != this$static && (msg.impl.string += 'Caused by: ' , msg);
    $append_2(msg, currentCause.getClass$().typeName);
    msg.impl.string += ': ';
    $append_0(msg.impl, causeMessage == null?'(No exception detail)':causeMessage);
    msg.impl.string += '\n';
    currentCause = currentCause.cause;
  }
}

function $setStackTrace(stackTrace){
  var c, copy, i_0;
  copy = initDim(_3Ljava_lang_StackTraceElement_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Object_$1]), Q$StackTraceElement, stackTrace.length, 0);
  for (i_0 = 0 , c = stackTrace.length; i_0 < c; ++i_0) {
    if (!stackTrace[i_0]) {
      throw new NullPointerException_0;
    }
    copy[i_0] = stackTrace[i_0];
  }
}

function $toString(this$static){
  var className, msg;
  className = this$static.getClass$().typeName;
  msg = this$static.getMessage();
  return msg != null?className + ': ' + msg:className;
}

function Throwable(){
}

_ = Throwable.prototype = new Object_0;
_.getClass$ = function getClass_10(){
  return Ljava_lang_Throwable_2_classLit;
}
;
_.getMessage = function getMessage(){
  return this.detailMessage;
}
;
_.toString$ = function toString_1(){
  return $toString(this);
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Throwable]);
_.cause = null;
_.detailMessage = null;
function Exception_0(message){
  $fillInStackTrace();
  this.detailMessage = message;
}

function Exception(){
}

_ = Exception.prototype = new Throwable;
_.getClass$ = function getClass_11(){
  return Ljava_lang_Exception_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$Throwable]);
function RuntimeException_0(message){
  Exception_0.call(this, message);
}

function RuntimeException_1(cause){
  $fillInStackTrace();
  this.cause = cause;
  this.detailMessage = 'One or more exceptions caught, see full set in UmbrellaException#getCauses';
}

function RuntimeException(){
}

_ = RuntimeException_0.prototype = RuntimeException.prototype = new Exception;
_.getClass$ = function getClass_12(){
  return Ljava_lang_RuntimeException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function JavaScriptException_0(e){
  $fillInStackTrace();
  this.e = e;
  $createStackTrace(this);
}

function getDescription(e){
  return instanceOfJso(e)?getDescription0(dynamicCastJso(e)):e + '';
}

function getDescription0(e){
  return e == null?null:e.message;
}

function getName(e){
  return e == null?'null':instanceOfJso(e)?getName0(dynamicCastJso(e)):instanceOf(e, Q$String)?'String':getClass__devirtual$(e).typeName;
}

function getName0(e){
  return e == null?null:e.name;
}

function getProperties(e){
  return instanceOfJso(e)?$getProperties(dynamicCastJso(e)):'';
}

function JavaScriptException(){
}

_ = JavaScriptException_0.prototype = JavaScriptException.prototype = new RuntimeException;
_.getClass$ = function getClass_13(){
  return Lcom_google_gwt_core_client_JavaScriptException_2_classLit;
}
;
_.getMessage = function getMessage_0(){
  return this.message_0 == null && (this.name_0 = getName(this.e) , this.description = getDescription(this.e) , this.message_0 = '(' + this.name_0 + '): ' + this.description + getProperties(this.e) , undefined) , this.message_0;
}
;
_.castableTypeMap$ = makeCastMap([Q$JavaScriptException, Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
_.description = null;
_.e = null;
_.message_0 = null;
_.name_0 = null;
function $clinit_JsonUtils(){
  var out;
  $clinit_JsonUtils = nullMethod;
  escapeTable = (out = ['\\u0000', '\\u0001', '\\u0002', '\\u0003', '\\u0004', '\\u0005', '\\u0006', '\\u0007', '\\b', '\\t', '\\n', '\\u000B', '\\f', '\\r', '\\u000E', '\\u000F', '\\u0010', '\\u0011', '\\u0012', '\\u0013', '\\u0014', '\\u0015', '\\u0016', '\\u0017', '\\u0018', '\\u0019', '\\u001A', '\\u001B', '\\u001C', '\\u001D', '\\u001E', '\\u001F'] , out[34] = '\\"' , out[92] = '\\\\' , out[173] = '\\u00ad' , out[1536] = '\\u0600' , out[1537] = '\\u0601' , out[1538] = '\\u0602' , out[1539] = '\\u0603' , out[1757] = '\\u06dd' , out[1807] = '\\u070f' , out[6068] = '\\u17b4' , out[6069] = '\\u17b5' , out[8204] = '\\u200c' , out[8205] = '\\u200d' , out[8206] = '\\u200e' , out[8207] = '\\u200f' , out[8232] = '\\u2028' , out[8233] = '\\u2029' , out[8234] = '\\u202a' , out[8235] = '\\u202b' , out[8236] = '\\u202c' , out[8237] = '\\u202d' , out[8238] = '\\u202e' , out[8288] = '\\u2060' , out[8289] = '\\u2061' , out[8290] = '\\u2062' , out[8291] = '\\u2063' , out[8298] = '\\u206a' , out[8299] = '\\u206b' , out[8300] = '\\u206c' , out[8301] = '\\u206d' , out[8302] = '\\u206e' , out[8303] = '\\u206f' , out[65279] = '\\ufeff' , out[65529] = '\\ufff9' , out[65530] = '\\ufffa' , out[65531] = '\\ufffb' , out);
  hasJsonParse = typeof JSON == 'object' && typeof JSON.parse == 'function';
}

function escapeChar(c){
  var lookedUp = escapeTable[c.charCodeAt(0)];
  return lookedUp == null?c:lookedUp;
}

function escapeJsonForEval(toEscape){
  $clinit_JsonUtils();
  var s = toEscape.replace(/[\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202e\u2060-\u2063\u206a-\u206f\ufeff\ufff9-\ufffb]/g, function(x){
    return escapeChar(x);
  }
  );
  return s;
}

function escapeValue(toEscape){
  $clinit_JsonUtils();
  var s = toEscape.replace(/[\x00-\x1f\xad\u0600-\u0603\u06dd\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202e\u2060-\u2063\u206a-\u206f\ufeff\ufff9-\ufffb"\\]/g, function(x){
    return escapeChar(x);
  }
  );
  return '"' + s + '"';
}

var escapeTable, hasJsonParse;
function Scheduler(){
}

_ = Scheduler.prototype = new Object_0;
_.getClass$ = function getClass_14(){
  return Lcom_google_gwt_core_client_Scheduler_2_classLit;
}
;
function apply(jsFunction, thisObj, arguments_0){
  return jsFunction.apply(thisObj, arguments_0);
  var __0;
}

function enter(){
  if (entryDepth++ == 0) {
    $flushEntryCommands(($clinit_SchedulerImpl() , INSTANCE_0));
    return true;
  }
  return false;
}

function entry_0(jsFunction){
  return function(){
    try {
      return entry0(jsFunction, this, arguments);
    }
     catch (e) {
      throw e;
    }
  }
  ;
}

function entry0(jsFunction, thisObj, arguments_0){
  var initialEntry;
  initialEntry = enter();
  try {
    return apply(jsFunction, thisObj, arguments_0);
  }
   finally {
    initialEntry && $flushFinallyCommands(($clinit_SchedulerImpl() , INSTANCE_0));
    --entryDepth;
  }
}

function getHashCode(o){
  return o.$H || (o.$H = ++sNextHashId);
}

var entryDepth = 0, sNextHashId = 0;
function $clinit_SchedulerImpl(){
  $clinit_SchedulerImpl = nullMethod;
  INSTANCE_0 = new SchedulerImpl_0;
}

function $flushEntryCommands(this$static){
  var oldQueue, rescheduled;
  if (this$static.entryCommands) {
    rescheduled = null;
    do {
      oldQueue = this$static.entryCommands;
      this$static.entryCommands = null;
      rescheduled = runScheduledTasks(oldQueue, rescheduled);
    }
     while (this$static.entryCommands);
    this$static.entryCommands = rescheduled;
  }
}

function $flushFinallyCommands(this$static){
  var oldQueue, rescheduled;
  if (this$static.finallyCommands) {
    rescheduled = null;
    do {
      oldQueue = this$static.finallyCommands;
      this$static.finallyCommands = null;
      rescheduled = runScheduledTasks(oldQueue, rescheduled);
    }
     while (this$static.finallyCommands);
    this$static.finallyCommands = rescheduled;
  }
}

function $flushPostEventPumpCommands(this$static){
  var oldDeferred;
  if (this$static.deferredCommands) {
    oldDeferred = this$static.deferredCommands;
    this$static.deferredCommands = null;
    !this$static.incrementalCommands && (this$static.incrementalCommands = []);
    runScheduledTasks(oldDeferred, this$static.incrementalCommands);
  }
  !!this$static.incrementalCommands && (this$static.incrementalCommands = runRepeatingTasks(this$static.incrementalCommands));
}

function $isWorkQueued(this$static){
  return !!this$static.deferredCommands || !!this$static.incrementalCommands;
}

function $maybeSchedulePostEventPumpCommands(this$static){
  if (!this$static.shouldBeRunning) {
    this$static.shouldBeRunning = true;
    !this$static.flusher && (this$static.flusher = new SchedulerImpl$Flusher_0(this$static));
    scheduleFixedDelayImpl(this$static.flusher, 1);
    !this$static.rescue && (this$static.rescue = new SchedulerImpl$Rescuer_0(this$static));
    scheduleFixedDelayImpl(this$static.rescue, 50);
  }
}

function $scheduleDeferred(this$static, cmd){
  this$static.deferredCommands = push(this$static.deferredCommands, [cmd, false]);
  $maybeSchedulePostEventPumpCommands(this$static);
}

function SchedulerImpl_0(){
}

function execute(cmd){
  return cmd.execute();
}

function push(queue, task){
  !queue && (queue = []);
  queue[queue.length] = task;
  return queue;
}

function runRepeatingTasks(tasks){
  var canceledSomeTasks, i_0, length_0, newTasks, start, t;
  length_0 = tasks.length;
  if (length_0 == 0) {
    return null;
  }
  canceledSomeTasks = false;
  start = currentTimeMillis();
  while (currentTimeMillis() - start < 100) {
    for (i_0 = 0; i_0 < length_0; ++i_0) {
      t = tasks[i_0];
      if (!t) {
        continue;
      }
      if (!t[0].execute()) {
        tasks[i_0] = null;
        canceledSomeTasks = true;
      }
    }
  }
  if (canceledSomeTasks) {
    newTasks = [];
    for (i_0 = 0; i_0 < length_0; ++i_0) {
      !!tasks[i_0] && (newTasks[newTasks.length] = tasks[i_0] , undefined);
    }
    return newTasks.length == 0?null:newTasks;
  }
   else {
    return tasks;
  }
}

function runScheduledTasks(tasks, rescheduled){
  var $e0, i_0, j, t;
  for (i_0 = 0 , j = tasks.length; i_0 < j; ++i_0) {
    t = tasks[i_0];
    try {
      t[1]?t[0].execute() && (rescheduled = push(rescheduled, t)):(t[0].val$callback.onSuccess_0(t[0].val$info.accessToken) , undefined);
    }
     catch ($e0) {
      $e0 = caught_0($e0);
      if (!instanceOf($e0, Q$RuntimeException))
        throw $e0;
    }
  }
  return rescheduled;
}

function scheduleFixedDelayImpl(cmd, delayMs){
  $clinit_SchedulerImpl();
  $wnd.setTimeout(function(){
    var ret = $entry(execute)(cmd);
    ret && $wnd.setTimeout(arguments.callee, delayMs);
  }
  , delayMs);
}

function SchedulerImpl(){
}

_ = SchedulerImpl_0.prototype = SchedulerImpl.prototype = new Scheduler;
_.getClass$ = function getClass_15(){
  return Lcom_google_gwt_core_client_impl_SchedulerImpl_2_classLit;
}
;
_.deferredCommands = null;
_.entryCommands = null;
_.finallyCommands = null;
_.flushRunning = false;
_.flusher = null;
_.incrementalCommands = null;
_.rescue = null;
_.shouldBeRunning = false;
var INSTANCE_0;
function SchedulerImpl$Flusher_0(this$0){
  this.this$0 = this$0;
}

function SchedulerImpl$Flusher(){
}

_ = SchedulerImpl$Flusher_0.prototype = SchedulerImpl$Flusher.prototype = new Object_0;
_.execute = function execute_0(){
  this.this$0.flushRunning = true;
  $flushPostEventPumpCommands(this.this$0);
  this.this$0.flushRunning = false;
  return this.this$0.shouldBeRunning = $isWorkQueued(this.this$0);
}
;
_.getClass$ = function getClass_16(){
  return Lcom_google_gwt_core_client_impl_SchedulerImpl$Flusher_2_classLit;
}
;
_.this$0 = null;
function SchedulerImpl$Rescuer_0(this$0){
  this.this$0 = this$0;
}

function SchedulerImpl$Rescuer(){
}

_ = SchedulerImpl$Rescuer_0.prototype = SchedulerImpl$Rescuer.prototype = new Object_0;
_.execute = function execute_1(){
  this.this$0.flushRunning && scheduleFixedDelayImpl(this.this$0.flusher, 1);
  return this.this$0.shouldBeRunning;
}
;
_.getClass$ = function getClass_17(){
  return Lcom_google_gwt_core_client_impl_SchedulerImpl$Rescuer_2_classLit;
}
;
_.this$0 = null;
function extractNameFromToString(fnToString){
  var index, start, toReturn;
  toReturn = '';
  fnToString = $trim(fnToString);
  index = fnToString.indexOf('(');
  if (index != -1) {
    start = fnToString.indexOf('function') == 0?8:0;
    toReturn = $trim(fnToString.substr(start, index - start));
  }
  return toReturn.length > 0?toReturn:'anonymous';
}

function splice(arr, length_0){
  arr.length >= length_0 && arr.splice(0, length_0);
  return arr;
}

function $createStackTrace(e){
  var i_0, j, stack, stackTrace;
  stack = $inferFrom(instanceOfJso(e.e)?dynamicCastJso(e.e):null);
  stackTrace = initDim(_3Ljava_lang_StackTraceElement_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Object_$1]), Q$StackTraceElement, stack.length, 0);
  for (i_0 = 0 , j = stackTrace.length; i_0 < j; ++i_0) {
    stackTrace[i_0] = new StackTraceElement_0(stack[i_0]);
  }
  $setStackTrace(stackTrace);
}

function $fillInStackTrace(){
  var i_0, j, stack, stackTrace;
  stack = splice($inferFrom($makeException()), 2);
  stackTrace = initDim(_3Ljava_lang_StackTraceElement_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Object_$1]), Q$StackTraceElement, stack.length, 0);
  for (i_0 = 0 , j = stackTrace.length; i_0 < j; ++i_0) {
    stackTrace[i_0] = new StackTraceElement_0(stack[i_0]);
  }
  $setStackTrace(stackTrace);
}

function $getProperties(e){
  var result = '';
  try {
    for (var prop in e) {
      if (prop != 'name' && prop != 'message' && prop != 'toString') {
        try {
          result += '\n ' + prop + ': ' + e[prop];
        }
         catch (ignored) {
        }
      }
    }
  }
   catch (ignored) {
  }
  return result;
}

function $makeException(){
  try {
    null.a();
  }
   catch (e) {
    return e;
  }
}

function $inferFrom(e){
  var i_0, j, stack;
  stack = e && e.stack?e.stack.split('\n'):[];
  for (i_0 = 0 , j = stack.length; i_0 < j; ++i_0) {
    stack[i_0] = extractNameFromToString(stack[i_0]);
  }
  return stack;
}

function StringBufferImpl(){
}

_ = StringBufferImpl.prototype = new Object_0;
_.getClass$ = function getClass_18(){
  return Lcom_google_gwt_core_client_impl_StringBufferImpl_2_classLit;
}
;
function $append(this$static, x){
  this$static.string += x;
}

function $append_0(this$static, x){
  this$static.string += x;
}

function $appendNonNull(this$static, x){
  this$static.string += x;
}

function StringBufferImplAppend_0(){
}

function StringBufferImplAppend(){
}

_ = StringBufferImplAppend_0.prototype = StringBufferImplAppend.prototype = new StringBufferImpl;
_.getClass$ = function getClass_19(){
  return Lcom_google_gwt_core_client_impl_StringBufferImplAppend_2_classLit;
}
;
_.string = '';
function Event_0(){
}

_ = Event_0.prototype = new Object_0;
_.getClass$ = function getClass_20(){
  return Lcom_google_web_bindery_event_shared_Event_2_classLit;
}
;
_.toString$ = function toString_2(){
  return 'An event type';
}
;
_.source = null;
function $overrideSource(this$static, source){
  this$static.source = source;
}

function GwtEvent(){
}

_ = GwtEvent.prototype = new Event_0;
_.getClass$ = function getClass_21(){
  return Lcom_google_gwt_event_shared_GwtEvent_2_classLit;
}
;
_.dead = false;
function CloseEvent_0(){
}

function fire(source){
  var event_0;
  if (TYPE) {
    event_0 = new CloseEvent_0;
    $fireEvent(source, event_0);
  }
}

function CloseEvent(){
}

_ = CloseEvent_0.prototype = CloseEvent.prototype = new GwtEvent;
_.dispatch = function dispatch(handler){
  $onClose();
}
;
_.getAssociatedType = function getAssociatedType(){
  return TYPE;
}
;
_.getClass$ = function getClass_22(){
  return Lcom_google_gwt_event_logical_shared_CloseEvent_2_classLit;
}
;
var TYPE = null;
function Event$Type(){
}

_ = Event$Type.prototype = new Object_0;
_.getClass$ = function getClass_23(){
  return Lcom_google_web_bindery_event_shared_Event$Type_2_classLit;
}
;
_.hashCode$ = function hashCode_1(){
  return this.index_0;
}
;
_.toString$ = function toString_3(){
  return 'Event type';
}
;
_.index_0 = 0;
var nextHashCode = 0;
function GwtEvent$Type_0(){
  this.index_0 = ++nextHashCode;
}

function GwtEvent$Type(){
}

_ = GwtEvent$Type_0.prototype = GwtEvent$Type.prototype = new Event$Type;
_.getClass$ = function getClass_24(){
  return Lcom_google_gwt_event_shared_GwtEvent$Type_2_classLit;
}
;
function $addHandler(this$static, type, handler){
  return new LegacyHandlerWrapper_0($doAdd(this$static.eventBus, type, handler));
}

function $fireEvent(this$static, event_0){
  var $e0, e, oldSource;
  !event_0.dead || (event_0.dead = false , event_0.source = null);
  oldSource = event_0.source;
  $overrideSource(event_0, this$static.source);
  try {
    $doFire(this$static.eventBus, event_0);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$UmbrellaException)) {
      e = $e0;
      throw new UmbrellaException_2(e.causes);
    }
     else 
      throw $e0;
  }
   finally {
    oldSource == null?(event_0.dead = true , event_0.source = null):(event_0.source = oldSource);
  }
}

function HandlerManager(){
}

_ = HandlerManager.prototype = new Object_0;
_.getClass$ = function getClass_25(){
  return Lcom_google_gwt_event_shared_HandlerManager_2_classLit;
}
;
_.eventBus = null;
_.source = null;
function EventBus(){
}

_ = EventBus.prototype = new Object_0;
_.getClass$ = function getClass_26(){
  return Lcom_google_web_bindery_event_shared_EventBus_2_classLit;
}
;
function $defer(this$static, command){
  !this$static.deferredDeltas && (this$static.deferredDeltas = new ArrayList_0);
  $add(this$static.deferredDeltas, command);
}

function $doAdd(this$static, type, handler){
  if (!type) {
    throw new NullPointerException_1('Cannot add a handler with a null type');
  }
  if (!handler) {
    throw new NullPointerException_1('Cannot add a null handler');
  }
  this$static.firingDepth > 0?$defer(this$static, new SimpleEventBus$2_0(this$static, type, handler)):$doAddNow(this$static, type, null, handler);
  return new SimpleEventBus$1_0;
}

function $doAddNow(this$static, type, source, handler){
  var l_0;
  l_0 = $ensureHandlerList(this$static, type, source);
  l_0.add(handler);
}

function $doFire(this$static, event_0){
  var $e0, causes, e, handler, handlers, it;
  if (!event_0) {
    throw new NullPointerException_1('Cannot fire null event');
  }
  try {
    ++this$static.firingDepth;
    handlers = $getDispatchList(this$static, event_0.getAssociatedType());
    causes = null;
    it = this$static.isReverseOrder?handlers.listIterator_0(handlers.size_0()):handlers.listIterator();
    while (this$static.isReverseOrder?it.i > 0:it.i < it.this$0_0.size_0()) {
      handler = this$static.isReverseOrder?$previous(it):$next(it);
      try {
        event_0.dispatch(dynamicCast(handler, Q$EventHandler));
      }
       catch ($e0) {
        $e0 = caught_0($e0);
        if (instanceOf($e0, Q$Throwable)) {
          e = $e0;
          !causes && (causes = new HashSet_0);
          $add_0(causes, e);
        }
         else 
          throw $e0;
      }
    }
    if (causes) {
      throw new UmbrellaException_1(causes);
    }
  }
   finally {
    --this$static.firingDepth;
    this$static.firingDepth == 0 && $handleQueuedAddsAndRemoves(this$static);
  }
}

function $ensureHandlerList(this$static, type, source){
  var handlers, sourceMap;
  sourceMap = dynamicCast(this$static.map.get_0(type), Q$Map);
  if (!sourceMap) {
    sourceMap = new HashMap_0;
    this$static.map.put(type, sourceMap);
  }
  handlers = dynamicCast(sourceMap.get_0(source), Q$List);
  if (!handlers) {
    handlers = new ArrayList_0;
    sourceMap.put(source, handlers);
  }
  return handlers;
}

function $getDispatchList(this$static, type){
  var directHandlers;
  directHandlers = $getHandlerList(this$static, type);
  return directHandlers;
}

function $getHandlerList(this$static, type){
  var handlers, sourceMap;
  sourceMap = dynamicCast(this$static.map.get_0(type), Q$Map);
  if (!sourceMap) {
    return $clinit_Collections() , $clinit_Collections() , EMPTY_LIST;
  }
  handlers = dynamicCast(sourceMap.get_0(null), Q$List);
  if (!handlers) {
    return $clinit_Collections() , $clinit_Collections() , EMPTY_LIST;
  }
  return handlers;
}

function $handleQueuedAddsAndRemoves(this$static){
  var c, c$iterator;
  if (this$static.deferredDeltas) {
    try {
      for (c$iterator = new AbstractList$IteratorImpl_0(this$static.deferredDeltas); c$iterator.i < c$iterator.this$0_0.size_0();) {
        c = dynamicCast($next(c$iterator), Q$SimpleEventBus$Command);
        $doAddNow(c.this$0, c.val$type, c.val$source, c.val$handler);
      }
    }
     finally {
      this$static.deferredDeltas = null;
    }
  }
}

function SimpleEventBus(){
}

_ = SimpleEventBus.prototype = new EventBus;
_.getClass$ = function getClass_27(){
  return Lcom_google_web_bindery_event_shared_SimpleEventBus_2_classLit;
}
;
_.deferredDeltas = null;
_.firingDepth = 0;
_.isReverseOrder = false;
function HandlerManager$Bus_0(){
  this.map = new HashMap_0;
  this.isReverseOrder = false;
}

function HandlerManager$Bus(){
}

_ = HandlerManager$Bus_0.prototype = HandlerManager$Bus.prototype = new SimpleEventBus;
_.getClass$ = function getClass_28(){
  return Lcom_google_gwt_event_shared_HandlerManager$Bus_2_classLit;
}
;
function LegacyHandlerWrapper_0(){
}

function LegacyHandlerWrapper(){
}

_ = LegacyHandlerWrapper_0.prototype = LegacyHandlerWrapper.prototype = new Object_0;
_.getClass$ = function getClass_29(){
  return Lcom_google_gwt_event_shared_LegacyHandlerWrapper_2_classLit;
}
;
function UmbrellaException_1(causes){
  RuntimeException_1.call(this, causes.size_0() == 0?null:dynamicCast(causes.toArray(initDim(_3Ljava_lang_Throwable_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Object_$1, Q$Throwable_$1]), Q$Throwable, 0, 0)), Q$Throwable_$1)[0]);
  this.causes = causes;
}

function UmbrellaException_0(){
}

_ = UmbrellaException_1.prototype = UmbrellaException_0.prototype = new RuntimeException;
_.getClass$ = function getClass_30(){
  return Lcom_google_web_bindery_event_shared_UmbrellaException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$UmbrellaException, Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
_.causes = null;
function UmbrellaException_2(causes){
  UmbrellaException_1.call(this, causes);
}

function UmbrellaException(){
}

_ = UmbrellaException_2.prototype = UmbrellaException.prototype = new UmbrellaException_0;
_.getClass$ = function getClass_31(){
  return Lcom_google_gwt_event_shared_UmbrellaException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$UmbrellaException, Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $cancel(this$static){
  var xmlHttp;
  if (this$static.xmlHttpRequest) {
    xmlHttp = this$static.xmlHttpRequest;
    this$static.xmlHttpRequest = null;
    $clearOnReadyStateChange(xmlHttp);
    xmlHttp.abort();
    !!this$static.timer && $cancel_0(this$static.timer);
  }
}

function $fireOnResponseReceived(this$static, callback){
  var errorMsg, exception, response, xhr;
  if (!this$static.xmlHttpRequest) {
    return;
  }
  !!this$static.timer && $cancel_0(this$static.timer);
  xhr = this$static.xmlHttpRequest;
  this$static.xmlHttpRequest = null;
  errorMsg = $getBrowserSpecificFailure(xhr);
  if (errorMsg != null) {
    exception = new RuntimeException_0(errorMsg);
    callback.onError(this$static, exception);
  }
   else {
    response = new Request$1_0(xhr);
    callback.onResponseReceived(this$static, response);
  }
}

function $fireOnTimeout(this$static, callback){
  if (!this$static.xmlHttpRequest) {
    return;
  }
  $cancel(this$static);
  callback.onError(this$static, new RequestTimeoutException_0(this$static.timeoutMillis));
}

function $getBrowserSpecificFailure(xhr){
  try {
    if (xhr.status === undefined) {
      return 'XmlHttpRequest.status == undefined, please see Safari bug http://bugs.webkit.org/show_bug.cgi?id=3810 for more details';
    }
    return null;
  }
   catch (e) {
    return 'Unable to read XmlHttpRequest.status; likely causes are a networking error or bad cross-domain request. Please see https://bugzilla.mozilla.org/show_bug.cgi?id=238559 for more details';
  }
}

function Request_0(xmlHttpRequest, timeoutMillis, callback){
  if (!xmlHttpRequest) {
    throw new NullPointerException_0;
  }
  if (!callback) {
    throw new NullPointerException_0;
  }
  if (timeoutMillis < 0) {
    throw new IllegalArgumentException_0;
  }
  this.timeoutMillis = timeoutMillis;
  this.xmlHttpRequest = xmlHttpRequest;
  if (timeoutMillis > 0) {
    this.timer = new Request$3_0(this, callback);
    $schedule(this.timer, timeoutMillis);
  }
   else {
    this.timer = null;
  }
}

function Request(){
}

_ = Request_0.prototype = Request.prototype = new Object_0;
_.getClass$ = function getClass_32(){
  return Lcom_google_gwt_http_client_Request_2_classLit;
}
;
_.timeoutMillis = 0;
_.timer = null;
_.xmlHttpRequest = null;
function Response(){
}

_ = Response.prototype = new Object_0;
_.getClass$ = function getClass_33(){
  return Lcom_google_gwt_http_client_Response_2_classLit;
}
;
function Request$1_0(val$xmlHttpRequest){
  this.val$xmlHttpRequest = val$xmlHttpRequest;
}

function Request$1(){
}

_ = Request$1_0.prototype = Request$1.prototype = new Response;
_.getClass$ = function getClass_34(){
  return Lcom_google_gwt_http_client_Request$1_2_classLit;
}
;
_.val$xmlHttpRequest = null;
function $clinit_Timer(){
  $clinit_Timer = nullMethod;
  timers = new ArrayList_0;
  addCloseHandler(new Timer$1_0);
}

function $cancel_0(this$static){
  this$static.isRepeating?clearInterval_0(this$static.timerId):clearTimeout_0(this$static.timerId);
  $remove(timers, this$static);
}

function $schedule(this$static, delayMillis){
  if (delayMillis <= 0) {
    throw new IllegalArgumentException_1('must be positive');
  }
  this$static.isRepeating?clearInterval_0(this$static.timerId):clearTimeout_0(this$static.timerId);
  $remove(timers, this$static);
  this$static.isRepeating = false;
  this$static.timerId = createTimeout(this$static, delayMillis);
  $add(timers, this$static);
}

function clearInterval_0(id){
  $wnd.clearInterval(id);
}

function clearTimeout_0(id){
  $wnd.clearTimeout(id);
}

function createTimeout(timer, delay){
  return $wnd.setTimeout($entry(function(){
    timer.fire();
  }
  ), delay);
}

function Timer(){
}

_ = Timer.prototype = new Object_0;
_.fire = function fire_0(){
  this.isRepeating || $remove(timers, this);
  $fireOnTimeout(this.this$0, this.val$callback);
}
;
_.getClass$ = function getClass_35(){
  return Lcom_google_gwt_user_client_Timer_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Timer]);
_.isRepeating = false;
_.timerId = 0;
var timers;
function Request$3_0(this$0, val$callback){
  $clinit_Timer();
  this.this$0 = this$0;
  this.val$callback = val$callback;
}

function Request$3(){
}

_ = Request$3_0.prototype = Request$3.prototype = new Timer;
_.getClass$ = function getClass_36(){
  return Lcom_google_gwt_http_client_Request$3_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Timer]);
_.this$0 = null;
_.val$callback = null;
function $clinit_RequestBuilder(){
  $clinit_RequestBuilder = nullMethod;
  new RequestBuilder$Method_0('DELETE');
  GET = new RequestBuilder$Method_0('GET');
  new RequestBuilder$Method_0('HEAD');
  POST = new RequestBuilder$Method_0('POST');
  new RequestBuilder$Method_0('PUT');
}

function $doSend(this$static, requestData, callback){
  var $e0, e, request, requestPermissionException, xmlHttpRequest;
  xmlHttpRequest = create_1();
  try {
    $open(xmlHttpRequest, this$static.httpMethod, this$static.url);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$JavaScriptException)) {
      e = $e0;
      requestPermissionException = new RequestPermissionException_0(this$static.url);
      $initCause(requestPermissionException, new RequestException_0(e.getMessage()));
      throw requestPermissionException;
    }
     else 
      throw $e0;
  }
  $setHeaders(this$static, xmlHttpRequest);
  request = new Request_0(xmlHttpRequest, this$static.timeoutMillis, callback);
  $setOnReadyStateChange(xmlHttpRequest, new RequestBuilder$1_0(request, callback));
  try {
    xmlHttpRequest.send(requestData);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$JavaScriptException)) {
      e = $e0;
      throw new RequestException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return request;
}

function $setHeader(this$static, header, value){
  throwIfEmptyOrNull('header', header);
  throwIfEmptyOrNull('value', value);
  !this$static.headers && (this$static.headers = new HashMap_0);
  this$static.headers.put(header, value);
}

function $setHeaders(this$static, xmlHttpRequest){
  var $e0, e, header, header$iterator;
  if (!!this$static.headers && this$static.headers.size_0() > 0) {
    for (header$iterator = this$static.headers.entrySet().iterator(); header$iterator.hasNext();) {
      header = dynamicCast(header$iterator.next_0(), Q$Map$Entry);
      try {
        $setRequestHeader(xmlHttpRequest, dynamicCast(header.getKey_0(), Q$String), dynamicCast(header.getValue(), Q$String));
      }
       catch ($e0) {
        $e0 = caught_0($e0);
        if (instanceOf($e0, Q$JavaScriptException)) {
          e = $e0;
          throw new RequestException_0(e.getMessage());
        }
         else 
          throw $e0;
      }
    }
  }
   else {
    xmlHttpRequest.setRequestHeader('Content-Type', 'text/plain; charset=utf-8');
  }
}

function RequestBuilder_0(httpMethod, url){
  $clinit_RequestBuilder();
  RequestBuilder_1.call(this, !httpMethod?null:httpMethod.name_0, url);
}

function RequestBuilder_1(httpMethod, url){
  throwIfEmptyOrNull('httpMethod', httpMethod);
  throwIfEmptyOrNull('url', url);
  this.httpMethod = httpMethod;
  this.url = url;
}

function RequestBuilder(){
}

_ = RequestBuilder_0.prototype = RequestBuilder.prototype = new Object_0;
_.getClass$ = function getClass_37(){
  return Lcom_google_gwt_http_client_RequestBuilder_2_classLit;
}
;
_.headers = null;
_.httpMethod = null;
_.timeoutMillis = 0;
_.url = null;
var GET, POST;
function RequestBuilder$1_0(val$request, val$callback){
  this.val$request = val$request;
  this.val$callback = val$callback;
}

function RequestBuilder$1(){
}

_ = RequestBuilder$1_0.prototype = RequestBuilder$1.prototype = new Object_0;
_.getClass$ = function getClass_38(){
  return Lcom_google_gwt_http_client_RequestBuilder$1_2_classLit;
}
;
_.onReadyStateChange = function onReadyStateChange(xhr){
  if (xhr.readyState == 4) {
    $clearOnReadyStateChange(xhr);
    $fireOnResponseReceived(this.val$request, this.val$callback);
  }
}
;
_.val$callback = null;
_.val$request = null;
function RequestBuilder$Method_0(name_0){
  this.name_0 = name_0;
}

function RequestBuilder$Method(){
}

_ = RequestBuilder$Method_0.prototype = RequestBuilder$Method.prototype = new Object_0;
_.getClass$ = function getClass_39(){
  return Lcom_google_gwt_http_client_RequestBuilder$Method_2_classLit;
}
;
_.toString$ = function toString_4(){
  return this.name_0;
}
;
_.name_0 = null;
function RequestException_0(message){
  Exception_0.call(this, message);
}

function RequestException(){
}

_ = RequestException_0.prototype = RequestException.prototype = new Exception;
_.getClass$ = function getClass_40(){
  return Lcom_google_gwt_http_client_RequestException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$Throwable]);
function RequestPermissionException_0(url){
  $fillInStackTrace();
  this.detailMessage = 'The URL ' + url + ' is invalid or violates the same-origin security restriction';
}

function RequestPermissionException(){
}

_ = RequestPermissionException_0.prototype = RequestPermissionException.prototype = new RequestException;
_.getClass$ = function getClass_41(){
  return Lcom_google_gwt_http_client_RequestPermissionException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$Throwable]);
function RequestTimeoutException_0(timeoutMillis){
  $fillInStackTrace();
  this.detailMessage = 'A request timeout has expired after ' + timeoutMillis + ' ms';
}

function RequestTimeoutException(){
}

_ = RequestTimeoutException_0.prototype = RequestTimeoutException.prototype = new RequestException;
_.getClass$ = function getClass_42(){
  return Lcom_google_gwt_http_client_RequestTimeoutException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$Throwable]);
function throwIfEmptyOrNull(name_0, value){
  throwIfNull(name_0, value);
  if (0 == $trim(value).length) {
    throw new IllegalArgumentException_1(name_0 + ' cannot be empty');
  }
}

function throwIfNull(name_0, value){
  if (null == value) {
    throw new NullPointerException_1(name_0 + ' cannot be null');
  }
}

function encode(decodedURL){
  throwIfNull('decodedURL', decodedURL);
  return encodeURI(decodedURL);
}

function JSONValue(){
}

_ = JSONValue.prototype = new Object_0;
_.getClass$ = function getClass_43(){
  return Lcom_google_gwt_json_client_JSONValue_2_classLit;
}
;
_.isString = function isString(){
  return null;
}
;
function $get(this$static, index){
  var v = this$static.jsArray[index];
  var func = ($clinit_JSONParser() , typeMap)[typeof v];
  return func?func(v):throwUnknownTypeException(typeof v);
}

function $set(this$static, index, value){
  var previous;
  previous = $get(this$static, index);
  $set0(this$static, index, value);
  return previous;
}

function $set0(this$static, index, value){
  if (value) {
    var func = value.getUnwrapper();
    value = func(value);
  }
   else {
    value = undefined;
  }
  this$static.jsArray[index] = value;
}

function JSONArray_0(){
  this.jsArray = [];
}

function JSONArray_1(arr){
  this.jsArray = arr;
}

function unwrap(value){
  return value.jsArray;
}

function JSONArray(){
}

_ = JSONArray_1.prototype = JSONArray_0.prototype = JSONArray.prototype = new JSONValue;
_.equals$ = function equals_0(other){
  if (!instanceOf(other, Q$JSONArray)) {
    return false;
  }
  return this.jsArray == dynamicCast(other, Q$JSONArray).jsArray;
}
;
_.getClass$ = function getClass_44(){
  return Lcom_google_gwt_json_client_JSONArray_2_classLit;
}
;
_.getUnwrapper = function getUnwrapper(){
  return unwrap;
}
;
_.hashCode$ = function hashCode_2(){
  return getHashCode(this.jsArray);
}
;
_.toString$ = function toString_5(){
  var c, i_0, sb;
  sb = new StringBuffer_0;
  sb.impl.string += '[';
  for (i_0 = 0 , c = this.jsArray.length; i_0 < c; ++i_0) {
    i_0 > 0 && (sb.impl.string += ',' , sb);
    $append_1(sb, $get(this, i_0));
  }
  sb.impl.string += ']';
  return sb.impl.string;
}
;
_.castableTypeMap$ = makeCastMap([Q$JSONArray]);
_.jsArray = null;
function $clinit_JSONBoolean(){
  $clinit_JSONBoolean = nullMethod;
  FALSE = new JSONBoolean_0(false);
  TRUE = new JSONBoolean_0(true);
}

function JSONBoolean_0(value){
  this.value = value;
}

function unwrap_0(value){
  return value.value;
}

function JSONBoolean(){
}

_ = JSONBoolean_0.prototype = JSONBoolean.prototype = new JSONValue;
_.getClass$ = function getClass_45(){
  return Lcom_google_gwt_json_client_JSONBoolean_2_classLit;
}
;
_.getUnwrapper = function getUnwrapper_0(){
  return unwrap_0;
}
;
_.toString$ = function toString_6(){
  return $clinit_Boolean() , '' + this.value;
}
;
_.castableTypeMap$ = makeCastMap([Q$JSONBoolean]);
_.value = false;
var FALSE, TRUE;
function JSONException_0(){
  $fillInStackTrace();
}

function JSONException_1(message){
  RuntimeException_0.call(this, message);
}

function JSONException_2(cause){
  $fillInStackTrace();
  this.detailMessage = !cause?null:$toString(cause);
  this.cause = cause;
}

function JSONException(){
}

_ = JSONException_2.prototype = JSONException_1.prototype = JSONException_0.prototype = JSONException.prototype = new RuntimeException;
_.getClass$ = function getClass_46(){
  return Lcom_google_gwt_json_client_JSONException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $clinit_JSONNull(){
  $clinit_JSONNull = nullMethod;
  instance_0 = new JSONNull_0;
}

function JSONNull_0(){
}

function unwrap_1(){
  return null;
}

function JSONNull(){
}

_ = JSONNull_0.prototype = JSONNull.prototype = new JSONValue;
_.getClass$ = function getClass_47(){
  return Lcom_google_gwt_json_client_JSONNull_2_classLit;
}
;
_.getUnwrapper = function getUnwrapper_1(){
  return unwrap_1;
}
;
_.toString$ = function toString_7(){
  return 'null';
}
;
_.castableTypeMap$ = makeCastMap([Q$JSONNull]);
var instance_0;
function JSONNumber_0(value){
  this.value = value;
}

function unwrap_2(value){
  return value.value;
}

function JSONNumber(){
}

_ = JSONNumber_0.prototype = JSONNumber.prototype = new JSONValue;
_.equals$ = function equals_1(other){
  if (!instanceOf(other, Q$JSONNumber)) {
    return false;
  }
  return this.value == dynamicCast(other, Q$JSONNumber).value;
}
;
_.getClass$ = function getClass_48(){
  return Lcom_google_gwt_json_client_JSONNumber_2_classLit;
}
;
_.getUnwrapper = function getUnwrapper_2(){
  return unwrap_2;
}
;
_.hashCode$ = function hashCode_3(){
  return round_int((new Double_0(this.value)).value);
}
;
_.toString$ = function toString_8(){
  return this.value + '';
}
;
_.castableTypeMap$ = makeCastMap([Q$JSONNumber]);
_.value = 0;
function $computeKeys0(this$static, result){
  var jsObject = this$static.jsObject;
  var i_0 = 0;
  for (var key in jsObject) {
    jsObject.hasOwnProperty(key) && (result[i_0++] = key);
  }
  return result;
}

function $get_0(this$static, key){
  if (key == null) {
    throw new NullPointerException_0;
  }
  return $get0(this$static, key);
}

function $get0(this$static, key){
  var jsObject = this$static.jsObject;
  var v;
  key = String(key);
  jsObject.hasOwnProperty(key) && (v = jsObject[key]);
  var func = ($clinit_JSONParser() , typeMap)[typeof v];
  var ret = func?func(v):throwUnknownTypeException(typeof v);
  return ret;
}

function $put(this$static, key, jsonValue){
  var previous;
  if (key == null) {
    throw new NullPointerException_0;
  }
  previous = $get_0(this$static, key);
  $put0(this$static, key, jsonValue);
  return previous;
}

function $put0(this$static, key, value){
  if (value) {
    var func = value.getUnwrapper();
    this$static.jsObject[key] = func(value);
  }
   else {
    delete this$static.jsObject[key];
  }
}

function JSONObject_0(){
  JSONObject_1.call(this, {});
}

function JSONObject_1(jsValue){
  this.jsObject = jsValue;
}

function unwrap_3(value){
  return value.jsObject;
}

function JSONObject(){
}

_ = JSONObject_1.prototype = JSONObject_0.prototype = JSONObject.prototype = new JSONValue;
_.equals$ = function equals_2(other){
  if (!instanceOf(other, Q$JSONObject)) {
    return false;
  }
  return this.jsObject == dynamicCast(other, Q$JSONObject).jsObject;
}
;
_.getClass$ = function getClass_49(){
  return Lcom_google_gwt_json_client_JSONObject_2_classLit;
}
;
_.getUnwrapper = function getUnwrapper_3(){
  return unwrap_3;
}
;
_.hashCode$ = function hashCode_4(){
  return getHashCode(this.jsObject);
}
;
_.toString$ = function toString_9(){
  var first, key, key$index, key$max, keys, sb;
  sb = new StringBuffer_0;
  sb.impl.string += '{';
  first = true;
  keys = $computeKeys0(this, initDim(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, 0, 0));
  for (key$index = 0 , key$max = keys.length; key$index < key$max; ++key$index) {
    key = keys[key$index];
    first?(first = false):(sb.impl.string += ', ' , sb);
    $append_2(sb, escapeValue(key));
    sb.impl.string += ':';
    $append_1(sb, $get_0(this, key));
  }
  sb.impl.string += '}';
  return sb.impl.string;
}
;
_.castableTypeMap$ = makeCastMap([Q$JSONObject]);
_.jsObject = null;
function $clinit_JSONParser(){
  $clinit_JSONParser = nullMethod;
  typeMap = {'boolean':createBoolean, number:createNumber, string:createString, object:createObject, 'function':createObject, undefined:createUndefined};
}

function createBoolean(v){
  return $clinit_JSONBoolean() , v?TRUE:FALSE;
}

function createNumber(v){
  return new JSONNumber_0(v);
}

function createObject(o){
  if (!o) {
    return $clinit_JSONNull() , instance_0;
  }
  var v = o.valueOf?o.valueOf():o;
  if (v !== o) {
    var func = typeMap[typeof v];
    return func?func(v):throwUnknownTypeException(typeof v);
  }
   else if (o instanceof Array || o instanceof $wnd.Array) {
    return new JSONArray_1(o);
  }
   else {
    return new JSONObject_1(o);
  }
}

function createString(v){
  return new JSONString_0(v);
}

function createUndefined(){
  return null;
}

function evaluate(json, strict){
  var v;
  if (strict && ($clinit_JsonUtils() , hasJsonParse)) {
    try {
      v = JSON.parse(json);
    }
     catch (e) {
      return throwJSONException('Error parsing JSON: ' + e);
    }
  }
   else {
    if (strict) {
      if (!($clinit_JsonUtils() , !/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(json.replace(/"(\\.|[^"\\])*"/g, '')))) {
        return throwJSONException('Illegal character in JSON string');
      }
    }
    json = escapeJsonForEval(json);
    try {
      v = eval('(' + json + ')');
    }
     catch (e) {
      return throwJSONException('Error parsing JSON: ' + e);
    }
  }
  var func = typeMap[typeof v];
  return func?func(v):throwUnknownTypeException(typeof v);
}

function parse(jsonString){
  $clinit_JSONParser();
  var $e0, ex;
  if (jsonString == null) {
    throw new NullPointerException_0;
  }
  if (jsonString.length == 0) {
    throw new IllegalArgumentException_1('empty argument');
  }
  try {
    return evaluate(jsonString, false);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$JavaScriptException)) {
      ex = $e0;
      throw new JSONException_2(ex);
    }
     else 
      throw $e0;
  }
}

function throwJSONException(message){
  throw new JSONException_1(message);
}

function throwUnknownTypeException(typeString){
  $clinit_JSONParser();
  throw new JSONException_1("Unexpected typeof result '" + typeString + "'; please report this bug to the GWT team");
}

var typeMap;
function JSONString_0(value){
  if (value == null) {
    throw new NullPointerException_0;
  }
  this.value = value;
}

function unwrap_4(value){
  return value.value;
}

function JSONString(){
}

_ = JSONString_0.prototype = JSONString.prototype = new JSONValue;
_.equals$ = function equals_3(other){
  if (!instanceOf(other, Q$JSONString)) {
    return false;
  }
  return $equals(this.value, dynamicCast(other, Q$JSONString).value);
}
;
_.getClass$ = function getClass_50(){
  return Lcom_google_gwt_json_client_JSONString_2_classLit;
}
;
_.getUnwrapper = function getUnwrapper_4(){
  return unwrap_4;
}
;
_.hashCode$ = function hashCode_5(){
  return getHashCode_0(this.value);
}
;
_.isString = function isString_0(){
  return this;
}
;
_.toString$ = function toString_10(){
  return escapeValue(this.value);
}
;
_.castableTypeMap$ = makeCastMap([Q$JSONString]);
_.value = null;
function Array_1(){
}

function createFrom(array, length_0){
  var a, result;
  a = array;
  result = createFromSeed(0, length_0);
  initValues(a.arrayClass$, a.castableTypeMap$, a.queryId$, result);
  return result;
}

function createFromSeed(seedType, length_0){
  var array = new Array(length_0);
  if (seedType == 3) {
    for (var i_0 = 0; i_0 < length_0; ++i_0) {
      var value = new Object;
      value.l = value.m = value.h = 0;
      array[i_0] = value;
    }
  }
   else if (seedType > 0) {
    var value = [null, 0, false][seedType];
    for (var i_0 = 0; i_0 < length_0; ++i_0) {
      array[i_0] = value;
    }
  }
  return array;
}

function initDim(arrayClass, castableTypeMap, queryId, length_0, seedType){
  var result;
  result = createFromSeed(seedType, length_0);
  initValues(arrayClass, castableTypeMap, queryId, result);
  return result;
}

function initValues(arrayClass, castableTypeMap, queryId, array){
  $clinit_Array$ExpandoWrapper();
  wrapArray(array, expandoNames_0, expandoValues_0);
  array.arrayClass$ = arrayClass;
  array.castableTypeMap$ = castableTypeMap;
  array.queryId$ = queryId;
  return array;
}

function setCheck(array, index, value){
  if (value != null) {
    if (array.queryId$ > 0 && !canCastUnsafe(value, array.queryId$)) {
      throw new ArrayStoreException_0;
    }
    if (array.queryId$ < 0 && (value.typeMarker$ == nullMethod || canCast(value, 1))) {
      throw new ArrayStoreException_0;
    }
  }
  return array[index] = value;
}

function Array_0(){
}

_ = Array_1.prototype = Array_0.prototype = new Object_0;
_.getClass$ = function getClass_51(){
  return this.arrayClass$;
}
;
_.arrayClass$ = null;
_.queryId$ = 0;
function $clinit_Array$ExpandoWrapper(){
  $clinit_Array$ExpandoWrapper = nullMethod;
  expandoNames_0 = [];
  expandoValues_0 = [];
  initExpandos(new Array_1, expandoNames_0, expandoValues_0);
}

function initExpandos(protoType, expandoNames, expandoValues){
  var i_0 = 0, value;
  for (var name_0 in protoType) {
    if (value = protoType[name_0]) {
      expandoNames[i_0] = name_0;
      expandoValues[i_0] = value;
      ++i_0;
    }
  }
}

function wrapArray(array, expandoNames, expandoValues){
  $clinit_Array$ExpandoWrapper();
  for (var i_0 = 0, c = expandoNames.length; i_0 < c; ++i_0) {
    array[expandoNames[i_0]] = expandoValues[i_0];
  }
}

var expandoNames_0, expandoValues_0;
function canCast(src, dstId){
  return src.castableTypeMap$ && !!src.castableTypeMap$[dstId];
}

function canCastUnsafe(src, dstId){
  return src.castableTypeMap$ && src.castableTypeMap$[dstId];
}

function dynamicCast(src, dstId){
  if (src != null && !canCastUnsafe(src, dstId)) {
    throw new ClassCastException_0;
  }
  return src;
}

function dynamicCastJso(src){
  if (src != null && (src.typeMarker$ == nullMethod || canCast(src, 1))) {
    throw new ClassCastException_0;
  }
  return src;
}

function instanceOf(src, dstId){
  return src != null && canCast(src, dstId);
}

function instanceOfJso(src){
  return src != null && src.typeMarker$ != nullMethod && !canCast(src, 1);
}

function isJavaObject(src){
  return src.typeMarker$ == nullMethod || canCast(src, 1);
}

function maskUndefined(src){
  return src == null?null:src;
}

function round_int(x){
  return ~~Math.max(Math.min(x, 2147483647), -2147483648);
}

function throwClassCastExceptionUnlessNull(o){
  if (o != null) {
    throw new ClassCastException_0;
  }
  return null;
}

function init(){
  var runtimeValue;
  !!$stats && onModuleStart('com.google.gwt.user.client.UserAgentAsserter');
  runtimeValue = $getRuntimeValue();
  $equals('gecko1_8', runtimeValue) || ($wnd.alert('ERROR: Possible problem with your *.gwt.xml module file.\nThe compile time user.agent value (gecko1_8) does not match the runtime user.agent value (' + runtimeValue + '). Expect more errors.\n') , undefined);
  !!$stats && onModuleStart('com.google.gwt.user.client.DocumentModeAsserter');
  $onModuleLoad();
  !!$stats && onModuleStart('com.kfuntak.gwt.json.serialization.client.GWTProJsonSerializer');
  !!$stats && onModuleStart('net.wacapps.napi.util.NAPIEntryPoint');
  $clinit_ExporterUtil();
  new ExportAllExporterImpl_0;
  $wnd.jscOnLoad && typeof $wnd.jscOnLoad == 'function' && $wnd.jscOnLoad();
}

function caught_0(e){
  if (instanceOf(e, Q$Throwable)) {
    return e;
  }
  return new JavaScriptException_0(e);
}

function create(value){
  var a0, a1, a2;
  a0 = value & 4194303;
  a1 = value >> 22 & 4194303;
  a2 = value < 0?1048575:0;
  return create0(a0, a1, a2);
}

function create_0(a){
  return create0(a.l, a.m, a.h);
}

function create0(l_0, m_0, h_0){
  return _ = new LongLibBase$LongEmul_0 , _.l = l_0 , _.m = m_0 , _.h = h_0 , _;
}

function divMod(a, b, computeRemainder){
  var aIsCopy, aIsMinValue, aIsNegative, bpower, c, negative;
  if (b.l == 0 && b.m == 0 && b.h == 0) {
    throw new ArithmeticException_0;
  }
  if (a.l == 0 && a.m == 0 && a.h == 0) {
    computeRemainder && (remainder = create0(0, 0, 0));
    return create0(0, 0, 0);
  }
  if (b.h == 524288 && b.m == 0 && b.l == 0) {
    return divModByMinValue(a, computeRemainder);
  }
  negative = false;
  if (b.h >> 19 != 0) {
    b = neg(b);
    negative = true;
  }
  bpower = powerOfTwo(b);
  aIsNegative = false;
  aIsMinValue = false;
  aIsCopy = false;
  if (a.h == 524288 && a.m == 0 && a.l == 0) {
    aIsMinValue = true;
    aIsNegative = true;
    if (bpower == -1) {
      a = create_0(($clinit_LongLib$Const() , MAX_VALUE));
      aIsCopy = true;
      negative = !negative;
    }
     else {
      c = shr(a, bpower);
      negative && negate(c);
      computeRemainder && (remainder = create0(0, 0, 0));
      return c;
    }
  }
   else if (a.h >> 19 != 0) {
    aIsNegative = true;
    a = neg(a);
    aIsCopy = true;
    negative = !negative;
  }
  if (bpower != -1) {
    return divModByShift(a, bpower, negative, aIsNegative, computeRemainder);
  }
  if (!gte_0(a, b)) {
    computeRemainder && (aIsNegative?(remainder = neg(a)):(remainder = create0(a.l, a.m, a.h)));
    return create0(0, 0, 0);
  }
  return divModHelper(aIsCopy?a:create0(a.l, a.m, a.h), b, negative, aIsNegative, aIsMinValue, computeRemainder);
}

function divModByMinValue(a, computeRemainder){
  if (a.h == 524288 && a.m == 0 && a.l == 0) {
    computeRemainder && (remainder = create0(0, 0, 0));
    return create_0(($clinit_LongLib$Const() , ONE));
  }
  computeRemainder && (remainder = create0(a.l, a.m, a.h));
  return create0(0, 0, 0);
}

function divModByShift(a, bpower, negative, aIsNegative, computeRemainder){
  var c;
  c = shr(a, bpower);
  negative && negate(c);
  if (computeRemainder) {
    a = maskRight(a, bpower);
    aIsNegative?(remainder = neg(a)):(remainder = create0(a.l, a.m, a.h));
  }
  return c;
}

function divModHelper(a, b, negative, aIsNegative, aIsMinValue, computeRemainder){
  var bshift, gte, quotient, shift, a0, a1, a2;
  shift = numberOfLeadingZeros(b) - numberOfLeadingZeros(a);
  bshift = shl(b, shift);
  quotient = create0(0, 0, 0);
  while (shift >= 0) {
    gte = trialSubtract(a, bshift);
    if (gte) {
      shift < 22?(quotient.l |= 1 << shift , undefined):shift < 44?(quotient.m |= 1 << shift - 22 , undefined):(quotient.h |= 1 << shift - 44 , undefined);
      if (a.l == 0 && a.m == 0 && a.h == 0) {
        break;
      }
    }
    a1 = bshift.m;
    a2 = bshift.h;
    a0 = bshift.l;
    bshift.h = a2 >>> 1;
    bshift.m = a1 >>> 1 | (a2 & 1) << 21;
    bshift.l = a0 >>> 1 | (a1 & 1) << 21;
    --shift;
  }
  negative && negate(quotient);
  if (computeRemainder) {
    if (aIsNegative) {
      remainder = neg(a);
      aIsMinValue && (remainder = sub(remainder, ($clinit_LongLib$Const() , ONE)));
    }
     else {
      remainder = create0(a.l, a.m, a.h);
    }
  }
  return quotient;
}

function maskRight(a, bits){
  var b0, b1, b2;
  if (bits <= 22) {
    b0 = a.l & (1 << bits) - 1;
    b1 = b2 = 0;
  }
   else if (bits <= 44) {
    b0 = a.l;
    b1 = a.m & (1 << bits - 22) - 1;
    b2 = 0;
  }
   else {
    b0 = a.l;
    b1 = a.m;
    b2 = a.h & (1 << bits - 44) - 1;
  }
  return create0(b0, b1, b2);
}

function negate(a){
  var neg0, neg1, neg2;
  neg0 = ~a.l + 1 & 4194303;
  neg1 = ~a.m + (neg0 == 0?1:0) & 4194303;
  neg2 = ~a.h + (neg0 == 0 && neg1 == 0?1:0) & 1048575;
  a.l = neg0;
  a.m = neg1;
  a.h = neg2;
}

function numberOfLeadingZeros(a){
  var b1, b2;
  b2 = numberOfLeadingZeros_0(a.h);
  if (b2 == 32) {
    b1 = numberOfLeadingZeros_0(a.m);
    return b1 == 32?numberOfLeadingZeros_0(a.l) + 32:b1 + 20 - 10;
  }
   else {
    return b2 - 12;
  }
}

function powerOfTwo(a){
  var h_0, l_0, m_0;
  l_0 = a.l;
  if ((l_0 & l_0 - 1) != 0) {
    return -1;
  }
  m_0 = a.m;
  if ((m_0 & m_0 - 1) != 0) {
    return -1;
  }
  h_0 = a.h;
  if ((h_0 & h_0 - 1) != 0) {
    return -1;
  }
  if (h_0 == 0 && m_0 == 0 && l_0 == 0) {
    return -1;
  }
  if (h_0 == 0 && m_0 == 0 && l_0 != 0) {
    return numberOfTrailingZeros(l_0);
  }
  if (h_0 == 0 && m_0 != 0 && l_0 == 0) {
    return numberOfTrailingZeros(m_0) + 22;
  }
  if (h_0 != 0 && m_0 == 0 && l_0 == 0) {
    return numberOfTrailingZeros(h_0) + 44;
  }
  return -1;
}

function toDoubleHelper(a){
  return a.l + a.m * 4194304 + a.h * 17592186044416;
}

function trialSubtract(a, b){
  var sum0, sum1, sum2;
  sum2 = a.h - b.h;
  if (sum2 < 0) {
    return false;
  }
  sum0 = a.l - b.l;
  sum1 = a.m - b.m + (sum0 >> 22);
  sum2 += sum1 >> 22;
  if (sum2 < 0) {
    return false;
  }
  a.l = sum0 & 4194303;
  a.m = sum1 & 4194303;
  a.h = sum2 & 1048575;
  return true;
}

var remainder = null;
function add(a, b){
  var sum0, sum1, sum2;
  sum0 = a.l + b.l;
  sum1 = a.m + b.m + (sum0 >> 22);
  sum2 = a.h + b.h + (sum1 >> 22);
  return create0(sum0 & 4194303, sum1 & 4194303, sum2 & 1048575);
}

function and(a, b){
  return create0(a.l & b.l, a.m & b.m, a.h & b.h);
}

function div(a, b){
  return divMod(a, b, false);
}

function eq(a, b){
  return a.l == b.l && a.m == b.m && a.h == b.h;
}

function fromDouble(value){
  var a0, a1, a2, negative, result;
  if (isNaN(value)) {
    return $clinit_LongLib$Const() , ZERO;
  }
  if (value < -9223372036854775808) {
    return $clinit_LongLib$Const() , MIN_VALUE;
  }
  if (value >= 9223372036854775807) {
    return $clinit_LongLib$Const() , MAX_VALUE;
  }
  negative = false;
  if (value < 0) {
    negative = true;
    value = -value;
  }
  a2 = 0;
  if (value >= 17592186044416) {
    a2 = round_int(value / 17592186044416);
    value -= a2 * 17592186044416;
  }
  a1 = 0;
  if (value >= 4194304) {
    a1 = round_int(value / 4194304);
    value -= a1 * 4194304;
  }
  a0 = round_int(value);
  result = create0(a0, a1, a2);
  negative && negate(result);
  return result;
}

function fromInt(value){
  var rebase, result;
  if (value > -129 && value < 128) {
    rebase = value + 128;
    boxedValues == null && (boxedValues = initDim(_3Lcom_google_gwt_lang_LongLibBase$LongEmul_2_classLit, makeCastMap([Q$Serializable, Q$Object_$1]), Q$LongLibBase$LongEmul, 256, 0));
    result = boxedValues[rebase];
    !result && (result = boxedValues[rebase] = create(value));
    return result;
  }
  return create(value);
}

function gt(a, b){
  var signa, signb;
  signa = a.h >> 19;
  signb = b.h >> 19;
  return signa == 0?signb != 0 || a.h > b.h || a.h == b.h && a.m > b.m || a.h == b.h && a.m == b.m && a.l > b.l:!(signb == 0 || a.h < b.h || a.h == b.h && a.m < b.m || a.h == b.h && a.m == b.m && a.l <= b.l);
}

function gte_0(a, b){
  var signa, signb;
  signa = a.h >> 19;
  signb = b.h >> 19;
  return signa == 0?signb != 0 || a.h > b.h || a.h == b.h && a.m > b.m || a.h == b.h && a.m == b.m && a.l >= b.l:!(signb == 0 || a.h < b.h || a.h == b.h && a.m < b.m || a.h == b.h && a.m == b.m && a.l < b.l);
}

function lt(a, b){
  return !gte_0(a, b);
}

function mod(a, b){
  divMod(a, b, true);
  return remainder;
}

function neg(a){
  var neg0, neg1, neg2;
  neg0 = ~a.l + 1 & 4194303;
  neg1 = ~a.m + (neg0 == 0?1:0) & 4194303;
  neg2 = ~a.h + (neg0 == 0 && neg1 == 0?1:0) & 1048575;
  return create0(neg0, neg1, neg2);
}

function shl(a, n){
  var res0, res1, res2;
  n &= 63;
  if (n < 22) {
    res0 = a.l << n;
    res1 = a.m << n | a.l >> 22 - n;
    res2 = a.h << n | a.m >> 22 - n;
  }
   else if (n < 44) {
    res0 = 0;
    res1 = a.l << n - 22;
    res2 = a.m << n - 22 | a.l >> 44 - n;
  }
   else {
    res0 = 0;
    res1 = 0;
    res2 = a.l << n - 44;
  }
  return create0(res0 & 4194303, res1 & 4194303, res2 & 1048575);
}

function shr(a, n){
  var a2, negative, res0, res1, res2;
  n &= 63;
  a2 = a.h;
  negative = (a2 & 524288) != 0;
  negative && (a2 |= -1048576);
  if (n < 22) {
    res2 = a2 >> n;
    res1 = a.m >> n | a2 << 22 - n;
    res0 = a.l >> n | a.m << 22 - n;
  }
   else if (n < 44) {
    res2 = negative?1048575:0;
    res1 = a2 >> n - 22;
    res0 = a.m >> n - 22 | a2 << 44 - n;
  }
   else {
    res2 = negative?1048575:0;
    res1 = negative?4194303:0;
    res0 = a2 >> n - 44;
  }
  return create0(res0 & 4194303, res1 & 4194303, res2 & 1048575);
}

function shru(a, n){
  var a2, res0, res1, res2;
  n &= 63;
  a2 = a.h & 1048575;
  if (n < 22) {
    res2 = a2 >>> n;
    res1 = a.m >> n | a2 << 22 - n;
    res0 = a.l >> n | a.m << 22 - n;
  }
   else if (n < 44) {
    res2 = 0;
    res1 = a2 >>> n - 22;
    res0 = a.m >> n - 22 | a.h << 44 - n;
  }
   else {
    res2 = 0;
    res1 = 0;
    res0 = a2 >>> n - 44;
  }
  return create0(res0 & 4194303, res1 & 4194303, res2 & 1048575);
}

function sub(a, b){
  var sum0, sum1, sum2;
  sum0 = a.l - b.l;
  sum1 = a.m - b.m + (sum0 >> 22);
  sum2 = a.h - b.h + (sum1 >> 22);
  return create0(sum0 & 4194303, sum1 & 4194303, sum2 & 1048575);
}

function toDouble(a){
  if (eq(a, ($clinit_LongLib$Const() , MIN_VALUE))) {
    return -9223372036854775808;
  }
  if (!gte_0(a, ZERO)) {
    return -toDoubleHelper(neg(a));
  }
  return a.l + a.m * 4194304 + a.h * 17592186044416;
}

function toInt(a){
  return a.l | a.m << 22;
}

function toString_11(a){
  var digits, rem, res, tenPowerLong, zeroesNeeded;
  if (a.l == 0 && a.m == 0 && a.h == 0) {
    return '0';
  }
  if (a.h == 524288 && a.m == 0 && a.l == 0) {
    return '-9223372036854775808';
  }
  if (a.h >> 19 != 0) {
    return '-' + toString_11(neg(a));
  }
  rem = a;
  res = '';
  while (!(rem.l == 0 && rem.m == 0 && rem.h == 0)) {
    tenPowerLong = fromInt(1000000000);
    rem = divMod(rem, tenPowerLong, true);
    digits = '' + toInt(remainder);
    if (!(rem.l == 0 && rem.m == 0 && rem.h == 0)) {
      zeroesNeeded = 9 - digits.length;
      for (; zeroesNeeded > 0; --zeroesNeeded) {
        digits = '0' + digits;
      }
    }
    res = digits + res;
  }
  return res;
}

var boxedValues = null;
function $clinit_LongLib$Const(){
  $clinit_LongLib$Const = nullMethod;
  MAX_VALUE = create0(4194303, 4194303, 524287);
  MIN_VALUE = create0(0, 0, 524288);
  ONE = fromInt(1);
  fromInt(2);
  ZERO = fromInt(0);
}

var MAX_VALUE, MIN_VALUE, ONE, ZERO;
function LongLibBase$LongEmul_0(){
}

function LongLibBase$LongEmul(){
}

_ = LongLibBase$LongEmul_0.prototype = LongLibBase$LongEmul.prototype = new Object_0;
_.getClass$ = function getClass_52(){
  return Lcom_google_gwt_lang_LongLibBase$LongEmul_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$LongLibBase$LongEmul]);
function onModuleStart(mainClassName){
  return $stats({moduleName:$moduleName, sessionId:$sessionId, subSystem:'startup', evtGroup:'moduleStartup', millis:(new Date).getTime(), type:'onModuleLoadStart', className:mainClassName});
}

function $getItem(this$static, key){
  return $getItem_0(this$static.storage, key);
}

function $setItem(this$static, key, data){
  $setItem_0(this$static.storage, key, data);
}

function Storage_0(storage){
  this.storage = storage;
}

function getLocalStorageIfSupported(){
  !supportDetectorImpl && (supportDetectorImpl = new Storage$StorageSupportDetector_0);
  if (supportDetectorImpl.isLocalStorageSupported) {
    !localStorage_0 && (localStorage_0 = new Storage_0('localStorage'));
    return localStorage_0;
  }
  return null;
}

function getSessionStorageIfSupported(){
  !supportDetectorImpl && (supportDetectorImpl = new Storage$StorageSupportDetector_0);
  if (supportDetectorImpl.isSessionStorageSupported) {
    !sessionStorage_0 && (sessionStorage_0 = new Storage_0('sessionStorage'));
    return sessionStorage_0;
  }
  return null;
}

function Storage(){
}

_ = Storage_0.prototype = Storage.prototype = new Object_0;
_.getClass$ = function getClass_53(){
  return Lcom_google_gwt_storage_client_Storage_2_classLit;
}
;
_.storage = null;
var localStorage_0 = null, sessionStorage_0 = null, supportDetectorImpl = null;
function Storage$StorageSupportDetector_0(){
  this.isLocalStorageSupported = typeof $wnd.localStorage != 'undefined';
  this.isSessionStorageSupported = typeof $wnd.sessionStorage != 'undefined';
}

function Storage$StorageSupportDetector(){
}

_ = Storage$StorageSupportDetector_0.prototype = Storage$StorageSupportDetector.prototype = new Object_0;
_.getClass$ = function getClass_54(){
  return Lcom_google_gwt_storage_client_Storage$StorageSupportDetector_2_classLit;
}
;
function $clear(storage){
  $wnd[storage].clear();
}

function $getItem_0(storage, key){
  return $wnd[storage].getItem(key);
}

function $setItem_0(storage, key, data){
  $wnd[storage].getItem(key);
  $wnd[storage].setItem(key, data);
}

var rawCookies = null;
function $onModuleLoad(){
  var allowedModes, currentMode, i_0;
  currentMode = $doc.compatMode;
  allowedModes = initValues(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, ['CSS1Compat']);
  for (i_0 = 0; i_0 < allowedModes.length; ++i_0) {
    if ($equals(allowedModes[i_0], currentMode)) {
      return;
    }
  }
  allowedModes.length == 1 && $equals('CSS1Compat', allowedModes[0]) && $equals('BackCompat', currentMode)?"GWT no longer supports Quirks Mode (document.compatMode=' BackCompat').<br>Make sure your application's host HTML page has a Standards Mode (document.compatMode=' CSS1Compat') doctype,<br>e.g. by using &lt;!doctype html&gt; at the start of your application's HTML page.<br><br>To continue using this unsupported rendering mode and risk layout problems, suppress this message by adding<br>the following line to your*.gwt.xml module file:<br>&nbsp;&nbsp;&lt;extend-configuration-property name=\"document.compatMode\" value=\"" + currentMode + '"/&gt;':"Your *.gwt.xml module configuration prohibits the use of the current doucment rendering mode (document.compatMode=' " + currentMode + "').<br>Modify your application's host HTML page doctype, or update your custom 'document.compatMode' configuration property settings.";
}

function $onClose(){
  while (($clinit_Timer() , timers).size > 0) {
    $cancel_0(dynamicCast($get_1(timers, 0), Q$Timer));
  }
}

function Timer$1_0(){
}

function Timer$1(){
}

_ = Timer$1_0.prototype = Timer$1.prototype = new Object_0;
_.getClass$ = function getClass_55(){
  return Lcom_google_gwt_user_client_Timer$1_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$EventHandler]);
function $getRuntimeValue(){
  var ua = navigator.userAgent.toLowerCase();
  var makeVersion = function(result){
    return parseInt(result[1]) * 1000 + parseInt(result[2]);
  }
  ;
  if (function(){
    return ua.indexOf('opera') != -1;
  }
  ())
    return 'opera';
  if (function(){
    return ua.indexOf('webkit') != -1 || function(){
      if (ua.indexOf('chromeframe') != -1) {
        return true;
      }
      if (typeof window['ActiveXObject'] != 'undefined') {
        try {
          var obj = new ActiveXObject('ChromeTab.ChromeFrame');
          if (obj) {
            obj.registerBhoIfNeeded();
            return true;
          }
        }
         catch (e) {
        }
      }
      return false;
    }
    ();
  }
  ())
    return 'safari';
  if (function(){
    return ua.indexOf('msie') != -1 && $doc.documentMode >= 9;
  }
  ())
    return 'ie9';
  if (function(){
    return ua.indexOf('msie') != -1 && $doc.documentMode >= 8;
  }
  ())
    return 'ie8';
  if (function(){
    var result = /msie ([0-9]+)\.([0-9]+)/.exec(ua);
    if (result && result.length == 3)
      return makeVersion(result) >= 6000;
  }
  ())
    return 'ie6';
  if (function(){
    return ua.indexOf('gecko') != -1;
  }
  ())
    return 'gecko1_8';
  return 'unknown';
}

function addCloseHandler(handler){
  maybeInitializeCloseHandlers();
  return addHandler(TYPE?TYPE:(TYPE = new GwtEvent$Type_0), handler);
}

function addHandler(type, handler){
  return $addHandler((!handlers_0 && (handlers_0 = new Window$WindowHandlers_0) , handlers_0), type, handler);
}

function alert_0(msg){
  $wnd.alert(msg);
}

function maybeInitializeCloseHandlers(){
  if (!closeHandlersInitialized) {
    $initWindowCloseHandler();
    closeHandlersInitialized = true;
  }
}

function onClosing(){
  var event_0;
  if (closeHandlersInitialized) {
    event_0 = new Window$ClosingEvent_0;
    !!handlers_0 && $fireEvent(handlers_0, event_0);
    return null;
  }
  return null;
}

var closeHandlersInitialized = false, handlers_0 = null;
function $clinit_Window$ClosingEvent(){
  $clinit_Window$ClosingEvent = nullMethod;
  TYPE_0 = new GwtEvent$Type_0;
}

function Window$ClosingEvent_0(){
  $clinit_Window$ClosingEvent();
}

function Window$ClosingEvent(){
}

_ = Window$ClosingEvent_0.prototype = Window$ClosingEvent.prototype = new GwtEvent;
_.dispatch = function dispatch_0(handler){
  throwClassCastExceptionUnlessNull(handler);
  null.nullMethod();
}
;
_.getAssociatedType = function getAssociatedType_0(){
  return TYPE_0;
}
;
_.getClass$ = function getClass_56(){
  return Lcom_google_gwt_user_client_Window$ClosingEvent_2_classLit;
}
;
var TYPE_0;
function Window$WindowHandlers_0(){
  this.eventBus = new HandlerManager$Bus_0;
  this.source = null;
}

function Window$WindowHandlers(){
}

_ = Window$WindowHandlers_0.prototype = Window$WindowHandlers.prototype = new HandlerManager;
_.getClass$ = function getClass_57(){
  return Lcom_google_gwt_user_client_Window$WindowHandlers_2_classLit;
}
;
function $initWindowCloseHandler(){
  var oldOnBeforeUnload = $wnd.onbeforeunload;
  var oldOnUnload = $wnd.onunload;
  $wnd.onbeforeunload = function(evt){
    var ret, oldRet;
    try {
      ret = $entry(onClosing)();
    }
     finally {
      oldRet = oldOnBeforeUnload && oldOnBeforeUnload(evt);
    }
    if (ret != null) {
      return ret;
    }
    if (oldRet != null) {
      return oldRet;
    }
  }
  ;
  $wnd.onunload = $entry(function(evt){
    try {
      closeHandlersInitialized && fire((!handlers_0 && (handlers_0 = new Window$WindowHandlers_0) , handlers_0));
    }
     finally {
      oldOnUnload && oldOnUnload(evt);
      $wnd.onresize = null;
      $wnd.onscroll = null;
      $wnd.onbeforeunload = null;
      $wnd.onunload = null;
    }
  }
  );
}

function $clearOnReadyStateChange(this$static){
  var self_0 = this$static;
  $wnd.setTimeout(function(){
    self_0.onreadystatechange = new Function;
  }
  , 0);
}

function $open(this$static, httpMethod, url){
  this$static.open(httpMethod, url, true);
}

function $setOnReadyStateChange(this$static, handler){
  var _this = this$static;
  this$static.onreadystatechange = $entry(function(){
    handler.onReadyStateChange(_this);
  }
  );
}

function $setRequestHeader(this$static, header, value){
  this$static.setRequestHeader(header, value);
}

function create_1(){
  if ($wnd.XMLHttpRequest) {
    return new $wnd.XMLHttpRequest;
  }
   else {
    try {
      return new $wnd.ActiveXObject('MSXML2.XMLHTTP.3.0');
    }
     catch (e) {
      return new $wnd.ActiveXObject('Microsoft.XMLHTTP');
    }
  }
}

function SimpleEventBus$1_0(){
}

function SimpleEventBus$1(){
}

_ = SimpleEventBus$1_0.prototype = SimpleEventBus$1.prototype = new Object_0;
_.getClass$ = function getClass_58(){
  return Lcom_google_web_bindery_event_shared_SimpleEventBus$1_2_classLit;
}
;
function SimpleEventBus$2_0(this$0, val$type, val$handler){
  this.this$0 = this$0;
  this.val$type = val$type;
  this.val$source = null;
  this.val$handler = val$handler;
}

function SimpleEventBus$2(){
}

_ = SimpleEventBus$2_0.prototype = SimpleEventBus$2.prototype = new Object_0;
_.getClass$ = function getClass_59(){
  return Lcom_google_web_bindery_event_shared_SimpleEventBus$2_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$SimpleEventBus$Command]);
_.this$0 = null;
_.val$handler = null;
_.val$source = null;
_.val$type = null;
function GeneralSecurityException(){
}

_ = GeneralSecurityException.prototype = new Exception;
_.getClass$ = function getClass_60(){
  return Lcom_googlecode_cryptogwt_emul_java_security_GeneralSecurityException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$Throwable]);
function $digest(this$static, input){
  return $digest_0(this$static, input, input.length);
}

function $digest_0(this$static, input, len){
  this$static.spi.engineUpdate(input, 0, len);
  return this$static.spi.engineDigest();
}

function $update(this$static, input){
  $update_0(this$static, input, 0, input.length);
}

function $update_0(this$static, input, offset, len){
  this$static.spi.engineUpdate(input, offset, len);
}

function MessageDigest_0(spi){
  this.spi = spi;
}

function getInstance(algorithm, provider){
  var service;
  if (!provider)
    throw new IllegalArgumentException_0;
  service = dynamicCast(provider.services.get_0('MessageDigest.' + algorithm), Q$Provider$Service);
  if (service) {
    return new MessageDigest_0(dynamicCast(service.newInstance(algorithm), Q$MessageDigestSpi));
  }
  throw new NoSuchAlgorithmException_0('Invalid digest: ' + algorithm);
}

function getInstance_0(algorithm){
  var $e0, provider, provider$array, provider$index, provider$max;
  for (provider$array = ($clinit_Security() , initValues(_3Lcom_googlecode_cryptogwt_emul_java_security_Provider_2_classLit, makeCastMap([Q$Serializable, Q$Object_$1]), Q$Provider, [($clinit_CryptoGwtProvider() , INSTANCE_1)])) , provider$index = 0 , provider$max = provider$array.length; provider$index < provider$max; ++provider$index) {
    provider = provider$array[provider$index];
    try {
      return getInstance(algorithm, provider);
    }
     catch ($e0) {
      $e0 = caught_0($e0);
      if (!instanceOf($e0, Q$NoSuchAlgorithmException))
        throw $e0;
    }
  }
  throw new NoSuchAlgorithmException_0('Invalid digest: ' + algorithm);
}

function MessageDigest(){
}

_ = MessageDigest_0.prototype = MessageDigest.prototype = new Object_0;
_.getClass$ = function getClass_61(){
  return Lcom_googlecode_cryptogwt_emul_java_security_MessageDigest_2_classLit;
}
;
_.spi = null;
function MessageDigestSpi(){
}

_ = MessageDigestSpi.prototype = new Object_0;
_.engineGetDigestLength = function engineGetDigestLength(){
  return 0;
}
;
_.getClass$ = function getClass_62(){
  return Lcom_googlecode_cryptogwt_emul_java_security_MessageDigestSpi_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MessageDigestSpi]);
function NoSuchAlgorithmException_0(message){
  Exception_0.call(this, message);
}

function NoSuchAlgorithmException(){
}

_ = NoSuchAlgorithmException_0.prototype = NoSuchAlgorithmException.prototype = new GeneralSecurityException;
_.getClass$ = function getClass_63(){
  return Lcom_googlecode_cryptogwt_emul_java_security_NoSuchAlgorithmException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$NoSuchAlgorithmException, Q$Serializable, Q$Exception, Q$Throwable]);
function $makeKey(algorithm, type){
  return type + '.' + algorithm;
}

function $putService(this$static, service){
  this$static.services.put($makeKey(service.algorithm, service.type), service);
}

function Provider(){
}

_ = Provider.prototype = new Object_0;
_.getClass$ = function getClass_64(){
  return Lcom_googlecode_cryptogwt_emul_java_security_Provider_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Provider]);
function Provider$Service(){
}

_ = Provider$Service.prototype = new Object_0;
_.getClass$ = function getClass_65(){
  return Lcom_googlecode_cryptogwt_emul_java_security_Provider$Service_2_classLit;
}
;
_.newInstance = function newInstance(constructorParameter){
  return null.nullMethod();
}
;
_.castableTypeMap$ = makeCastMap([Q$Provider$Service]);
_.algorithm = null;
_.type = null;
function SecureRandomSpi(){
}

_ = SecureRandomSpi.prototype = new Object_0;
_.getClass$ = function getClass_66(){
  return Lcom_googlecode_cryptogwt_emul_java_security_SecureRandomSpi_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable]);
function $clinit_Security(){
  $clinit_Security = nullMethod;
  new LinkedHashSet_0;
}

function CipherSpi(){
}

_ = CipherSpi.prototype = new Object_0;
_.getClass$ = function getClass_67(){
  return Lcom_googlecode_cryptogwt_emul_javax_crypto_CipherSpi_2_classLit;
}
;
function $update_1(this$static, input){
  this$static.macSpi.engineUpdate(input, 0, input.length);
}

function Mac_0(macSpi){
  this.macSpi = macSpi;
}

function getInstance_1(){
  var $e0, provider, provider$array, provider$index, provider$max;
  for (provider$array = ($clinit_Security() , initValues(_3Lcom_googlecode_cryptogwt_emul_java_security_Provider_2_classLit, makeCastMap([Q$Serializable, Q$Object_$1]), Q$Provider, [($clinit_CryptoGwtProvider() , INSTANCE_1)])) , provider$index = 0 , provider$max = provider$array.length; provider$index < provider$max; ++provider$index) {
    provider = provider$array[provider$index];
    try {
      return getInstance_2(provider);
    }
     catch ($e0) {
      $e0 = caught_0($e0);
      if (!instanceOf($e0, Q$NoSuchAlgorithmException))
        throw $e0;
    }
  }
  throw new NoSuchAlgorithmException_0('Invalid MAC: HmacSHA256');
}

function getInstance_2(provider){
  var service;
  if (!provider)
    throw new IllegalArgumentException_0;
  service = dynamicCast(provider.services.get_0('Mac.HmacSHA256'), Q$Provider$Service);
  if (service) {
    return new Mac_0(dynamicCast(service.newInstance('HmacSHA256'), Q$MacSpi));
  }
  throw new NoSuchAlgorithmException_0('Invalid digest: HmacSHA256');
}

function Mac(){
}

_ = Mac_0.prototype = Mac.prototype = new Object_0;
_.getClass$ = function getClass_68(){
  return Lcom_googlecode_cryptogwt_emul_javax_crypto_Mac_2_classLit;
}
;
_.macSpi = null;
function MacSpi(){
}

_ = MacSpi.prototype = new Object_0;
_.getClass$ = function getClass_69(){
  return Lcom_googlecode_cryptogwt_emul_javax_crypto_MacSpi_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MacSpi]);
function SecretKeyFactorySpi(){
}

_ = SecretKeyFactorySpi.prototype = new Object_0;
_.getClass$ = function getClass_70(){
  return Lcom_googlecode_cryptogwt_emul_javax_crypto_SecretKeyFactorySpi_2_classLit;
}
;
function SecretKeySpec_0(key){
  this.key = key;
  this.algorithm = 'HmacSHA256';
}

function SecretKeySpec(){
}

_ = SecretKeySpec_0.prototype = SecretKeySpec.prototype = new Object_0;
_.equals$ = function equals_4(obj){
  var other;
  if (this === obj)
    return true;
  if (obj == null)
    return false;
  if (Lcom_googlecode_cryptogwt_emul_javax_crypto_spec_SecretKeySpec_2_classLit != getClass__devirtual$(obj))
    return false;
  other = dynamicCast(obj, Q$SecretKeySpec);
  if (this.algorithm == null) {
    if (other.algorithm != null)
      return false;
  }
   else if (!$equals(this.algorithm, other.algorithm))
    return false;
  if (!equals_15(this.key, other.key))
    return false;
  return true;
}
;
_.getClass$ = function getClass_71(){
  return Lcom_googlecode_cryptogwt_emul_javax_crypto_spec_SecretKeySpec_2_classLit;
}
;
_.hashCode$ = function hashCode_6(){
  var result;
  result = 31 + (this.algorithm == null?0:getHashCode_0(this.algorithm));
  result = 31 * result + hashCode_17(this.key);
  return result;
}
;
_.castableTypeMap$ = makeCastMap([Q$SecretKeySpec, Q$Serializable]);
_.algorithm = null;
_.key = null;
function BlockCipher_0(){
}

function BlockCipher(){
}

_ = BlockCipher_0.prototype = BlockCipher.prototype = new CipherSpi;
_.getClass$ = function getClass_72(){
  return Lcom_googlecode_cryptogwt_provider_BlockCipher_2_classLit;
}
;
function $clinit_CryptoGwtProvider(){
  $clinit_CryptoGwtProvider = nullMethod;
  INSTANCE_1 = new CryptoGwtProvider_0;
}

function CryptoGwtProvider_0(){
  this.services = new HashMap_0;
  $putService(this, new SpiFactoryService_0('MessageDigest', 'SHA-256', ($clinit_Collections() , $clinit_Collections() , new CryptoGwtProvider$1_0)));
  $putService(this, new SpiFactoryService_0('MessageDigest', 'SHA1', new CryptoGwtProvider$2_0));
  $putService(this, new SpiFactoryService_0('Cipher', 'AES', new CryptoGwtProvider$3_0));
  $putService(this, new SpiFactoryService_0('SecureRandom', 'FORTUNA', new CryptoGwtProvider$4_0));
  $putService(this, new SpiFactoryService_0('Mac', 'HmacSHA256', new CryptoGwtProvider$5_0));
  $putService(this, new SpiFactoryService_0('Mac', 'HmacSHA1', new CryptoGwtProvider$6_0));
  $putService(this, new SpiFactoryService_0('SecretKeyFactory', 'PBKDF2WithHmacSHA1', new CryptoGwtProvider$7_0));
}

function CryptoGwtProvider(){
}

_ = CryptoGwtProvider_0.prototype = CryptoGwtProvider.prototype = new Provider;
_.getClass$ = function getClass_73(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Provider]);
var INSTANCE_1;
function CryptoGwtProvider$1_0(){
}

function CryptoGwtProvider$1(){
}

_ = CryptoGwtProvider$1_0.prototype = CryptoGwtProvider$1.prototype = new Object_0;
_.create = function create_2(constructorParam){
  return new SHA256MessageDigest_0;
}
;
_.getClass$ = function getClass_74(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$1_2_classLit;
}
;
function CryptoGwtProvider$2_0(){
}

function CryptoGwtProvider$2(){
}

_ = CryptoGwtProvider$2_0.prototype = CryptoGwtProvider$2.prototype = new Object_0;
_.create = function create_3(constructorParam){
  return new SHA1MessageDigest_0;
}
;
_.getClass$ = function getClass_75(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$2_2_classLit;
}
;
function CryptoGwtProvider$3_0(){
}

function CryptoGwtProvider$3(){
}

_ = CryptoGwtProvider$3_0.prototype = CryptoGwtProvider$3.prototype = new Object_0;
_.create = function create_4(constructorParam){
  return new BlockCipher_0;
}
;
_.getClass$ = function getClass_76(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$3_2_classLit;
}
;
function CryptoGwtProvider$4_0(){
}

function CryptoGwtProvider$4(){
}

_ = CryptoGwtProvider$4_0.prototype = CryptoGwtProvider$4.prototype = new Object_0;
_.create = function create_5(constructorParam){
  return $clinit_FortunaSecureRandom() , $clinit_FortunaSecureRandom() , INSTANCE_2;
}
;
_.getClass$ = function getClass_77(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$4_2_classLit;
}
;
function CryptoGwtProvider$5_0(){
}

function CryptoGwtProvider$5(){
}

_ = CryptoGwtProvider$5_0.prototype = CryptoGwtProvider$5.prototype = new Object_0;
_.create = function create_6(constructorParam){
  return new Hmac$SHA256_0;
}
;
_.getClass$ = function getClass_78(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$5_2_classLit;
}
;
function CryptoGwtProvider$6_0(){
}

function CryptoGwtProvider$6(){
}

_ = CryptoGwtProvider$6_0.prototype = CryptoGwtProvider$6.prototype = new Object_0;
_.create = function create_7(constructorParam){
  return new Hmac$SHA1_0;
}
;
_.getClass$ = function getClass_79(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$6_2_classLit;
}
;
function CryptoGwtProvider$7_0(){
}

function CryptoGwtProvider$7(){
}

_ = CryptoGwtProvider$7_0.prototype = CryptoGwtProvider$7.prototype = new Object_0;
_.create = function create_8(constructorParam){
  return new Pbkdf2$HmacSHA1_0;
}
;
_.getClass$ = function getClass_80(){
  return Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$7_2_classLit;
}
;
function $clinit_FortunaSecureRandom(){
  $clinit_FortunaSecureRandom = nullMethod;
  INSTANCE_2 = new FortunaSecureRandom_0;
}

function FortunaSecureRandom_0(){
  new LinkedHashSet_0;
  new ArrayList_0;
}

function FortunaSecureRandom(){
}

_ = FortunaSecureRandom_0.prototype = FortunaSecureRandom.prototype = new SecureRandomSpi;
_.getClass$ = function getClass_81(){
  return Lcom_googlecode_cryptogwt_provider_FortunaSecureRandom_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable]);
var INSTANCE_2;
function $expandOrReduceKeyToBlocksize(this$static, inputKey){
  var result;
  result = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, this$static.blockSize, 1);
  inputKey.length > this$static.blockSize && (inputKey = $digest(this$static.digest, inputKey));
  arraycopy(inputKey, 0, result, 0, min(inputKey.length, result.length));
  return result;
}

function Hmac_0(algorithm){
  this.digest = getInstance_0(algorithm);
  this.digest.spi.engineGetDigestLength();
  this.blockSize = 64;
}

function Hmac(){
}

_ = Hmac.prototype = new MacSpi;
_.engineDoFinal = function engineDoFinal(){
  var inner, result;
  inner = this.digest.spi.engineDigest();
  $update(this.digest, this.opad);
  result = $digest(this.digest, inner);
  this.digest.spi.engineReset();
  $update(this.digest, this.ipad);
  return result;
}
;
_.engineInit = function engineInit(key, params){
  var blockKey;
  this.digest.spi.engineReset();
  this.opad = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, this.blockSize, 1);
  this.ipad = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, this.blockSize, 1);
  fill(this.opad, 92);
  fill(this.ipad, 54);
  blockKey = $expandOrReduceKeyToBlocksize(this, copyOfRange(key.key, key.key.length));
  xor_0(this.opad, blockKey);
  xor_0(this.ipad, blockKey);
  this.digest.spi.engineReset();
  $update(this.digest, this.ipad);
}
;
_.engineUpdate = function engineUpdate(input, offset, len){
  $update_0(this.digest, input, offset, len);
}
;
_.getClass$ = function getClass_82(){
  return Lcom_googlecode_cryptogwt_provider_Hmac_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MacSpi]);
_.blockSize = 0;
_.digest = null;
_.ipad = null;
_.opad = null;
function Hmac$SHA1_0(){
  Hmac_0.call(this, 'SHA1');
}

function Hmac$SHA1(){
}

_ = Hmac$SHA1_0.prototype = Hmac$SHA1.prototype = new Hmac;
_.getClass$ = function getClass_83(){
  return Lcom_googlecode_cryptogwt_provider_Hmac$SHA1_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MacSpi]);
function Hmac$SHA256_0(){
  Hmac_0.call(this, 'SHA-256');
}

function Hmac$SHA256(){
}

_ = Hmac$SHA256_0.prototype = Hmac$SHA256.prototype = new Hmac;
_.getClass$ = function getClass_84(){
  return Lcom_googlecode_cryptogwt_provider_Hmac$SHA256_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MacSpi]);
function toByteArray(array){
  var result;
  result = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, array.length * 4, 1);
  toByteArray_0(array, result);
  return result;
}

function toByteArray_0(array, result){
  var i_0, j, value;
  j = 0;
  for (i_0 = 0; i_0 < array.length; ++i_0) {
    value = array[i_0];
    result[j++] = value >>> 24 << 24 >> 24;
    result[j++] = value >>> 16 << 24 >> 24;
    result[j++] = value >>> 8 << 24 >> 24;
    result[j++] = value << 24 >> 24;
  }
  return result;
}

function $update_2(this$static, b){
  this$static.update_byte(b);
}

function newInstance_0(){
  function SHA256(){
    this.initialize();
  }

  SHA256.prototype = {init:[1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225], k:[1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298], initialize:function(){
    this.h = this.init.slice(0);
    this.word_buffer = [];
    this.bit_buffer = 0;
    this.bits_buffered = 0;
    this.length = 0;
    this.length_upper = 0;
  }
  , block:function(words){
    var w = words.slice(0), i_0, h_0 = this.h, tmp, k_0 = this.k;
    var h0 = h_0[0], h1 = h_0[1], h2 = h_0[2], h3 = h_0[3], h4 = h_0[4], h5 = h_0[5], h6 = h_0[6], h7 = h_0[7];
    for (i_0 = 0; i_0 < 64; i_0++) {
      if (i_0 < 16) {
        tmp = w[i_0];
      }
       else {
        var a = w[i_0 + 1 & 15], b = w[i_0 + 14 & 15];
        tmp = w[i_0 & 15] = (a >>> 7 ^ a >>> 18 ^ a >>> 3 ^ a << 25 ^ a << 14) + (b >>> 17 ^ b >>> 19 ^ b >>> 10 ^ b << 15 ^ b << 13) + w[i_0 & 15] + w[i_0 + 9 & 15] | 0;
      }
      tmp = tmp + h7 + (h4 >>> 6 ^ h4 >>> 11 ^ h4 >>> 25 ^ h4 << 26 ^ h4 << 21 ^ h4 << 7) + (h6 ^ h4 & (h5 ^ h6)) + k_0[i_0] | 0;
      h7 = h6;
      h6 = h5;
      h5 = h4;
      h4 = h3 + tmp | 0;
      h3 = h2;
      h2 = h1;
      h1 = h0;
      h0 = tmp + (h1 & h2 ^ h3 & (h1 ^ h2)) + (h1 >>> 2 ^ h1 >>> 13 ^ h1 >>> 22 ^ h1 << 30 ^ h1 << 19 ^ h1 << 10) | 0;
    }
    h_0[0] += h0;
    h_0[1] += h1;
    h_0[2] += h2;
    h_0[3] += h3;
    h_0[4] += h4;
    h_0[5] += h5;
    h_0[6] += h6;
    h_0[7] += h7;
  }
  , update_word_big_endian:function(word){
    var bb;
    if (bb = this.bits_buffered) {
      this.word_buffer.push(word >>> 32 - bb | this.bit_buffer);
      this.bit_buffer = word << bb;
    }
     else {
      this.word_buffer.push(word);
    }
    this.length += 32;
    this.length == 0 && this.length_upper++;
    if (this.word_buffer.length == 16) {
      this.block(this.word_buffer);
      this.word_buffer = [];
    }
  }
  , update_word_little_endian:function(word){
    word = word >>> 16 ^ word << 16;
    word = word >>> 8 & 16711935 ^ word << 8 & 4278255360;
    this.update_word_big_endian(word);
  }
  , update_words_big_endian:function(words){
    for (var i_0 = 0; i_0 < words.length; i_0++)
      this.update_word_big_endian(words[i_0]);
  }
  , update_words_little_endian:function(words){
    for (var i_0 = 0; i_0 < words.length; i_0++)
      this.update_word_little_endian(words[i_0]);
  }
  , update_byte:function(b){
    this.bit_buffer |= (b & 255) << 24 - this.bits_buffered;
    this.bits_buffered += 8;
    if (this.bits_buffered == 32) {
      this.bits_buffered = 0;
      this.update_word_big_endian(this.bit_buffer);
      this.bit_buffer = 0;
    }
  }
  , update_string:function(string){
    throw 'not yet implemented';
  }
  , finalize:function(){
    var i_0, wb = this.word_buffer;
    wb.push(this.bit_buffer | 1 << 31 - this.bits_buffered);
    var zeros_to_pad = 16 - wb.length - 2;
    zeros_to_pad < 0 && (zeros_to_pad += 16);
    for (i_0 = 0; i_0 < zeros_to_pad; i_0++) {
      wb.push(0);
    }
    wb.push(this.length_upper);
    wb.push(this.length + this.bits_buffered);
    this.block(wb.slice(0, 16));
    wb.length > 16 && this.block(wb.slice(16, 32));
    var h_0 = this.h;
    this.initialize();
    h_0[0] = h_0[0] | 0;
    h_0[1] = h_0[1] | 0;
    h_0[2] = h_0[2] | 0;
    h_0[3] = h_0[3] | 0;
    h_0[4] = h_0[4] | 0;
    h_0[5] = h_0[5] | 0;
    h_0[6] = h_0[6] | 0;
    h_0[7] = h_0[7] | 0;
    return h_0;
  }
  };
  return new SHA256;
}

function $update_3(this$static){
  this$static.buffer[this$static.bufOffset++] = -128;
  if (this$static.bufOffset == this$static.blockSize) {
    $block(this$static, this$static.buffer, 0, this$static.blockSize);
    this$static.bufOffset = 0;
  }
}

function $update_4(this$static, input, offset, len){
  var lenToCopy;
  if (this$static.bufOffset != 0) {
    lenToCopy = min(len, this$static.blockSize - this$static.bufOffset);
    arraycopy(input, offset, this$static.buffer, this$static.bufOffset, lenToCopy);
    offset += lenToCopy;
    len -= lenToCopy;
    this$static.bufOffset += lenToCopy;
    if (this$static.bufOffset == this$static.blockSize) {
      $block(this$static, this$static.buffer, 0, this$static.blockSize);
      this$static.bufOffset = 0;
    }
  }
  if (len == 0)
    return;
  while (len >= this$static.blockSize) {
    $block(this$static, input, offset, this$static.blockSize);
    len -= this$static.blockSize;
    offset += this$static.blockSize;
  }
  arraycopy(input, offset, this$static.buffer, 0, len);
  this$static.bufOffset = len;
}

function MessageDigestSupport(){
}

_ = MessageDigestSupport.prototype = new MessageDigestSpi;
_.engineDigest = function engineDigest(){
  var result, zerosToAppend;
  result = ($update_3(this) , zerosToAppend = this.blockSize - this.bufOffset - 8 , zerosToAppend < 0 && (zerosToAppend += this.blockSize) , $update_4(this, initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, zerosToAppend, 1), 0, zerosToAppend) , $update_4(this, toBytes_1(this.bitsProcessed), 0, 8) , toBytes_0(initValues(_3I_classLit, makeCastMap([Q$Serializable]), -1, [this.h0, this.h1, this.h2, this.h3, this.h4])));
  $init(this);
  return result;
}
;
_.engineGetDigestLength = function engineGetDigestLength_0(){
  return this.outputLen;
}
;
_.engineReset = function engineReset(){
  $init(this);
}
;
_.engineUpdate = function engineUpdate_0(input, offset, len){
  this.bitsProcessed = add(this.bitsProcessed, fromInt(len * 8));
  $update_4(this, input, offset, len);
}
;
_.getClass$ = function getClass_85(){
  return Lcom_googlecode_cryptogwt_provider_MessageDigestSupport_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MessageDigestSpi]);
_.bitsProcessed = P0_longLit;
_.blockSize = 0;
_.bufOffset = 0;
_.buffer = null;
_.outputLen = 0;
function Pbkdf2(){
}

_ = Pbkdf2.prototype = new SecretKeyFactorySpi;
_.getClass$ = function getClass_86(){
  return Lcom_googlecode_cryptogwt_provider_Pbkdf2_2_classLit;
}
;
function Pbkdf2$HmacSHA1_0(){
}

function Pbkdf2$HmacSHA1(){
}

_ = Pbkdf2$HmacSHA1_0.prototype = Pbkdf2$HmacSHA1.prototype = new Pbkdf2;
_.getClass$ = function getClass_87(){
  return Lcom_googlecode_cryptogwt_provider_Pbkdf2$HmacSHA1_2_classLit;
}
;
function $block(this$static, input, offset, len){
  var a, b, c, d, e, f, k_0, t, temp, w;
  w = initDim(_3I_classLit, makeCastMap([Q$Serializable]), -1, 80, 1);
  toIntegerArray(input, offset, len, w);
  for (t = 16; t < 80; ++t) {
    w[t] = (w[t - 3] ^ w[t - 8] ^ w[t - 14] ^ w[t - 16]) << 1 | (w[t - 3] ^ w[t - 8] ^ w[t - 14] ^ w[t - 16]) >>> 31;
  }
  a = this$static.h0;
  b = this$static.h1;
  c = this$static.h2;
  d = this$static.h3;
  e = this$static.h4;
  for (t = 0; t < 80; ++t) {
    if (t < 20) {
      f = b & c ^ ~b & d;
      k_0 = 1518500249;
    }
     else if (t < 40) {
      f = b ^ c ^ d;
      k_0 = 1859775393;
    }
     else if (t < 60) {
      f = b & c ^ b & d ^ c & d;
      k_0 = -1894007588;
    }
     else {
      f = b ^ c ^ d;
      k_0 = -899497514;
    }
    temp = (a << 5 | a >>> 27) + f + e + k_0 + w[t];
    e = d;
    d = c;
    c = b << 30 | b >>> 2;
    b = a;
    a = temp;
  }
  this$static.h0 += a;
  this$static.h1 += b;
  this$static.h2 += c;
  this$static.h3 += d;
  this$static.h4 += e;
}

function $init(this$static){
  this$static.h0 = 1732584193;
  this$static.h1 = -271733879;
  this$static.h2 = -1732584194;
  this$static.h3 = 271733878;
  this$static.h4 = -1009589776;
  this$static.bufOffset = 0;
  this$static.bitsProcessed = P0_longLit;
}

function SHA1MessageDigest_0(){
  this.blockSize = 64;
  this.outputLen = 20;
  this.buffer = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, 64, 1);
  $init(this);
}

function SHA1MessageDigest(){
}

_ = SHA1MessageDigest_0.prototype = SHA1MessageDigest.prototype = new MessageDigestSupport;
_.getClass$ = function getClass_88(){
  return Lcom_googlecode_cryptogwt_provider_SHA1MessageDigest_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MessageDigestSpi]);
_.h0 = 0;
_.h1 = 0;
_.h2 = 0;
_.h3 = 0;
_.h4 = 0;
function SHA256MessageDigest_0(){
  this.delegate = newInstance_0();
}

function SHA256MessageDigest(){
}

_ = SHA256MessageDigest_0.prototype = SHA256MessageDigest.prototype = new MessageDigestSpi;
_.engineDigest = function engineDigest_0(){
  var result;
  result = this.delegate.finalize();
  return toByteArray(result);
}
;
_.engineGetDigestLength = function engineGetDigestLength_1(){
  return 32;
}
;
_.engineReset = function engineReset_0(){
  this.delegate = newInstance_0();
}
;
_.engineUpdate = function engineUpdate_1(input, offset, len){
  var i_0;
  if (len <= 0)
    return;
  for (i_0 = offset; i_0 < offset + len; ++i_0) {
    $update_2(this.delegate, input[i_0]);
  }
}
;
_.getClass$ = function getClass_89(){
  return Lcom_googlecode_cryptogwt_provider_SHA256MessageDigest_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$MessageDigestSpi]);
_.delegate = null;
function copyOfRange(bytes, len){
  var result;
  result = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, len, 1);
  arraycopy(bytes, 0, result, 0, len);
  return result;
}

function toBytes(integer, output, offset){
  var i_0;
  i_0 = offset;
  output[i_0++] = integer >>> 24 << 24 >> 24;
  output[i_0++] = integer >>> 16 << 24 >> 24;
  output[i_0++] = integer >>> 8 << 24 >> 24;
  output[i_0++] = (integer & 255) << 24 >> 24;
}

function toBytes_0(integer){
  var i_0, offset, result;
  result = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, integer.length * 4, 1);
  offset = 0;
  for (i_0 = 0; i_0 < integer.length; ++i_0) {
    toBytes(integer[i_0], result, offset);
    offset += 4;
  }
  return result;
}

function toBytes_1(longValue){
  return initValues(_3B_classLit, makeCastMap([Q$Serializable]), -1, [toInt(shru(longValue, 56)) << 24 >> 24, toInt(shru(longValue, 48)) << 24 >> 24, toInt(shru(longValue, 40)) << 24 >> 24, toInt(shru(longValue, 32)) << 24 >> 24, toInt(shru(longValue, 24)) << 24 >> 24, toInt(shru(longValue, 16)) << 24 >> 24, toInt(shru(longValue, 8)) << 24 >> 24, toInt(and(longValue, Pff_longLit)) << 24 >> 24]);
}

function toInteger(input, offset){
  return (input[offset++] & 255) << 24 | (input[offset++] & 255) << 16 | (input[offset++] & 255) << 8 | input[offset++] & 255;
}

function toIntegerArray(input, offset, len, output){
  var i_0, outputLen;
  outputLen = ~~(len / 4);
  for (i_0 = 0; i_0 < outputLen; ++i_0) {
    output[i_0] = toInteger(input, offset);
    offset += 4;
  }
}

function xor(bytes, offset, bytesToMix, mixOffset, len){
  var bytesLength;
  bytesLength = offset + len;
  for (; offset < bytesLength; ++offset) {
    bytes[offset] = bytes[offset] ^ bytesToMix[mixOffset++];
  }
}

function xor_0(dest, bytesToMix){
  xor(dest, 0, bytesToMix, 0, dest.length);
}

function SpiFactoryService_0(type, algorithm, factory){
  this.type = type;
  this.algorithm = algorithm;
  this.factory = factory;
}

function SpiFactoryService(){
}

_ = SpiFactoryService_0.prototype = SpiFactoryService.prototype = new Provider$Service;
_.getClass$ = function getClass_90(){
  return Lcom_googlecode_cryptogwt_util_SpiFactoryService_2_classLit;
}
;
_.newInstance = function newInstance_1(constructorParameter){
  return this.factory.create(constructorParameter);
}
;
_.castableTypeMap$ = makeCastMap([Q$Provider$Service]);
_.factory = null;
function getBoolean(value){
  var jsonBoolean;
  if (!value || instanceOf(value, Q$JSONNull)) {
    return null;
  }
  if (instanceOf(value, Q$JSONBoolean)) {
    jsonBoolean = dynamicCast(value, Q$JSONBoolean);
    return $clinit_Boolean() , jsonBoolean.value?TRUE_0:FALSE_0;
  }
   else {
    throw new JSONException_0;
  }
}

function getDouble(value){
  var $e0, jsonNumber, stringValue;
  if (!value || instanceOf(value, Q$JSONNull)) {
    return null;
  }
  if (instanceOf(value, Q$JSONNumber)) {
    jsonNumber = dynamicCast(value, Q$JSONNumber);
    return new Double_0(jsonNumber.value);
  }
   else {
    if (instanceOf(value, Q$JSONString)) {
      try {
        stringValue = value.isString().value;
        return new Double_0(__parseAndValidateDouble(stringValue));
      }
       catch ($e0) {
        $e0 = caught_0($e0);
        if (instanceOf($e0, Q$NumberFormatException)) {
          return null;
        }
         else 
          throw $e0;
      }
    }
     else {
      throw new JSONException_0;
    }
  }
}

function getInt(value){
  var jsonNumber;
  if (!value || instanceOf(value, Q$JSONNull)) {
    return null;
  }
  if (instanceOf(value, Q$JSONNumber)) {
    jsonNumber = dynamicCast(value, Q$JSONNumber);
    return valueOf(round_int((new Double_0(jsonNumber.value)).value));
  }
   else {
    throw new JSONException_0;
  }
}

function getString(value){
  var jsonString;
  if (!value || instanceOf(value, Q$JSONNull)) {
    return null;
  }
  if (instanceOf(value, Q$JSONString)) {
    jsonString = dynamicCast(value, Q$JSONString);
    return jsonString.value;
  }
   else {
    throw new JSONException_0;
  }
}

function IncompatibleObjectException_0(){
  $fillInStackTrace();
}

function IncompatibleObjectException(){
}

_ = IncompatibleObjectException_0.prototype = IncompatibleObjectException.prototype = new JSONException;
_.getClass$ = function getClass_91(){
  return Lcom_kfuntak_gwt_json_serialization_client_IncompatibleObjectException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function SerializationException_0(arg0){
  RuntimeException_0.call(this, arg0);
}

function SerializationException(){
}

_ = SerializationException_0.prototype = SerializationException.prototype = new RuntimeException;
_.getClass$ = function getClass_92(){
  return Lcom_kfuntak_gwt_json_serialization_client_SerializationException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $addObjectSerializer(name_0, obj){
  (!SERIALIZABLE_TYPES && (SERIALIZABLE_TYPES = new HashMap_0) , SERIALIZABLE_TYPES).put(name_0, obj);
}

function $deSerialize(jsonValue, className){
  var serializer;
  serializer = dynamicCast((!SERIALIZABLE_TYPES && (SERIALIZABLE_TYPES = new HashMap_0) , SERIALIZABLE_TYPES).get_0(className), Q$ObjectSerializer);
  if (!serializer) {
    throw new SerializationException_0("Can't find object serializer for " + className);
  }
  return serializer.deSerialize(jsonValue, className);
}

function $deSerialize_0(jsonString, className){
  var serializer;
  serializer = dynamicCast((!SERIALIZABLE_TYPES && (SERIALIZABLE_TYPES = new HashMap_0) , SERIALIZABLE_TYPES).get_0(className), Q$ObjectSerializer);
  if (!serializer) {
    throw new SerializationException_0("Can't find object serializer for " + className);
  }
  return serializer.deSerialize_0(jsonString, className);
}

function $serialize(pojo){
  var name_0, serializer;
  name_0 = getClass__devirtual$(pojo).typeName;
  serializer = dynamicCast((!SERIALIZABLE_TYPES && (SERIALIZABLE_TYPES = new HashMap_0) , SERIALIZABLE_TYPES).get_0(name_0), Q$ObjectSerializer);
  if (!serializer) {
    throw new SerializationException_0("Can't find object serializer for " + name_0);
  }
  return serializer.serialize(pojo);
}

function $serializeToJson(pojo){
  var name_0, serializer;
  if (pojo == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  name_0 = getClass__devirtual$(pojo).typeName;
  serializer = dynamicCast((!SERIALIZABLE_TYPES && (SERIALIZABLE_TYPES = new HashMap_0) , SERIALIZABLE_TYPES).get_0(name_0), Q$ObjectSerializer);
  if (!serializer) {
    throw new SerializationException_0("Can't find object serializer for " + name_0);
  }
  return serializer.serializeToJson(pojo);
}

function Serializer(){
}

_ = Serializer.prototype = new Object_0;
_.getClass$ = function getClass_93(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_2_classLit;
}
;
var SERIALIZABLE_TYPES = null;
function getBoolean_0(boolValue){
  if (!boolValue) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  return $clinit_JSONBoolean() , boolValue.value?TRUE:FALSE;
}

function getNumber(number){
  if (!number) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  return new JSONNumber_0(number.doubleValue());
}

function getString_0(string){
  if (string == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  return new JSONString_0(string);
}

function Serializer_TypeSerializer_0(){
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.PaymentAmount', new Serializer_TypeSerializer$PaymentAmount_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Product', new Serializer_TypeSerializer$Product_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.ServiceException', new Serializer_TypeSerializer$ServiceException_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth2AuthorizationProxyToken', new Serializer_TypeSerializer$Oauth2AuthorizationProxyToken_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth2ProtectedAuthorizationToken', new Serializer_TypeSerializer$Oauth2ProtectedAuthorizationToken_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.TransactionList', new Serializer_TypeSerializer$TransactionList_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.AuthorizationUris', new Serializer_TypeSerializer$AuthorizationUris_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth2AuthorizationToken', new Serializer_TypeSerializer$Oauth2AuthorizationToken_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.PrepareAuthenticationIdentifier', new Serializer_TypeSerializer$PrepareAuthenticationIdentifier_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth1Authorization', new Serializer_TypeSerializer$Oauth1Authorization_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth1AuthorizationProxyToken', new Serializer_TypeSerializer$Oauth1AuthorizationProxyToken_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.AuthorizationApi', new Serializer_TypeSerializer$AuthorizationApi_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth2AccessToken', new Serializer_TypeSerializer$Oauth2AccessToken_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Operator', new Serializer_TypeSerializer$Operator_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Response', new Serializer_TypeSerializer$Response_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.CustomerReference', new Serializer_TypeSerializer$CustomerReference_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.TransactionArray', new Serializer_TypeSerializer$TransactionArray_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Apis', new Serializer_TypeSerializer$Apis_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.GatewayResponse', new Serializer_TypeSerializer$GatewayResponse_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth1AuthorizationVerifier', new Serializer_TypeSerializer$Oauth1AuthorizationVerifier_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.AmountTransaction', new Serializer_TypeSerializer$AmountTransaction_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth2Authorization', new Serializer_TypeSerializer$Oauth2Authorization_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.MessageBody', new Serializer_TypeSerializer$MessageBody_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Item', new Serializer_TypeSerializer$Item_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Payment', new Serializer_TypeSerializer$Payment_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth1Token', new Serializer_TypeSerializer$Oauth1Token_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.PaymentApi', new Serializer_TypeSerializer$PaymentApi_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.ChargingInformation', new Serializer_TypeSerializer$ChargingInformation_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.QueryApi', new Serializer_TypeSerializer$QueryApi_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.ReservedTransaction', new Serializer_TypeSerializer$ReservedTransaction_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth1AuthorizationToken', new Serializer_TypeSerializer$Oauth1AuthorizationToken_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.GatewayError', new Serializer_TypeSerializer$GatewayError_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.GenericError', new Serializer_TypeSerializer$GenericError_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.InvalidRequestError', new Serializer_TypeSerializer$InvalidRequestError_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Oauth2AuthenticationToken', new Serializer_TypeSerializer$Oauth2AuthenticationToken_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.Transaction', new Serializer_TypeSerializer$Transaction_SerializableImpl_0);
  $addObjectSerializer('net.wacapps.napi.resource.jaxb.RequestError', new Serializer_TypeSerializer$RequestError_SerializableImpl_0);
}

function Serializer_TypeSerializer(){
}

_ = Serializer_TypeSerializer_0.prototype = Serializer_TypeSerializer.prototype = new Serializer;
_.getClass$ = function getClass_94(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer_2_classLit;
}
;
function $deSerialize_1(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new AmountTransaction_0;
  fieldJsonValue = $get_0(jsonObject, 'clientCorrelator');
  $setClientCorrelator(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'endUserId');
  $setEndUserId(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'paymentAmount');
  new Serializer_TypeSerializer_0;
  $setPaymentAmount(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.PaymentAmount'), Q$PaymentAmount));
  fieldJsonValue = $get_0(jsonObject, 'referenceCode');
  $setReferenceCode(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'serverReferenceCode');
  $setServerReferenceCode(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'resourceURL');
  $setResourceURL(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'transactionOperationStatus');
  $setTransactionOperationStatus(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_0(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$AmountTransaction)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$AmountTransaction);
  fieldValue = mainVariable.clientCorrelator;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'clientCorrelator', jsonValue);
  fieldValue = mainVariable.endUserId;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'endUserId', jsonValue);
  fieldValue = mainVariable.paymentAmount;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'paymentAmount', $serializeToJson(fieldValue));
  fieldValue = mainVariable.referenceCode;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'referenceCode', jsonValue);
  fieldValue = mainVariable.serverReferenceCode;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'serverReferenceCode', jsonValue);
  fieldValue = mainVariable.resourceURL;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'resourceURL', jsonValue);
  fieldValue = mainVariable.transactionOperationStatus;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'transactionOperationStatus', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.AmountTransaction'));
  return mainResult;
}

function Serializer_TypeSerializer$AmountTransaction_SerializableImpl_0(){
}

function Serializer_TypeSerializer$AmountTransaction_SerializableImpl(){
}

_ = Serializer_TypeSerializer$AmountTransaction_SerializableImpl_0.prototype = Serializer_TypeSerializer$AmountTransaction_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize(jsonString, className){
  return $deSerialize_1(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_0(jsonValue, className){
  return $deSerialize_1(jsonValue);
}
;
_.getClass$ = function getClass_95(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$AmountTransaction_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize(pojo){
  return $serializeToJson_0(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson(object){
  return $serializeToJson_0(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_2(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Apis_0;
  fieldJsonValue = $get_0(jsonObject, 'uri');
  $setUri(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'authorization');
  new Serializer_TypeSerializer_0;
  $setAuthorization(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.AuthorizationApi'), Q$AuthorizationApi));
  fieldJsonValue = $get_0(jsonObject, 'query');
  new Serializer_TypeSerializer_0;
  $setQuery(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.QueryApi'), Q$QueryApi));
  fieldJsonValue = $get_0(jsonObject, 'payment');
  new Serializer_TypeSerializer_0;
  $setPayment(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.PaymentApi'), Q$PaymentApi));
  return mainResult;
}

function $serializeToJson_1(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Apis)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Apis);
  fieldValue = mainVariable.uri;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'uri', jsonValue);
  fieldValue = mainVariable.authorization;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'authorization', $serializeToJson(fieldValue));
  fieldValue = mainVariable.query;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'query', $serializeToJson(fieldValue));
  fieldValue = mainVariable.payment;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'payment', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Apis'));
  return mainResult;
}

function Serializer_TypeSerializer$Apis_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Apis_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Apis_SerializableImpl_0.prototype = Serializer_TypeSerializer$Apis_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_1(jsonString, className){
  return $deSerialize_2(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_2(jsonValue, className){
  return $deSerialize_2(jsonValue);
}
;
_.getClass$ = function getClass_96(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Apis_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_0(pojo){
  return $serializeToJson_1(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_0(object){
  return $serializeToJson_1(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_3(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new AuthorizationApi_0;
  fieldJsonValue = $get_0(jsonObject, 'type');
  $setType(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'uris');
  new Serializer_TypeSerializer_0;
  $setUris(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.AuthorizationUris'), Q$AuthorizationUris));
  return mainResult;
}

function $serializeToJson_2(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$AuthorizationApi)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$AuthorizationApi);
  fieldValue = mainVariable.type;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'type', jsonValue);
  fieldValue = mainVariable.uris;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'uris', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.AuthorizationApi'));
  return mainResult;
}

function Serializer_TypeSerializer$AuthorizationApi_SerializableImpl_0(){
}

function Serializer_TypeSerializer$AuthorizationApi_SerializableImpl(){
}

_ = Serializer_TypeSerializer$AuthorizationApi_SerializableImpl_0.prototype = Serializer_TypeSerializer$AuthorizationApi_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_3(jsonString, className){
  return $deSerialize_3(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_4(jsonValue, className){
  return $deSerialize_3(jsonValue);
}
;
_.getClass$ = function getClass_97(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$AuthorizationApi_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_1(pojo){
  return $serializeToJson_2(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_1(object){
  return $serializeToJson_2(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_4(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new AuthorizationUris_0;
  fieldJsonValue = $get_0(jsonObject, 'requestToken');
  $setRequestToken(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'authorize');
  $setAuthorize(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'accessToken');
  $setAccessToken(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_3(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$AuthorizationUris)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$AuthorizationUris);
  fieldValue = mainVariable.requestToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'requestToken', jsonValue);
  fieldValue = mainVariable.authorize;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'authorize', jsonValue);
  fieldValue = mainVariable.accessToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'accessToken', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.AuthorizationUris'));
  return mainResult;
}

function Serializer_TypeSerializer$AuthorizationUris_SerializableImpl_0(){
}

function Serializer_TypeSerializer$AuthorizationUris_SerializableImpl(){
}

_ = Serializer_TypeSerializer$AuthorizationUris_SerializableImpl_0.prototype = Serializer_TypeSerializer$AuthorizationUris_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_5(jsonString, className){
  return $deSerialize_4(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_6(jsonValue, className){
  return $deSerialize_4(jsonValue);
}
;
_.getClass$ = function getClass_98(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$AuthorizationUris_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_2(pojo){
  return $serializeToJson_3(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_2(object){
  return $serializeToJson_3(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_5(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new ChargingInformation_0;
  fieldJsonValue = $get_0(jsonObject, 'amount');
  $setAmount(mainResult, getDouble(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'code');
  $setCode(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'currency');
  $setCurrency(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'description');
  $setDescription(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_4(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$ChargingInformation)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$ChargingInformation);
  fieldValue = mainVariable.amount;
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'amount', jsonValue);
  fieldValue = mainVariable.code;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'code', jsonValue);
  fieldValue = mainVariable.currency;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'currency', jsonValue);
  fieldValue = mainVariable.description;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'description', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.ChargingInformation'));
  return mainResult;
}

function Serializer_TypeSerializer$ChargingInformation_SerializableImpl_0(){
}

function Serializer_TypeSerializer$ChargingInformation_SerializableImpl(){
}

_ = Serializer_TypeSerializer$ChargingInformation_SerializableImpl_0.prototype = Serializer_TypeSerializer$ChargingInformation_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_7(jsonString, className){
  return $deSerialize_5(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_8(jsonValue, className){
  return $deSerialize_5(jsonValue);
}
;
_.getClass$ = function getClass_99(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$ChargingInformation_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_3(pojo){
  return $serializeToJson_4(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_3(object){
  return $serializeToJson_4(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_6(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new CustomerReference_0;
  fieldJsonValue = $get_0(jsonObject, 'acr');
  $setAcr(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_5(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$CustomerReference)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$CustomerReference);
  fieldValue = mainVariable.acr;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'acr', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.CustomerReference'));
  return mainResult;
}

function Serializer_TypeSerializer$CustomerReference_SerializableImpl_0(){
}

function Serializer_TypeSerializer$CustomerReference_SerializableImpl(){
}

_ = Serializer_TypeSerializer$CustomerReference_SerializableImpl_0.prototype = Serializer_TypeSerializer$CustomerReference_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_9(jsonString, className){
  return $deSerialize_6(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_10(jsonValue, className){
  return $deSerialize_6(jsonValue);
}
;
_.getClass$ = function getClass_100(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$CustomerReference_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_4(pojo){
  return $serializeToJson_5(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_4(object){
  return $serializeToJson_5(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_7(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new GatewayError_0;
  fieldJsonValue = $get_0(jsonObject, 'error');
  $setError(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'errorDescription');
  $setErrorDescription(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_6(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$GatewayError)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$GatewayError);
  fieldValue = mainVariable.error;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'error', jsonValue);
  fieldValue = mainVariable.errorDescription;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'errorDescription', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.GatewayError'));
  return mainResult;
}

function Serializer_TypeSerializer$GatewayError_SerializableImpl_0(){
}

function Serializer_TypeSerializer$GatewayError_SerializableImpl(){
}

_ = Serializer_TypeSerializer$GatewayError_SerializableImpl_0.prototype = Serializer_TypeSerializer$GatewayError_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_11(jsonString, className){
  return $deSerialize_7(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_12(jsonValue, className){
  return $deSerialize_7(jsonValue);
}
;
_.getClass$ = function getClass_101(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$GatewayError_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_5(pojo){
  return $serializeToJson_6(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_5(object){
  return $serializeToJson_6(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_8(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new GatewayResponse_0;
  fieldJsonValue = $get_0(jsonObject, 'code');
  $setCode_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'response');
  new Serializer_TypeSerializer_0;
  $setResponse(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Response'), Q$Response));
  return mainResult;
}

function $serializeToJson_7(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$GatewayResponse)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$GatewayResponse);
  fieldValue = mainVariable.code;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'code', jsonValue);
  fieldValue = mainVariable.response;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'response', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.GatewayResponse'));
  return mainResult;
}

function Serializer_TypeSerializer$GatewayResponse_SerializableImpl_0(){
}

function Serializer_TypeSerializer$GatewayResponse_SerializableImpl(){
}

_ = Serializer_TypeSerializer$GatewayResponse_SerializableImpl_0.prototype = Serializer_TypeSerializer$GatewayResponse_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_13(jsonString, className){
  return $deSerialize_8(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_14(jsonValue, className){
  return $deSerialize_8(jsonValue);
}
;
_.getClass$ = function getClass_102(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$GatewayResponse_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_6(pojo){
  return $serializeToJson_7(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_6(object){
  return $serializeToJson_7(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_9(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new GenericError_0;
  fieldJsonValue = $get_0(jsonObject, 'code');
  $setCode_1(mainResult, getInt(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'message');
  $setMessage(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_8(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$GenericError)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$GenericError);
  fieldValue = valueOf(mainVariable.code);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'code', jsonValue);
  fieldValue = mainVariable.message_0;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'message', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.GenericError'));
  return mainResult;
}

function Serializer_TypeSerializer$GenericError_SerializableImpl_0(){
}

function Serializer_TypeSerializer$GenericError_SerializableImpl(){
}

_ = Serializer_TypeSerializer$GenericError_SerializableImpl_0.prototype = Serializer_TypeSerializer$GenericError_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_15(jsonString, className){
  return $deSerialize_9(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_16(jsonValue, className){
  return $deSerialize_9(jsonValue);
}
;
_.getClass$ = function getClass_103(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$GenericError_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_7(pojo){
  return $serializeToJson_8(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_7(object){
  return $serializeToJson_8(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_10(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new InvalidRequestError_0;
  fieldJsonValue = $get_0(jsonObject, 'requestError');
  new Serializer_TypeSerializer_0;
  $setRequestError(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.RequestError'), Q$RequestError));
  return mainResult;
}

function $serializeToJson_9(object){
  var fieldValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$InvalidRequestError)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$InvalidRequestError);
  fieldValue = mainVariable.requestError;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'requestError', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.InvalidRequestError'));
  return mainResult;
}

function Serializer_TypeSerializer$InvalidRequestError_SerializableImpl_0(){
}

function Serializer_TypeSerializer$InvalidRequestError_SerializableImpl(){
}

_ = Serializer_TypeSerializer$InvalidRequestError_SerializableImpl_0.prototype = Serializer_TypeSerializer$InvalidRequestError_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_17(jsonString, className){
  return $deSerialize_10(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_18(jsonValue, className){
  return $deSerialize_10(jsonValue);
}
;
_.getClass$ = function getClass_104(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$InvalidRequestError_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_8(pojo){
  return $serializeToJson_9(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_8(object){
  return $serializeToJson_9(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_11(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Item_0;
  fieldJsonValue = $get_0(jsonObject, 'itemId');
  $setItemId(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'description');
  $setDescription_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'price');
  $setPrice(mainResult, getDouble(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'currency');
  $setCurrency_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'billingReceipt');
  $setBillingReceipt(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_10(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Item)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Item);
  fieldValue = mainVariable.itemId;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'itemId', jsonValue);
  fieldValue = mainVariable.description;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'description', jsonValue);
  fieldValue = new Double_0(mainVariable.price);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'price', jsonValue);
  fieldValue = mainVariable.currency;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'currency', jsonValue);
  fieldValue = mainVariable.billingReceipt;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'billingReceipt', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Item'));
  return mainResult;
}

function Serializer_TypeSerializer$Item_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Item_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Item_SerializableImpl_0.prototype = Serializer_TypeSerializer$Item_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_19(jsonString, className){
  return $deSerialize_11(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_20(jsonValue, className){
  return $deSerialize_11(jsonValue);
}
;
_.getClass$ = function getClass_105(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Item_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_9(pojo){
  return $serializeToJson_10(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_9(object){
  return $serializeToJson_10(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_12(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new MessageBody_0;
  fieldJsonValue = $get_0(jsonObject, 'payment');
  new Serializer_TypeSerializer_0;
  $setPayment_0(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Payment'), Q$Payment));
  fieldJsonValue = $get_0(jsonObject, 'transaction');
  new Serializer_TypeSerializer_0;
  $setTransaction(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Transaction'), Q$Transaction));
  fieldJsonValue = $get_0(jsonObject, 'invalidRequestError');
  new Serializer_TypeSerializer_0;
  $setInvalidRequestError(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.InvalidRequestError'), Q$InvalidRequestError));
  fieldJsonValue = $get_0(jsonObject, 'genericError');
  new Serializer_TypeSerializer_0;
  $setGenericError(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.GenericError'), Q$GenericError));
  fieldJsonValue = $get_0(jsonObject, 'transactionList');
  new Serializer_TypeSerializer_0;
  $setTransactionList(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.TransactionList'), Q$TransactionList));
  fieldJsonValue = $get_0(jsonObject, 'prepareAuthenticationIdentifier');
  new Serializer_TypeSerializer_0;
  $setPrepareAuthenticationIdentifier(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.PrepareAuthenticationIdentifier'), Q$PrepareAuthenticationIdentifier));
  fieldJsonValue = $get_0(jsonObject, 'customerReference');
  new Serializer_TypeSerializer_0;
  $setCustomerReference(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.CustomerReference'), Q$CustomerReference));
  fieldJsonValue = $get_0(jsonObject, 'gatewayResponse');
  new Serializer_TypeSerializer_0;
  $setGatewayResponse(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.GatewayResponse'), Q$GatewayResponse));
  fieldJsonValue = $get_0(jsonObject, 'oauth2AuthorizationToken');
  new Serializer_TypeSerializer_0;
  $setOauth2AuthorizationToken(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth2AuthorizationToken'), Q$Oauth2AuthorizationToken));
  fieldJsonValue = $get_0(jsonObject, 'oauth2Authorization');
  new Serializer_TypeSerializer_0;
  $setOauth2Authorization(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth2Authorization'), Q$Oauth2Authorization));
  fieldJsonValue = $get_0(jsonObject, 'oauth2AuthorizationProxyToken');
  new Serializer_TypeSerializer_0;
  $setOauth2AuthorizationProxyToken(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth2AuthorizationProxyToken'), Q$Oauth2AuthorizationProxyToken));
  fieldJsonValue = $get_0(jsonObject, 'oauth2AuthenticationToken');
  new Serializer_TypeSerializer_0;
  $setOauth2AuthenticationToken(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth2AuthenticationToken'), Q$Oauth2AuthenticationToken));
  fieldJsonValue = $get_0(jsonObject, 'oauth2AccessToken');
  new Serializer_TypeSerializer_0;
  $setOauth2AccessToken(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth2AccessToken'), Q$Oauth2AccessToken));
  fieldJsonValue = $get_0(jsonObject, 'oauth1Authorization');
  new Serializer_TypeSerializer_0;
  $setOauth1Authorization(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth1Authorization'), Q$Oauth1Authorization));
  fieldJsonValue = $get_0(jsonObject, 'oauth1Token');
  new Serializer_TypeSerializer_0;
  $setOauth1Token(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth1Token'), Q$Oauth1Token));
  fieldJsonValue = $get_0(jsonObject, 'oauth1AuthorizationToken');
  new Serializer_TypeSerializer_0;
  $setOauth1AuthorizationToken(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth1AuthorizationToken'), Q$Oauth1AuthorizationToken));
  fieldJsonValue = $get_0(jsonObject, 'oauth1AuthorizationProxyToken');
  new Serializer_TypeSerializer_0;
  $setOauth1AuthorizationProxyToken(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth1AuthorizationProxyToken'), Q$Oauth1AuthorizationProxyToken));
  fieldJsonValue = $get_0(jsonObject, 'oauth1AuthorizationVerifier');
  new Serializer_TypeSerializer_0;
  $setOauth1AuthorizationVerifier(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth1AuthorizationVerifier'), Q$Oauth1AuthorizationVerifier));
  return mainResult;
}

function $serializeToJson_11(object){
  var fieldValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$MessageBody)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$MessageBody);
  fieldValue = mainVariable.payment;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'payment', $serializeToJson(fieldValue));
  fieldValue = mainVariable.transaction;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'transaction', $serializeToJson(fieldValue));
  fieldValue = mainVariable.invalidRequestError;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'invalidRequestError', $serializeToJson(fieldValue));
  fieldValue = mainVariable.genericError;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'genericError', $serializeToJson(fieldValue));
  fieldValue = mainVariable.transactionList;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'transactionList', $serializeToJson(fieldValue));
  fieldValue = mainVariable.prepareAuthenticationIdentifier;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'prepareAuthenticationIdentifier', $serializeToJson(fieldValue));
  fieldValue = mainVariable.customerReference;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'customerReference', $serializeToJson(fieldValue));
  fieldValue = mainVariable.gatewayResponse;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'gatewayResponse', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth2AuthorizationToken;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth2AuthorizationToken', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth2Authorization;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth2Authorization', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth2AuthorizationProxyToken;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth2AuthorizationProxyToken', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth2AuthenticationToken;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth2AuthenticationToken', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth2AccessToken;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth2AccessToken', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth1Authorization;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth1Authorization', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth1Token;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth1Token', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth1AuthorizationToken;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth1AuthorizationToken', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth1AuthorizationProxyToken;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth1AuthorizationProxyToken', $serializeToJson(fieldValue));
  fieldValue = mainVariable.oauth1AuthorizationVerifier;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth1AuthorizationVerifier', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.MessageBody'));
  return mainResult;
}

function Serializer_TypeSerializer$MessageBody_SerializableImpl_0(){
}

function Serializer_TypeSerializer$MessageBody_SerializableImpl(){
}

_ = Serializer_TypeSerializer$MessageBody_SerializableImpl_0.prototype = Serializer_TypeSerializer$MessageBody_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_21(jsonString, className){
  return $deSerialize_12(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_22(jsonValue, className){
  return $deSerialize_12(jsonValue);
}
;
_.getClass$ = function getClass_106(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$MessageBody_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_10(pojo){
  return $serializeToJson_11(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_10(object){
  return $serializeToJson_11(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_13(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth1AuthorizationProxyToken_0;
  fieldJsonValue = $get_0(jsonObject, 'uri');
  $setUri_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthToken');
  $setOauthToken_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthTokenSecret');
  $setOauthTokenSecret(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthCallbackConfirmed');
  $setOauthCallbackConfirmed(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_12(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth1AuthorizationProxyToken)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth1AuthorizationProxyToken);
  fieldValue = mainVariable.uri;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'uri', jsonValue);
  fieldValue = mainVariable.oauthToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthToken', jsonValue);
  fieldValue = mainVariable.oauthTokenSecret;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthTokenSecret', jsonValue);
  fieldValue = mainVariable.oauthCallbackConfirmed;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthCallbackConfirmed', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth1AuthorizationProxyToken'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth1AuthorizationProxyToken_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth1AuthorizationProxyToken_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth1AuthorizationProxyToken_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth1AuthorizationProxyToken_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_23(jsonString, className){
  return $deSerialize_13(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_24(jsonValue, className){
  return $deSerialize_13(jsonValue);
}
;
_.getClass$ = function getClass_107(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1AuthorizationProxyToken_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_11(pojo){
  return $serializeToJson_12(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_11(object){
  return $serializeToJson_12(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_14(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth1AuthorizationToken_0;
  fieldJsonValue = $get_0(jsonObject, 'oauthToken');
  $setOauthToken_1(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_13(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth1AuthorizationToken)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth1AuthorizationToken);
  fieldValue = mainVariable.oauthToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthToken', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth1AuthorizationToken'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth1AuthorizationToken_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth1AuthorizationToken_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth1AuthorizationToken_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth1AuthorizationToken_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_25(jsonString, className){
  return $deSerialize_14(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_26(jsonValue, className){
  return $deSerialize_14(jsonValue);
}
;
_.getClass$ = function getClass_108(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1AuthorizationToken_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_12(pojo){
  return $serializeToJson_13(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_12(object){
  return $serializeToJson_13(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_15(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth1AuthorizationVerifier_0;
  fieldJsonValue = $get_0(jsonObject, 'oauthVerifier');
  $setOauthVerifier_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthToken');
  $setOauthToken_2(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_14(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth1AuthorizationVerifier)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth1AuthorizationVerifier);
  fieldValue = mainVariable.oauthVerifier;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthVerifier', jsonValue);
  fieldValue = mainVariable.oauthToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthToken', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth1AuthorizationVerifier'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth1AuthorizationVerifier_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth1AuthorizationVerifier_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth1AuthorizationVerifier_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth1AuthorizationVerifier_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_27(jsonString, className){
  return $deSerialize_15(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_28(jsonValue, className){
  return $deSerialize_15(jsonValue);
}
;
_.getClass$ = function getClass_109(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1AuthorizationVerifier_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_13(pojo){
  return $serializeToJson_14(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_13(object){
  return $serializeToJson_14(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_16(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth1Authorization_0;
  fieldJsonValue = $get_0(jsonObject, 'oauthConsumerKey');
  $setOauthConsumerKey(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthSignatureMethod');
  $setOauthSignatureMethod(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthCallback');
  $setOauthCallback(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthNonce');
  $setOauthNonce(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthScope');
  $setOauthScope(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthSignature');
  $setOauthSignature(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthTimestamp');
  $setOauthTimestamp(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthVersion');
  $setOauthVersion(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthToken');
  $setOauthToken(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthVerifier');
  $setOauthVerifier(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'requestType');
  $setRequestType(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_15(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth1Authorization)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth1Authorization);
  fieldValue = mainVariable.oauthConsumerKey;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthConsumerKey', jsonValue);
  fieldValue = mainVariable.oauthSignatureMethod;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthSignatureMethod', jsonValue);
  fieldValue = mainVariable.oauthCallback;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthCallback', jsonValue);
  fieldValue = mainVariable.oauthNonce;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthNonce', jsonValue);
  fieldValue = mainVariable.oauthScope;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthScope', jsonValue);
  fieldValue = mainVariable.oauthSignature;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthSignature', jsonValue);
  fieldValue = mainVariable.oauthTimestamp;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthTimestamp', jsonValue);
  fieldValue = mainVariable.oauthVersion;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthVersion', jsonValue);
  fieldValue = mainVariable.oauthToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthToken', jsonValue);
  fieldValue = mainVariable.oauthVerifier;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthVerifier', jsonValue);
  fieldValue = mainVariable.requestType;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'requestType', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth1Authorization'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth1Authorization_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth1Authorization_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth1Authorization_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth1Authorization_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_29(jsonString, className){
  return $deSerialize_16(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_30(jsonValue, className){
  return $deSerialize_16(jsonValue);
}
;
_.getClass$ = function getClass_110(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1Authorization_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_14(pojo){
  return $serializeToJson_15(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_14(object){
  return $serializeToJson_15(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_17(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth1Token_0;
  fieldJsonValue = $get_0(jsonObject, 'oauthToken');
  $setOauthToken_3(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauthTokenSecret');
  $setOauthTokenSecret_0(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_16(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth1Token)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth1Token);
  fieldValue = mainVariable.oauthToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthToken', jsonValue);
  fieldValue = mainVariable.oauthTokenSecret;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'oauthTokenSecret', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth1Token'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth1Token_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth1Token_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth1Token_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth1Token_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_31(jsonString, className){
  return $deSerialize_17(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_32(jsonValue, className){
  return $deSerialize_17(jsonValue);
}
;
_.getClass$ = function getClass_111(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1Token_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_15(pojo){
  return $serializeToJson_16(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_15(object){
  return $serializeToJson_16(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_18(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth2AccessToken_0;
  fieldJsonValue = $get_0(jsonObject, 'accessToken');
  $setAccessToken_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'expiresIn');
  $setExpiresIn(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'tokenType');
  $setTokenType(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'secret');
  $setSecret(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'algorithm');
  $setAlgorithm(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'state');
  $setState(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'scope');
  $setScope(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'refreshToken');
  $setRefreshToken(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'serverReferenceCode');
  $setServerReferenceCode_0(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_17(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth2AccessToken)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth2AccessToken);
  fieldValue = mainVariable.accessToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'accessToken', jsonValue);
  fieldValue = mainVariable.expiresIn_0;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'expiresIn', jsonValue);
  fieldValue = mainVariable.tokenType;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'tokenType', jsonValue);
  fieldValue = mainVariable.secret;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'secret', jsonValue);
  fieldValue = mainVariable.algorithm;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'algorithm', jsonValue);
  fieldValue = mainVariable.state;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'state', jsonValue);
  fieldValue = mainVariable.scope;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'scope', jsonValue);
  fieldValue = mainVariable.refreshToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'refreshToken', jsonValue);
  fieldValue = mainVariable.serverReferenceCode;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'serverReferenceCode', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth2AccessToken'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth2AccessToken_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth2AccessToken_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth2AccessToken_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth2AccessToken_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_33(jsonString, className){
  return $deSerialize_18(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_34(jsonValue, className){
  return $deSerialize_18(jsonValue);
}
;
_.getClass$ = function getClass_112(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AccessToken_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_16(pojo){
  return $serializeToJson_17(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_16(object){
  return $serializeToJson_17(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_19(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth2AuthenticationToken_0;
  fieldJsonValue = $get_0(jsonObject, 'code');
  $setCode_2(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'clientId');
  $setClientId(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'clientSecret');
  $setClientSecret(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'redirectUri');
  $setRedirectUri(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'grantType');
  $setGrantType(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'username');
  $setUsername(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'password');
  $setPassword(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'refreshToken');
  $setRefreshToken_0(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_18(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth2AuthenticationToken)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth2AuthenticationToken);
  fieldValue = mainVariable.code;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'code', jsonValue);
  fieldValue = mainVariable.clientId_0;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'clientId', jsonValue);
  fieldValue = mainVariable.clientSecret;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'clientSecret', jsonValue);
  fieldValue = mainVariable.redirectUri;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'redirectUri', jsonValue);
  fieldValue = mainVariable.grantType;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'grantType', jsonValue);
  fieldValue = mainVariable.username;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'username', jsonValue);
  fieldValue = mainVariable.password;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'password', jsonValue);
  fieldValue = mainVariable.refreshToken;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'refreshToken', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth2AuthenticationToken'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth2AuthenticationToken_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth2AuthenticationToken_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth2AuthenticationToken_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth2AuthenticationToken_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_35(jsonString, className){
  return $deSerialize_19(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_36(jsonValue, className){
  return $deSerialize_19(jsonValue);
}
;
_.getClass$ = function getClass_113(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AuthenticationToken_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_17(pojo){
  return $serializeToJson_18(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_17(object){
  return $serializeToJson_18(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_20(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth2AuthorizationProxyToken_0;
  fieldJsonValue = $get_0(jsonObject, 'uri');
  $setUri_1(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oauth2AuthorizationToken');
  new Serializer_TypeSerializer_0;
  $setOauth2AuthorizationToken_0(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Oauth2AuthorizationToken'), Q$Oauth2AuthorizationToken));
  fieldJsonValue = $get_0(jsonObject, 'proxySessionToken');
  $setProxySessionToken(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_19(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth2AuthorizationProxyToken)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth2AuthorizationProxyToken);
  fieldValue = mainVariable.uri;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'uri', jsonValue);
  fieldValue = mainVariable.oauth2AuthorizationToken;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'oauth2AuthorizationToken', $serializeToJson(fieldValue));
  fieldValue = mainVariable.proxySessionToken;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'proxySessionToken', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth2AuthorizationProxyToken'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth2AuthorizationProxyToken_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth2AuthorizationProxyToken_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth2AuthorizationProxyToken_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth2AuthorizationProxyToken_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_37(jsonString, className){
  return $deSerialize_20(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_38(jsonValue, className){
  return $deSerialize_20(jsonValue);
}
;
_.getClass$ = function getClass_114(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AuthorizationProxyToken_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_18(pojo){
  return $serializeToJson_19(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_18(object){
  return $serializeToJson_19(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_21(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth2AuthorizationToken_0;
  fieldJsonValue = $get_0(jsonObject, 'clientId');
  $setClientId_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'redirectUri');
  $setRedirectUri_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'responseType');
  $setResponseType(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'scope');
  $setScope_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'state');
  $setState_0(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_20(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth2AuthorizationToken)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth2AuthorizationToken);
  fieldValue = mainVariable.clientId_0;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'clientId', jsonValue);
  fieldValue = mainVariable.redirectUri;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'redirectUri', jsonValue);
  fieldValue = mainVariable.responseType;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'responseType', jsonValue);
  fieldValue = mainVariable.scope;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'scope', jsonValue);
  fieldValue = mainVariable.state;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'state', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth2AuthorizationToken'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth2AuthorizationToken_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth2AuthorizationToken_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth2AuthorizationToken_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth2AuthorizationToken_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_39(jsonString, className){
  return $deSerialize_21(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_40(jsonValue, className){
  return $deSerialize_21(jsonValue);
}
;
_.getClass$ = function getClass_115(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AuthorizationToken_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_19(pojo){
  return $serializeToJson_20(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_19(object){
  return $serializeToJson_20(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_22(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth2Authorization_0;
  fieldJsonValue = $get_0(jsonObject, 'code');
  $setCode_3(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_21(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth2Authorization)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth2Authorization);
  fieldValue = mainVariable.code;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'code', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth2Authorization'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth2Authorization_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth2Authorization_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth2Authorization_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth2Authorization_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_41(jsonString, className){
  return $deSerialize_22(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_42(jsonValue, className){
  return $deSerialize_22(jsonValue);
}
;
_.getClass$ = function getClass_116(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2Authorization_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_20(pojo){
  return $serializeToJson_21(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_20(object){
  return $serializeToJson_21(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_23(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Oauth2ProtectedAuthorizationToken_0;
  fieldJsonValue = $get_0(jsonObject, 'type');
  $setType_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'token');
  $setToken_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'timestamp');
  $setTimestamp(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'nonce');
  $setNonce(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'signature');
  $setSignature(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_22(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Oauth2ProtectedAuthorizationToken)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Oauth2ProtectedAuthorizationToken);
  fieldValue = mainVariable.type;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'type', jsonValue);
  fieldValue = mainVariable.token;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'token', jsonValue);
  fieldValue = mainVariable.timestamp;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'timestamp', jsonValue);
  fieldValue = mainVariable.nonce;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'nonce', jsonValue);
  fieldValue = mainVariable.signature;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'signature', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Oauth2ProtectedAuthorizationToken'));
  return mainResult;
}

function Serializer_TypeSerializer$Oauth2ProtectedAuthorizationToken_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Oauth2ProtectedAuthorizationToken_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Oauth2ProtectedAuthorizationToken_SerializableImpl_0.prototype = Serializer_TypeSerializer$Oauth2ProtectedAuthorizationToken_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_43(jsonString, className){
  return $deSerialize_23(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_44(jsonValue, className){
  return $deSerialize_23(jsonValue);
}
;
_.getClass$ = function getClass_117(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2ProtectedAuthorizationToken_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_21(pojo){
  return $serializeToJson_22(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_21(object){
  return $serializeToJson_22(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_24(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Operator_0;
  fieldJsonValue = $get_0(jsonObject, 'name');
  $setName(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'mcc');
  $setMcc(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'mnc');
  $setMnc(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'apis');
  new Serializer_TypeSerializer_0;
  $setApis(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Apis'), Q$Apis));
  return mainResult;
}

function $serializeToJson_23(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Operator)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Operator);
  fieldValue = mainVariable.name_0;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'name', jsonValue);
  fieldValue = mainVariable.mcc;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'mcc', jsonValue);
  fieldValue = mainVariable.mnc;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'mnc', jsonValue);
  fieldValue = mainVariable.apis;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'apis', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Operator'));
  return mainResult;
}

function Serializer_TypeSerializer$Operator_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Operator_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Operator_SerializableImpl_0.prototype = Serializer_TypeSerializer$Operator_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_45(jsonString, className){
  return $deSerialize_24(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_46(jsonValue, className){
  return $deSerialize_24(jsonValue);
}
;
_.getClass$ = function getClass_118(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Operator_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_22(pojo){
  return $serializeToJson_23(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_22(object){
  return $serializeToJson_23(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_25(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new PaymentAmount_0;
  fieldJsonValue = $get_0(jsonObject, 'chargingInformation');
  new Serializer_TypeSerializer_0;
  $setChargingInformation(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.ChargingInformation'), Q$ChargingInformation));
  fieldJsonValue = $get_0(jsonObject, 'totalAmountCharged');
  $setTotalAmountCharged(mainResult, getDouble(fieldJsonValue).value);
  return mainResult;
}

function $serializeToJson_24(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$PaymentAmount)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$PaymentAmount);
  fieldValue = mainVariable.chargingInformation;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'chargingInformation', $serializeToJson(fieldValue));
  fieldValue = new Double_0(mainVariable.totalAmountCharged);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'totalAmountCharged', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.PaymentAmount'));
  return mainResult;
}

function Serializer_TypeSerializer$PaymentAmount_SerializableImpl_0(){
}

function Serializer_TypeSerializer$PaymentAmount_SerializableImpl(){
}

_ = Serializer_TypeSerializer$PaymentAmount_SerializableImpl_0.prototype = Serializer_TypeSerializer$PaymentAmount_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_47(jsonString, className){
  return $deSerialize_25(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_48(jsonValue, className){
  return $deSerialize_25(jsonValue);
}
;
_.getClass$ = function getClass_119(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$PaymentAmount_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_23(pojo){
  return $serializeToJson_24(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_23(object){
  return $serializeToJson_24(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_26(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new PaymentApi_0;
  fieldJsonValue = $get_0(jsonObject, 'uri');
  $setUri_2(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'pos');
  $setPos(mainResult, getBoolean(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'currency');
  $setCurrency_2(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_25(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$PaymentApi)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$PaymentApi);
  fieldValue = mainVariable.uri;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'uri', jsonValue);
  fieldValue = ($clinit_Boolean() , mainVariable.pos?TRUE_0:FALSE_0);
  jsonValue = getBoolean_0(dynamicCast(fieldValue, Q$Boolean));
  $put(mainResult, 'pos', jsonValue);
  fieldValue = mainVariable.currency;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'currency', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.PaymentApi'));
  return mainResult;
}

function Serializer_TypeSerializer$PaymentApi_SerializableImpl_0(){
}

function Serializer_TypeSerializer$PaymentApi_SerializableImpl(){
}

_ = Serializer_TypeSerializer$PaymentApi_SerializableImpl_0.prototype = Serializer_TypeSerializer$PaymentApi_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_49(jsonString, className){
  return $deSerialize_26(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_50(jsonValue, className){
  return $deSerialize_26(jsonValue);
}
;
_.getClass$ = function getClass_120(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$PaymentApi_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_24(pojo){
  return $serializeToJson_25(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_24(object){
  return $serializeToJson_25(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_27(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Payment_0;
  fieldJsonValue = $get_0(jsonObject, 'endUserId');
  $setEndUserId_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'referenceCode');
  $setReferenceCode_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'transactionOperationStatus');
  $setTransactionOperationStatus_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'description');
  $setDescription_1(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'currency');
  $setCurrency_1(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'amount');
  $setAmount_0(mainResult, getDouble(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'code');
  $setCode_4(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'clientCorrelator');
  $setClientCorrelator_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'onBehalfOf');
  $setOnBehalfOf(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'purchaseCategoryCode');
  $setPurchaseCategoryCode(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'channel');
  $setChannel(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'taxAmount');
  $setTaxAmount(mainResult, getDouble(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'serviceID');
  $setServiceID(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'productID');
  $setProductID(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_26(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Payment)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Payment);
  fieldValue = mainVariable.endUserId;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'endUserId', jsonValue);
  fieldValue = mainVariable.referenceCode;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'referenceCode', jsonValue);
  fieldValue = mainVariable.transactionOperationStatus;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'transactionOperationStatus', jsonValue);
  fieldValue = mainVariable.description;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'description', jsonValue);
  fieldValue = mainVariable.currency;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'currency', jsonValue);
  fieldValue = new Double_0(mainVariable.amount);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'amount', jsonValue);
  fieldValue = mainVariable.code;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'code', jsonValue);
  fieldValue = mainVariable.clientCorrelator;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'clientCorrelator', jsonValue);
  fieldValue = mainVariable.onBehalfOf;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'onBehalfOf', jsonValue);
  fieldValue = mainVariable.purchaseCategoryCode;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'purchaseCategoryCode', jsonValue);
  fieldValue = mainVariable.channel;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'channel', jsonValue);
  fieldValue = new Double_0(mainVariable.taxAmount);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'taxAmount', jsonValue);
  fieldValue = mainVariable.serviceID;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'serviceID', jsonValue);
  fieldValue = mainVariable.productID;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'productID', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Payment'));
  return mainResult;
}

function Serializer_TypeSerializer$Payment_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Payment_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Payment_SerializableImpl_0.prototype = Serializer_TypeSerializer$Payment_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_51(jsonString, className){
  return $deSerialize_27(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_52(jsonValue, className){
  return $deSerialize_27(jsonValue);
}
;
_.getClass$ = function getClass_121(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Payment_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_25(pojo){
  return $serializeToJson_26(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_25(object){
  return $serializeToJson_26(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_28(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new PrepareAuthenticationIdentifier_0;
  fieldJsonValue = $get_0(jsonObject, 'apiIdentifier');
  $setApiIdentifier(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'apiKey');
  $setApiKey(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'userId');
  $setUserId(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_27(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$PrepareAuthenticationIdentifier)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$PrepareAuthenticationIdentifier);
  fieldValue = mainVariable.apiIdentifier;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'apiIdentifier', jsonValue);
  fieldValue = mainVariable.apiKey;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'apiKey', jsonValue);
  fieldValue = mainVariable.userId;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'userId', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.PrepareAuthenticationIdentifier'));
  return mainResult;
}

function Serializer_TypeSerializer$PrepareAuthenticationIdentifier_SerializableImpl_0(){
}

function Serializer_TypeSerializer$PrepareAuthenticationIdentifier_SerializableImpl(){
}

_ = Serializer_TypeSerializer$PrepareAuthenticationIdentifier_SerializableImpl_0.prototype = Serializer_TypeSerializer$PrepareAuthenticationIdentifier_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_53(jsonString, className){
  return $deSerialize_28(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_54(jsonValue, className){
  return $deSerialize_28(jsonValue);
}
;
_.getClass$ = function getClass_122(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$PrepareAuthenticationIdentifier_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_26(pojo){
  return $serializeToJson_27(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_26(object){
  return $serializeToJson_27(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_29(jsonValue){
  var _class, fieldJsonValue, ij, inpJsonArSize, inputJsonArray, itemsCol, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Product_0;
  fieldJsonValue = $get_0(jsonObject, 'applicationId');
  $setApplicationId(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'items');
  (!fieldJsonValue || instanceOf(fieldJsonValue, Q$JSONNull)) && (mainResult.items = null);
  instanceOf(fieldJsonValue, Q$JSONArray) || (fieldJsonValue = new JSONArray_0);
  inputJsonArray = dynamicCast(fieldJsonValue, Q$JSONArray);
  inpJsonArSize = inputJsonArray.jsArray.length;
  itemsCol = new ArrayList_0;
  for (ij = 0; ij < inpJsonArSize; ++ij) {
    fieldJsonValue = $get(inputJsonArray, ij);
    new Serializer_TypeSerializer_0;
    _class = $get_0(dynamicCast(fieldJsonValue, Q$JSONObject), 'class');
    !!_class && instanceOf(_class, Q$JSONString)?$add(itemsCol, dynamicCast($deSerialize(fieldJsonValue, dynamicCast(_class, Q$JSONString).value), Q$Item)):$add(itemsCol, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Item'), Q$Item));
  }
  mainResult.items = itemsCol;
  return mainResult;
}

function $serializeToJson_28(object){
  var dummy, dummy$iterator, fieldValue, index, itemColValue, jsonResultArray, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Product)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Product);
  fieldValue = mainVariable.applicationId;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'applicationId', jsonValue);
  fieldValue = (!mainVariable.items && (mainVariable.items = new ArrayList_0) , mainVariable.items);
  if (fieldValue != null) {
    itemColValue = dynamicCast(fieldValue, Q$Collection);
    jsonResultArray = new JSONArray_0;
    index = 0;
    for (dummy$iterator = itemColValue.iterator(); dummy$iterator.hasNext();) {
      dummy = dynamicCast(dummy$iterator.next_0(), Q$Item);
      new Serializer_TypeSerializer_0;
      $set(jsonResultArray, index++, $serializeToJson(dummy));
    }
    $put(mainResult, 'items', jsonResultArray);
  }
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Product'));
  return mainResult;
}

function Serializer_TypeSerializer$Product_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Product_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Product_SerializableImpl_0.prototype = Serializer_TypeSerializer$Product_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_55(jsonString, className){
  return $deSerialize_29(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_56(jsonValue, className){
  return $deSerialize_29(jsonValue);
}
;
_.getClass$ = function getClass_123(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Product_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_27(pojo){
  return $serializeToJson_28(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_27(object){
  return $serializeToJson_28(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_30(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new QueryApi_0;
  fieldJsonValue = $get_0(jsonObject, 'type');
  $setType_1(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'uri');
  $setUri_3(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_29(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$QueryApi)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$QueryApi);
  fieldValue = mainVariable.type;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'type', jsonValue);
  fieldValue = mainVariable.uri;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'uri', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.QueryApi'));
  return mainResult;
}

function Serializer_TypeSerializer$QueryApi_SerializableImpl_0(){
}

function Serializer_TypeSerializer$QueryApi_SerializableImpl(){
}

_ = Serializer_TypeSerializer$QueryApi_SerializableImpl_0.prototype = Serializer_TypeSerializer$QueryApi_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_57(jsonString, className){
  return $deSerialize_30(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_58(jsonValue, className){
  return $deSerialize_30(jsonValue);
}
;
_.getClass$ = function getClass_124(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$QueryApi_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_28(pojo){
  return $serializeToJson_29(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_28(object){
  return $serializeToJson_29(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_31(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new RequestError_0;
  fieldJsonValue = $get_0(jsonObject, 'serviceException');
  new Serializer_TypeSerializer_0;
  $setServiceException(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.ServiceException'), Q$ServiceException));
  return mainResult;
}

function $serializeToJson_30(object){
  var fieldValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$RequestError)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$RequestError);
  fieldValue = mainVariable.serviceException;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'serviceException', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.RequestError'));
  return mainResult;
}

function Serializer_TypeSerializer$RequestError_SerializableImpl_0(){
}

function Serializer_TypeSerializer$RequestError_SerializableImpl(){
}

_ = Serializer_TypeSerializer$RequestError_SerializableImpl_0.prototype = Serializer_TypeSerializer$RequestError_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_59(jsonString, className){
  return $deSerialize_31(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_60(jsonValue, className){
  return $deSerialize_31(jsonValue);
}
;
_.getClass$ = function getClass_125(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$RequestError_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_29(pojo){
  return $serializeToJson_30(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_29(object){
  return $serializeToJson_30(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_32(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new ReservedTransaction_0;
  fieldJsonValue = $get_0(jsonObject, 'operationMode');
  $setOperationMode(mainResult, getInt(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'accessToken');
  $setAccessToken_1(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'refCode');
  $setRefCode(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'serverReferenceCode');
  $setServerReferenceCode_1(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'itemId');
  $setItemId_0(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'itemDesc');
  $setItemDesc(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'itemPrice');
  $setItemPrice(mainResult, getDouble(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'itemCurrency');
  $setItemCurrency(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'operatorMcc');
  $setOperatorMcc(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'operatorMnc');
  $setOperatorMnc(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'paymentUri');
  $setPaymentUri(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'apiVersion');
  $setApiVersion(mainResult, getInt(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'paymentMethod');
  $setPaymentMethod(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'verifier');
  $setVerifier(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'oAuthSecret');
  $setOAuthSecret(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'credential');
  $setCredential(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'serviceSecret');
  $setServiceSecret(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'serviceCredential');
  $setServiceCredential(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'appId');
  $setAppId(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_31(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$ReservedTransaction)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$ReservedTransaction);
  fieldValue = valueOf(mainVariable.operationMode);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'operationMode', jsonValue);
  fieldValue = mainVariable.accessToken;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'accessToken', jsonValue);
  fieldValue = mainVariable.refCode;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'refCode', jsonValue);
  fieldValue = mainVariable.serverReferenceCode;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'serverReferenceCode', jsonValue);
  fieldValue = mainVariable.itemId;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'itemId', jsonValue);
  fieldValue = mainVariable.itemDesc;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'itemDesc', jsonValue);
  fieldValue = new Double_0(mainVariable.itemPrice);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'itemPrice', jsonValue);
  fieldValue = mainVariable.itemCurrency;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'itemCurrency', jsonValue);
  fieldValue = mainVariable.operatorMcc;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'operatorMcc', jsonValue);
  fieldValue = mainVariable.operatorMnc;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'operatorMnc', jsonValue);
  fieldValue = mainVariable.paymentUri;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'paymentUri', jsonValue);
  fieldValue = valueOf(mainVariable.apiVersion);
  jsonValue = getNumber(dynamicCast(fieldValue, Q$Number));
  $put(mainResult, 'apiVersion', jsonValue);
  fieldValue = mainVariable.paymentMethod;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'paymentMethod', jsonValue);
  fieldValue = mainVariable.verifier;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'verifier', jsonValue);
  fieldValue = mainVariable.oAuthSecret;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'oAuthSecret', jsonValue);
  fieldValue = mainVariable.credential;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'credential', jsonValue);
  fieldValue = mainVariable.serviceSecret;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'serviceSecret', jsonValue);
  fieldValue = mainVariable.serviceCredential;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'serviceCredential', jsonValue);
  fieldValue = mainVariable.appId;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'appId', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.ReservedTransaction'));
  return mainResult;
}

function Serializer_TypeSerializer$ReservedTransaction_SerializableImpl_0(){
}

function Serializer_TypeSerializer$ReservedTransaction_SerializableImpl(){
}

_ = Serializer_TypeSerializer$ReservedTransaction_SerializableImpl_0.prototype = Serializer_TypeSerializer$ReservedTransaction_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_61(jsonString, className){
  return $deSerialize_32(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_62(jsonValue, className){
  return $deSerialize_32(jsonValue);
}
;
_.getClass$ = function getClass_126(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$ReservedTransaction_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_30(pojo){
  return $serializeToJson_31(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_30(object){
  return $serializeToJson_31(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_33(jsonValue){
  var _class, fieldJsonValue, ij, inpJsonArSize, inputJsonArray, jsonObject, mainResult, operatorsCol;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Response_1;
  fieldJsonValue = $get_0(jsonObject, 'operator');
  new Serializer_TypeSerializer_0;
  $setOperator(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Operator'), Q$Operator));
  fieldJsonValue = $get_0(jsonObject, 'operators');
  (!fieldJsonValue || instanceOf(fieldJsonValue, Q$JSONNull)) && (mainResult.operators = null);
  instanceOf(fieldJsonValue, Q$JSONArray) || (fieldJsonValue = new JSONArray_0);
  inputJsonArray = dynamicCast(fieldJsonValue, Q$JSONArray);
  inpJsonArSize = inputJsonArray.jsArray.length;
  operatorsCol = new ArrayList_0;
  for (ij = 0; ij < inpJsonArSize; ++ij) {
    fieldJsonValue = $get(inputJsonArray, ij);
    new Serializer_TypeSerializer_0;
    _class = $get_0(dynamicCast(fieldJsonValue, Q$JSONObject), 'class');
    !!_class && instanceOf(_class, Q$JSONString)?$add(operatorsCol, dynamicCast($deSerialize(fieldJsonValue, dynamicCast(_class, Q$JSONString).value), Q$Operator)):$add(operatorsCol, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Operator'), Q$Operator));
  }
  mainResult.operators = operatorsCol;
  fieldJsonValue = $get_0(jsonObject, 'product');
  new Serializer_TypeSerializer_0;
  $setProduct(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.Product'), Q$Product));
  return mainResult;
}

function $serializeToJson_32(object){
  var dummy, dummy$iterator, fieldValue, index, jsonResultArray, mainResult, mainVariable, operatorColValue;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Response)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Response);
  fieldValue = mainVariable.operator;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'operator', $serializeToJson(fieldValue));
  fieldValue = (!mainVariable.operators && (mainVariable.operators = new ArrayList_0) , mainVariable.operators);
  if (fieldValue != null) {
    operatorColValue = dynamicCast(fieldValue, Q$Collection);
    jsonResultArray = new JSONArray_0;
    index = 0;
    for (dummy$iterator = operatorColValue.iterator(); dummy$iterator.hasNext();) {
      dummy = dynamicCast(dummy$iterator.next_0(), Q$Operator);
      new Serializer_TypeSerializer_0;
      $set(jsonResultArray, index++, $serializeToJson(dummy));
    }
    $put(mainResult, 'operators', jsonResultArray);
  }
  fieldValue = mainVariable.product;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'product', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Response'));
  return mainResult;
}

function Serializer_TypeSerializer$Response_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Response_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Response_SerializableImpl_0.prototype = Serializer_TypeSerializer$Response_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_63(jsonString, className){
  return $deSerialize_33(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_64(jsonValue, className){
  return $deSerialize_33(jsonValue);
}
;
_.getClass$ = function getClass_127(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Response_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_31(pojo){
  return $serializeToJson_32(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_31(object){
  return $serializeToJson_32(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_34(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new ServiceException_0;
  fieldJsonValue = $get_0(jsonObject, 'messageId');
  $setMessageId(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'text');
  $setText(mainResult, getString(fieldJsonValue));
  fieldJsonValue = $get_0(jsonObject, 'variables');
  $setVariables(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_33(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$ServiceException)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$ServiceException);
  fieldValue = mainVariable.messageId;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'messageId', jsonValue);
  fieldValue = mainVariable.text;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'text', jsonValue);
  fieldValue = mainVariable.variables;
  jsonValue = getString_0(fieldValue);
  $put(mainResult, 'variables', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.ServiceException'));
  return mainResult;
}

function Serializer_TypeSerializer$ServiceException_SerializableImpl_0(){
}

function Serializer_TypeSerializer$ServiceException_SerializableImpl(){
}

_ = Serializer_TypeSerializer$ServiceException_SerializableImpl_0.prototype = Serializer_TypeSerializer$ServiceException_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_65(jsonString, className){
  return $deSerialize_34(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_66(jsonValue, className){
  return $deSerialize_34(jsonValue);
}
;
_.getClass$ = function getClass_128(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$ServiceException_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_32(pojo){
  return $serializeToJson_33(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_32(object){
  return $serializeToJson_33(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_35(jsonValue){
  var _class, amountTransactionCol, fieldJsonValue, ij, inpJsonArSize, inputJsonArray, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new TransactionArray_0;
  fieldJsonValue = $get_0(jsonObject, 'amountTransaction');
  (!fieldJsonValue || instanceOf(fieldJsonValue, Q$JSONNull)) && (mainResult.amountTransaction = null);
  instanceOf(fieldJsonValue, Q$JSONArray) || (fieldJsonValue = new JSONArray_0);
  inputJsonArray = dynamicCast(fieldJsonValue, Q$JSONArray);
  inpJsonArSize = inputJsonArray.jsArray.length;
  amountTransactionCol = new ArrayList_0;
  for (ij = 0; ij < inpJsonArSize; ++ij) {
    fieldJsonValue = $get(inputJsonArray, ij);
    new Serializer_TypeSerializer_0;
    _class = $get_0(dynamicCast(fieldJsonValue, Q$JSONObject), 'class');
    !!_class && instanceOf(_class, Q$JSONString)?$add(amountTransactionCol, dynamicCast($deSerialize(fieldJsonValue, dynamicCast(_class, Q$JSONString).value), Q$AmountTransaction)):$add(amountTransactionCol, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.AmountTransaction'), Q$AmountTransaction));
  }
  mainResult.amountTransaction = amountTransactionCol;
  fieldJsonValue = $get_0(jsonObject, 'resourceURL');
  $setResourceURL_0(mainResult, getString(fieldJsonValue));
  return mainResult;
}

function $serializeToJson_34(object){
  var amounttransactionColValue, dummy, dummy$iterator, fieldValue, index, jsonResultArray, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$TransactionArray)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$TransactionArray);
  fieldValue = (!mainVariable.amountTransaction && (mainVariable.amountTransaction = new ArrayList_0) , mainVariable.amountTransaction);
  if (fieldValue != null) {
    amounttransactionColValue = dynamicCast(fieldValue, Q$Collection);
    jsonResultArray = new JSONArray_0;
    index = 0;
    for (dummy$iterator = amounttransactionColValue.iterator(); dummy$iterator.hasNext();) {
      dummy = dynamicCast(dummy$iterator.next_0(), Q$AmountTransaction);
      new Serializer_TypeSerializer_0;
      $set(jsonResultArray, index++, $serializeToJson(dummy));
    }
    $put(mainResult, 'amountTransaction', jsonResultArray);
  }
  fieldValue = mainVariable.resourceURL;
  jsonValue = getString_0(dynamicCast(fieldValue, Q$String));
  $put(mainResult, 'resourceURL', jsonValue);
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.TransactionArray'));
  return mainResult;
}

function Serializer_TypeSerializer$TransactionArray_SerializableImpl_0(){
}

function Serializer_TypeSerializer$TransactionArray_SerializableImpl(){
}

_ = Serializer_TypeSerializer$TransactionArray_SerializableImpl_0.prototype = Serializer_TypeSerializer$TransactionArray_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_67(jsonString, className){
  return $deSerialize_35(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_68(jsonValue, className){
  return $deSerialize_35(jsonValue);
}
;
_.getClass$ = function getClass_129(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$TransactionArray_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_33(pojo){
  return $serializeToJson_34(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_33(object){
  return $serializeToJson_34(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_36(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new TransactionList_0;
  fieldJsonValue = $get_0(jsonObject, 'fromLocalTransactionStorage');
  $setFromLocalTransactionStorage(mainResult, getBoolean(fieldJsonValue).value);
  fieldJsonValue = $get_0(jsonObject, 'paymentTransactionList');
  new Serializer_TypeSerializer_0;
  $setPaymentTransactionList(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.TransactionArray'), Q$TransactionArray));
  return mainResult;
}

function $serializeToJson_35(object){
  var fieldValue, jsonValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$TransactionList)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$TransactionList);
  fieldValue = ($clinit_Boolean() , mainVariable.fromLocalTransactionStorage?TRUE_0:FALSE_0);
  jsonValue = getBoolean_0(dynamicCast(fieldValue, Q$Boolean));
  $put(mainResult, 'fromLocalTransactionStorage', jsonValue);
  fieldValue = mainVariable.paymentTransactionList;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'paymentTransactionList', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.TransactionList'));
  return mainResult;
}

function Serializer_TypeSerializer$TransactionList_SerializableImpl_0(){
}

function Serializer_TypeSerializer$TransactionList_SerializableImpl(){
}

_ = Serializer_TypeSerializer$TransactionList_SerializableImpl_0.prototype = Serializer_TypeSerializer$TransactionList_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_69(jsonString, className){
  return $deSerialize_36(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_70(jsonValue, className){
  return $deSerialize_36(jsonValue);
}
;
_.getClass$ = function getClass_130(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$TransactionList_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_34(pojo){
  return $serializeToJson_35(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_34(object){
  return $serializeToJson_35(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function $deSerialize_37(jsonValue){
  var fieldJsonValue, jsonObject, mainResult;
  (instanceOf(jsonValue, Q$JSONNull) || !jsonValue) && (jsonValue = ($clinit_JSONNull() , $clinit_JSONNull() , instance_0));
  if (!instanceOf(jsonValue, Q$JSONObject)) {
    return null;
  }
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  mainResult = new Transaction_0;
  fieldJsonValue = $get_0(jsonObject, 'amountTransaction');
  new Serializer_TypeSerializer_0;
  $setAmountTransaction(mainResult, dynamicCast($deSerialize(fieldJsonValue, 'net.wacapps.napi.resource.jaxb.AmountTransaction'), Q$AmountTransaction));
  return mainResult;
}

function $serializeToJson_36(object){
  var fieldValue, mainResult, mainVariable;
  if (object == null) {
    return $clinit_JSONNull() , $clinit_JSONNull() , instance_0;
  }
  if (!instanceOf(object, Q$Transaction)) {
    throw new IncompatibleObjectException_0;
  }
  mainResult = new JSONObject_0;
  mainVariable = dynamicCast(object, Q$Transaction);
  fieldValue = mainVariable.amountTransaction;
  new Serializer_TypeSerializer_0;
  $put(mainResult, 'amountTransaction', $serializeToJson(fieldValue));
  $put(mainResult, 'class', new JSONString_0('net.wacapps.napi.resource.jaxb.Transaction'));
  return mainResult;
}

function Serializer_TypeSerializer$Transaction_SerializableImpl_0(){
}

function Serializer_TypeSerializer$Transaction_SerializableImpl(){
}

_ = Serializer_TypeSerializer$Transaction_SerializableImpl_0.prototype = Serializer_TypeSerializer$Transaction_SerializableImpl.prototype = new Object_0;
_.deSerialize_0 = function deSerialize_71(jsonString, className){
  return $deSerialize_37(($clinit_JSONParser() , parse(jsonString)));
}
;
_.deSerialize = function deSerialize_72(jsonValue, className){
  return $deSerialize_37(jsonValue);
}
;
_.getClass$ = function getClass_131(){
  return Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Transaction_1SerializableImpl_2_classLit;
}
;
_.serialize = function serialize_35(pojo){
  return $serializeToJson_36(pojo).toString$();
}
;
_.serializeToJson = function serializeToJson_35(object){
  return $serializeToJson_36(object);
}
;
_.castableTypeMap$ = makeCastMap([Q$ObjectSerializer]);
function ArithmeticException_0(){
  RuntimeException_0.call(this, 'divide by zero');
}

function ArithmeticException(){
}

_ = ArithmeticException_0.prototype = ArithmeticException.prototype = new RuntimeException;
_.getClass$ = function getClass_132(){
  return Ljava_lang_ArithmeticException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function ArrayStoreException_0(){
  $fillInStackTrace();
}

function ArrayStoreException_1(message){
  RuntimeException_0.call(this, message);
}

function ArrayStoreException(){
}

_ = ArrayStoreException_1.prototype = ArrayStoreException_0.prototype = ArrayStoreException.prototype = new RuntimeException;
_.getClass$ = function getClass_133(){
  return Ljava_lang_ArrayStoreException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $clinit_Boolean(){
  $clinit_Boolean = nullMethod;
  FALSE_0 = new Boolean_1(false);
  TRUE_0 = new Boolean_1(true);
}

function $compareTo(this$static, other){
  return this$static.value == other.value?0:this$static.value?1:-1;
}

function Boolean_1(value){
  this.value = value;
}

function Boolean_0(){
}

_ = Boolean_1.prototype = Boolean_0.prototype = new Object_0;
_.compareTo$ = function compareTo(other){
  return $compareTo(this, dynamicCast(other, Q$Boolean));
}
;
_.equals$ = function equals_5(o){
  return instanceOf(o, Q$Boolean) && dynamicCast(o, Q$Boolean).value == this.value;
}
;
_.getClass$ = function getClass_134(){
  return Ljava_lang_Boolean_2_classLit;
}
;
_.hashCode$ = function hashCode_7(){
  return this.value?1231:1237;
}
;
_.toString$ = function toString_12(){
  return this.value?'true':'false';
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Boolean, Q$Comparable]);
_.value = false;
var FALSE_0, TRUE_0;
function codePointAt(cs, index, limit){
  var hiSurrogate, loSurrogate;
  hiSurrogate = $charAt(cs, index++);
  if (hiSurrogate >= 55296 && hiSurrogate <= 56319 && index < limit && isLowSurrogate(loSurrogate = cs.charCodeAt(index))) {
    return 65536 + ((hiSurrogate & 1023) << 10) + (loSurrogate & 1023);
  }
  return hiSurrogate;
}

function isLowSurrogate(ch){
  return ch >= 56320 && ch <= 57343;
}

function toChars(codePoint, dst, dstIndex){
  if (codePoint < 0 || codePoint > 1114111) {
    throw new IllegalArgumentException_0;
  }
  if (codePoint >= 65536) {
    dst[dstIndex++] = 55296 + (codePoint - 65536 >> 10 & 1023) & 65535;
    dst[dstIndex] = 56320 + (codePoint - 65536 & 1023) & 65535;
    return 2;
  }
   else {
    dst[dstIndex] = codePoint & 65535;
    return 1;
  }
}

function Class_0(){
}

function createForArray(packageName, className, componentType){
  var clazz;
  clazz = new Class_0;
  clazz.typeName = packageName + className;
  clazz.modifiers = 4;
  clazz.superclass = Ljava_lang_Object_2_classLit;
  clazz.componentType = componentType;
  return clazz;
}

function createForClass(packageName, className, superclass){
  var clazz;
  clazz = new Class_0;
  clazz.typeName = packageName + className;
  clazz.superclass = superclass;
  return clazz;
}

function createForEnum(packageName, className, superclass, enumConstantsFunc){
  var clazz;
  clazz = new Class_0;
  clazz.typeName = packageName + className;
  clazz.modifiers = enumConstantsFunc?8:0;
  clazz.superclass = superclass;
  return clazz;
}

function createForInterface(packageName, className){
  var clazz;
  clazz = new Class_0;
  clazz.typeName = packageName + className;
  clazz.modifiers = 2;
  return clazz;
}

function createForPrimitive(className){
  var clazz;
  clazz = new Class_0;
  clazz.typeName = '' + className;
  clazz.modifiers = 1;
  return clazz;
}

function Class(){
}

_ = Class_0.prototype = Class.prototype = new Object_0;
_.getClass$ = function getClass_135(){
  return Ljava_lang_Class_2_classLit;
}
;
_.toString$ = function toString_13(){
  return ((this.modifiers & 2) != 0?'interface ':(this.modifiers & 1) != 0?'':'class ') + this.typeName;
}
;
_.castableTypeMap$ = makeCastMap([Q$Class]);
_.componentType = null;
_.modifiers = 0;
_.superclass = null;
_.typeName = null;
function ClassCastException_0(){
  $fillInStackTrace();
}

function ClassCastException(){
}

_ = ClassCastException_0.prototype = ClassCastException.prototype = new RuntimeException;
_.getClass$ = function getClass_136(){
  return Ljava_lang_ClassCastException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function __parseAndValidateDouble(s){
  var toReturn;
  toReturn = __parseDouble(s);
  if (isNaN(toReturn)) {
    throw new NumberFormatException_0('For input string: "' + s + '"');
  }
  return toReturn;
}

function __parseDouble(str){
  var floatRegex = floatRegex_0;
  !floatRegex && (floatRegex = floatRegex_0 = /^\s*[+-]?((\d+\.?\d*)|(\.\d+))([eE][+-]?\d+)?[dDfF]?\s*$/i);
  if (floatRegex.test(str)) {
    return parseFloat(str);
  }
   else {
    return Number.NaN;
  }
}

function Number_0(){
}

_ = Number_0.prototype = new Object_0;
_.getClass$ = function getClass_137(){
  return Ljava_lang_Number_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Number]);
var floatRegex_0 = null;
function $compareTo_0(this$static, b){
  return compare(this$static.value, b.value);
}

function Double_0(value){
  this.value = value;
}

function compare(x, y){
  if (isNaN(x)) {
    return isNaN(y)?0:1;
  }
   else if (isNaN(y)) {
    return -1;
  }
  return x < y?-1:x > y?1:0;
}

function Double(){
}

_ = Double_0.prototype = Double.prototype = new Number_0;
_.compareTo$ = function compareTo_0(b){
  return $compareTo_0(this, dynamicCast(b, Q$Double));
}
;
_.doubleValue = function doubleValue(){
  return this.value;
}
;
_.equals$ = function equals_6(o){
  return instanceOf(o, Q$Double) && dynamicCast(o, Q$Double).value == this.value;
}
;
_.getClass$ = function getClass_138(){
  return Ljava_lang_Double_2_classLit;
}
;
_.hashCode$ = function hashCode_8(){
  return round_int(this.value);
}
;
_.toString$ = function toString_14(){
  return '' + this.value;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Double, Q$Number]);
_.value = 0;
function $compareTo_1(this$static, other){
  return this$static.ordinal - other.ordinal;
}

function Enum(){
}

_ = Enum.prototype = new Object_0;
_.compareTo$ = function compareTo_1(other){
  return $compareTo_1(this, dynamicCast(other, Q$Enum));
}
;
_.equals$ = function equals_7(other){
  return this === other;
}
;
_.getClass$ = function getClass_139(){
  return Ljava_lang_Enum_2_classLit;
}
;
_.hashCode$ = function hashCode_9(){
  return getHashCode(this);
}
;
_.toString$ = function toString_15(){
  return this.name_0;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Enum]);
_.name_0 = null;
_.ordinal = 0;
function IllegalArgumentException_0(){
  $fillInStackTrace();
}

function IllegalArgumentException_1(message){
  RuntimeException_0.call(this, message);
}

function IllegalArgumentException(){
}

_ = IllegalArgumentException_1.prototype = IllegalArgumentException_0.prototype = IllegalArgumentException.prototype = new RuntimeException;
_.getClass$ = function getClass_140(){
  return Ljava_lang_IllegalArgumentException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function IllegalStateException_0(s){
  RuntimeException_0.call(this, s);
}

function IllegalStateException(){
}

_ = IllegalStateException_0.prototype = IllegalStateException.prototype = new RuntimeException;
_.getClass$ = function getClass_141(){
  return Ljava_lang_IllegalStateException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function IndexOutOfBoundsException_0(){
  $fillInStackTrace();
}

function IndexOutOfBoundsException_1(message){
  RuntimeException_0.call(this, message);
}

function IndexOutOfBoundsException(){
}

_ = IndexOutOfBoundsException_1.prototype = IndexOutOfBoundsException_0.prototype = IndexOutOfBoundsException.prototype = new RuntimeException;
_.getClass$ = function getClass_142(){
  return Ljava_lang_IndexOutOfBoundsException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $compareTo_2(this$static, b){
  return this$static.value < b.value?-1:this$static.value > b.value?1:0;
}

function Integer_0(value){
  this.value = value;
}

function numberOfLeadingZeros_0(i_0){
  var m_0, n, y;
  if (i_0 < 0) {
    return 0;
  }
   else if (i_0 == 0) {
    return 32;
  }
   else {
    y = -(i_0 >> 16);
    m_0 = y >> 16 & 16;
    n = 16 - m_0;
    i_0 = i_0 >> m_0;
    y = i_0 - 256;
    m_0 = y >> 16 & 8;
    n += m_0;
    i_0 <<= m_0;
    y = i_0 - 4096;
    m_0 = y >> 16 & 4;
    n += m_0;
    i_0 <<= m_0;
    y = i_0 - 16384;
    m_0 = y >> 16 & 2;
    n += m_0;
    i_0 <<= m_0;
    y = i_0 >> 14;
    m_0 = y & ~(y >> 1);
    return n + 2 - m_0;
  }
}

function numberOfTrailingZeros(i_0){
  var r, rtn;
  if (i_0 == 0) {
    return 32;
  }
   else {
    rtn = 0;
    for (r = 1; (r & i_0) == 0; r <<= 1) {
      ++rtn;
    }
    return rtn;
  }
}

function toPowerOfTwoString(value){
  var buf, digits, pos;
  buf = initDim(_3C_classLit, makeCastMap([Q$Serializable]), -1, 8, 1);
  digits = ($clinit_Number$__Digits() , digits_0);
  pos = 7;
  if (value >= 0) {
    while (value > 15) {
      buf[pos--] = digits[value & 15];
      value >>= 4;
    }
  }
   else {
    while (pos > 0) {
      buf[pos--] = digits[value & 15];
      value >>= 4;
    }
  }
  buf[pos] = digits[value & 15];
  return __valueOf(buf, pos, 8);
}

function valueOf(i_0){
  var rebase, result;
  if (i_0 > -129 && i_0 < 128) {
    rebase = i_0 + 128;
    result = ($clinit_Integer$BoxedValues() , boxedValues_0)[rebase];
    !result && (result = boxedValues_0[rebase] = new Integer_0(i_0));
    return result;
  }
  return new Integer_0(i_0);
}

function Integer(){
}

_ = Integer_0.prototype = Integer.prototype = new Number_0;
_.compareTo$ = function compareTo_2(b){
  return $compareTo_2(this, dynamicCast(b, Q$Integer));
}
;
_.doubleValue = function doubleValue_0(){
  return this.value;
}
;
_.equals$ = function equals_8(o){
  return instanceOf(o, Q$Integer) && dynamicCast(o, Q$Integer).value == this.value;
}
;
_.getClass$ = function getClass_143(){
  return Ljava_lang_Integer_2_classLit;
}
;
_.hashCode$ = function hashCode_10(){
  return this.value;
}
;
_.toString$ = function toString_16(){
  return '' + this.value;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Integer, Q$Number]);
_.value = 0;
function $clinit_Integer$BoxedValues(){
  $clinit_Integer$BoxedValues = nullMethod;
  boxedValues_0 = initDim(_3Ljava_lang_Integer_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Comparable_$1, Q$Object_$1]), Q$Integer, 256, 0);
}

var boxedValues_0;
function $compareTo_3(this$static, b){
  return lt(this$static.value, b.value)?-1:gt(this$static.value, b.value)?1:0;
}

function Long_0(value){
  this.value = value;
}

function valueOf_0(i_0){
  var rebase, result;
  if (gt(i_0, N81_longLit) && lt(i_0, P80_longLit)) {
    rebase = toInt(i_0) + 128;
    result = ($clinit_Long$BoxedValues() , boxedValues_1)[rebase];
    !result && (result = boxedValues_1[rebase] = new Long_0(i_0));
    return result;
  }
  return new Long_0(i_0);
}

function Long(){
}

_ = Long_0.prototype = Long.prototype = new Number_0;
_.compareTo$ = function compareTo_3(b){
  return $compareTo_3(this, dynamicCast(b, Q$Long));
}
;
_.doubleValue = function doubleValue_1(){
  return toDouble(this.value);
}
;
_.equals$ = function equals_9(o){
  return instanceOf(o, Q$Long) && eq(dynamicCast(o, Q$Long).value, this.value);
}
;
_.getClass$ = function getClass_144(){
  return Ljava_lang_Long_2_classLit;
}
;
_.hashCode$ = function hashCode_11(){
  return toInt(this.value);
}
;
_.toString$ = function toString_17(){
  return '' + toString_11(this.value);
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Long, Q$Number]);
_.value = P0_longLit;
function $clinit_Long$BoxedValues(){
  $clinit_Long$BoxedValues = nullMethod;
  boxedValues_1 = initDim(_3Ljava_lang_Long_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Comparable_$1, Q$Object_$1]), Q$Long, 256, 0);
}

var boxedValues_1;
function min(x, y){
  return x < y?x:y;
}

function NullPointerException_0(){
  $fillInStackTrace();
}

function NullPointerException_1(message){
  RuntimeException_0.call(this, message);
}

function NullPointerException(){
}

_ = NullPointerException_1.prototype = NullPointerException_0.prototype = NullPointerException.prototype = new RuntimeException;
_.getClass$ = function getClass_145(){
  return Ljava_lang_NullPointerException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $clinit_Number$__Digits(){
  $clinit_Number$__Digits = nullMethod;
  digits_0 = initValues(_3C_classLit, makeCastMap([Q$Serializable]), -1, [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122]);
}

var digits_0;
function NumberFormatException_0(message){
  IllegalArgumentException_1.call(this, message);
}

function NumberFormatException(){
}

_ = NumberFormatException_0.prototype = NumberFormatException.prototype = new IllegalArgumentException;
_.getClass$ = function getClass_146(){
  return Ljava_lang_NumberFormatException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$NumberFormatException, Q$RuntimeException, Q$Throwable]);
function StackTraceElement_0(methodName){
  this.className = 'Unknown';
  this.methodName = methodName;
  this.lineNumber = -1;
}

function StackTraceElement(){
}

_ = StackTraceElement_0.prototype = StackTraceElement.prototype = new Object_0;
_.getClass$ = function getClass_147(){
  return Ljava_lang_StackTraceElement_2_classLit;
}
;
_.toString$ = function toString_18(){
  return this.className + '.' + this.methodName + '(Unknown Source' + (this.lineNumber >= 0?':' + this.lineNumber:'') + ')';
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$StackTraceElement]);
_.className = null;
_.lineNumber = 0;
_.methodName = null;
function $charAt(this$static, index){
  return this$static.charCodeAt(index);
}

function $equals(this$static, other){
  if (!instanceOf(other, Q$String)) {
    return false;
  }
  return String(this$static) == other;
}

function $equalsIgnoreCase(this$static, other){
  if (other == null)
    return false;
  return this$static == other || this$static.toLowerCase() == other.toLowerCase();
}

function $getChars(this$static, srcEnd, dst, dstBegin){
  var srcIdx;
  for (srcIdx = 0; srcIdx < srcEnd; ++srcIdx) {
    dst[dstBegin++] = this$static.charCodeAt(srcIdx);
  }
}

function $indexOf(this$static, str, startIndex){
  return this$static.indexOf(str, startIndex);
}

function $replace(this$static, from, to){
  var regex, replacement;
  regex = $replaceAll(from, '([/\\\\\\.\\*\\+\\?\\|\\(\\)\\[\\]\\{\\}$^])', '\\\\$1');
  replacement = $replaceAll($replaceAll(to, '\\\\', '\\\\\\\\'), '\\$', '\\\\$');
  return $replaceAll(this$static, regex, replacement);
}

function $replaceAll(this$static, regex, replace){
  replace = __translateReplaceString(replace);
  return this$static.replace(RegExp(regex, 'g'), replace);
}

function $split(this$static, regex, maxMatch){
  var compiled = new RegExp(regex, 'g');
  var out = [];
  var count = 0;
  var trail = this$static;
  var lastTrail = null;
  while (true) {
    var matchObj = compiled.exec(trail);
    if (matchObj == null || trail == '' || count == maxMatch - 1 && maxMatch > 0) {
      out[count] = trail;
      break;
    }
     else {
      out[count] = trail.substring(0, matchObj.index);
      trail = trail.substring(matchObj.index + matchObj[0].length, trail.length);
      compiled.lastIndex = 0;
      if (lastTrail == trail) {
        out[count] = trail.substring(0, 1);
        trail = trail.substring(1);
      }
      lastTrail = trail;
      count++;
    }
  }
  if (maxMatch == 0 && this$static.length > 0) {
    var lastNonEmpty = out.length;
    while (lastNonEmpty > 0 && out[lastNonEmpty - 1] == '') {
      --lastNonEmpty;
    }
    lastNonEmpty < out.length && out.splice(lastNonEmpty, out.length - lastNonEmpty);
  }
  var jr = __createArray(out.length);
  for (var i_0 = 0; i_0 < out.length; ++i_0) {
    jr[i_0] = out[i_0];
  }
  return jr;
}

function $substring(this$static, beginIndex){
  return this$static.substr(beginIndex, this$static.length - beginIndex);
}

function $toCharArray(this$static){
  var charArr, n;
  n = this$static.length;
  charArr = initDim(_3C_classLit, makeCastMap([Q$Serializable]), -1, n, 1);
  $getChars(this$static, n, charArr, 0);
  return charArr;
}

function $trim(this$static){
  if (this$static.length == 0 || this$static[0] > ' ' && this$static[this$static.length - 1] > ' ') {
    return this$static;
  }
  var r1 = this$static.replace(/^(\s*)/, '');
  var r2 = r1.replace(/\s*$/, '');
  return r2;
}

function _String(bytes){
  return utf8ToString(bytes, bytes.length);
}

function __createArray(numElements){
  return initDim(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, numElements, 0);
}

function __translateReplaceString(replaceStr){
  var pos;
  pos = 0;
  while (0 <= (pos = replaceStr.indexOf('\\', pos))) {
    replaceStr.charCodeAt(pos + 1) == 36?(replaceStr = replaceStr.substr(0, pos - 0) + '$' + $substring(replaceStr, ++pos)):(replaceStr = replaceStr.substr(0, pos - 0) + $substring(replaceStr, ++pos));
  }
  return replaceStr;
}

function __valueOf(x, start, end){
  x = x.slice(start, end);
  return String.fromCharCode.apply(null, x);
}

function compareTo_4(thisStr, otherStr){
  thisStr = String(thisStr);
  if (thisStr == otherStr) {
    return 0;
  }
  return thisStr < otherStr?-1:1;
}

function encodeUtf8(bytes, ofs, codePoint){
  if (codePoint < 128) {
    bytes[ofs] = (codePoint & 127) << 24 >> 24;
    return 1;
  }
   else if (codePoint < 2048) {
    bytes[ofs++] = (codePoint >> 6 & 31 | 192) << 24 >> 24;
    bytes[ofs] = (codePoint & 63 | 128) << 24 >> 24;
    return 2;
  }
   else if (codePoint < 65536) {
    bytes[ofs++] = (codePoint >> 12 & 15 | 224) << 24 >> 24;
    bytes[ofs++] = (codePoint >> 6 & 63 | 128) << 24 >> 24;
    bytes[ofs] = (codePoint & 63 | 128) << 24 >> 24;
    return 3;
  }
   else if (codePoint < 2097152) {
    bytes[ofs++] = (codePoint >> 18 & 7 | 240) << 24 >> 24;
    bytes[ofs++] = (codePoint >> 12 & 63 | 128) << 24 >> 24;
    bytes[ofs++] = (codePoint >> 6 & 63 | 128) << 24 >> 24;
    bytes[ofs] = (codePoint & 63 | 128) << 24 >> 24;
    return 4;
  }
   else if (codePoint < 67108864) {
    bytes[ofs++] = (codePoint >> 24 & 3 | 248) << 24 >> 24;
    bytes[ofs++] = (codePoint >> 18 & 63 | 128) << 24 >> 24;
    bytes[ofs++] = (codePoint >> 12 & 63 | 128) << 24 >> 24;
    bytes[ofs++] = (codePoint >> 6 & 63 | 128) << 24 >> 24;
    bytes[ofs] = (codePoint & 63 | 128) << 24 >> 24;
    return 5;
  }
  throw new IllegalArgumentException_1('Character out of range: ' + codePoint);
}

function fromCodePoint(codePoint){
  var hiSurrogate, loSurrogate;
  if (codePoint >= 65536) {
    hiSurrogate = 55296 + (codePoint - 65536 >> 10 & 1023) & 65535;
    loSurrogate = 56320 + (codePoint - 65536 & 1023) & 65535;
    return String.fromCharCode(hiSurrogate) + String.fromCharCode(loSurrogate);
  }
   else {
    return String.fromCharCode(codePoint & 65535);
  }
}

function getBytesUtf8(str){
  var byteCount, bytes, ch, i_0, n, out;
  n = str.length;
  byteCount = 0;
  for (i_0 = 0; i_0 < n;) {
    ch = codePointAt(str, i_0, str.length);
    i_0 += ch >= 65536?2:1;
    ch < 128?++byteCount:ch < 2048?(byteCount += 2):ch < 65536?(byteCount += 3):ch < 2097152?(byteCount += 4):ch < 67108864 && (byteCount += 5);
  }
  bytes = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, byteCount, 1);
  out = 0;
  for (i_0 = 0; i_0 < n;) {
    ch = codePointAt(str, i_0, str.length);
    i_0 += ch >= 65536?2:1;
    out += encodeUtf8(bytes, out, ch);
  }
  return bytes;
}

function utf8ToString(bytes, len){
  var b, ch, charCount, chars, count, i_0, outIdx;
  charCount = 0;
  for (i_0 = 0; i_0 < len;) {
    ++charCount;
    ch = bytes[i_0];
    if ((ch & 192) == 128) {
      throw new IllegalArgumentException_1('Invalid UTF8 sequence');
    }
     else if ((ch & 128) == 0) {
      ++i_0;
    }
     else if ((ch & 224) == 192) {
      i_0 += 2;
    }
     else if ((ch & 240) == 224) {
      i_0 += 3;
    }
     else if ((ch & 248) == 240) {
      i_0 += 4;
    }
     else {
      throw new IllegalArgumentException_1('Invalid UTF8 sequence');
    }
    if (i_0 > len) {
      throw new IndexOutOfBoundsException_1('Invalid UTF8 sequence');
    }
  }
  chars = initDim(_3C_classLit, makeCastMap([Q$Serializable]), -1, charCount, 1);
  outIdx = 0;
  count = 0;
  for (i_0 = 0; i_0 < len;) {
    ch = bytes[i_0++];
    if ((ch & 128) == 0) {
      count = 1;
      ch &= 127;
    }
     else if ((ch & 224) == 192) {
      count = 2;
      ch &= 31;
    }
     else if ((ch & 240) == 224) {
      count = 3;
      ch &= 15;
    }
     else if ((ch & 248) == 240) {
      count = 4;
      ch &= 7;
    }
     else if ((ch & 252) == 248) {
      count = 5;
      ch &= 3;
    }
    while (--count > 0) {
      b = bytes[i_0++];
      if ((b & 192) != 128) {
        throw new IllegalArgumentException_1('Invalid UTF8 sequence at ' + (i_0 - 1) + ', byte=' + toPowerOfTwoString(b));
      }
      ch = ch << 6 | b & 63;
    }
    outIdx += toChars(ch, chars, outIdx);
  }
  return valueOf_1(chars);
}

function valueOf_1(x){
  return String.fromCharCode.apply(null, x);
}

_ = String.prototype;
_.compareTo$ = function compareTo_5(other){
  return compareTo_4(this, dynamicCast(other, Q$String));
}
;
_.equals$ = function equals_10(other){
  return $equals(this, other);
}
;
_.getClass$ = function getClass_148(){
  return Ljava_lang_String_2_classLit;
}
;
_.hashCode$ = function hashCode_12(){
  return getHashCode_0(this);
}
;
_.toString$ = function toString_19(){
  return this;
}
;
_.castableTypeMap$ = makeCastMap([Q$String, Q$Serializable, Q$CharSequence, Q$Comparable]);
function $clinit_String$HashCache(){
  $clinit_String$HashCache = nullMethod;
  back_0 = {};
  front = {};
}

function compute(str){
  var hashCode, i_0, n, nBatch;
  hashCode = 0;
  n = str.length;
  nBatch = n - 4;
  i_0 = 0;
  while (i_0 < nBatch) {
    hashCode = str.charCodeAt(i_0 + 3) + 31 * (str.charCodeAt(i_0 + 2) + 31 * (str.charCodeAt(i_0 + 1) + 31 * (str.charCodeAt(i_0) + 31 * hashCode))) | 0;
    i_0 += 4;
  }
  while (i_0 < n) {
    hashCode = hashCode * 31 + $charAt(str, i_0++);
  }
  return hashCode | 0;
}

function getHashCode_0(str){
  $clinit_String$HashCache();
  var key = ':' + str;
  var result = front[key];
  if (result != null) {
    return result;
  }
  result = back_0[key];
  result == null && (result = compute(str));
  increment();
  return front[key] = result;
}

function increment(){
  if (count_0 == 256) {
    back_0 = front;
    front = {};
    count_0 = 0;
  }
  ++count_0;
}

var back_0, count_0 = 0, front;
function $append_1(this$static, x){
  $append(this$static.impl, x);
  return this$static;
}

function $append_2(this$static, x){
  $append_0(this$static.impl, x);
  return this$static;
}

function StringBuffer_0(){
  this.impl = new StringBufferImplAppend_0;
}

function StringBuffer(){
}

_ = StringBuffer_0.prototype = StringBuffer.prototype = new Object_0;
_.getClass$ = function getClass_149(){
  return Ljava_lang_StringBuffer_2_classLit;
}
;
_.toString$ = function toString_20(){
  return this.impl.string;
}
;
_.castableTypeMap$ = makeCastMap([Q$CharSequence]);
function $$init(this$static){
  this$static.impl = new StringBufferImplAppend_0;
}

function $append_3(this$static, x){
  $appendNonNull(this$static.impl, String.fromCharCode(x));
  return this$static;
}

function $append_4(this$static, x){
  $append_0(this$static.impl, x);
  return this$static;
}

function StringBuilder_0(){
  $$init(this);
}

function StringBuilder_1(s){
  $$init(this);
  $append_0(this.impl, s);
}

function StringBuilder(){
}

_ = StringBuilder_1.prototype = StringBuilder_0.prototype = StringBuilder.prototype = new Object_0;
_.getClass$ = function getClass_150(){
  return Ljava_lang_StringBuilder_2_classLit;
}
;
_.toString$ = function toString_21(){
  return this.impl.string;
}
;
_.castableTypeMap$ = makeCastMap([Q$CharSequence]);
function arraycopy(src, srcOfs, dest, destOfs, len){
  var destArray, destComp, destEnd, destType, destlen, srcArray, srcComp, srcType, srclen;
  if (src == null || dest == null) {
    throw new NullPointerException_0;
  }
  srcType = src.getClass$();
  destType = getClass__devirtual$(dest);
  if ((srcType.modifiers & 4) == 0 || (destType.modifiers & 4) == 0) {
    throw new ArrayStoreException_1('Must be array types');
  }
  srcComp = srcType.componentType;
  destComp = destType.componentType;
  if (!((srcComp.modifiers & 1) != 0?srcComp == destComp:(destComp.modifiers & 1) == 0)) {
    throw new ArrayStoreException_1('Array types must match');
  }
  srclen = src.length;
  destlen = dest.length;
  if (srcOfs < 0 || destOfs < 0 || len < 0 || srcOfs + len > srclen || destOfs + len > destlen) {
    throw new IndexOutOfBoundsException_0;
  }
  if (((srcComp.modifiers & 1) == 0 || (srcComp.modifiers & 4) != 0) && srcType != destType) {
    srcArray = dynamicCast(src, Q$Object_$1);
    destArray = dynamicCast(dest, Q$Object_$1);
    if (maskUndefined(src) === maskUndefined(dest) && srcOfs < destOfs) {
      srcOfs += len;
      for (destEnd = destOfs + len; destEnd-- > destOfs;) {
        setCheck(destArray, destEnd, srcArray[--srcOfs]);
      }
    }
     else {
      for (destEnd = destOfs + len; destOfs < destEnd;) {
        setCheck(destArray, destOfs++, srcArray[srcOfs++]);
      }
    }
  }
   else {
    Array.prototype.splice.apply(dest, [destOfs, len].concat(src.slice(srcOfs, srcOfs + len)));
  }
}

function currentTimeMillis0(){
  return (new Date).getTime();
}

function UnsupportedOperationException_0(message){
  RuntimeException_0.call(this, message);
}

function UnsupportedOperationException(){
}

_ = UnsupportedOperationException_0.prototype = UnsupportedOperationException.prototype = new RuntimeException;
_.getClass$ = function getClass_151(){
  return Ljava_lang_UnsupportedOperationException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $advanceToFind(iter, o){
  var t;
  while (iter.hasNext()) {
    t = iter.next_0();
    if (o == null?t == null:equals__devirtual$(o, t)) {
      return iter;
    }
  }
  return null;
}

function $toString_0(this$static){
  var comma, iter, sb, value;
  sb = new StringBuffer_0;
  comma = null;
  sb.impl.string += '[';
  iter = this$static.iterator();
  while (iter.hasNext()) {
    comma != null?($append_0(sb.impl, comma) , sb):(comma = ', ');
    value = iter.next_0();
    $append_0(sb.impl, value === this$static?'(this Collection)':'' + value);
  }
  sb.impl.string += ']';
  return sb.impl.string;
}

function AbstractCollection(){
}

_ = AbstractCollection.prototype = new Object_0;
_.add = function add_0(o){
  throw new UnsupportedOperationException_0('Add not supported on this collection');
}
;
_.contains = function contains(o){
  var iter;
  iter = $advanceToFind(this.iterator(), o);
  return !!iter;
}
;
_.getClass$ = function getClass_152(){
  return Ljava_util_AbstractCollection_2_classLit;
}
;
_.toArray = function toArray(a){
  var i_0, it, size;
  size = this.size_0();
  a.length < size && (a = createFrom(a, size));
  it = this.iterator();
  for (i_0 = 0; i_0 < size; ++i_0) {
    setCheck(a, i_0, it.next_0());
  }
  a.length > size && setCheck(a, size, null);
  return a;
}
;
_.toString$ = function toString_22(){
  return $toString_0(this);
}
;
_.castableTypeMap$ = makeCastMap([Q$Collection]);
function $implFindEntry(this$static, key){
  var entry, iter, k_0;
  for (iter = this$static.entrySet().iterator(); iter.hasNext();) {
    entry = dynamicCast(iter.next_0(), Q$Map$Entry);
    k_0 = entry.getKey_0();
    if (key == null?k_0 == null:equals__devirtual$(key, k_0)) {
      return entry;
    }
  }
  return null;
}

function $keySet(this$static){
  var entrySet;
  entrySet = this$static.entrySet();
  return new AbstractMap$1_0(this$static, entrySet);
}

function $toString_1(this$static){
  var comma, entry, iter, s;
  s = '{';
  comma = false;
  for (iter = this$static.entrySet().iterator(); iter.hasNext();) {
    entry = dynamicCast(iter.next_0(), Q$Map$Entry);
    comma?(s += ', '):(comma = true);
    s += '' + entry.getKey_0();
    s += '=';
    s += '' + entry.getValue();
  }
  return s + '}';
}

function AbstractMap(){
}

_ = AbstractMap.prototype = new Object_0;
_.containsKey = function containsKey(key){
  return !!$implFindEntry(this, key);
}
;
_.equals$ = function equals_11(obj){
  var entry, entry$iterator, otherKey, otherMap, otherValue;
  if (obj === this) {
    return true;
  }
  if (!instanceOf(obj, Q$Map)) {
    return false;
  }
  otherMap = dynamicCast(obj, Q$Map);
  if (this.size_0() != otherMap.size_0()) {
    return false;
  }
  for (entry$iterator = otherMap.entrySet().iterator(); entry$iterator.hasNext();) {
    entry = dynamicCast(entry$iterator.next_0(), Q$Map$Entry);
    otherKey = entry.getKey_0();
    otherValue = entry.getValue();
    if (!this.containsKey(otherKey)) {
      return false;
    }
    if (!equalsWithNullCheck(otherValue, this.get_0(otherKey))) {
      return false;
    }
  }
  return true;
}
;
_.get_0 = function get_1(key){
  var entry;
  entry = $implFindEntry(this, key);
  return !entry?null:entry.getValue();
}
;
_.getClass$ = function getClass_153(){
  return Ljava_util_AbstractMap_2_classLit;
}
;
_.hashCode$ = function hashCode_13(){
  var entry, entry$iterator, hashCode;
  hashCode = 0;
  for (entry$iterator = this.entrySet().iterator(); entry$iterator.hasNext();) {
    entry = dynamicCast(entry$iterator.next_0(), Q$Map$Entry);
    hashCode += entry.hashCode$();
    hashCode = ~~hashCode;
  }
  return hashCode;
}
;
_.put = function put(key, value){
  throw new UnsupportedOperationException_0('Put not supported on this map');
}
;
_.size_0 = function size_0(){
  return this.entrySet().size_0();
}
;
_.toString$ = function toString_23(){
  return $toString_1(this);
}
;
_.castableTypeMap$ = makeCastMap([Q$Map]);
function $addAllHashEntries(this$static, dest){
  var hashCodeMap = this$static.hashCodeMap;
  for (var hashCode in hashCodeMap) {
    var hashCodeInt = parseInt(hashCode, 10);
    if (hashCode == hashCodeInt) {
      var array = hashCodeMap[hashCodeInt];
      for (var i_0 = 0, c = array.length; i_0 < c; ++i_0) {
        dest.add(array[i_0]);
      }
    }
  }
}

function $addAllStringEntries(this$static, dest){
  var stringMap = this$static.stringMap;
  for (var key in stringMap) {
    if (key.charCodeAt(0) == 58) {
      var entry = new AbstractHashMap$MapEntryString_0(this$static, key.substring(1));
      dest.add(entry);
    }
  }
}

function $clearImpl(this$static){
  this$static.hashCodeMap = [];
  this$static.stringMap = {};
  this$static.nullSlotLive = false;
  this$static.nullSlot = null;
  this$static.size = 0;
}

function $getHashValue(this$static, key, hashCode){
  var array = this$static.hashCodeMap[hashCode];
  if (array) {
    for (var i_0 = 0, c = array.length; i_0 < c; ++i_0) {
      var entry = array[i_0];
      var entryKey = entry.getKey_0();
      if (this$static.equalsBridge(key, entryKey)) {
        return entry.getValue();
      }
    }
  }
  return null;
}

function $getStringValue(this$static, key){
  return this$static.stringMap[':' + key];
}

function $hasHashValue(this$static, key, hashCode){
  var array = this$static.hashCodeMap[hashCode];
  if (array) {
    for (var i_0 = 0, c = array.length; i_0 < c; ++i_0) {
      var entry = array[i_0];
      var entryKey = entry.getKey_0();
      if (this$static.equalsBridge(key, entryKey)) {
        return true;
      }
    }
  }
  return false;
}

function $putHashValue(this$static, key, value, hashCode){
  var array = this$static.hashCodeMap[hashCode];
  if (array) {
    for (var i_0 = 0, c = array.length; i_0 < c; ++i_0) {
      var entry = array[i_0];
      var entryKey = entry.getKey_0();
      if (this$static.equalsBridge(key, entryKey)) {
        var previous = entry.getValue();
        entry.setValue(value);
        return previous;
      }
    }
  }
   else {
    array = this$static.hashCodeMap[hashCode] = [];
  }
  var entry = new MapEntryImpl_0(key, value);
  array.push(entry);
  ++this$static.size;
  return null;
}

function $putNullSlot(this$static, value){
  var result;
  result = this$static.nullSlot;
  this$static.nullSlot = value;
  if (!this$static.nullSlotLive) {
    this$static.nullSlotLive = true;
    ++this$static.size;
  }
  return result;
}

function $putStringValue(this$static, key, value){
  var result, stringMap = this$static.stringMap;
  key = ':' + key;
  key in stringMap?(result = stringMap[key]):++this$static.size;
  stringMap[key] = value;
  return result;
}

function AbstractHashMap(){
}

_ = AbstractHashMap.prototype = new AbstractMap;
_.containsKey = function containsKey_0(key){
  return key == null?this.nullSlotLive:instanceOf(key, Q$String)?':' + dynamicCast(key, Q$String) in this.stringMap:$hasHashValue(this, key, this.getHashCode(key));
}
;
_.entrySet = function entrySet_0(){
  return new AbstractHashMap$EntrySet_0(this);
}
;
_.equalsBridge = function equalsBridge(value1, value2){
  return this.equals(value1, value2);
}
;
_.get_0 = function get_2(key){
  return key == null?this.nullSlot:instanceOf(key, Q$String)?$getStringValue(this, dynamicCast(key, Q$String)):$getHashValue(this, key, this.getHashCode(key));
}
;
_.getClass$ = function getClass_154(){
  return Ljava_util_AbstractHashMap_2_classLit;
}
;
_.put = function put_0(key, value){
  return key == null?$putNullSlot(this, value):instanceOf(key, Q$String)?$putStringValue(this, dynamicCast(key, Q$String), value):$putHashValue(this, key, value, this.getHashCode(key));
}
;
_.size_0 = function size_1(){
  return this.size;
}
;
_.castableTypeMap$ = makeCastMap([Q$Map]);
_.hashCodeMap = null;
_.nullSlot = null;
_.nullSlotLive = false;
_.size = 0;
_.stringMap = null;
function AbstractSet(){
}

_ = AbstractSet.prototype = new AbstractCollection;
_.equals$ = function equals_12(o){
  var iter, other, otherItem;
  if (o === this) {
    return true;
  }
  if (!instanceOf(o, Q$Set)) {
    return false;
  }
  other = dynamicCast(o, Q$Set);
  if (other.size_0() != this.size_0()) {
    return false;
  }
  for (iter = other.iterator(); iter.hasNext();) {
    otherItem = iter.next_0();
    if (!this.contains(otherItem)) {
      return false;
    }
  }
  return true;
}
;
_.getClass$ = function getClass_155(){
  return Ljava_util_AbstractSet_2_classLit;
}
;
_.hashCode$ = function hashCode_14(){
  var hashCode, iter, next;
  hashCode = 0;
  for (iter = this.iterator(); iter.hasNext();) {
    next = iter.next_0();
    if (next != null) {
      hashCode += hashCode__devirtual$(next);
      hashCode = ~~hashCode;
    }
  }
  return hashCode;
}
;
_.castableTypeMap$ = makeCastMap([Q$Collection, Q$Set]);
function AbstractHashMap$EntrySet_0(this$0){
  this.this$0 = this$0;
}

function AbstractHashMap$EntrySet(){
}

_ = AbstractHashMap$EntrySet_0.prototype = AbstractHashMap$EntrySet.prototype = new AbstractSet;
_.contains = function contains_0(o){
  var entry, key, value;
  if (instanceOf(o, Q$Map$Entry)) {
    entry = dynamicCast(o, Q$Map$Entry);
    key = entry.getKey_0();
    if (this.this$0.containsKey(key)) {
      value = this.this$0.get_0(key);
      return this.this$0.equals(entry.getValue(), value);
    }
  }
  return false;
}
;
_.getClass$ = function getClass_156(){
  return Ljava_util_AbstractHashMap$EntrySet_2_classLit;
}
;
_.iterator = function iterator(){
  return new AbstractHashMap$EntrySetIterator_0(this.this$0);
}
;
_.size_0 = function size_2(){
  return this.this$0.size_0();
}
;
_.castableTypeMap$ = makeCastMap([Q$Collection, Q$Set]);
_.this$0 = null;
function AbstractHashMap$EntrySetIterator_0(this$0){
  var list;
  list = new ArrayList_0;
  this$0.nullSlotLive && $add(list, new AbstractHashMap$MapEntryNull_0(this$0));
  $addAllStringEntries(this$0, list);
  $addAllHashEntries(this$0, list);
  this.iter = new AbstractList$IteratorImpl_0(list);
}

function AbstractHashMap$EntrySetIterator(){
}

_ = AbstractHashMap$EntrySetIterator_0.prototype = AbstractHashMap$EntrySetIterator.prototype = new Object_0;
_.getClass$ = function getClass_157(){
  return Ljava_util_AbstractHashMap$EntrySetIterator_2_classLit;
}
;
_.hasNext = function hasNext(){
  return $hasNext(this.iter);
}
;
_.next_0 = function next_0(){
  return dynamicCast($next(this.iter), Q$Map$Entry);
}
;
_.iter = null;
function AbstractMapEntry(){
}

_ = AbstractMapEntry.prototype = new Object_0;
_.equals$ = function equals_13(other){
  var entry;
  if (instanceOf(other, Q$Map$Entry)) {
    entry = dynamicCast(other, Q$Map$Entry);
    if (equalsWithNullCheck(this.getKey_0(), entry.getKey_0()) && equalsWithNullCheck(this.getValue(), entry.getValue())) {
      return true;
    }
  }
  return false;
}
;
_.getClass$ = function getClass_158(){
  return Ljava_util_AbstractMapEntry_2_classLit;
}
;
_.hashCode$ = function hashCode_15(){
  var keyHash, valueHash;
  keyHash = 0;
  valueHash = 0;
  this.getKey_0() != null && (keyHash = hashCode__devirtual$(this.getKey_0()));
  this.getValue() != null && (valueHash = hashCode__devirtual$(this.getValue()));
  return keyHash ^ valueHash;
}
;
_.toString$ = function toString_24(){
  return this.getKey_0() + '=' + this.getValue();
}
;
_.castableTypeMap$ = makeCastMap([Q$Map$Entry]);
function AbstractHashMap$MapEntryNull_0(this$0){
  this.this$0 = this$0;
}

function AbstractHashMap$MapEntryNull(){
}

_ = AbstractHashMap$MapEntryNull_0.prototype = AbstractHashMap$MapEntryNull.prototype = new AbstractMapEntry;
_.getClass$ = function getClass_159(){
  return Ljava_util_AbstractHashMap$MapEntryNull_2_classLit;
}
;
_.getKey_0 = function getKey(){
  return null;
}
;
_.getValue = function getValue(){
  return this.this$0.nullSlot;
}
;
_.setValue = function setValue(object){
  return $putNullSlot(this.this$0, object);
}
;
_.castableTypeMap$ = makeCastMap([Q$Map$Entry]);
_.this$0 = null;
function AbstractHashMap$MapEntryString_0(this$0, key){
  this.this$0 = this$0;
  this.key = key;
}

function AbstractHashMap$MapEntryString(){
}

_ = AbstractHashMap$MapEntryString_0.prototype = AbstractHashMap$MapEntryString.prototype = new AbstractMapEntry;
_.getClass$ = function getClass_160(){
  return Ljava_util_AbstractHashMap$MapEntryString_2_classLit;
}
;
_.getKey_0 = function getKey_0(){
  return this.key;
}
;
_.getValue = function getValue_0(){
  return $getStringValue(this.this$0, this.key);
}
;
_.setValue = function setValue_0(object){
  return $putStringValue(this.this$0, this.key, object);
}
;
_.castableTypeMap$ = makeCastMap([Q$Map$Entry]);
_.key = null;
_.this$0 = null;
function checkIndex(index, size){
  (index < 0 || index >= size) && indexOutOfBounds(index, size);
}

function indexOutOfBounds(index, size){
  throw new IndexOutOfBoundsException_1('Index: ' + index + ', Size: ' + size);
}

function AbstractList(){
}

_ = AbstractList.prototype = new AbstractCollection;
_.add = function add_1(obj){
  this.add_0(this.size_0(), obj);
  return true;
}
;
_.add_0 = function add_2(index, element){
  throw new UnsupportedOperationException_0('Add not supported on this list');
}
;
_.equals$ = function equals_14(o){
  var elem, elemOther, iter, iterOther, other;
  if (o === this) {
    return true;
  }
  if (!instanceOf(o, Q$List)) {
    return false;
  }
  other = dynamicCast(o, Q$List);
  if (this.size_0() != other.size_0()) {
    return false;
  }
  iter = new AbstractList$IteratorImpl_0(this);
  iterOther = other.iterator();
  while (iter.i < iter.this$0_0.size_0()) {
    elem = $next(iter);
    elemOther = $next(iterOther);
    if (!(elem == null?elemOther == null:equals__devirtual$(elem, elemOther))) {
      return false;
    }
  }
  return true;
}
;
_.getClass$ = function getClass_161(){
  return Ljava_util_AbstractList_2_classLit;
}
;
_.hashCode$ = function hashCode_16(){
  var iter, k_0, obj;
  k_0 = 1;
  iter = new AbstractList$IteratorImpl_0(this);
  while (iter.i < iter.this$0_0.size_0()) {
    obj = $next(iter);
    k_0 = 31 * k_0 + (obj == null?0:hashCode__devirtual$(obj));
    k_0 = ~~k_0;
  }
  return k_0;
}
;
_.iterator = function iterator_0(){
  return new AbstractList$IteratorImpl_0(this);
}
;
_.listIterator = function listIterator(){
  return new AbstractList$ListIteratorImpl_0(this, 0);
}
;
_.listIterator_0 = function listIterator_0(from){
  return new AbstractList$ListIteratorImpl_0(this, from);
}
;
_.castableTypeMap$ = makeCastMap([Q$Collection, Q$List]);
function $hasNext(this$static){
  return this$static.i < this$static.this$0_0.size_0();
}

function $next(this$static){
  if (this$static.i >= this$static.this$0_0.size_0()) {
    throw new NoSuchElementException_0;
  }
  return this$static.this$0_0.get_1(this$static.i++);
}

function AbstractList$IteratorImpl_0(this$0){
  this.this$0_0 = this$0;
}

function AbstractList$IteratorImpl(){
}

_ = AbstractList$IteratorImpl_0.prototype = AbstractList$IteratorImpl.prototype = new Object_0;
_.getClass$ = function getClass_162(){
  return Ljava_util_AbstractList$IteratorImpl_2_classLit;
}
;
_.hasNext = function hasNext_0(){
  return $hasNext(this);
}
;
_.next_0 = function next_1(){
  return $next(this);
}
;
_.i = 0;
_.this$0_0 = null;
function $previous(this$static){
  if (this$static.i <= 0) {
    throw new NoSuchElementException_0;
  }
  return this$static.this$0.get_1(--this$static.i);
}

function AbstractList$ListIteratorImpl_0(this$0, start){
  var size;
  this.this$0 = this$0;
  this.this$0_0 = this$0;
  size = this$0.size_0();
  (start < 0 || start > size) && indexOutOfBounds(start, size);
  this.i = start;
}

function AbstractList$ListIteratorImpl(){
}

_ = AbstractList$ListIteratorImpl_0.prototype = AbstractList$ListIteratorImpl.prototype = new AbstractList$IteratorImpl;
_.getClass$ = function getClass_163(){
  return Ljava_util_AbstractList$ListIteratorImpl_2_classLit;
}
;
_.this$0 = null;
function $iterator(this$static){
  var outerIter;
  outerIter = this$static.val$entrySet.iterator();
  return new AbstractMap$1$1_0(outerIter);
}

function AbstractMap$1_0(this$0, val$entrySet){
  this.this$0 = this$0;
  this.val$entrySet = val$entrySet;
}

function AbstractMap$1(){
}

_ = AbstractMap$1_0.prototype = AbstractMap$1.prototype = new AbstractSet;
_.contains = function contains_1(key){
  return this.this$0.containsKey(key);
}
;
_.getClass$ = function getClass_164(){
  return Ljava_util_AbstractMap$1_2_classLit;
}
;
_.iterator = function iterator_1(){
  return $iterator(this);
}
;
_.size_0 = function size_3(){
  return this.val$entrySet.size_0();
}
;
_.castableTypeMap$ = makeCastMap([Q$Collection, Q$Set]);
_.this$0 = null;
_.val$entrySet = null;
function $next_0(this$static){
  var entry;
  entry = dynamicCast(this$static.val$outerIter.next_0(), Q$Map$Entry);
  return entry.getKey_0();
}

function AbstractMap$1$1_0(val$outerIter){
  this.val$outerIter = val$outerIter;
}

function AbstractMap$1$1(){
}

_ = AbstractMap$1$1_0.prototype = AbstractMap$1$1.prototype = new Object_0;
_.getClass$ = function getClass_165(){
  return Ljava_util_AbstractMap$1$1_2_classLit;
}
;
_.hasNext = function hasNext_1(){
  return this.val$outerIter.hasNext();
}
;
_.next_0 = function next_2(){
  return $next_0(this);
}
;
_.val$outerIter = null;
function $add(this$static, o){
  setCheck(this$static.array, this$static.size++, o);
  return true;
}

function $get_1(this$static, index){
  checkIndex(index, this$static.size);
  return this$static.array[index];
}

function $indexOf_0(this$static, o, index){
  for (; index < this$static.size; ++index) {
    if (equalsWithNullCheck(o, this$static.array[index])) {
      return index;
    }
  }
  return -1;
}

function $remove(this$static, o){
  var i_0, previous;
  i_0 = $indexOf_0(this$static, o, 0);
  if (i_0 == -1) {
    return false;
  }
  previous = (checkIndex(i_0, this$static.size) , this$static.array[i_0]);
  splice_0(this$static.array, i_0, 1);
  --this$static.size;
  return true;
}

function ArrayList_0(){
  this.array = initDim(_3Ljava_lang_Object_2_classLit, makeCastMap([Q$Serializable, Q$Object_$1]), Q$Object, 0, 0);
}

function splice_0(array, index, deleteCount){
  array.splice(index, deleteCount);
}

function splice_1(array, index, deleteCount, value){
  array.splice(index, deleteCount, value);
}

function ArrayList(){
}

_ = ArrayList_0.prototype = ArrayList.prototype = new AbstractList;
_.add = function add_3(o){
  return $add(this, o);
}
;
_.add_0 = function add_4(index, o){
  (index < 0 || index > this.size) && indexOutOfBounds(index, this.size);
  splice_1(this.array, index, 0, o);
  ++this.size;
}
;
_.contains = function contains_2(o){
  return $indexOf_0(this, o, 0) != -1;
}
;
_.get_1 = function get_3(index){
  return $get_1(this, index);
}
;
_.getClass$ = function getClass_166(){
  return Ljava_util_ArrayList_2_classLit;
}
;
_.size_0 = function size_4(){
  return this.size;
}
;
_.toArray = function toArray_0(out){
  var i_0;
  out.length < this.size && (out = createFrom(out, this.size));
  for (i_0 = 0; i_0 < this.size; ++i_0) {
    setCheck(out, i_0, this.array[i_0]);
  }
  out.length > this.size && setCheck(out, this.size, null);
  return out;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Collection, Q$List]);
_.size = 0;
function equals_15(array1, array2){
  var i_0;
  if (maskUndefined(array1) === maskUndefined(array2)) {
    return true;
  }
  if (array1 == null || array2 == null) {
    return false;
  }
  if (array1.length != array2.length) {
    return false;
  }
  for (i_0 = 0; i_0 < array1.length; ++i_0) {
    if (array1[i_0] != array2[i_0]) {
      return false;
    }
  }
  return true;
}

function fill(a, val){
  fill_0(a, a.length, val);
}

function fill_0(a, toIndex, val){
  var i_0;
  for (i_0 = 0; i_0 < toIndex; ++i_0) {
    a[i_0] = val;
  }
}

function hashCode_17(a){
  var hashCode, i_0, n;
  if (a == null) {
    return 0;
  }
  hashCode = 1;
  for (i_0 = 0 , n = a.length; i_0 < n; ++i_0) {
    hashCode = 31 * hashCode + a[i_0] | 0;
  }
  return hashCode;
}

function $clinit_Collections(){
  $clinit_Collections = nullMethod;
  EMPTY_LIST = new Collections$EmptyList_0;
}

var EMPTY_LIST;
function Collections$EmptyList_0(){
}

function Collections$EmptyList(){
}

_ = Collections$EmptyList_0.prototype = Collections$EmptyList.prototype = new AbstractList;
_.contains = function contains_3(object){
  return false;
}
;
_.get_1 = function get_4(location_0){
  throw new IndexOutOfBoundsException_0;
}
;
_.getClass$ = function getClass_167(){
  return Ljava_util_Collections$EmptyList_2_classLit;
}
;
_.size_0 = function size_5(){
  return 0;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Collection, Q$List]);
function HashMap_0(){
  $clearImpl(this);
}

function HashMap(){
}

_ = HashMap_0.prototype = HashMap.prototype = new AbstractHashMap;
_.equals = function equals_16(value1, value2){
  return maskUndefined(value1) === maskUndefined(value2) || value1 != null && equals__devirtual$(value1, value2);
}
;
_.getClass$ = function getClass_168(){
  return Ljava_util_HashMap_2_classLit;
}
;
_.getHashCode = function getHashCode_1(key){
  return ~~hashCode__devirtual$(key);
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Map]);
function $add_0(this$static, o){
  var old;
  old = this$static.map.put(o, this$static);
  return old == null;
}

function HashSet_0(){
  this.map = new HashMap_0;
}

function HashSet_1(map){
  this.map = map;
}

function HashSet(){
}

_ = HashSet_0.prototype = HashSet.prototype = new AbstractSet;
_.add = function add_5(o){
  return $add_0(this, o);
}
;
_.contains = function contains_4(o){
  return this.map.containsKey(o);
}
;
_.getClass$ = function getClass_169(){
  return Ljava_util_HashSet_2_classLit;
}
;
_.iterator = function iterator_2(){
  return $iterator($keySet(this.map));
}
;
_.size_0 = function size_6(){
  return this.map.size_0();
}
;
_.toString$ = function toString_25(){
  return $toString_0($keySet(this.map));
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Collection, Q$Set]);
_.map = null;
function $containsKey(this$static, key){
  return this$static.map.containsKey(key);
}

function $get_2(this$static, key){
  var entry;
  entry = dynamicCast(this$static.map.get_0(key), Q$LinkedHashMap$ChainEntry);
  if (entry) {
    $recordAccess(this$static, entry);
    return entry.value;
  }
  return null;
}

function $recordAccess(this$static, entry){
  if (this$static.accessOrder) {
    entry.next.prev = entry.prev;
    entry.prev.next = entry.next;
    entry.next = entry.prev = null;
    $addToEnd(entry);
  }
}

function LinkedHashMap_0(){
  $clearImpl(this);
  this.head = new LinkedHashMap$ChainEntry_0(this);
  this.map = new HashMap_0;
  this.head.prev = this.head;
  this.head.next = this.head;
}

function LinkedHashMap(){
}

_ = LinkedHashMap_0.prototype = LinkedHashMap.prototype = new HashMap;
_.containsKey = function containsKey_1(key){
  return this.map.containsKey(key);
}
;
_.entrySet = function entrySet_1(){
  return new LinkedHashMap$EntrySet_0(this);
}
;
_.get_0 = function get_5(key){
  return $get_2(this, key);
}
;
_.getClass$ = function getClass_170(){
  return Ljava_util_LinkedHashMap_2_classLit;
}
;
_.put = function put_1(key, value){
  var newEntry, old, oldValue;
  old = dynamicCast(this.map.get_0(key), Q$LinkedHashMap$ChainEntry);
  if (!old) {
    newEntry = new LinkedHashMap$ChainEntry_1(this, key, value);
    this.map.put(key, newEntry);
    $addToEnd(newEntry);
    return null;
  }
   else {
    oldValue = old.value;
    $setValue(old, value);
    $recordAccess(this, old);
    return oldValue;
  }
}
;
_.size_0 = function size_7(){
  return this.map.size_0();
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Map]);
_.accessOrder = false;
function $setValue(this$static, value){
  var old;
  old = this$static.value;
  this$static.value = value;
  return old;
}

function MapEntryImpl_0(key, value){
  this.key = key;
  this.value = value;
}

function MapEntryImpl(){
}

_ = MapEntryImpl_0.prototype = MapEntryImpl.prototype = new AbstractMapEntry;
_.getClass$ = function getClass_171(){
  return Ljava_util_MapEntryImpl_2_classLit;
}
;
_.getKey_0 = function getKey_1(){
  return this.key;
}
;
_.getValue = function getValue_1(){
  return this.value;
}
;
_.setValue = function setValue_1(value){
  return $setValue(this, value);
}
;
_.castableTypeMap$ = makeCastMap([Q$Map$Entry]);
_.key = null;
_.value = null;
function $addToEnd(this$static){
  var tail;
  tail = this$static.this$0.head.prev;
  this$static.prev = tail;
  this$static.next = this$static.this$0.head;
  tail.next = this$static.this$0.head.prev = this$static;
}

function LinkedHashMap$ChainEntry_0(this$0){
  LinkedHashMap$ChainEntry_1.call(this, this$0, null, null);
}

function LinkedHashMap$ChainEntry_1(this$0, key, value){
  this.this$0 = this$0;
  MapEntryImpl_0.call(this, key, value);
  this.next = this.prev = null;
}

function LinkedHashMap$ChainEntry(){
}

_ = LinkedHashMap$ChainEntry_1.prototype = LinkedHashMap$ChainEntry_0.prototype = LinkedHashMap$ChainEntry.prototype = new MapEntryImpl;
_.getClass$ = function getClass_172(){
  return Ljava_util_LinkedHashMap$ChainEntry_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$LinkedHashMap$ChainEntry, Q$Map$Entry]);
_.next = null;
_.prev = null;
_.this$0 = null;
function LinkedHashMap$EntrySet_0(this$0){
  this.this$0 = this$0;
}

function LinkedHashMap$EntrySet(){
}

_ = LinkedHashMap$EntrySet_0.prototype = LinkedHashMap$EntrySet.prototype = new AbstractSet;
_.contains = function contains_5(o){
  var entry, key, value;
  if (!instanceOf(o, Q$Map$Entry)) {
    return false;
  }
  entry = dynamicCast(o, Q$Map$Entry);
  key = entry.getKey_0();
  if ($containsKey(this.this$0, key)) {
    value = $get_2(this.this$0, key);
    return equalsWithNullCheck(entry.getValue(), value);
  }
  return false;
}
;
_.getClass$ = function getClass_173(){
  return Ljava_util_LinkedHashMap$EntrySet_2_classLit;
}
;
_.iterator = function iterator_3(){
  return new LinkedHashMap$EntrySet$EntryIterator_0(this);
}
;
_.size_0 = function size_8(){
  return this.this$0.map.size_0();
}
;
_.castableTypeMap$ = makeCastMap([Q$Collection, Q$Set]);
_.this$0 = null;
function $next_1(this$static){
  if (this$static.next == this$static.this$1.this$0.head) {
    throw new NoSuchElementException_0;
  }
  this$static.last = this$static.next;
  this$static.next = this$static.next.next;
  return this$static.last;
}

function LinkedHashMap$EntrySet$EntryIterator_0(this$1){
  this.this$1 = this$1;
  this.next = this$1.this$0.head.next;
}

function LinkedHashMap$EntrySet$EntryIterator(){
}

_ = LinkedHashMap$EntrySet$EntryIterator_0.prototype = LinkedHashMap$EntrySet$EntryIterator.prototype = new Object_0;
_.getClass$ = function getClass_174(){
  return Ljava_util_LinkedHashMap$EntrySet$EntryIterator_2_classLit;
}
;
_.hasNext = function hasNext_2(){
  return this.next != this.this$1.this$0.head;
}
;
_.next_0 = function next_3(){
  return $next_1(this);
}
;
_.last = null;
_.next = null;
_.this$1 = null;
function LinkedHashSet_0(){
  HashSet_1.call(this, new LinkedHashMap_0);
}

function LinkedHashSet(){
}

_ = LinkedHashSet_0.prototype = LinkedHashSet.prototype = new HashSet;
_.getClass$ = function getClass_175(){
  return Ljava_util_LinkedHashSet_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Collection, Q$Set]);
function NoSuchElementException_0(){
  $fillInStackTrace();
}

function NoSuchElementException(){
}

_ = NoSuchElementException_0.prototype = NoSuchElementException.prototype = new RuntimeException;
_.getClass$ = function getClass_176(){
  return Ljava_util_NoSuchElementException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$RuntimeException, Q$Throwable]);
function $getEntry(this$static, key){
  var c, tree;
  tree = this$static.root;
  while (tree) {
    c = $compare_0(key, tree.key);
    if (c == 0) {
      return tree;
    }
    c < 0?(tree = tree.child[0]):(tree = tree.child[1]);
  }
  return null;
}

function $insert(this$static, tree, newNode, state){
  var c, childNum;
  if (!tree) {
    return newNode;
  }
   else {
    c = $compare_0(tree.key, newNode.key);
    if (c == 0) {
      state.value = tree.value;
      state.found = true;
      tree.value = newNode.value;
      return tree;
    }
    childNum = c > 0?0:1;
    tree.child[childNum] = $insert(this$static, tree.child[childNum], newNode, state);
    if ($isRed(tree.child[childNum])) {
      if ($isRed(tree.child[1 - childNum])) {
        tree.isRed = true;
        tree.child[0].isRed = false;
        tree.child[1].isRed = false;
      }
       else {
        $isRed(tree.child[childNum].child[childNum])?(tree = $rotateSingle(tree, 1 - childNum)):$isRed(tree.child[childNum].child[1 - childNum]) && (tree = (tree.child[1 - (1 - childNum)] = $rotateSingle(tree.child[1 - (1 - childNum)], 1 - (1 - childNum)) , $rotateSingle(tree, 1 - childNum)));
      }
    }
  }
  return tree;
}

function $isRed(node){
  return !!node && node.isRed;
}

function $put_0(this$static, key, value){
  var node, state;
  node = new TreeMap$Node_0(key, value);
  state = new TreeMap$State_0;
  this$static.root = $insert(this$static, this$static.root, node, state);
  state.found || ++this$static.size;
  this$static.root.isRed = false;
  return state.value;
}

function $rotateSingle(tree, rotateDirection){
  var save;
  save = tree.child[1 - rotateDirection];
  tree.child[1 - rotateDirection] = save.child[rotateDirection];
  save.child[rotateDirection] = tree;
  tree.isRed = true;
  save.isRed = false;
  return save;
}

function TreeMap_0(){
  this.root = null;
}

function TreeMap(){
}

_ = TreeMap_0.prototype = TreeMap.prototype = new AbstractMap;
_.containsKey = function containsKey_2(key){
  return !!$getEntry(this, key);
}
;
_.entrySet = function entrySet_2(){
  return new TreeMap$EntrySet_0(this);
}
;
_.get_0 = function get_6(k_0){
  var entry;
  entry = $getEntry(this, k_0);
  return entry?entry.value:null;
}
;
_.getClass$ = function getClass_177(){
  return Ljava_util_TreeMap_2_classLit;
}
;
_.put = function put_2(key, value){
  return $put_0(this, key, value);
}
;
_.size_0 = function size_9(){
  return this.size;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Map]);
_.root = null;
_.size = 0;
function $compare(a, b){
  if (a == null || b == null) {
    throw new NullPointerException_0;
  }
  return a.compareTo$(b);
}

function $compare_0(a, b){
  return $compare(dynamicCast(a, Q$Comparable), b);
}

function $inOrderAdd(this$static, list, type, current, fromKey, toKey){
  if (!current) {
    return;
  }
  !!current.child[0] && $inOrderAdd(this$static, list, type, current.child[0], fromKey, toKey);
  $inRange(type, current.key, fromKey, toKey) && list.add(current);
  !!current.child[1] && $inOrderAdd(this$static, list, type, current.child[1], fromKey, toKey);
}

function $inRange(type, key, fromKey, toKey){
  if (type.toKeyValid()) {
    if ($compare(key, dynamicCast(toKey, Q$Comparable)) >= 0) {
      return false;
    }
  }
  if (type.fromKeyValid()) {
    if ($compare(key, dynamicCast(fromKey, Q$Comparable)) < 0) {
      return false;
    }
  }
  return true;
}

function TreeMap$EntryIterator_0(this$0){
  TreeMap$EntryIterator_1.call(this, this$0, ($clinit_TreeMap$SubMapType() , All));
}

function TreeMap$EntryIterator_1(this$0, type){
  var list;
  list = new ArrayList_0;
  $inOrderAdd(this, list, type, this$0.root, null, null);
  this.iter = new AbstractList$IteratorImpl_0(list);
}

function TreeMap$EntryIterator(){
}

_ = TreeMap$EntryIterator_0.prototype = TreeMap$EntryIterator.prototype = new Object_0;
_.getClass$ = function getClass_178(){
  return Ljava_util_TreeMap$EntryIterator_2_classLit;
}
;
_.hasNext = function hasNext_3(){
  return $hasNext(this.iter);
}
;
_.next_0 = function next_4(){
  return dynamicCast($next(this.iter), Q$Map$Entry);
}
;
_.iter = null;
function TreeMap$EntrySet_0(this$0){
  this.this$0 = this$0;
}

function TreeMap$EntrySet(){
}

_ = TreeMap$EntrySet_0.prototype = TreeMap$EntrySet.prototype = new AbstractSet;
_.contains = function contains_6(o){
  var entry, lookupEntry;
  if (!instanceOf(o, Q$Map$Entry)) {
    return false;
  }
  entry = dynamicCast(o, Q$Map$Entry);
  lookupEntry = $getEntry(this.this$0, entry.getKey_0());
  return !!lookupEntry && equalsWithNullCheck(lookupEntry.value, entry.getValue());
}
;
_.getClass$ = function getClass_179(){
  return Ljava_util_TreeMap$EntrySet_2_classLit;
}
;
_.iterator = function iterator_4(){
  return new TreeMap$EntryIterator_0(this.this$0);
}
;
_.size_0 = function size_10(){
  return this.this$0.size;
}
;
_.castableTypeMap$ = makeCastMap([Q$Collection, Q$Set]);
_.this$0 = null;
function TreeMap$Node_0(key, value){
  this.key = key;
  this.value = value;
  this.child = initDim(_3Ljava_util_TreeMap$Node_2_classLit, makeCastMap([Q$Serializable, Q$Object_$1]), Q$TreeMap$Node, 2, 0);
  this.isRed = true;
}

function TreeMap$Node(){
}

_ = TreeMap$Node_0.prototype = TreeMap$Node.prototype = new Object_0;
_.equals$ = function equals_17(o){
  var other;
  if (!instanceOf(o, Q$TreeMap$Node)) {
    return false;
  }
  other = dynamicCast(o, Q$TreeMap$Node);
  return equalsWithNullCheck(this.key, other.key) && equalsWithNullCheck(this.value, other.value);
}
;
_.getClass$ = function getClass_180(){
  return Ljava_util_TreeMap$Node_2_classLit;
}
;
_.getKey_0 = function getKey_2(){
  return this.key;
}
;
_.getValue = function getValue_2(){
  return this.value;
}
;
_.hashCode$ = function hashCode_18(){
  var keyHash, valueHash;
  keyHash = this.key != null?getHashCode_0(this.key):0;
  valueHash = this.value != null?hashCode__devirtual$(this.value):0;
  return keyHash ^ valueHash;
}
;
_.setValue = function setValue_2(value){
  var old;
  old = this.value;
  this.value = value;
  return old;
}
;
_.toString$ = function toString_26(){
  return this.key + '=' + this.value;
}
;
_.castableTypeMap$ = makeCastMap([Q$Map$Entry, Q$TreeMap$Node]);
_.child = null;
_.isRed = false;
_.key = null;
_.value = null;
function TreeMap$State_0(){
}

function TreeMap$State(){
}

_ = TreeMap$State_0.prototype = TreeMap$State.prototype = new Object_0;
_.getClass$ = function getClass_181(){
  return Ljava_util_TreeMap$State_2_classLit;
}
;
_.toString$ = function toString_27(){
  return 'State: mv=' + this.matchValue + ' value=' + this.value + ' done=' + this.done + ' found=' + this.found;
}
;
_.done = false;
_.found = false;
_.matchValue = false;
_.value = null;
function $clinit_TreeMap$SubMapType(){
  $clinit_TreeMap$SubMapType = nullMethod;
  All = new TreeMap$SubMapType_0('All', 0);
  Head = new TreeMap$SubMapType$1_0;
  Range_0 = new TreeMap$SubMapType$2_0;
  Tail = new TreeMap$SubMapType$3_0;
  $VALUES = initValues(_3Ljava_util_TreeMap$SubMapType_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Comparable_$1, Q$Object_$1]), Q$TreeMap$SubMapType, [All, Head, Range_0, Tail]);
}

function TreeMap$SubMapType_0(enum$name, enum$ordinal){
  this.name_0 = enum$name;
  this.ordinal = enum$ordinal;
}

function values(){
  $clinit_TreeMap$SubMapType();
  return $VALUES;
}

function TreeMap$SubMapType(){
}

_ = TreeMap$SubMapType_0.prototype = TreeMap$SubMapType.prototype = new Enum;
_.fromKeyValid = function fromKeyValid(){
  return false;
}
;
_.getClass$ = function getClass_182(){
  return Ljava_util_TreeMap$SubMapType_2_classLit;
}
;
_.toKeyValid = function toKeyValid(){
  return false;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Enum, Q$TreeMap$SubMapType]);
var $VALUES, All, Head, Range_0, Tail;
function TreeMap$SubMapType$1_0(){
  TreeMap$SubMapType_0.call(this, 'Head', 1);
}

function TreeMap$SubMapType$1(){
}

_ = TreeMap$SubMapType$1_0.prototype = TreeMap$SubMapType$1.prototype = new TreeMap$SubMapType;
_.getClass$ = function getClass_183(){
  return Ljava_util_TreeMap$SubMapType$1_2_classLit;
}
;
_.toKeyValid = function toKeyValid_0(){
  return true;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Enum, Q$TreeMap$SubMapType]);
function TreeMap$SubMapType$2_0(){
  TreeMap$SubMapType_0.call(this, 'Range', 2);
}

function TreeMap$SubMapType$2(){
}

_ = TreeMap$SubMapType$2_0.prototype = TreeMap$SubMapType$2.prototype = new TreeMap$SubMapType;
_.fromKeyValid = function fromKeyValid_0(){
  return true;
}
;
_.getClass$ = function getClass_184(){
  return Ljava_util_TreeMap$SubMapType$2_2_classLit;
}
;
_.toKeyValid = function toKeyValid_1(){
  return true;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Enum, Q$TreeMap$SubMapType]);
function TreeMap$SubMapType$3_0(){
  TreeMap$SubMapType_0.call(this, 'Tail', 3);
}

function TreeMap$SubMapType$3(){
}

_ = TreeMap$SubMapType$3_0.prototype = TreeMap$SubMapType$3.prototype = new TreeMap$SubMapType;
_.fromKeyValid = function fromKeyValid_1(){
  return true;
}
;
_.getClass$ = function getClass_185(){
  return Ljava_util_TreeMap$SubMapType$3_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Comparable, Q$Enum, Q$TreeMap$SubMapType]);
function equalsWithNullCheck(a, b){
  return maskUndefined(a) === maskUndefined(b) || a != null && equals__devirtual$(a, b);
}

function $clinit_Base64(){
  $clinit_Base64 = nullMethod;
  ALPHABET = initValues(_3B_classLit, makeCastMap([Q$Serializable]), -1, [65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47]);
}

function encode_0(source, len, alphabet, doPadding){
  $clinit_Base64();
  var outBuff, outLen;
  outBuff = encode_1(source, len, alphabet);
  outLen = outBuff.length;
  while (!doPadding && outLen > 0) {
    if (outBuff[outLen - 1] != 61) {
      break;
    }
    outLen -= 1;
  }
  return utf8ToString(outBuff, outLen);
}

function encode_1(source, len, alphabet){
  var d, e, inBuff, len2, len43, lenDiv3, lineLength, outBuff;
  lenDiv3 = ~~((len + 2) / 3);
  len43 = lenDiv3 * 4;
  outBuff = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, len43 + ~~(len43 / 2147483647), 1);
  d = 0;
  e = 0;
  len2 = len - 2;
  lineLength = 0;
  for (; d < len2; d += 3 , e += 4) {
    inBuff = source[d] << 24 >>> 8 | source[d + 1] << 24 >>> 16 | source[d + 2] << 24 >>> 24;
    outBuff[e] = alphabet[inBuff >>> 18];
    outBuff[e + 1] = alphabet[inBuff >>> 12 & 63];
    outBuff[e + 2] = alphabet[inBuff >>> 6 & 63];
    outBuff[e + 3] = alphabet[inBuff & 63];
    lineLength += 4;
    if (lineLength == 2147483647) {
      outBuff[e + 4] = 10;
      ++e;
      lineLength = 0;
    }
  }
  if (d < len) {
    encode3to4(source, d, len - d, outBuff, e, alphabet);
    lineLength += 4;
    if (lineLength == 2147483647) {
      outBuff[e + 4] = 10;
      ++e;
    }
    e += 4;
  }
  return outBuff;
}

function encode3to4(source, srcOffset, numSigBytes, destination, destOffset, alphabet){
  var inBuff;
  inBuff = (numSigBytes > 0?source[srcOffset] << 24 >>> 8:0) | (numSigBytes > 1?source[srcOffset + 1] << 24 >>> 16:0) | (numSigBytes > 2?source[srcOffset + 2] << 24 >>> 24:0);
  switch (numSigBytes) {
    case 3:
      destination[destOffset] = alphabet[inBuff >>> 18];
      destination[destOffset + 1] = alphabet[inBuff >>> 12 & 63];
      destination[destOffset + 2] = alphabet[inBuff >>> 6 & 63];
      destination[destOffset + 3] = alphabet[inBuff & 63];
      return destination;
    case 2:
      destination[destOffset] = alphabet[inBuff >>> 18];
      destination[destOffset + 1] = alphabet[inBuff >>> 12 & 63];
      destination[destOffset + 2] = alphabet[inBuff >>> 6 & 63];
      destination[destOffset + 3] = 61;
      return destination;
    case 1:
      destination[destOffset] = alphabet[inBuff >>> 18];
      destination[destOffset + 1] = alphabet[inBuff >>> 12 & 63];
      destination[destOffset + 2] = 61;
      destination[destOffset + 3] = 61;
      return destination;
    default:return destination;
  }
}

var ALPHABET;
function $clinit_HexEncoder(){
  $clinit_HexEncoder = nullMethod;
  encodingTable = initValues(_3B_classLit, makeCastMap([Q$Serializable]), -1, [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102]);
}

function encode_2(data, length_0){
  $clinit_HexEncoder();
  var i_0, index, result, v;
  result = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, length_0 * 2, 1);
  index = 0;
  for (i_0 = 0; i_0 < length_0; ++i_0) {
    v = data[i_0] & 255;
    result[index++] = encodingTable[v >>> 4];
    result[index++] = encodingTable[v & 15];
  }
  return result;
}

var encodingTable;
function NameValuePair_0(name_0, value){
  this.name_0 = name_0;
  this.value = value;
}

function NameValuePair(){
}

_ = NameValuePair_0.prototype = NameValuePair.prototype = new Object_0;
_.getClass$ = function getClass_186(){
  return Lnet_wacapps_napi_api_NameValuePair_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$NameValuePair]);
_.name_0 = null;
_.value = null;
function NapiException_0(message){
  Exception_0.call(this, message);
}

function NapiException(){
}

_ = NapiException_0.prototype = NapiException.prototype = new Exception;
_.getClass$ = function getClass_187(){
  return Lnet_wacapps_napi_api_NapiException_2_classLit;
}
;
_.getMessage = function getMessage_1(){
  return this.detailMessage;
}
;
_.castableTypeMap$ = makeCastMap([Q$Serializable, Q$Exception, Q$Throwable, Q$Exportable]);
function $clinit_Util(){
  $clinit_Util = nullMethod;
  HEX_DIGITS = $toCharArray('0123456789ABCDEF');
}

function getBase64HmacSHA256(sharedSecret, applicationIdentifier, userName, timeStamp){
  $clinit_Util();
  var base64Bytes, baseString, hexBytes, keyBytes, mac, macBytes, secretKeySpec;
  keyBytes = getBytesUtf8(sharedSecret);
  secretKeySpec = new SecretKeySpec_0(keyBytes);
  mac = getInstance_1();
  mac.macSpi.engineInit(secretKeySpec, null);
  baseString = userName + applicationIdentifier + toString_11(timeStamp);
  $update_1(mac, getBytesUtf8(baseString));
  macBytes = mac.macSpi.engineDoFinal();
  base64Bytes = getBytesUtf8(($clinit_Base64() , encode_0(macBytes, macBytes.length, ALPHABET, true)));
  hexBytes = _String(($clinit_HexEncoder() , encode_2(base64Bytes, base64Bytes.length)));
  return hexBytes;
}

function oEncode1(str){
  $clinit_Util();
  var c, c$array, c$index, c$max, sb;
  sb = new StringBuilder_0;
  for (c$array = $toCharArray(str) , c$index = 0 , c$max = c$array.length; c$index < c$max; ++c$index) {
    c = c$array[c$index];
    switch (c) {
      case 33:
        sb.impl.string += '%21';
        break;
      case 42:
        sb.impl.string += '%2A';
        break;
      case 39:
        sb.impl.string += '%27';
        break;
      case 40:
        sb.impl.string += '%28';
        break;
      case 41:
        sb.impl.string += '%29';
        break;
      case 59:
        sb.impl.string += '%3B';
        break;
      case 58:
        sb.impl.string += '%3A';
        break;
      case 64:
        sb.impl.string += '%40';
        break;
      case 44:
      case 38:
        sb.impl.string += '%26';
        break;
      case 61:
        sb.impl.string += '%3D';
        break;
      case 43:
        sb.impl.string += '%2B';
        break;
      case 36:
        sb.impl.string += '%24';
        break;
      case 47:
        sb.impl.string += '%2F';
        break;
      case 63:
        sb.impl.string += '%3F';
        break;
      case 37:
        sb.impl.string += '%25';
        break;
      case 35:
        sb.impl.string += '%23';
        break;
      case 91:
        sb.impl.string += '%5B';
        break;
      case 93:
        sb.impl.string += '%5D';
        break;
      default:$appendNonNull(sb.impl, String.fromCharCode(c));
    }
  }
  return sb.impl.string;
}

function oauthEncode(input){
  $clinit_Util();
  var ch, i_0, sb;
  if (input == null || $equals('', input)) {
    return '';
  }
  sb = new StringBuilder_0;
  for (i_0 = 0; i_0 < input.length; ++i_0) {
    ch = input.charCodeAt(i_0);
    if (null != String.fromCharCode(ch).match(/[A-Z]/i) || null != String.fromCharCode(ch).match(/\d/) || ch == 45 || ch == 46 || ch == 95 || ch == 38 || ch == 126) {
      $appendNonNull(sb.impl, String.fromCharCode(ch));
    }
     else {
      if (ch > 256) {
        throw new IllegalArgumentException_1('CHARACTER_OUT_OF_RANGE');
      }
      sb.impl.string += '%';
      $append_3(sb, HEX_DIGITS[ch >> 4]);
      $append_3(sb, HEX_DIGITS[ch & 15]);
    }
  }
  return sb.impl.string;
}

var HEX_DIGITS;
function $$init_0(this$static){
  this$static.discoveryPathR1 = this$static.baseUrlHttpR1 + '/discovery/operator/';
}

function $adjustToProxy(url){
  return prefix_0 != null && proxy != null?$replace(url, prefix_0, proxy):url;
}

function WacEndpoints_0(httpBaseUrl, httpsBaseUrl, discoveryPath){
  $$init_0(this);
  this.baseUrlHttpR1 = httpBaseUrl;
  this.baseUrlHttpsR1 = httpsBaseUrl;
  this.discoveryPathR1 = discoveryPath;
}

function WacEndpoints_1(env){
  $$init_0(this);
  this.currentEnv = env;
  switch (env) {
    case 10111:
      this.baseUrlHttpR1 = 'http://pro1.api.wacapps.net';
      this.baseUrlHttpsR1 = 'https://pro1.api.wacapps.net';
      this.discoveryPathR1 = this.baseUrlHttpR1 + '/discovery/operator/';
      this.localizationPath = 'https://res.api.wacapps.net/i18n/';
      this.queryPathR2 = 'https://api.wacapps.net/products';
      this.authorizationChargePathR2 = 'https://api.wacapps.net//2/oauth/authorize';
      this.chargePaymentPathR2 = 'https://api.wacapps.net//2/payment/acr:Authorization/transactions/amount';
      this.accessTokenPathR2 = 'https://api.wacapps.net//2/oauth/access-token';
      break;
    case 10112:
      this.baseUrlHttpR1 = 'http://prostage.api.wacapps.net';
      this.baseUrlHttpsR1 = 'https://prostage.api.wacapps.net';
      this.discoveryPathR1 = this.baseUrlHttpR1 + '/discovery/operator/';
      this.localizationPath = 'https://res.api.wacapps.net/dev/i18n/';
      this.queryPathR2 = 'https://staging.api.wacapps.net/products';
      this.authorizationChargePathR2 = 'https://staging.api.wacapps.net//2/oauth/authorize';
      this.chargePaymentPathR2 = 'https://staging.api.wacapps.net//2/payment/acr:Authorization/transactions/amount';
      this.accessTokenPathR2 = 'https://staging.api.wacapps.net//2/oauth/access-token';
      break;
    case 10115:
      this.baseUrlHttpR1 = 'http://prosbx.api.wacapps.net';
      this.baseUrlHttpsR1 = 'https://prosbx.api.wacapps.net';
      this.discoveryPathR1 = this.baseUrlHttpR1 + '/discovery/operator/';
      this.localizationPath = 'https://res.api.wacapps.net/stage/i18n/';
      this.queryPathR2 = 'https://api.wacapps.net/products';
      this.authorizationChargePathR2 = 'https://api.wacapps.net//2/oauth/authorize';
      this.chargePaymentPathR2 = 'https://api.wacapps.net//2/payment/acr:Authorization/transactions/amount';
      this.accessTokenPathR2 = 'https://api.wacapps.net//2/oauth/access-token';
      break;
    case 10114:
    default:throw new UnsupportedOperationException_0('ENV_NOT_SUPPORTED');
  }
}

function WacEndpoints(){
}

_ = WacEndpoints_1.prototype = WacEndpoints_0.prototype = WacEndpoints.prototype = new Object_0;
_.getAccessTokenPath_0 = function getAccessTokenPath(){
  return $adjustToProxy(this.accessTokenPathR2);
}
;
_.getAuthorizationChargePath_0 = function getAuthorizationChargePath(){
  return $adjustToProxy(this.authorizationChargePathR2);
}
;
_.getBaseUrlHttp_0 = function getBaseUrlHttp(){
  return $adjustToProxy(this.baseUrlHttpR1);
}
;
_.getBaseUrlHttps_0 = function getBaseUrlHttps(){
  return $adjustToProxy(this.baseUrlHttpsR1);
}
;
_.getChargePaymentPath_0 = function getChargePaymentPath(){
  return $adjustToProxy(this.chargePaymentPathR2);
}
;
_.getClass$ = function getClass_188(){
  return Lnet_wacapps_napi_api_WacEndpoints_2_classLit;
}
;
_.getDiscoveryPath_0 = function getDiscoveryPath(){
  return $adjustToProxy(this.discoveryPathR1);
}
;
_.getLocalizationPath_0 = function getLocalizationPath(){
  return this.localizationPath;
}
;
_.getLocalizationPathForSuccessPage_0 = function getLocalizationPathForSuccessPage(){
  return this.localizationPathSuccessPage;
}
;
_.getQueryPath_0 = function getQueryPath(){
  return $adjustToProxy(this.queryPathR2);
}
;
_.getSpoofedDiscoverySourceIPForStaging_0 = function getSpoofedDiscoverySourceIPForStaging(){
  return spoofedSourceIPForStaging;
}
;
_.inProduction_0 = function inProduction(){
  return this.currentEnv == 10111;
}
;
_.setAccessTokenPath_0 = function setAccessTokenPath(accessTokenPathR2){
  this.accessTokenPathR2 = accessTokenPathR2;
}
;
_.setAuthorizationChargePath_0 = function setAuthorizationChargePath(chargePaymentPathR2){
  this.authorizationChargePathR2 = chargePaymentPathR2;
}
;
_.setBaseUrlHttp_0 = function setBaseUrlHttp(baseUrlHttp){
  this.baseUrlHttpR1 = baseUrlHttp;
}
;
_.setBaseUrlHttps_0 = function setBaseUrlHttps(baseUrlHttps){
  this.baseUrlHttpsR1 = baseUrlHttps;
}
;
_.setChargePaymentPath_0 = function setChargePaymentPath(chargePaymentPath){
  this.chargePaymentPathR2 = chargePaymentPath;
}
;
_.setDiscoveryPath_0 = function setDiscoveryPath(discoveryPath){
  this.discoveryPathR1 = discoveryPath;
}
;
_.setLocalizationPath_0 = function setLocalizationPath(localizationPath){
  this.localizationPath = localizationPath;
}
;
_.setLocalizationPathForSuccessPage_0 = function setLocalizationPathForSuccessPage(localizationPathSuccessPage){
  this.localizationPathSuccessPage = localizationPathSuccessPage;
}
;
_.setQueryPath_0 = function setQueryPath(queryPathR2){
  this.queryPathR2 = queryPathR2;
}
;
_.setUseHttpClientForRedirects_0 = function setUseHttpClientForRedirects(useHttpClientForRedirects){
  this.useHttpClientForRedirects = useHttpClientForRedirects;
}
;
_.useHttpClientForForwards_0 = function useHttpClientForForwards(){
  return this.useHttpClientForRedirects;
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.accessTokenPathR2 = null;
_.authorizationChargePathR2 = null;
_.baseUrlHttpR1 = 'http://pro1.api.wacapps.net';
_.baseUrlHttpsR1 = 'https://pro1.api.wacapps.net';
_.chargePaymentPathR2 = null;
_.currentEnv = -1;
_.localizationPath = 'https://res.api.wacapps.net/i18n/';
_.localizationPathSuccessPage = 'http://res.api.wacapps.net/payment/confirm';
_.queryPathR2 = null;
_.useHttpClientForRedirects = false;
var prefix_0 = null, proxy = null, spoofedSourceIPForStaging = null;
function $export(){
  if (!exported) {
    exported = true;
    $export0();
  }
}

function $export0(){
  var pkg = declarePackage('net.wacapps.napi.api.WacEndpoints');
  var __0;
  $wnd.net.wacapps.napi.api.WacEndpoints = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_api_WacEndpoints_2_classLit, arguments)?(g = arguments[0]):arguments.length == 3?(g = ___create(arguments[0], arguments[1], arguments[2])):arguments.length == 1 && (g = ___create_0(arguments[0]));
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.api.WacEndpoints.prototype = new Object;
  $wnd.net.wacapps.napi.api.WacEndpoints.GERMAN_IP_STR = '139.7.147.49';
  $wnd.net.wacapps.napi.api.WacEndpoints.PRODUCTION = 10111;
  $wnd.net.wacapps.napi.api.WacEndpoints.STAGING = 10112;
  $wnd.net.wacapps.napi.api.WacEndpoints.DEFAULT = 10114;
  $wnd.net.wacapps.napi.api.WacEndpoints.SANDBOX = 10115;
  __0.getAccessTokenPath = $entry(function(){
    return this.g.getAccessTokenPath_0();
  }
  );
  __0.inProduction = $entry(function(){
    return this.g.inProduction_0();
  }
  );
  __0.setUseHttpClientForRedirects = $entry(function(a0){
    this.g.setUseHttpClientForRedirects_0(a0);
  }
  );
  __0.setLocalizationPathForSuccessPage = $entry(function(a0){
    this.g.setLocalizationPathForSuccessPage_0(a0);
  }
  );
  __0.getBaseUrlHttps = $entry(function(){
    return this.g.getBaseUrlHttps_0();
  }
  );
  __0.getSpoofedDiscoverySourceIPForStaging = $entry(function(){
    return this.g.getSpoofedDiscoverySourceIPForStaging_0();
  }
  );
  __0.setQueryPath = $entry(function(a0){
    this.g.setQueryPath_0(a0);
  }
  );
  __0.getQueryPath = $entry(function(){
    return this.g.getQueryPath_0();
  }
  );
  $wnd.net.wacapps.napi.api.WacEndpoints.setProxy = $entry(function(a0, a1){
    prefix_0 = a0;
    proxy = a1;
  }
  );
  __0.getAuthorizationChargePath = $entry(function(){
    return this.g.getAuthorizationChargePath_0();
  }
  );
  __0.getLocalizationPath = $entry(function(){
    return this.g.getLocalizationPath_0();
  }
  );
  __0.setAccessTokenPath = $entry(function(a0){
    this.g.setAccessTokenPath_0(a0);
  }
  );
  __0.setBaseUrlHttps = $entry(function(a0){
    this.g.setBaseUrlHttps_0(a0);
  }
  );
  __0.setDiscoveryPath = $entry(function(a0){
    this.g.setDiscoveryPath_0(a0);
  }
  );
  __0.setChargePaymentPath = $entry(function(a0){
    this.g.setChargePaymentPath_0(a0);
  }
  );
  __0.getBaseUrlHttp = $entry(function(){
    return this.g.getBaseUrlHttp_0();
  }
  );
  __0.useHttpClientForForwards = $entry(function(){
    return this.g.useHttpClientForForwards_0();
  }
  );
  __0.getChargePaymentPath = $entry(function(){
    return this.g.getChargePaymentPath_0();
  }
  );
  __0.setBaseUrlHttp = $entry(function(a0){
    this.g.setBaseUrlHttp_0(a0);
  }
  );
  __0.setLocalizationPath = $entry(function(a0){
    this.g.setLocalizationPath_0(a0);
  }
  );
  __0.getLocalizationPathForSuccessPage = $entry(function(){
    return this.g.getLocalizationPathForSuccessPage_0();
  }
  );
  __0.getDiscoveryPath = $entry(function(){
    return this.g.getDiscoveryPath_0();
  }
  );
  __0.setAuthorizationChargePath = $entry(function(a0){
    this.g.setAuthorizationChargePath_0(a0);
  }
  );
  $wnd.net.wacapps.napi.api.WacEndpoints.setSpoofedDiscoverySourceIPForStaging = $entry(function(a0){
    spoofedSourceIPForStaging = a0;
  }
  );
  addTypeMap(Lnet_wacapps_napi_api_WacEndpoints_2_classLit, $wnd.net.wacapps.napi.api.WacEndpoints);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.api.WacEndpoints[p] === undefined && ($wnd.net.wacapps.napi.api.WacEndpoints[p] = pkg[p]);
}

function WacEndpointsExporterImpl_0(){
  $export();
}

function ___create(a0, a1, a2){
  return new WacEndpoints_0(a0, a1, a2);
}

function ___create_0(a0){
  return new WacEndpoints_1(a0);
}

function WacEndpointsExporterImpl(){
}

_ = WacEndpointsExporterImpl_0.prototype = WacEndpointsExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_189(){
  return Lnet_wacapps_napi_api_WacEndpointsExporterImpl_2_classLit;
}
;
var exported = false;
function executeHttpGet(url, headers, callback){
  return executeHttpMethod(($clinit_RequestBuilder() , GET), url, null, headers, callback);
}

function executeHttpMethod(method, url, postParameters, headers, callback){
  var builder, encoded, headerKeys, i_0, key, key$iterator, nv, postData;
  builder = new RequestBuilder_0(method, url);
  builder.timeoutMillis = 30000;
  if (headers) {
    headerKeys = $keySet(headers);
    for (key$iterator = $iterator(headerKeys); key$iterator.val$outerIter.hasNext();) {
      key = dynamicCast($next_0(key$iterator), Q$String);
      $setHeader(builder, key, dynamicCast(headers.get_0(key), Q$String));
    }
  }
  postData = new StringBuffer_0;
  if (postParameters) {
    for (i_0 = 0; i_0 < postParameters.size; ++i_0) {
      nv = dynamicCast((checkIndex(i_0, postParameters.size) , postParameters.array[i_0]), Q$NameValuePair);
      $append_2($append_2($append_2(postData, nv.name_0), '='), nv.value);
      i_0 < postParameters.size - 1 && (postData.impl.string += '&' , postData);
    }
  }
  $setHeader(builder, 'Content-Type', 'application/x-www-form-urlencoded');
  encoded = encode(postData.impl.string);
  request_0 = (throwIfNull('callback', callback) , $doSend(builder, encoded, callback));
  return request_0;
}

function executeHttpPost(url, postParameters, headers, callback){
  return executeHttpMethod(($clinit_RequestBuilder() , POST), url, postParameters, headers, callback);
}

var request_0 = null;
function $setEndPoints(this$static, endPoints){
  this$static.endPoints = endPoints;
}

function WacNapiContext_0(){
}

function WacNapiContext(){
}

_ = WacNapiContext_0.prototype = WacNapiContext.prototype = new Object_0;
_.getCallback_0 = function getCallback(){
  return this.callback;
}
;
_.getClass$ = function getClass_190(){
  return Lnet_wacapps_napi_api_WacNapiContext_2_classLit;
}
;
_.getEndPoints_0 = function getEndPoints(){
  return this.endPoints;
}
;
_.getPaymentService_0 = function getPaymentService(){
  return this.service;
}
;
_.setCallback_0 = function setCallback(callback){
  this.callback = callback;
}
;
_.setEndPoints_0 = function setEndPoints(endPoints){
  this.endPoints = endPoints;
}
;
_.setPaymentService_0 = function setPaymentService(service){
  this.service = service;
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.callback = null;
_.endPoints = null;
_.service = null;
var instance_1 = null;
function $export_0(){
  if (!exported_0) {
    exported_0 = true;
    new WacEndpointsExporterImpl_0;
    $export0_0();
  }
}

function $export0_0(){
  var pkg = declarePackage('net.wacapps.napi.api.WacNapiContext');
  var __0;
  $wnd.net.wacapps.napi.api.WacNapiContext = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_api_WacNapiContext_2_classLit, arguments) && (g = arguments[0]);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.api.WacNapiContext.prototype = new Object;
  __0.setEndPoints = $entry(function(a0){
    this.g.setEndPoints_0(gwtInstance(a0));
  }
  );
  __0.setCallback = $entry(function(a0){
    this.g.setCallback_0(a0);
  }
  );
  __0.getCallback = $entry(function(){
    return this.g.getCallback_0();
  }
  );
  __0.getEndPoints = $entry(function(){
    return wrap(this.g.getEndPoints_0());
  }
  );
  __0.setPaymentService = $entry(function(a0){
    this.g.setPaymentService_0(gwtInstance(a0));
  }
  );
  $wnd.net.wacapps.napi.api.WacNapiContext.getInstance = $entry(function(){
    return wrap((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1));
  }
  );
  __0.getPaymentService = $entry(function(){
    return this.g.getPaymentService_0();
  }
  );
  addTypeMap(Lnet_wacapps_napi_api_WacNapiContext_2_classLit, $wnd.net.wacapps.napi.api.WacNapiContext);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.api.WacNapiContext[p] === undefined && ($wnd.net.wacapps.napi.api.WacNapiContext[p] = pkg[p]);
}

function WacNapiContextExporterImpl_0(){
  $export_0();
}

function WacNapiContextExporterImpl(){
}

_ = WacNapiContextExporterImpl_0.prototype = WacNapiContextExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_191(){
  return Lnet_wacapps_napi_api_WacNapiContextExporterImpl_2_classLit;
}
;
var exported_0 = false;
function WacRestApi_0(){
}

function doAOauth1CheckTransaction(callback, token, verifier, tokenSecret, clientSecret, cred, operator, referenceCode){
  var $e0, e, encodedString, err, generatedNonce, headers, key, keyString, mac, oAuthHeader, oAuthHeaderParams, sigBaseUrl, sign2Param, signatureBaseString, signatureBaseString1, signatureBaseString2, skeySpec, timeStamp, blockKey;
  sigBaseUrl = operator.apis.payment.uri + '/' + referenceCode;
  generatedNonce = ($clinit_UUID() , uuid_2());
  timeStamp = '' + toString_11(div(fromDouble(currentTimeMillis0()), P3e8_longLit));
  signatureBaseString1 = oauthEncode('GET&' + sigBaseUrl + '&');
  sign2Param = new TreeMap_0;
  $put_0(sign2Param, 'oauth_consumer_key', cred);
  $put_0(sign2Param, 'oauth_nonce', generatedNonce);
  $put_0(sign2Param, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(sign2Param, 'oauth_timestamp', timeStamp);
  $put_0(sign2Param, 'oauth_token', oauthEncode(token));
  $put_0(sign2Param, 'oauth_verifier', oauthEncode(verifier));
  $put_0(sign2Param, 'oauth_version', '1.0');
  signatureBaseString2 = keyValueParameters(sign2Param, ',', false);
  signatureBaseString = signatureBaseString1 + ($clinit_Util() , oEncode1(signatureBaseString2));
  keyString = oauthEncode(clientSecret + '&' + (throwIfNull('encodedURL', tokenSecret) , decodeURI(tokenSecret)));
  key = getBytesUtf8(keyString);
  try {
    mac = new Hmac$SHA1_2;
    skeySpec = new SecretKeySpec_2(key);
    mac.digest.delegate = new Sha256_0;
    mac.opad = repeat(92, mac.blockSize);
    mac.ipad = repeat(54, mac.blockSize);
    blockKey = $expandOrReduceKeyToBlocksize_0(mac, copyOfRange_0(skeySpec.key, skeySpec.key.length));
    xor_2(mac.opad, blockKey);
    xor_2(mac.ipad, blockKey);
    mac.digest.delegate = new Sha256_0;
    $update_5(mac.digest, mac.ipad);
    encodedString = encode_3($doFinal(mac, getBytesUtf8(signatureBaseString)));
    encodedString = oauthEncode(encodedString);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      err = $e0;
      throw new NapiException_0(err.getMessage());
    }
     else 
      throw $e0;
  }
  oAuthHeaderParams = new TreeMap_0;
  $put_0(oAuthHeaderParams, 'oauth_signature', encodedString);
  $put_0(oAuthHeaderParams, 'oauth_version', '1.0');
  $put_0(oAuthHeaderParams, 'oauth_nonce', oauthEncode(generatedNonce));
  $put_0(oAuthHeaderParams, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(oAuthHeaderParams, 'oauth_consumer_key', cred);
  $put_0(oAuthHeaderParams, 'oauth_timestamp', timeStamp);
  $put_0(oAuthHeaderParams, 'oauth_token', oauthEncode(token));
  $put_0(oAuthHeaderParams, 'oauth_verifier', oauthEncode(verifier));
  oAuthHeader = 'OAuth ' + keyValueParameters(oAuthHeaderParams, ',', true);
  headers = new HashMap_0;
  headers.put('Authorization', oAuthHeader);
  headers.put('x-mnc', operator.mnc);
  headers.put('x-mcc', operator.mcc);
  try {
    executeHttpMethod(($clinit_RequestBuilder() , GET), sigBaseUrl, null, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doAOauth1ListTransactions(callback, token, verifier, tokenSecret, clientSecret, cred, operator){
  var $e0, e, generatedNonce, headers, oAuthHeader, oAuthHeaderParams, sigBaseUrl, sign2Param, signatureBaseString1, signatureBaseString2, timeStamp;
  sigBaseUrl = operator.apis.payment.uri;
  generatedNonce = ($clinit_UUID() , uuid_2());
  timeStamp = '' + toString_11(div(fromDouble(currentTimeMillis0()), P3e8_longLit));
  signatureBaseString1 = oauthEncode('GET&' + sigBaseUrl + '&');
  sign2Param = new TreeMap_0;
  $put_0(sign2Param, 'oauth_consumer_key', cred);
  $put_0(sign2Param, 'oauth_nonce', generatedNonce);
  $put_0(sign2Param, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(sign2Param, 'oauth_timestamp', timeStamp);
  $put_0(sign2Param, 'oauth_token', oauthEncode(token));
  $put_0(sign2Param, 'oauth_verifier', oauthEncode(verifier));
  $put_0(sign2Param, 'oauth_version', '1.0');
  signatureBaseString2 = keyValueParameters(sign2Param, ',', false);
  signatureBaseString1 + ($clinit_Util() , oEncode1(signatureBaseString2));
  oauthEncode(clientSecret + '&' + (throwIfNull('encodedURL', tokenSecret) , decodeURI(tokenSecret)));
  oAuthHeaderParams = new TreeMap_0;
  $put_0(oAuthHeaderParams, 'oauth_version', '1.0');
  $put_0(oAuthHeaderParams, 'oauth_nonce', oauthEncode(generatedNonce));
  $put_0(oAuthHeaderParams, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(oAuthHeaderParams, 'oauth_consumer_key', cred);
  $put_0(oAuthHeaderParams, 'oauth_timestamp', timeStamp);
  $put_0(oAuthHeaderParams, 'oauth_token', oauthEncode(token));
  $put_0(oAuthHeaderParams, 'oauth_verifier', oauthEncode(verifier));
  oAuthHeader = 'OAuth ' + keyValueParameters(oAuthHeaderParams, ',', true);
  headers = new HashMap_0;
  headers.put('Authorization', oAuthHeader);
  headers.put('x-mnc', operator.mnc);
  headers.put('x-mcc', operator.mcc);
  try {
    executeHttpMethod(($clinit_RequestBuilder() , GET), sigBaseUrl, null, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doAOauth1Payment(requestCallback, token, verifier, tokenSecret, clientSecret, cred, refCode, itemId, itemDesc, itemCurrency, itemPrice, mcc, mnc, paymentUri){
  var $e0, e, generatedNonce, headers, oAuthHeader, oAuthHeaderParams, postParams, sign2Param, signatureBaseString1, signatureBaseString2, timeStamp;
  generatedNonce = ($clinit_UUID() , uuid_2());
  timeStamp = '' + toString_11(div(fromDouble(currentTimeMillis0()), P3e8_longLit));
  signatureBaseString1 = oauthEncode('POST&' + paymentUri + '&');
  sign2Param = new TreeMap_0;
  $put_0(sign2Param, 'code', itemId);
  $put_0(sign2Param, 'description', oauthEncode(itemDesc));
  $put_0(sign2Param, 'endUserId', oauthEncode('acr:Authorization'));
  $put_0(sign2Param, 'oauth_consumer_key', cred);
  $put_0(sign2Param, 'oauth_nonce', generatedNonce);
  $put_0(sign2Param, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(sign2Param, 'oauth_timestamp', timeStamp);
  $put_0(sign2Param, 'oauth_token', oauthEncode(token));
  $put_0(sign2Param, 'oauth_verifier', oauthEncode(verifier));
  $put_0(sign2Param, 'oauth_version', '1.0');
  $put_0(sign2Param, 'referenceCode', refCode);
  $put_0(sign2Param, 'transactionOperationStatus', 'Charged');
  signatureBaseString2 = keyValueParameters(sign2Param, ',', false);
  signatureBaseString1 + ($clinit_Util() , oEncode1(signatureBaseString2));
  oauthEncode(clientSecret + '&' + (throwIfNull('encodedURL', tokenSecret) , decodeURI(tokenSecret)));
  oAuthHeaderParams = new TreeMap_0;
  $put_0(oAuthHeaderParams, 'oauth_version', '1.0');
  $put_0(oAuthHeaderParams, 'oauth_nonce', oauthEncode(generatedNonce));
  $put_0(oAuthHeaderParams, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(oAuthHeaderParams, 'oauth_consumer_key', cred);
  $put_0(oAuthHeaderParams, 'oauth_timestamp', timeStamp);
  $put_0(oAuthHeaderParams, 'oauth_token', oauthEncode(token));
  $put_0(oAuthHeaderParams, 'oauth_verifier', oauthEncode(verifier));
  oAuthHeader = 'OAuth ' + keyValueParameters(oAuthHeaderParams, ',', true);
  headers = new HashMap_0;
  headers.put('Authorization', oAuthHeader);
  headers.put('x-mnc', mnc);
  headers.put('x-mcc', mcc);
  postParams = new ArrayList_0;
  $add(postParams, new NameValuePair_0('endUserId', 'acr:Authorization'));
  $add(postParams, new NameValuePair_0('referenceCode', refCode));
  $add(postParams, new NameValuePair_0('transactionOperationStatus', 'Charged'));
  $add(postParams, new NameValuePair_0('description', itemDesc));
  $add(postParams, new NameValuePair_0('code', itemId));
  try {
    executeHttpMethod(($clinit_RequestBuilder() , POST), paymentUri, postParams, headers, requestCallback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doAOauth2CheckTransaction(callback, token, operator, transactionId){
  var $e0, e, headers, sigBaseUrl;
  sigBaseUrl = operator.apis.payment.uri;
  headers = new HashMap_0;
  headers.put('Accept', 'application/json');
  headers.put('Authorization', 'BEARER ' + token);
  headers.put('x-mnc', operator.mnc);
  headers.put('x-mcc', operator.mcc);
  sigBaseUrl = sigBaseUrl + '/' + transactionId;
  try {
    executeHttpMethod(($clinit_RequestBuilder() , GET), sigBaseUrl, null, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doAOauth2ListTransactions(callback, token, operator){
  var $e0, e, headers, sigBaseUrl;
  sigBaseUrl = operator.apis.payment.uri;
  headers = new HashMap_0;
  headers.put('Authorization', 'BEARER ' + token);
  headers.put('x-mnc', operator.mnc);
  headers.put('x-mcc', operator.mcc);
  headers.put('Accept', 'application/json');
  try {
    executeHttpMethod(($clinit_RequestBuilder() , GET), sigBaseUrl, null, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doAOauth2Payment(callback, token, refCode, serverReferenceCode, itemId, itemDesc, itemCurrency, itemPrice, mcc, mnc, paymentUri, apiVersion){
  var $e0, e, headers, postParams;
  headers = new HashMap_0;
  headers.put('Accept', 'application/json');
  headers.put('Authorization', 'BEARER ' + token);
  if (apiVersion == 2001) {
    headers.put('x-mnc', mnc);
    headers.put('x-mcc', mcc);
  }
  postParams = new ArrayList_0;
  $add(postParams, new NameValuePair_0('endUserId', 'acr:Authorization'));
  $add(postParams, new NameValuePair_0('referenceCode', refCode));
  $add(postParams, new NameValuePair_0('serverReferenceCode', serverReferenceCode));
  $add(postParams, new NameValuePair_0('transactionOperationStatus', 'Charged'));
  $add(postParams, new NameValuePair_0('description', itemDesc));
  $add(postParams, new NameValuePair_0('code', itemId));
  $add(postParams, new NameValuePair_0('currency', itemCurrency));
  $add(postParams, new NameValuePair_0('amount', '' + itemPrice));
  try {
    executeHttpMethod(($clinit_RequestBuilder() , POST), paymentUri, postParams, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doDiscovery(callback, applicationID){
  var $e0, e, header, queryPath;
  queryPath = $adjustToProxy((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1).endPoints.discoveryPathR1) + applicationID;
  try {
    header = new HashMap_0;
    executeHttpMethod(($clinit_RequestBuilder() , GET), queryPath, null, header, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doDiscoveryForOperator(callback, app, operator){
  var $e0, e, queryPath;
  queryPath = $adjustToProxy((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1).endPoints.discoveryPathR1) + app.applicationIdentifier + '?x-mnc=' + operator.mnc + '&x-mcc=' + operator.mcc;
  try {
    executeHttpGet(queryPath, new HashMap_0, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function doQuery(callback, app, item, cred, developer, secret){
  var $e0, e, headers, queryPath, requestParams, signature, timeStamp, uriParams;
  timeStamp = valueOf_0(fromDouble(currentTimeMillis0()));
  try {
    signature = getBase64HmacSHA256(secret, app.applicationIdentifier, developer.userName, timeStamp.value);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  queryPath = $adjustToProxy((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1).endPoints.queryPathR2);
  uriParams = '/' + app.applicationIdentifier;
  uriParams += '';
  requestParams = '?client_id=' + cred.key + '&timestamp=' + timeStamp;
  queryPath += uriParams + requestParams;
  headers = new HashMap_0;
  headers.put('Accept', 'application/json');
  headers.put('Authorization', 'Signature ' + signature);
  if ((!instance_1 && (instance_1 = new WacNapiContext_0) , spoofedSourceIPForStaging) != null) {
    d_0('Setting spoofed IP - ' + (!instance_1 && (instance_1 = new WacNapiContext_0) , spoofedSourceIPForStaging));
    headers.put('x-source-ip', (!instance_1 && (instance_1 = new WacNapiContext_0) , spoofedSourceIPForStaging));
  }
  d_0('Header is : ' + $toString_1(headers));
  try {
    executeHttpMethod(($clinit_RequestBuilder() , GET), queryPath, null, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
      throw new NapiException_0(e.getMessage());
    }
     else 
      throw $e0;
  }
  return null;
}

function formUrlStringForOAuth1(requestToken, operator, url){
  var parameters, result;
  parameters = new HashMap_0;
  parameters.put('oauth_token', requestToken);
  parameters.put('x-mcc', operator.mcc);
  parameters.put('x-mnc', operator.mnc);
  return result = new StringBuilder_0 , $append_4($append_4(($append_0(result.impl, url) , result), '?'), keyValueParameters(parameters, '&', false)) , result.impl.string;
}

function getOAuth1AccessToken(callback, verifier, requestToken, operator, cred, secret, oAuthSecret){
  var $e0, e, generatedNonce, headers, oAuthHeader, oAuthHeaderParams, params, sigBaseUrl, signatureBaseString1, signatureBaseString2, timeStamp;
  sigBaseUrl = operator.apis.authorization.uris.accessToken;
  generatedNonce = ($clinit_UUID() , uuid_2());
  timeStamp = '' + toString_11(div(fromDouble(currentTimeMillis0()), P3e8_longLit));
  signatureBaseString1 = 'POST&' + ($clinit_Util() , oEncode1(sigBaseUrl)) + '&';
  params = new TreeMap_0;
  $put_0(params, 'oauth_consumer_key', cred);
  $put_0(params, 'oauth_nonce', generatedNonce);
  $put_0(params, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(params, 'oauth_timestamp', timeStamp);
  $put_0(params, 'oauth_token', requestToken);
  $put_0(params, 'oauth_verifier', verifier);
  $put_0(params, 'oauth_version', '1.0');
  signatureBaseString2 = keyValueParameters(params, ',', false);
  signatureBaseString1 + oEncode1(signatureBaseString2);
  oauthEncode(secret + '&' + oAuthSecret);
  oAuthHeaderParams = new HashMap_0;
  oAuthHeaderParams.put('oauth_consumer_key', cred);
  oAuthHeaderParams.put('oauth_signature_method', oEncode1('HMAC-SHA1'));
  oAuthHeaderParams.put('oauth_version', '1.0');
  oAuthHeaderParams.put('oauth_nonce', oEncode1(generatedNonce));
  oAuthHeaderParams.put('oauth_timestamp', oEncode1(timeStamp));
  oAuthHeaderParams.put('oauth_token', oEncode1(requestToken));
  oAuthHeaderParams.put('oauth_verifier', oEncode1(verifier));
  oAuthHeader = 'OAuth ' + keyValueParameters(oAuthHeaderParams, ',', true);
  headers = new HashMap_0;
  headers.put('Authorization', oAuthHeader);
  headers.put('x-mnc', operator.mnc);
  headers.put('x-mcc', operator.mcc);
  try {
    executeHttpPost(sigBaseUrl, new ArrayList_0, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
    }
     else 
      throw $e0;
  }
  return null;
}

function getOAuth1RequestToken(callback, operator, item, cred, secret, redirectUri, scope){
  var $e0, e, generatedNonce, headers, oAuthHeader, parameters, params, scopeStr, sigBaseUrl, signatureBaseString1, signatureBaseString2, timeStamp;
  sigBaseUrl = operator.apis.authorization.uris.requestToken;
  scopeStr = $equals('GET-/payment/acr:Authorization/transactions/amount', scope)?scope:scope + '?code=' + item.itemId;
  generatedNonce = ($clinit_UUID() , uuid_2());
  timeStamp = '' + toString_11(div(fromDouble(currentTimeMillis0()), P3e8_longLit));
  signatureBaseString1 = oauthEncode('POST&' + sigBaseUrl + '&');
  params = new TreeMap_0;
  $put_0(params, 'oauth_callback', oauthEncode(redirectUri));
  $put_0(params, 'oauth_consumer_key', cred);
  $put_0(params, 'oauth_nonce', generatedNonce);
  $put_0(params, 'oauth_scope', oauthEncode(scopeStr));
  $put_0(params, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(params, 'oauth_timestamp', timeStamp);
  $put_0(params, 'oauth_version', '1.0');
  signatureBaseString2 = keyValueParameters(params, ',', false);
  signatureBaseString1 + ($clinit_Util() , oEncode1(signatureBaseString2));
  oauthEncode(secret + '&');
  parameters = new TreeMap_0;
  $put_0(parameters, 'oauth_callback', oauthEncode(redirectUri));
  $put_0(parameters, 'oauth_consumer_key', cred);
  $put_0(parameters, 'oauth_scope', oauthEncode(scopeStr));
  $put_0(parameters, 'oauth_signature_method', 'HMAC-SHA1');
  $put_0(parameters, 'oauth_version', '1.0');
  $put_0(parameters, 'oauth_nonce', generatedNonce);
  $put_0(parameters, 'oauth_timestamp', timeStamp);
  oAuthHeader = 'OAuth ' + keyValueParameters(parameters, ',', true);
  headers = new HashMap_0;
  headers.put('Authorization', oAuthHeader);
  headers.put('x-mnc', operator.mnc);
  headers.put('x-mcc', operator.mcc);
  try {
    executeHttpPost(sigBaseUrl, new ArrayList_0, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
    }
     else 
      throw $e0;
  }
  return null;
}

function getOAuth2AccessToken(callback, operator, item, cred, secret, code, redirectUri){
  var $e0, accessTokenUrl, e, headers, params;
  headers = new HashMap_0;
  headers.put('Accept', 'application/json');
  headers.put('Content-Type', 'application/x-www-form-urlencoded');
  if ((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1).service.nullMethod() == 2001) {
    headers.put('x-mnc', operator.mnc);
    headers.put('x-mcc', operator.mcc);
  }
  params = new ArrayList_0;
  $add(params, new NameValuePair_0('client_id', cred));
  $add(params, new NameValuePair_0('client_secret', secret));
  $add(params, new NameValuePair_0('code', code));
  $add(params, new NameValuePair_0('grant_type', 'authorization_code'));
  $add(params, new NameValuePair_0('redirect_uri', redirectUri));
  accessTokenUrl = (!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1).service.nullMethod() == 2002?$adjustToProxy((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1).endPoints.accessTokenPathR2):operator.apis.authorization.uris.accessToken;
  try {
    executeHttpMethod(($clinit_RequestBuilder() , POST), accessTokenUrl, params, headers, callback);
  }
   catch ($e0) {
    $e0 = caught_0($e0);
    if (instanceOf($e0, Q$Exception)) {
      e = $e0;
      $printStackTrace(e);
    }
     else 
      throw $e0;
  }
  return null;
}

function WacRestApi(){
}

_ = WacRestApi_0.prototype = WacRestApi.prototype = new Object_0;
_.getClass$ = function getClass_192(){
  return Lnet_wacapps_napi_api_WacRestApi_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
function $export_1(){
  if (!exported_1) {
    exported_1 = true;
    new ItemExporterImpl_0;
    new ApplicationExporterImpl_0;
    new CredentialExporterImpl_0;
    new DeveloperExporterImpl_0;
    $export0_1();
  }
}

function $export0_1(){
  var pkg = declarePackage('net.wacapps.napi.api.WacRestApi');
  var __0;
  $wnd.net.wacapps.napi.api.WacRestApi = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_api_WacRestApi_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new WacRestApi_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.api.WacRestApi.prototype = new Object;
  $wnd.net.wacapps.napi.api.WacRestApi.GET_POST_SCOPE = 'GET,POST-/payment/acr:Authorization/transactions/amount';
  $wnd.net.wacapps.napi.api.WacRestApi.POST_SCOPE = 'POST-/payment/acr:Authorization/transactions/amount';
  $wnd.net.wacapps.napi.api.WacRestApi.GET_SCOPE = 'GET-/payment/acr:Authorization/transactions/amount';
  $wnd.net.wacapps.napi.api.WacRestApi.doAOauth2ListTransactions = $entry(function(a0, a1, a2){
    return doAOauth2ListTransactions(a0, a1, gwtInstance(a2));
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doDiscovery = $entry(function(a0, a1){
    return doDiscovery(a0, a1);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.getOAuth2AccessToken = $entry(function(a0, a1, a2, a3, a4, a5, a6){
    return getOAuth2AccessToken(a0, gwtInstance(a1), gwtInstance(a2), a3, a4, a5, a6);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doQuery = $entry(function(a0, a1, a2, a3, a4, a5){
    return doQuery(a0, gwtInstance(a1), gwtInstance(a2), gwtInstance(a3), gwtInstance(a4), a5);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.getOAuth1AccessToken = $entry(function(a0, a1, a2, a3, a4, a5, a6, a7){
    return runDispatch(null, Lnet_wacapps_napi_api_WacRestApi_2_classLit, 0, arguments, true, true)[0];
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doDiscoveryForOperator = $entry(function(a0, a1, a2){
    return doDiscoveryForOperator(a0, gwtInstance(a1), gwtInstance(a2));
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doAOauth1ListTransactions = $entry(function(a0, a1, a2, a3, a4, a5, a6){
    return doAOauth1ListTransactions(a0, a1, a2, a3, a4, a5, gwtInstance(a6));
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doAOauth2CheckTransaction = $entry(function(a0, a1, a2, a3){
    return doAOauth2CheckTransaction(a0, a1, gwtInstance(a2), a3);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doAOauth1Payment = $entry(function(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13){
    return doAOauth1Payment(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.formUrlStringForOAuth1 = $entry(function(a0, a1, a2){
    return formUrlStringForOAuth1(a0, gwtInstance(a1), a2);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.getOAuth1RequestToken = $entry(function(a0, a1, a2, a3, a4, a5, a6){
    return getOAuth1RequestToken(a0, gwtInstance(a1), gwtInstance(a2), a3, a4, a5, a6);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doAOauth1CheckTransaction = $entry(function(a0, a1, a2, a3, a4, a5, a6, a7){
    return doAOauth1CheckTransaction(a0, a1, a2, a3, a4, a5, gwtInstance(a6), a7);
  }
  );
  $wnd.net.wacapps.napi.api.WacRestApi.doAOauth2Payment = $entry(function(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11){
    return doAOauth2Payment(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11);
  }
  );
  registerDispatchMap(Lnet_wacapps_napi_api_WacRestApi_2_classLit, {0:{8:[[__static_wrapper_getOAuth1AccessToken, null, undefined, Lcom_google_gwt_http_client_RequestCallback_2_classLit, 'string', 'string', Lnet_wacapps_napi_resource_jaxb_Operator_2_classLit, 'string', 'string', 'string', 'array']]}}, true);
  addTypeMap(Lnet_wacapps_napi_api_WacRestApi_2_classLit, $wnd.net.wacapps.napi.api.WacRestApi);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.api.WacRestApi[p] === undefined && ($wnd.net.wacapps.napi.api.WacRestApi[p] = pkg[p]);
}

function WacRestApiExporterImpl_0(){
  $export_1();
}

function __static_wrapper_getOAuth1AccessToken(a0, a1, a2, a3, a4, a5, a6, a7){
  return getOAuth1AccessToken(a0, a1, a2, a3, a4, a5, a6, ($clinit_ExporterUtil() , $toArrString(a7)));
}

function WacRestApiExporterImpl(){
}

_ = WacRestApiExporterImpl_0.prototype = WacRestApiExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_193(){
  return Lnet_wacapps_napi_api_WacRestApiExporterImpl_2_classLit;
}
;
var exported_1 = false;
function $setClientCorrelator(this$static, value){
  this$static.clientCorrelator = value;
}

function $setEndUserId(this$static, value){
  this$static.endUserId = value;
}

function $setPaymentAmount(this$static, value){
  this$static.paymentAmount = value;
}

function $setReferenceCode(this$static, value){
  this$static.referenceCode = value;
}

function $setResourceURL(this$static, value){
  this$static.resourceURL = value;
}

function $setServerReferenceCode(this$static, value){
  this$static.serverReferenceCode = value;
}

function $setTransactionOperationStatus(this$static, value){
  this$static.transactionOperationStatus = value;
}

function AmountTransaction_0(){
}

function AmountTransaction(){
}

_ = AmountTransaction_0.prototype = AmountTransaction.prototype = new Object_0;
_.getClass$ = function getClass_194(){
  return Lnet_wacapps_napi_resource_jaxb_AmountTransaction_2_classLit;
}
;
_.getClientCorrelator_0 = function getClientCorrelator(){
  return this.clientCorrelator;
}
;
_.getEndUserId_0 = function getEndUserId(){
  return this.endUserId;
}
;
_.getPaymentAmount_0 = function getPaymentAmount(){
  return this.paymentAmount;
}
;
_.getReferenceCode_0 = function getReferenceCode(){
  return this.referenceCode;
}
;
_.getResourceURL_0 = function getResourceURL(){
  return this.resourceURL;
}
;
_.getServerReferenceCode_0 = function getServerReferenceCode(){
  return this.serverReferenceCode;
}
;
_.getTransactionOperationStatus_0 = function getTransactionOperationStatus(){
  return this.transactionOperationStatus;
}
;
_.setClientCorrelator_0 = function setClientCorrelator(value){
  this.clientCorrelator = value;
}
;
_.setEndUserId_0 = function setEndUserId(value){
  this.endUserId = value;
}
;
_.setPaymentAmount_0 = function setPaymentAmount(value){
  this.paymentAmount = value;
}
;
_.setReferenceCode_0 = function setReferenceCode(value){
  this.referenceCode = value;
}
;
_.setResourceURL_0 = function setResourceURL(value){
  this.resourceURL = value;
}
;
_.setServerReferenceCode_0 = function setServerReferenceCode(value){
  this.serverReferenceCode = value;
}
;
_.setTransactionOperationStatus_0 = function setTransactionOperationStatus(value){
  this.transactionOperationStatus = value;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$AmountTransaction, Q$Exportable]);
_.clientCorrelator = null;
_.endUserId = null;
_.paymentAmount = null;
_.referenceCode = null;
_.resourceURL = null;
_.serverReferenceCode = null;
_.transactionOperationStatus = null;
function $export_2(){
  if (!exported_2) {
    exported_2 = true;
    new PaymentAmountExporterImpl_0;
    $export0_2();
  }
}

function $export0_2(){
  var pkg = declarePackage('net.wacapps.napi.resource.jaxb.AmountTransaction');
  var __0;
  $wnd.net.wacapps.napi.resource.jaxb.AmountTransaction = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_resource_jaxb_AmountTransaction_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new AmountTransaction_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.resource.jaxb.AmountTransaction.prototype = new Object;
  __0.setClientCorrelator = $entry(function(a0){
    this.g.setClientCorrelator_0(a0);
  }
  );
  __0.getResourceURL = $entry(function(){
    return this.g.getResourceURL_0();
  }
  );
  __0.getServerReferenceCode = $entry(function(){
    return this.g.getServerReferenceCode_0();
  }
  );
  __0.getEndUserId = $entry(function(){
    return this.g.getEndUserId_0();
  }
  );
  __0.getPaymentAmount = $entry(function(){
    return wrap(this.g.getPaymentAmount_0());
  }
  );
  __0.setTransactionOperationStatus = $entry(function(a0){
    this.g.setTransactionOperationStatus_0(a0);
  }
  );
  __0.getClientCorrelator = $entry(function(){
    return this.g.getClientCorrelator_0();
  }
  );
  __0.setEndUserId = $entry(function(a0){
    this.g.setEndUserId_0(a0);
  }
  );
  __0.getTransactionOperationStatus = $entry(function(){
    return this.g.getTransactionOperationStatus_0();
  }
  );
  __0.setPaymentAmount = $entry(function(a0){
    this.g.setPaymentAmount_0(gwtInstance(a0));
  }
  );
  __0.setServerReferenceCode = $entry(function(a0){
    this.g.setServerReferenceCode_0(a0);
  }
  );
  __0.setReferenceCode = $entry(function(a0){
    this.g.setReferenceCode_0(a0);
  }
  );
  __0.getReferenceCode = $entry(function(){
    return this.g.getReferenceCode_0();
  }
  );
  __0.setResourceURL = $entry(function(a0){
    this.g.setResourceURL_0(a0);
  }
  );
  addTypeMap(Lnet_wacapps_napi_resource_jaxb_AmountTransaction_2_classLit, $wnd.net.wacapps.napi.resource.jaxb.AmountTransaction);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.resource.jaxb.AmountTransaction[p] === undefined && ($wnd.net.wacapps.napi.resource.jaxb.AmountTransaction[p] = pkg[p]);
}

function AmountTransactionExporterImpl_0(){
  $export_2();
}

function AmountTransactionExporterImpl(){
}

_ = AmountTransactionExporterImpl_0.prototype = AmountTransactionExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_195(){
  return Lnet_wacapps_napi_resource_jaxb_AmountTransactionExporterImpl_2_classLit;
}
;
var exported_2 = false;
function $setAuthorization(this$static, value){
  this$static.authorization = value;
}

function $setPayment(this$static, value){
  this$static.payment = value;
}

function $setQuery(this$static, value){
  this$static.query = value;
}

function $setUri(this$static, value){
  this$static.uri = value;
}

function Apis_0(){
}

function Apis(){
}

_ = Apis_0.prototype = Apis.prototype = new Object_0;
_.getClass$ = function getClass_196(){
  return Lnet_wacapps_napi_resource_jaxb_Apis_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Apis]);
_.authorization = null;
_.payment = null;
_.query = null;
_.uri = null;
function $setType(this$static, value){
  this$static.type = value;
}

function $setUris(this$static, value){
  this$static.uris = value;
}

function AuthorizationApi_0(){
}

function AuthorizationApi(){
}

_ = AuthorizationApi_0.prototype = AuthorizationApi.prototype = new Object_0;
_.getClass$ = function getClass_197(){
  return Lnet_wacapps_napi_resource_jaxb_AuthorizationApi_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$AuthorizationApi]);
_.type = null;
_.uris = null;
function $setAccessToken(this$static, value){
  this$static.accessToken = value;
}

function $setAuthorize(this$static, value){
  this$static.authorize = value;
}

function $setRequestToken(this$static, value){
  this$static.requestToken = value;
}

function AuthorizationUris_0(){
}

function AuthorizationUris(){
}

_ = AuthorizationUris_0.prototype = AuthorizationUris.prototype = new Object_0;
_.getClass$ = function getClass_198(){
  return Lnet_wacapps_napi_resource_jaxb_AuthorizationUris_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$AuthorizationUris]);
_.accessToken = null;
_.authorize = null;
_.requestToken = null;
function $setAmount(this$static, value){
  this$static.amount = value;
}

function $setCode(this$static, value){
  this$static.code = value;
}

function $setCurrency(this$static, value){
  this$static.currency = value;
}

function $setDescription(this$static, value){
  this$static.description = value;
}

function ChargingInformation_0(){
}

function ChargingInformation(){
}

_ = ChargingInformation_0.prototype = ChargingInformation.prototype = new Object_0;
_.getAmount_0 = function getAmount(){
  return this.amount;
}
;
_.getClass$ = function getClass_199(){
  return Lnet_wacapps_napi_resource_jaxb_ChargingInformation_2_classLit;
}
;
_.getCode_0 = function getCode(){
  return this.code;
}
;
_.getCurrency_0 = function getCurrency(){
  return this.currency;
}
;
_.getDescription_0 = function getDescription_0(){
  return this.description;
}
;
_.setAmount_0 = function setAmount(value){
  this.amount = value;
}
;
_.setCode_0 = function setCode(value){
  this.code = value;
}
;
_.setCurrency_0 = function setCurrency(value){
  this.currency = value;
}
;
_.setDescription_0 = function setDescription(value){
  this.description = value;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$ChargingInformation, Q$Exportable]);
_.amount = null;
_.code = null;
_.currency = null;
_.description = null;
function $export_3(){
  if (!exported_3) {
    exported_3 = true;
    $export0_3();
  }
}

function $export0_3(){
  var pkg = declarePackage('net.wacapps.napi.resource.jaxb.ChargingInformation');
  var __0;
  $wnd.net.wacapps.napi.resource.jaxb.ChargingInformation = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_resource_jaxb_ChargingInformation_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new ChargingInformation_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.resource.jaxb.ChargingInformation.prototype = new Object;
  __0.setAmount = $entry(function(a0){
    this.g.setAmount_0(gwtInstance(a0));
  }
  );
  __0.setDescription = $entry(function(a0){
    this.g.setDescription_0(a0);
  }
  );
  __0.getCurrency = $entry(function(){
    return this.g.getCurrency_0();
  }
  );
  __0.getCode = $entry(function(){
    return this.g.getCode_0();
  }
  );
  __0.setCode = $entry(function(a0){
    this.g.setCode_0(a0);
  }
  );
  __0.setCurrency = $entry(function(a0){
    this.g.setCurrency_0(a0);
  }
  );
  __0.getAmount = $entry(function(){
    return this.g.getAmount_0();
  }
  );
  __0.getDescription = $entry(function(){
    return this.g.getDescription_0();
  }
  );
  addTypeMap(Lnet_wacapps_napi_resource_jaxb_ChargingInformation_2_classLit, $wnd.net.wacapps.napi.resource.jaxb.ChargingInformation);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.resource.jaxb.ChargingInformation[p] === undefined && ($wnd.net.wacapps.napi.resource.jaxb.ChargingInformation[p] = pkg[p]);
}

function ChargingInformationExporterImpl_0(){
  $export_3();
}

function ChargingInformationExporterImpl(){
}

_ = ChargingInformationExporterImpl_0.prototype = ChargingInformationExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_200(){
  return Lnet_wacapps_napi_resource_jaxb_ChargingInformationExporterImpl_2_classLit;
}
;
var exported_3 = false;
function $setAcr(this$static, value){
  this$static.acr = value;
}

function CustomerReference_0(){
}

function CustomerReference(){
}

_ = CustomerReference_0.prototype = CustomerReference.prototype = new Object_0;
_.getClass$ = function getClass_201(){
  return Lnet_wacapps_napi_resource_jaxb_CustomerReference_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$CustomerReference]);
_.acr = null;
function $setError(this$static, value){
  this$static.error = value;
}

function $setErrorDescription(this$static, value){
  this$static.errorDescription = value;
}

function GatewayError_0(){
}

function GatewayError(){
}

_ = GatewayError_0.prototype = GatewayError.prototype = new Object_0;
_.getClass$ = function getClass_202(){
  return Lnet_wacapps_napi_resource_jaxb_GatewayError_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$GatewayError]);
_.error = null;
_.errorDescription = null;
function $setCode_0(this$static, value){
  this$static.code = value;
}

function $setResponse(this$static, value){
  this$static.response = value;
}

function GatewayResponse_0(){
}

function GatewayResponse(){
}

_ = GatewayResponse_0.prototype = GatewayResponse.prototype = new Object_0;
_.getClass$ = function getClass_203(){
  return Lnet_wacapps_napi_resource_jaxb_GatewayResponse_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$GatewayResponse]);
_.code = null;
_.response = null;
function $setCode_1(this$static, value){
  this$static.code = value;
}

function $setMessage(this$static, value){
  this$static.message_0 = value;
}

function GenericError_0(){
}

function GenericError(){
}

_ = GenericError_0.prototype = GenericError.prototype = new Object_0;
_.getClass$ = function getClass_204(){
  return Lnet_wacapps_napi_resource_jaxb_GenericError_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$GenericError]);
_.code = 0;
_.message_0 = null;
function $setRequestError(this$static, value){
  this$static.requestError = value;
}

function InvalidRequestError_0(){
}

function InvalidRequestError(){
}

_ = InvalidRequestError_0.prototype = InvalidRequestError.prototype = new Object_0;
_.getClass$ = function getClass_205(){
  return Lnet_wacapps_napi_resource_jaxb_InvalidRequestError_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$InvalidRequestError]);
_.requestError = null;
function $setBillingReceipt(this$static, value){
  this$static.billingReceipt = value;
}

function $setCurrency_0(this$static, value){
  this$static.currency = value;
}

function $setDescription_0(this$static, value){
  this$static.description = value;
}

function $setItemId(this$static, value){
  this$static.itemId = value;
}

function $setPrice(this$static, value){
  this$static.price = value;
}

function Item_0(){
}

function Item(){
}

_ = Item_0.prototype = Item.prototype = new Object_0;
_.getBillingReceipt_0 = function getBillingReceipt(){
  return this.billingReceipt;
}
;
_.getClass$ = function getClass_206(){
  return Lnet_wacapps_napi_resource_jaxb_Item_2_classLit;
}
;
_.getCurrency_0 = function getCurrency_0(){
  return this.currency;
}
;
_.getDescription_0 = function getDescription_1(){
  return this.description;
}
;
_.getItemId_0 = function getItemId(){
  return this.itemId;
}
;
_.getPrice_0 = function getPrice(){
  return this.price;
}
;
_.setBillingReceipt_0 = function setBillingReceipt(value){
  this.billingReceipt = value;
}
;
_.setCurrency_0 = function setCurrency_0(value){
  this.currency = value;
}
;
_.setDescription_0 = function setDescription_0(value){
  this.description = value;
}
;
_.setItemId_0 = function setItemId(value){
  this.itemId = value;
}
;
_.setPrice_0 = function setPrice(value){
  this.price = value;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Item, Q$Exportable]);
_.billingReceipt = null;
_.currency = null;
_.description = null;
_.itemId = null;
_.price = 0;
function $export_4(){
  if (!exported_4) {
    exported_4 = true;
    $export0_4();
  }
}

function $export0_4(){
  var pkg = declarePackage('net.wacapps.napi.resource.jaxb.Item');
  var __0;
  $wnd.net.wacapps.napi.resource.jaxb.Item = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_resource_jaxb_Item_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new Item_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.resource.jaxb.Item.prototype = new Object;
  __0.getItemId = $entry(function(){
    return this.g.getItemId_0();
  }
  );
  __0.getBillingReceipt = $entry(function(){
    return this.g.getBillingReceipt_0();
  }
  );
  __0.setBillingReceipt = $entry(function(a0){
    this.g.setBillingReceipt_0(a0);
  }
  );
  __0.setDescription = $entry(function(a0){
    this.g.setDescription_0(a0);
  }
  );
  __0.setPrice = $entry(function(a0){
    this.g.setPrice_0(a0);
  }
  );
  __0.getDescription = $entry(function(){
    return this.g.getDescription_0();
  }
  );
  __0.getPrice = $entry(function(){
    return this.g.getPrice_0();
  }
  );
  __0.setItemId = $entry(function(a0){
    this.g.setItemId_0(a0);
  }
  );
  __0.setCurrency = $entry(function(a0){
    this.g.setCurrency_0(a0);
  }
  );
  __0.getCurrency = $entry(function(){
    return this.g.getCurrency_0();
  }
  );
  addTypeMap(Lnet_wacapps_napi_resource_jaxb_Item_2_classLit, $wnd.net.wacapps.napi.resource.jaxb.Item);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.resource.jaxb.Item[p] === undefined && ($wnd.net.wacapps.napi.resource.jaxb.Item[p] = pkg[p]);
}

function ItemExporterImpl_0(){
  $export_4();
}

function ItemExporterImpl(){
}

_ = ItemExporterImpl_0.prototype = ItemExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_207(){
  return Lnet_wacapps_napi_resource_jaxb_ItemExporterImpl_2_classLit;
}
;
var exported_4 = false;
function $setCustomerReference(this$static, value){
  this$static.customerReference = value;
}

function $setGatewayResponse(this$static, value){
  this$static.gatewayResponse = value;
}

function $setGenericError(this$static, value){
  this$static.genericError = value;
}

function $setInvalidRequestError(this$static, value){
  this$static.invalidRequestError = value;
}

function $setOauth1Authorization(this$static, value){
  this$static.oauth1Authorization = value;
}

function $setOauth1AuthorizationProxyToken(this$static, value){
  this$static.oauth1AuthorizationProxyToken = value;
}

function $setOauth1AuthorizationToken(this$static, value){
  this$static.oauth1AuthorizationToken = value;
}

function $setOauth1AuthorizationVerifier(this$static, value){
  this$static.oauth1AuthorizationVerifier = value;
}

function $setOauth1Token(this$static, value){
  this$static.oauth1Token = value;
}

function $setOauth2AccessToken(this$static, value){
  this$static.oauth2AccessToken = value;
}

function $setOauth2AuthenticationToken(this$static, value){
  this$static.oauth2AuthenticationToken = value;
}

function $setOauth2Authorization(this$static, value){
  this$static.oauth2Authorization = value;
}

function $setOauth2AuthorizationProxyToken(this$static, value){
  this$static.oauth2AuthorizationProxyToken = value;
}

function $setOauth2AuthorizationToken(this$static, value){
  this$static.oauth2AuthorizationToken = value;
}

function $setPayment_0(this$static, value){
  this$static.payment = value;
}

function $setPrepareAuthenticationIdentifier(this$static, value){
  this$static.prepareAuthenticationIdentifier = value;
}

function $setTransaction(this$static, value){
  this$static.transaction = value;
}

function $setTransactionList(this$static, value){
  this$static.transactionList = value;
}

function MessageBody_0(){
}

function MessageBody(){
}

_ = MessageBody_0.prototype = MessageBody.prototype = new Object_0;
_.getClass$ = function getClass_208(){
  return Lnet_wacapps_napi_resource_jaxb_MessageBody_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$MessageBody]);
_.customerReference = null;
_.gatewayResponse = null;
_.genericError = null;
_.invalidRequestError = null;
_.oauth1Authorization = null;
_.oauth1AuthorizationProxyToken = null;
_.oauth1AuthorizationToken = null;
_.oauth1AuthorizationVerifier = null;
_.oauth1Token = null;
_.oauth2AccessToken = null;
_.oauth2AuthenticationToken = null;
_.oauth2Authorization = null;
_.oauth2AuthorizationProxyToken = null;
_.oauth2AuthorizationToken = null;
_.payment = null;
_.prepareAuthenticationIdentifier = null;
_.transaction = null;
_.transactionList = null;
function $setOauthCallback(this$static, value){
  this$static.oauthCallback = value;
}

function $setOauthConsumerKey(this$static, value){
  this$static.oauthConsumerKey = value;
}

function $setOauthNonce(this$static, value){
  this$static.oauthNonce = value;
}

function $setOauthScope(this$static, value){
  this$static.oauthScope = value;
}

function $setOauthSignature(this$static, value){
  this$static.oauthSignature = value;
}

function $setOauthSignatureMethod(this$static, value){
  this$static.oauthSignatureMethod = value;
}

function $setOauthTimestamp(this$static, value){
  this$static.oauthTimestamp = value;
}

function $setOauthToken(this$static, value){
  this$static.oauthToken = value;
}

function $setOauthVerifier(this$static, value){
  this$static.oauthVerifier = value;
}

function $setOauthVersion(this$static, value){
  this$static.oauthVersion = value;
}

function $setRequestType(this$static, value){
  this$static.requestType = value;
}

function Oauth1Authorization_0(){
}

function Oauth1Authorization(){
}

_ = Oauth1Authorization_0.prototype = Oauth1Authorization.prototype = new Object_0;
_.getClass$ = function getClass_209(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth1Authorization_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth1Authorization]);
_.oauthCallback = null;
_.oauthConsumerKey = null;
_.oauthNonce = null;
_.oauthScope = null;
_.oauthSignature = null;
_.oauthSignatureMethod = null;
_.oauthTimestamp = null;
_.oauthToken = null;
_.oauthVerifier = null;
_.oauthVersion = null;
_.requestType = null;
function $setOauthCallbackConfirmed(this$static, value){
  this$static.oauthCallbackConfirmed = value;
}

function $setOauthToken_0(this$static, value){
  this$static.oauthToken = value;
}

function $setOauthTokenSecret(this$static, value){
  this$static.oauthTokenSecret = value;
}

function $setUri_0(this$static, value){
  this$static.uri = value;
}

function Oauth1AuthorizationProxyToken_0(){
}

function Oauth1AuthorizationProxyToken(){
}

_ = Oauth1AuthorizationProxyToken_0.prototype = Oauth1AuthorizationProxyToken.prototype = new Object_0;
_.getClass$ = function getClass_210(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth1AuthorizationProxyToken_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth1AuthorizationProxyToken]);
_.oauthCallbackConfirmed = null;
_.oauthToken = null;
_.oauthTokenSecret = null;
_.uri = null;
function $setOauthToken_1(this$static, value){
  this$static.oauthToken = value;
}

function Oauth1AuthorizationToken_0(){
}

function Oauth1AuthorizationToken(){
}

_ = Oauth1AuthorizationToken_0.prototype = Oauth1AuthorizationToken.prototype = new Object_0;
_.getClass$ = function getClass_211(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth1AuthorizationToken_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth1AuthorizationToken]);
_.oauthToken = null;
function $setOauthToken_2(this$static, value){
  this$static.oauthToken = value;
}

function $setOauthVerifier_0(this$static, value){
  this$static.oauthVerifier = value;
}

function Oauth1AuthorizationVerifier_0(){
}

function Oauth1AuthorizationVerifier(){
}

_ = Oauth1AuthorizationVerifier_0.prototype = Oauth1AuthorizationVerifier.prototype = new Object_0;
_.getClass$ = function getClass_212(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth1AuthorizationVerifier_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth1AuthorizationVerifier]);
_.oauthToken = null;
_.oauthVerifier = null;
function $setOauthToken_3(this$static, value){
  this$static.oauthToken = value;
}

function $setOauthTokenSecret_0(this$static, value){
  this$static.oauthTokenSecret = value;
}

function Oauth1Token_0(){
}

function Oauth1Token(){
}

_ = Oauth1Token_0.prototype = Oauth1Token.prototype = new Object_0;
_.getClass$ = function getClass_213(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth1Token_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth1Token]);
_.oauthToken = null;
_.oauthTokenSecret = null;
function $setAccessToken_0(this$static, value){
  this$static.accessToken = value;
}

function $setAlgorithm(this$static, value){
  this$static.algorithm = value;
}

function $setExpiresIn(this$static, value){
  this$static.expiresIn_0 = value;
}

function $setRefreshToken(this$static, value){
  this$static.refreshToken = value;
}

function $setScope(this$static, value){
  this$static.scope = value;
}

function $setSecret(this$static, value){
  this$static.secret = value;
}

function $setServerReferenceCode_0(this$static, serverReferenceCode){
  this$static.serverReferenceCode = serverReferenceCode;
}

function $setState(this$static, value){
  this$static.state = value;
}

function $setTokenType(this$static, value){
  this$static.tokenType = value;
}

function Oauth2AccessToken_0(){
}

function Oauth2AccessToken(){
}

_ = Oauth2AccessToken_0.prototype = Oauth2AccessToken.prototype = new Object_0;
_.getClass$ = function getClass_214(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth2AccessToken_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth2AccessToken]);
_.accessToken = null;
_.algorithm = null;
_.expiresIn_0 = null;
_.refreshToken = null;
_.scope = null;
_.secret = null;
_.serverReferenceCode = null;
_.state = null;
_.tokenType = null;
function $setClientId(this$static, value){
  this$static.clientId_0 = value;
}

function $setClientSecret(this$static, value){
  this$static.clientSecret = value;
}

function $setCode_2(this$static, value){
  this$static.code = value;
}

function $setGrantType(this$static, value){
  this$static.grantType = value;
}

function $setPassword(this$static, value){
  this$static.password = value;
}

function $setRedirectUri(this$static, value){
  this$static.redirectUri = value;
}

function $setRefreshToken_0(this$static, value){
  this$static.refreshToken = value;
}

function $setUsername(this$static, value){
  this$static.username = value;
}

function Oauth2AuthenticationToken_0(){
}

function Oauth2AuthenticationToken(){
}

_ = Oauth2AuthenticationToken_0.prototype = Oauth2AuthenticationToken.prototype = new Object_0;
_.getClass$ = function getClass_215(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth2AuthenticationToken_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth2AuthenticationToken]);
_.clientId_0 = null;
_.clientSecret = null;
_.code = null;
_.grantType = null;
_.password = null;
_.redirectUri = null;
_.refreshToken = null;
_.username = null;
function $setCode_3(this$static, value){
  this$static.code = value;
}

function Oauth2Authorization_0(){
}

function Oauth2Authorization(){
}

_ = Oauth2Authorization_0.prototype = Oauth2Authorization.prototype = new Object_0;
_.getClass$ = function getClass_216(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth2Authorization_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth2Authorization]);
_.code = null;
function $setOauth2AuthorizationToken_0(this$static, value){
  this$static.oauth2AuthorizationToken = value;
}

function $setProxySessionToken(this$static, value){
  this$static.proxySessionToken = value;
}

function $setUri_1(this$static, value){
  this$static.uri = value;
}

function Oauth2AuthorizationProxyToken_0(){
}

function Oauth2AuthorizationProxyToken(){
}

_ = Oauth2AuthorizationProxyToken_0.prototype = Oauth2AuthorizationProxyToken.prototype = new Object_0;
_.getClass$ = function getClass_217(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth2AuthorizationProxyToken_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth2AuthorizationProxyToken]);
_.oauth2AuthorizationToken = null;
_.proxySessionToken = null;
_.uri = null;
function $setClientId_0(this$static, value){
  this$static.clientId_0 = value;
}

function $setRedirectUri_0(this$static, value){
  this$static.redirectUri = value;
}

function $setResponseType(this$static, value){
  this$static.responseType = value;
}

function $setScope_0(this$static, value){
  this$static.scope = value;
}

function $setState_0(this$static, value){
  this$static.state = value;
}

function Oauth2AuthorizationToken_0(){
}

function Oauth2AuthorizationToken(){
}

_ = Oauth2AuthorizationToken_0.prototype = Oauth2AuthorizationToken.prototype = new Object_0;
_.getClass$ = function getClass_218(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth2AuthorizationToken_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth2AuthorizationToken]);
_.clientId_0 = null;
_.redirectUri = null;
_.responseType = null;
_.scope = null;
_.state = null;
function $setNonce(this$static, value){
  this$static.nonce = value;
}

function $setSignature(this$static, value){
  this$static.signature = value;
}

function $setTimestamp(this$static, value){
  this$static.timestamp = value;
}

function $setToken_0(this$static, value){
  this$static.token = value;
}

function $setType_0(this$static, value){
  this$static.type = value;
}

function Oauth2ProtectedAuthorizationToken_0(){
}

function Oauth2ProtectedAuthorizationToken(){
}

_ = Oauth2ProtectedAuthorizationToken_0.prototype = Oauth2ProtectedAuthorizationToken.prototype = new Object_0;
_.getClass$ = function getClass_219(){
  return Lnet_wacapps_napi_resource_jaxb_Oauth2ProtectedAuthorizationToken_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Oauth2ProtectedAuthorizationToken]);
_.nonce = null;
_.signature = null;
_.timestamp = null;
_.token = null;
_.type = null;
function $setApis(this$static, value){
  this$static.apis = value;
}

function $setMcc(this$static, value){
  this$static.mcc = value;
}

function $setMnc(this$static, value){
  this$static.mnc = value;
}

function $setName(this$static, value){
  this$static.name_0 = value;
}

function Operator_0(){
}

function Operator(){
}

_ = Operator_0.prototype = Operator.prototype = new Object_0;
_.getClass$ = function getClass_220(){
  return Lnet_wacapps_napi_resource_jaxb_Operator_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Operator]);
_.apis = null;
_.mcc = null;
_.mnc = null;
_.name_0 = null;
function $setAmount_0(this$static, value){
  this$static.amount = value;
}

function $setChannel(this$static, value){
  this$static.channel = value;
}

function $setClientCorrelator_0(this$static, value){
  this$static.clientCorrelator = value;
}

function $setCode_4(this$static, value){
  this$static.code = value;
}

function $setCurrency_1(this$static, value){
  this$static.currency = value;
}

function $setDescription_1(this$static, value){
  this$static.description = value;
}

function $setEndUserId_0(this$static, value){
  this$static.endUserId = value;
}

function $setOnBehalfOf(this$static, value){
  this$static.onBehalfOf = value;
}

function $setProductID(this$static, value){
  this$static.productID = value;
}

function $setPurchaseCategoryCode(this$static, value){
  this$static.purchaseCategoryCode = value;
}

function $setReferenceCode_0(this$static, value){
  this$static.referenceCode = value;
}

function $setServiceID(this$static, value){
  this$static.serviceID = value;
}

function $setTaxAmount(this$static, value){
  this$static.taxAmount = value;
}

function $setTransactionOperationStatus_0(this$static, value){
  this$static.transactionOperationStatus = value;
}

function Payment_0(){
}

function Payment(){
}

_ = Payment_0.prototype = Payment.prototype = new Object_0;
_.getClass$ = function getClass_221(){
  return Lnet_wacapps_napi_resource_jaxb_Payment_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Payment]);
_.amount = 0;
_.channel = null;
_.clientCorrelator = null;
_.code = null;
_.currency = null;
_.description = null;
_.endUserId = null;
_.onBehalfOf = null;
_.productID = null;
_.purchaseCategoryCode = null;
_.referenceCode = null;
_.serviceID = null;
_.taxAmount = 0;
_.transactionOperationStatus = null;
function $setChargingInformation(this$static, value){
  this$static.chargingInformation = value;
}

function $setTotalAmountCharged(this$static, value){
  this$static.totalAmountCharged = value;
}

function PaymentAmount_0(){
}

function PaymentAmount(){
}

_ = PaymentAmount_0.prototype = PaymentAmount.prototype = new Object_0;
_.getChargingInformation_0 = function getChargingInformation(){
  return this.chargingInformation;
}
;
_.getClass$ = function getClass_222(){
  return Lnet_wacapps_napi_resource_jaxb_PaymentAmount_2_classLit;
}
;
_.getTotalAmountCharged_0 = function getTotalAmountCharged(){
  return this.totalAmountCharged;
}
;
_.setChargingInformation_0 = function setChargingInformation(value){
  this.chargingInformation = value;
}
;
_.setTotalAmountCharged_0 = function setTotalAmountCharged(value){
  this.totalAmountCharged = value;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$PaymentAmount, Q$Exportable]);
_.chargingInformation = null;
_.totalAmountCharged = -1;
function $export_5(){
  if (!exported_5) {
    exported_5 = true;
    new ChargingInformationExporterImpl_0;
    $export0_5();
  }
}

function $export0_5(){
  var pkg = declarePackage('net.wacapps.napi.resource.jaxb.PaymentAmount');
  var __0;
  $wnd.net.wacapps.napi.resource.jaxb.PaymentAmount = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_resource_jaxb_PaymentAmount_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new PaymentAmount_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.resource.jaxb.PaymentAmount.prototype = new Object;
  __0.setTotalAmountCharged = $entry(function(a0){
    this.g.setTotalAmountCharged_0(a0);
  }
  );
  __0.getChargingInformation = $entry(function(){
    return wrap(this.g.getChargingInformation_0());
  }
  );
  __0.getTotalAmountCharged = $entry(function(){
    return this.g.getTotalAmountCharged_0();
  }
  );
  __0.setChargingInformation = $entry(function(a0){
    this.g.setChargingInformation_0(gwtInstance(a0));
  }
  );
  addTypeMap(Lnet_wacapps_napi_resource_jaxb_PaymentAmount_2_classLit, $wnd.net.wacapps.napi.resource.jaxb.PaymentAmount);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.resource.jaxb.PaymentAmount[p] === undefined && ($wnd.net.wacapps.napi.resource.jaxb.PaymentAmount[p] = pkg[p]);
}

function PaymentAmountExporterImpl_0(){
  $export_5();
}

function PaymentAmountExporterImpl(){
}

_ = PaymentAmountExporterImpl_0.prototype = PaymentAmountExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_223(){
  return Lnet_wacapps_napi_resource_jaxb_PaymentAmountExporterImpl_2_classLit;
}
;
var exported_5 = false;
function $setCurrency_2(this$static, value){
  this$static.currency = value;
}

function $setPos(this$static, value){
  this$static.pos = value;
}

function $setUri_2(this$static, value){
  this$static.uri = value;
}

function PaymentApi_0(){
}

function PaymentApi(){
}

_ = PaymentApi_0.prototype = PaymentApi.prototype = new Object_0;
_.getClass$ = function getClass_224(){
  return Lnet_wacapps_napi_resource_jaxb_PaymentApi_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$PaymentApi]);
_.currency = null;
_.pos = false;
_.uri = null;
function $setApiIdentifier(this$static, value){
  this$static.apiIdentifier = value;
}

function $setApiKey(this$static, value){
  this$static.apiKey = value;
}

function $setUserId(this$static, value){
  this$static.userId = value;
}

function PrepareAuthenticationIdentifier_0(){
}

function PrepareAuthenticationIdentifier(){
}

_ = PrepareAuthenticationIdentifier_0.prototype = PrepareAuthenticationIdentifier.prototype = new Object_0;
_.getClass$ = function getClass_225(){
  return Lnet_wacapps_napi_resource_jaxb_PrepareAuthenticationIdentifier_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$PrepareAuthenticationIdentifier]);
_.apiIdentifier = null;
_.apiKey = null;
_.userId = null;
function $getItems(this$static){
  !this$static.items && (this$static.items = new ArrayList_0);
  return this$static.items;
}

function $setApplicationId(this$static, value){
  this$static.applicationId = value;
}

function Product_0(){
}

function Product(){
}

_ = Product_0.prototype = Product.prototype = new Object_0;
_.getClass$ = function getClass_226(){
  return Lnet_wacapps_napi_resource_jaxb_Product_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Product]);
_.applicationId = null;
_.items = null;
function $setType_1(this$static, value){
  this$static.type = value;
}

function $setUri_3(this$static, value){
  this$static.uri = value;
}

function QueryApi_0(){
}

function QueryApi(){
}

_ = QueryApi_0.prototype = QueryApi.prototype = new Object_0;
_.getClass$ = function getClass_227(){
  return Lnet_wacapps_napi_resource_jaxb_QueryApi_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$QueryApi]);
_.type = null;
_.uri = null;
function $setServiceException(this$static, value){
  this$static.serviceException = value;
}

function RequestError_0(){
}

function RequestError(){
}

_ = RequestError_0.prototype = RequestError.prototype = new Object_0;
_.getClass$ = function getClass_228(){
  return Lnet_wacapps_napi_resource_jaxb_RequestError_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$RequestError]);
_.serviceException = null;
function $setAccessToken_1(this$static, accessToken){
  this$static.accessToken = accessToken;
}

function $setApiVersion(this$static, apiVersion){
  this$static.apiVersion = apiVersion;
}

function $setAppId(this$static, appId){
  this$static.appId = appId;
}

function $setCredential(this$static, credential){
  this$static.credential = credential;
}

function $setItemCurrency(this$static, itemCurrency){
  this$static.itemCurrency = itemCurrency;
}

function $setItemDesc(this$static, itemDesc){
  this$static.itemDesc = itemDesc;
}

function $setItemId_0(this$static, itemId){
  this$static.itemId = itemId;
}

function $setItemPrice(this$static, itemPrice){
  this$static.itemPrice = itemPrice;
}

function $setOAuthSecret(this$static, secret){
  this$static.oAuthSecret = secret;
}

function $setOperationMode(this$static, operationMode){
  this$static.operationMode = operationMode;
}

function $setOperatorMcc(this$static, operatorMcc){
  this$static.operatorMcc = operatorMcc;
}

function $setOperatorMnc(this$static, operatorMnc){
  this$static.operatorMnc = operatorMnc;
}

function $setPaymentMethod(this$static, paymentMethod){
  this$static.paymentMethod = paymentMethod;
}

function $setPaymentUri(this$static, paymentUri){
  this$static.paymentUri = paymentUri;
}

function $setRefCode(this$static, refCode){
  this$static.refCode = refCode;
}

function $setServerReferenceCode_1(this$static, serverReferenceCode){
  this$static.serverReferenceCode = serverReferenceCode;
}

function $setServiceCredential(this$static, serviceCredential){
  this$static.serviceCredential = serviceCredential;
}

function $setServiceSecret(this$static, serviceSecret){
  this$static.serviceSecret = serviceSecret;
}

function $setVerifier(this$static, verifier){
  this$static.verifier = verifier;
}

function ReservedTransaction_0(){
}

function ReservedTransaction(){
}

_ = ReservedTransaction_0.prototype = ReservedTransaction.prototype = new Object_0;
_.getClass$ = function getClass_229(){
  return Lnet_wacapps_napi_resource_jaxb_ReservedTransaction_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$ReservedTransaction]);
_.accessToken = null;
_.apiVersion = 0;
_.appId = null;
_.credential = null;
_.itemCurrency = null;
_.itemDesc = null;
_.itemId = null;
_.itemPrice = 0;
_.oAuthSecret = null;
_.operationMode = 0;
_.operatorMcc = null;
_.operatorMnc = null;
_.paymentMethod = null;
_.paymentUri = null;
_.refCode = null;
_.serverReferenceCode = null;
_.serviceCredential = null;
_.serviceSecret = null;
_.verifier = null;
function $setOperator(this$static, value){
  this$static.operator = value;
}

function $setProduct(this$static, value){
  this$static.product = value;
}

function Response_1(){
}

function Response_0(){
}

_ = Response_1.prototype = Response_0.prototype = new Object_0;
_.getClass$ = function getClass_230(){
  return Lnet_wacapps_napi_resource_jaxb_Response_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Response]);
_.operator = null;
_.operators = null;
_.product = null;
function $setMessageId(this$static, value){
  this$static.messageId = value;
}

function $setText(this$static, value){
  this$static.text = value;
}

function $setVariables(this$static, value){
  this$static.variables = value;
}

function ServiceException_0(){
}

function ServiceException(){
}

_ = ServiceException_0.prototype = ServiceException.prototype = new Object_0;
_.getClass$ = function getClass_231(){
  return Lnet_wacapps_napi_resource_jaxb_ServiceException_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$ServiceException]);
_.messageId = null;
_.text = null;
_.variables = null;
function $setAmountTransaction(this$static, value){
  this$static.amountTransaction = value;
}

function Transaction_0(){
}

function Transaction(){
}

_ = Transaction_0.prototype = Transaction.prototype = new Object_0;
_.getClass$ = function getClass_232(){
  return Lnet_wacapps_napi_resource_jaxb_Transaction_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$Transaction]);
_.amountTransaction = null;
function $setResourceURL_0(this$static, value){
  this$static.resourceURL = value;
}

function TransactionArray_0(){
}

function TransactionArray(){
}

_ = TransactionArray_0.prototype = TransactionArray.prototype = new Object_0;
_.getClass$ = function getClass_233(){
  return Lnet_wacapps_napi_resource_jaxb_TransactionArray_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$TransactionArray]);
_.amountTransaction = null;
_.resourceURL = null;
function $setFromLocalTransactionStorage(this$static, fromLocalTransactionStorage){
  this$static.fromLocalTransactionStorage = fromLocalTransactionStorage;
}

function $setPaymentTransactionList(this$static, value){
  this$static.paymentTransactionList = value;
}

function TransactionList_0(){
}

function TransactionList(){
}

_ = TransactionList_0.prototype = TransactionList.prototype = new Object_0;
_.getClass$ = function getClass_234(){
  return Lnet_wacapps_napi_resource_jaxb_TransactionList_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$JsonSerializable, Q$Serializable, Q$TransactionList]);
_.fromLocalTransactionStorage = false;
_.paymentTransactionList = null;
function $clinit_Base64_0(){
  $clinit_Base64_0 = nullMethod;
  ALPHABET_0 = initValues(_3B_classLit, makeCastMap([Q$Serializable]), -1, [65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47]);
}

function encode_3(source){
  $clinit_Base64_0();
  return encode_4(source, source.length, ALPHABET_0, true);
}

function encode_4(source, len, alphabet, doPadding){
  var outBuff, outLen;
  outBuff = encode_5(source, len, alphabet);
  outLen = outBuff.length;
  while (!doPadding && outLen > 0) {
    if (outBuff[outLen - 1] != 61) {
      break;
    }
    outLen -= 1;
  }
  return utf8ToString(outBuff, outLen);
}

function encode_5(source, len, alphabet){
  var d, e, inBuff, len2, len43, lenDiv3, lineLength, outBuff;
  lenDiv3 = ~~((len + 2) / 3);
  len43 = lenDiv3 * 4;
  outBuff = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, len43 + ~~(len43 / 2147483647), 1);
  d = 0;
  e = 0;
  len2 = len - 2;
  lineLength = 0;
  for (; d < len2; d += 3 , e += 4) {
    inBuff = source[d] << 24 >>> 8 | source[d + 1] << 24 >>> 16 | source[d + 2] << 24 >>> 24;
    outBuff[e] = alphabet[inBuff >>> 18];
    outBuff[e + 1] = alphabet[inBuff >>> 12 & 63];
    outBuff[e + 2] = alphabet[inBuff >>> 6 & 63];
    outBuff[e + 3] = alphabet[inBuff & 63];
    lineLength += 4;
    if (lineLength == 2147483647) {
      outBuff[e + 4] = 10;
      ++e;
      lineLength = 0;
    }
  }
  if (d < len) {
    encode3to4_0(source, d, len - d, outBuff, e, alphabet);
    lineLength += 4;
    if (lineLength == 2147483647) {
      outBuff[e + 4] = 10;
      ++e;
    }
    e += 4;
  }
  return outBuff;
}

function encode3to4_0(source, srcOffset, numSigBytes, destination, destOffset, alphabet){
  var inBuff;
  inBuff = (numSigBytes > 0?source[srcOffset] << 24 >>> 8:0) | (numSigBytes > 1?source[srcOffset + 1] << 24 >>> 16:0) | (numSigBytes > 2?source[srcOffset + 2] << 24 >>> 24:0);
  switch (numSigBytes) {
    case 3:
      destination[destOffset] = alphabet[inBuff >>> 18];
      destination[destOffset + 1] = alphabet[inBuff >>> 12 & 63];
      destination[destOffset + 2] = alphabet[inBuff >>> 6 & 63];
      destination[destOffset + 3] = alphabet[inBuff & 63];
      return destination;
    case 2:
      destination[destOffset] = alphabet[inBuff >>> 18];
      destination[destOffset + 1] = alphabet[inBuff >>> 12 & 63];
      destination[destOffset + 2] = alphabet[inBuff >>> 6 & 63];
      destination[destOffset + 3] = 61;
      return destination;
    case 1:
      destination[destOffset] = alphabet[inBuff >>> 18];
      destination[destOffset + 1] = alphabet[inBuff >>> 12 & 63];
      destination[destOffset + 2] = 61;
      destination[destOffset + 3] = 61;
      return destination;
    default:return destination;
  }
}

var ALPHABET_0;
function $export_6(){
  if (!exported_6) {
    exported_6 = true;
    new AmountTransactionExporterImpl_0;
    $export0_6();
  }
}

function $export0_6(){
  var pkg = declarePackage('net.wacapps.napi.util.CaptureClosure');
  var __0;
  $wnd.net.wacapps.napi.util.CaptureClosure = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_util_CaptureClosure_2_classLit, arguments) && (g = arguments[0]);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.util.CaptureClosure.prototype = new Object;
  __0.onFailure = $entry(function(a0){
    this.g.onFailure_1(a0);
  }
  );
  __0.onSuccess = $entry(function(a0){
    this.g.onSuccess_1(gwtInstance(a0));
  }
  );
  addTypeMap(Lnet_wacapps_napi_util_CaptureClosure_2_classLit, $wnd.net.wacapps.napi.util.CaptureClosure);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.util.CaptureClosure[p] === undefined && ($wnd.net.wacapps.napi.util.CaptureClosure[p] = pkg[p]);
}

function $invoke(closure, a0){
  closure.apply(null, [a0]);
}

function $invoke_0(closure, a0){
  closure.apply(null, [wrap(a0)]);
}

function $onFailure(this$static, a0){
  $invoke(this$static.jso, a0);
}

function $onSuccess(this$static, a0){
  $invoke_0(this$static.jso, a0);
}

function CaptureClosureExporterImpl_0(){
  $export_6();
}

function CaptureClosureExporterImpl_1(jso){
  this.jso = jso;
}

function CaptureClosureExporterImpl(){
}

_ = CaptureClosureExporterImpl_1.prototype = CaptureClosureExporterImpl_0.prototype = CaptureClosureExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_235(){
  return Lnet_wacapps_napi_util_CaptureClosureExporterImpl_2_classLit;
}
;
_.onFailure_1 = function onFailure_0(a0){
  $onFailure(this, a0);
}
;
_.onSuccess_1 = function onSuccess_0(a0){
  $onSuccess(this, a0);
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.jso = null;
var exported_6 = false;
function $export_7(){
  if (!exported_7) {
    exported_7 = true;
    $export0_7();
  }
}

function $export0_7(){
  var pkg = declarePackage('net.wacapps.napi.util.DoQueryClosure');
  var __0;
  $wnd.net.wacapps.napi.util.DoQueryClosure = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_util_DoQueryClosure_2_classLit, arguments) && (g = arguments[0]);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.util.DoQueryClosure.prototype = new Object;
  __0.onFailure = $entry(function(a0){
    this.g.onFailure_1(a0);
  }
  );
  __0.onSuccess = $entry(function(a0){
    __static_wrapper_onSuccess(this.g, a0);
  }
  );
  addTypeMap(Lnet_wacapps_napi_util_DoQueryClosure_2_classLit, $wnd.net.wacapps.napi.util.DoQueryClosure);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.util.DoQueryClosure[p] === undefined && ($wnd.net.wacapps.napi.util.DoQueryClosure[p] = pkg[p]);
}

function $invoke_1(closure, a0){
  closure.apply(null, [a0]);
}

function $invoke_2(closure, a0){
  closure.apply(null, [a0]);
}

function $onFailure_0(this$static, a0){
  $invoke_1(this$static.jso, a0);
}

function $onSuccess_0(this$static, a0){
  $invoke_2(this$static.jso, a0);
}

function DoQueryClosureExporterImpl_0(){
  $export_7();
}

function DoQueryClosureExporterImpl_1(jso){
  this.jso = jso;
}

function __static_wrapper_onSuccess(instance, a0){
  $onSuccess_0(instance, ($clinit_ExporterUtil() , $toArrObject(a0, initDim(_3Lnet_wacapps_napi_resource_jaxb_Item_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Object_$1]), Q$Item, a0.length, 0))));
}

function DoQueryClosureExporterImpl(){
}

_ = DoQueryClosureExporterImpl_1.prototype = DoQueryClosureExporterImpl_0.prototype = DoQueryClosureExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_236(){
  return Lnet_wacapps_napi_util_DoQueryClosureExporterImpl_2_classLit;
}
;
_.onFailure_1 = function onFailure_1(a0){
  $onFailure_0(this, a0);
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.jso = null;
var exported_7 = false;
function $clinit_NAPIJSProxy(){
  $clinit_NAPIJSProxy = nullMethod;
  AUTH = ($clinit_AuthImpl() , INSTANCE);
  substititions = initValues(_3_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Object_$1]), Q$String_$1, [initValues(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, ['approximate-price', 'approximatePrice']), initValues(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, ['item-id', 'itemId']), initValues(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, ['billing-receipt', 'billingReceipt']), initValues(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, ['application-id', 'applicationId'])]);
  WAC_AUTH_URL = 'https://api.wacapps.net//2/oauth/authorize?response_type=token&redirect_uri=' + encode(redirectUri_0);
}

function $clearStorage(){
  var store;
  store = (!supportDetectorImpl && (supportDetectorImpl = new Storage$StorageSupportDetector_0) , supportDetectorImpl.isLocalStorageSupported?getLocalStorageIfSupported():getSessionStorageIfSupported());
  $clear(store.storage);
}

function $getPaymentAmounts(serialized){
  var paStrings, paymentAmount, transactionString, transactionString$index, transactionString$max, transactions;
  transactions = new ArrayList_0;
  if (serialized != null) {
    paStrings = $split(serialized, '-----', 0);
    for (transactionString$index = 0 , transactionString$max = paStrings.length; transactionString$index < transactionString$max; ++transactionString$index) {
      transactionString = paStrings[transactionString$index];
      if (transactionString.length > 3) {
        new Serializer_TypeSerializer_0;
        paymentAmount = dynamicCast($deSerialize_0(transactionString, 'net.wacapps.napi.resource.jaxb.PaymentAmount'), Q$PaymentAmount);
        setCheck(transactions.array, transactions.size++, paymentAmount);
      }
    }
  }
  return transactions;
}

function $processPaymentCallback(jsonText){
  var amountTransaction, jsonObject, jsonValue, responseJSON;
  new Serializer_TypeSerializer_0;
  jsonValue = ($clinit_JSONParser() , parse(jsonText));
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  responseJSON = $get_0(jsonObject, 'amountTransaction');
  responseJSON.toString$();
  amountTransaction = dynamicCast($deSerialize_0(runSubstitutions(responseJSON.toString$()), 'net.wacapps.napi.resource.jaxb.AmountTransaction'), Q$AmountTransaction);
  return amountTransaction;
}

function $processQueryCallback(jsonText){
  var jsonObject, jsonValue, response, responseJSON;
  new Serializer_TypeSerializer_0;
  jsonValue = ($clinit_JSONParser() , parse(jsonText));
  jsonObject = dynamicCast(jsonValue, Q$JSONObject);
  responseJSON = $get_0(jsonObject, 'response');
  responseJSON.toString$();
  response = dynamicCast($deSerialize_0(runSubstitutions(responseJSON.toString$()), 'net.wacapps.napi.resource.jaxb.Response'), Q$Response);
  return response;
}

function $setSpoofIP(string){
  spoofedSourceIPForStaging = string;
}

function $storeTransaction(paymentAmount){
  var serializedPaymentAmount, store, transactionsString;
  store = (!supportDetectorImpl && (supportDetectorImpl = new Storage$StorageSupportDetector_0) , supportDetectorImpl.isLocalStorageSupported?getLocalStorageIfSupported():getSessionStorageIfSupported());
  transactionsString = $getItem_0(store.storage, 'wac-transactions');
  transactionsString == null && (transactionsString = '');
  new Serializer_TypeSerializer_0;
  serializedPaymentAmount = $serialize(paymentAmount);
  transactionsString += '-----' + serializedPaymentAmount;
  $setItem_0(store.storage, 'wac-transactions', transactionsString);
}

function NAPIJSProxy_0(){
  $clinit_NAPIJSProxy();
}

function runSubstitutions(json){
  var i_0, result;
  if (json != null) {
    result = json;
    for (i_0 = 0; i_0 < substititions.length; ++i_0) {
      result = $replace(result, substititions[i_0][0], substititions[i_0][1]);
    }
    return result;
  }
   else {
    return null;
  }
}

function NAPIJSProxy(){
}

_ = NAPIJSProxy_0.prototype = NAPIJSProxy.prototype = new Object_0;
_.clearStorage_0 = function clearStorage(){
  $clearStorage();
}
;
_.doCapturePayment_0 = function doCapturePayment(token, expiresIn, referenceCode, serverReferenceCode, item, paymentUri, closure){
  doAOauth2Payment(new NAPIJSProxy$4_0(this, closure), token, referenceCode, serverReferenceCode, item.itemId, item.description, item.currency, item.price, null, null, paymentUri, 2002);
}
;
_.doReservePayment_0 = function doReservePayment(productID, callback){
  var payScope;
  payScope = 'GET,POST-/payment/acr:Authorization/transactions/amount?code=' + productID;
  ($clinit_UUID() , uuid_2()).substr(0, 32 - 0);
  authRequest = $withScopes(new AuthRequest_0(WAC_AUTH_URL, clientID_0), initValues(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, [payScope]));
  $adjustToProxy((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1).endPoints.chargePaymentPathR2);
  $login(AUTH, authRequest, new NAPIJSProxy$3_0(callback));
}
;
_.getClass$ = function getClass_237(){
  return Lnet_wacapps_napi_util_NAPIJSProxy_2_classLit;
}
;
_.getPaymentAmounts_0 = function getPaymentAmounts(serialized){
  return $getPaymentAmounts(serialized);
}
;
_.getTransactions_0 = function getTransactions(){
  var amountsList, i_0, paymentAmount, paymentAmount$index, paymentAmount$max, result, store, transactionsString;
  store = (!supportDetectorImpl && (supportDetectorImpl = new Storage$StorageSupportDetector_0) , supportDetectorImpl.isLocalStorageSupported?getLocalStorageIfSupported():getSessionStorageIfSupported());
  transactionsString = $getItem_0(store.storage, 'wac-transactions');
  amountsList = $getPaymentAmounts(transactionsString);
  if (amountsList) {
    result = initDim(_3Lnet_wacapps_napi_resource_jaxb_PaymentAmount_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Object_$1]), Q$PaymentAmount, amountsList.size, 0);
    i_0 = 0;
    for (paymentAmount$index = 0 , paymentAmount$max = result.length; paymentAmount$index < paymentAmount$max; ++paymentAmount$index) {
      paymentAmount = result[paymentAmount$index];
      result[i_0++] = paymentAmount;
    }
    return result;
  }
  return null;
}
;
_.initalize_0 = function initalize(applicationID, clientID, developerID, sharedSecretKey, redirectUri, ENDPOINT, closure){
  var app, cred, dev, hash;
  redirectUri_0 = redirectUri;
  clientID_0 = clientID;
  export_$();
  hash = $wnd.location.hash;
  $equalsIgnoreCase('#clear', hash) && $clearStorage();
  hash != null && hash.toLowerCase().indexOf('#spooifip=') == 0 && $setSpoofIP($split(hash, '=', 0)[1]);
  $setEndPoints((!instance_1 && (instance_1 = new WacNapiContext_0) , instance_1), new WacEndpoints_1(ENDPOINT));
  app = new Application_0;
  app.applicationIdentifier = applicationID;
  cred = new Credential_0;
  cred.key = clientID;
  dev = new Developer_0;
  dev.userName = developerID;
  doQuery(new NAPIJSProxy$1_0(this, closure), app, null, cred, dev, sharedSecretKey);
}
;
_.processPaymentCallback_0 = function processPaymentCallback(jsonText){
  return $processPaymentCallback(jsonText);
}
;
_.processPaymentResult_0 = function processPaymentResult(request, response){
}
;
_.processQueryCallback_0 = function processQueryCallback(jsonText){
  return $processQueryCallback(jsonText);
}
;
_.setSpoofIP_0 = function setSpoofIP(string){
  spoofedSourceIPForStaging = string;
}
;
_.storeTransaction_0 = function storeTransaction(paymentAmount){
  $storeTransaction(paymentAmount);
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
var AUTH, WAC_AUTH_URL, authRequest = null, clientID_0 = 'wac-f9edacb9406b4f2eced696eb9f8348262d77b89d', redirectUri_0 = 'http://html5dev.api.wacapps.net/testcinema/oauthWindow.html', substititions;
function NAPIJSProxy$1_0(this$0, val$closure){
  this.this$0 = this$0;
  this.val$closure = val$closure;
}

function NAPIJSProxy$1(){
}

_ = NAPIJSProxy$1_0.prototype = NAPIJSProxy$1.prototype = new Object_0;
_.getClass$ = function getClass_238(){
  return Lnet_wacapps_napi_util_NAPIJSProxy$1_2_classLit;
}
;
_.onError = function onError(request, exception){
  $onFailure_0(this.val$closure, exception.getMessage());
}
;
_.onResponseReceived = function onResponseReceived(request, response){
  var i_0, item, item$index, item$max, itemsArray, resp;
  if (response.val$xmlHttpRequest.status == 200) {
    resp = $processQueryCallback(response.val$xmlHttpRequest.responseText);
    if (!!resp && !!resp.product && !!$getItems(resp.product)) {
      itemsArray = initDim(_3Lnet_wacapps_napi_resource_jaxb_Item_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$Object_$1]), Q$Item, $getItems(resp.product).size, 0);
      i_0 = 0;
      for (item$index = 0 , item$max = itemsArray.length; item$index < item$max; ++item$index) {
        item = itemsArray[item$index];
        itemsArray[i_0++] = item;
      }
      $onSuccess_0(this.val$closure, itemsArray);
    }
     else {
      $onSuccess_0(this.val$closure, null);
    }
  }
   else {
    $onFailure_0(this.val$closure, response.val$xmlHttpRequest.responseText);
  }
}
;
_.this$0 = null;
_.val$closure = null;
function NAPIJSProxy$3_0(val$callback){
  this.val$callback = val$callback;
}

function NAPIJSProxy$3(){
}

_ = NAPIJSProxy$3_0.prototype = NAPIJSProxy$3.prototype = new Object_0;
_.getClass$ = function getClass_239(){
  return Lnet_wacapps_napi_util_NAPIJSProxy$3_2_classLit;
}
;
_.onFailure_0 = function onFailure_2(caught){
  $onFailure_1(this.val$callback, caught.getMessage(), caught.getMessage());
}
;
_.onSuccess_0 = function onSuccess_1(token){
  $onSuccess_1(this.val$callback, token);
}
;
_.val$callback = null;
function NAPIJSProxy$4_0(this$0, val$closure){
  this.this$0 = this$0;
  this.val$closure = val$closure;
}

function NAPIJSProxy$4(){
}

_ = NAPIJSProxy$4_0.prototype = NAPIJSProxy$4.prototype = new Object_0;
_.getClass$ = function getClass_240(){
  return Lnet_wacapps_napi_util_NAPIJSProxy$4_2_classLit;
}
;
_.onError = function onError_0(request, exception){
  $onFailure(this.val$closure, exception.getMessage());
}
;
_.onResponseReceived = function onResponseReceived_0(request, response){
  var amountTransaction, jsonResponse;
  jsonResponse = response.val$xmlHttpRequest.responseText;
  amountTransaction = $processPaymentCallback(jsonResponse);
  $storeTransaction(amountTransaction.paymentAmount);
  $onSuccess(this.val$closure, amountTransaction);
}
;
_.this$0 = null;
_.val$closure = null;
function $export_8(){
  if (!exported_8) {
    exported_8 = true;
    new ItemExporterImpl_0;
    new AmountTransactionExporterImpl_0;
    $export0_8();
  }
}

function $export0_8(){
  var pkg = declarePackage('net.wacapps.napi.util.NAPIJSProxy');
  var __0;
  $wnd.net.wacapps.napi.util.NAPIJSProxy = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_util_NAPIJSProxy_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new NAPIJSProxy_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.util.NAPIJSProxy.prototype = new Object;
  $wnd.net.wacapps.napi.util.NAPIJSProxy.AUTH = ($clinit_NAPIJSProxy() , AUTH);
  __0.setSpoofIP = $entry(function(a0){
    this.g.setSpoofIP_0(a0);
  }
  );
  __0.doCapturePayment = $entry(function(a0, a1, a2, a3, a4, a5, a6){
    this.g.doCapturePayment_0(a0, a1, a2, a3, gwtInstance(a4), a5, a6 == null?null:a6.constructor == $wnd.net.wacapps.napi.util.CaptureClosure?a6.g:new CaptureClosureExporterImpl_1(a6));
  }
  );
  __0.processPaymentResult = $entry(function(a0, a1){
    this.g.processPaymentResult_0(gwtInstance(a0), gwtInstance(a1));
  }
  );
  __0.getPaymentAmounts = $entry(function(a0){
    return this.g.getPaymentAmounts_0(a0);
  }
  );
  $wnd.net.wacapps.napi.util.NAPIJSProxy.getAuth = $entry(function(){
    return AUTH;
  }
  );
  __0.clearStorage = $entry(function(){
    this.g.clearStorage_0();
  }
  );
  $wnd.net.wacapps.napi.util.NAPIJSProxy.getAuthRequest = $entry(function(){
    return authRequest;
  }
  );
  __0.processQueryCallback = $entry(function(a0){
    return this.g.processQueryCallback_0(a0);
  }
  );
  __0.processPaymentCallback = $entry(function(a0){
    return wrap(this.g.processPaymentCallback_0(a0));
  }
  );
  __0.initalize = $entry(function(a0, a1, a2, a3, a4, a5, a6){
    this.g.initalize_0(a0, a1, a2, a3, a4, a5, a6 == null?null:a6.constructor == $wnd.net.wacapps.napi.util.DoQueryClosure?a6.g:new DoQueryClosureExporterImpl_1(a6));
  }
  );
  __0.getTransactions = $entry(function(){
    return wrap_0(this.g.getTransactions_0());
  }
  );
  __0.doReservePayment = $entry(function(a0, a1){
    this.g.doReservePayment_0(a0, a1 == null?null:a1.constructor == $wnd.net.wacapps.napi.util.PaymentClosure?a1.g:new PaymentClosureExporterImpl_1(a1));
  }
  );
  __0.storeTransaction = $entry(function(a0){
    this.g.storeTransaction_0(gwtInstance(a0));
  }
  );
  addTypeMap(Lnet_wacapps_napi_util_NAPIJSProxy_2_classLit, $wnd.net.wacapps.napi.util.NAPIJSProxy);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.util.NAPIJSProxy[p] === undefined && ($wnd.net.wacapps.napi.util.NAPIJSProxy[p] = pkg[p]);
}

function NAPIJSProxyExporterImpl_0(){
  $export_8();
}

function NAPIJSProxyExporterImpl(){
}

_ = NAPIJSProxyExporterImpl_0.prototype = NAPIJSProxyExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_241(){
  return Lnet_wacapps_napi_util_NAPIJSProxyExporterImpl_2_classLit;
}
;
var exported_8 = false;
function keyValueParameters(params, separator, doubleQuotedValues){
  var entry, entry$iterator, firstParam, result, value;
  result = new StringBuilder_0;
  firstParam = true;
  for (entry$iterator = params.entrySet().iterator(); entry$iterator.hasNext();) {
    entry = dynamicCast(entry$iterator.next_0(), Q$Map$Entry);
    value = dynamicCast(entry.getValue(), Q$String);
    $append_4($append_4($append_4(($append_0(result.impl, firstParam?'':separator) , result), dynamicCast(entry.getKey_0(), Q$String)), '='), doubleQuotedValues?'"' + value + '"':value);
    firstParam = false;
  }
  return result.impl.string;
}

function d_0(){
}

function $export_9(){
  if (!exported_9) {
    exported_9 = true;
    $export0_9();
  }
}

function $export0_9(){
  var pkg = declarePackage('net.wacapps.napi.util.PaymentClosure');
  var __0;
  $wnd.net.wacapps.napi.util.PaymentClosure = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_util_PaymentClosure_2_classLit, arguments) && (g = arguments[0]);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.util.PaymentClosure.prototype = new Object;
  __0.onSuccess = $entry(function(a0){
    this.g.onSuccess_2(a0);
  }
  );
  __0.onFailure = $entry(function(a0, a1){
    this.g.onFailure_2(a0, a1);
  }
  );
  addTypeMap(Lnet_wacapps_napi_util_PaymentClosure_2_classLit, $wnd.net.wacapps.napi.util.PaymentClosure);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.util.PaymentClosure[p] === undefined && ($wnd.net.wacapps.napi.util.PaymentClosure[p] = pkg[p]);
}

function $invoke_3(closure, a0){
  closure.apply(null, [a0]);
}

function $invoke_4(closure, a0, a1){
  closure.apply(null, [a0, a1]);
}

function $onFailure_1(this$static, a0, a1){
  $invoke_4(this$static.jso, a0, a1);
}

function $onSuccess_1(this$static, a0){
  $invoke_3(this$static.jso, a0);
}

function PaymentClosureExporterImpl_0(){
  $export_9();
}

function PaymentClosureExporterImpl_1(jso){
  this.jso = jso;
}

function PaymentClosureExporterImpl(){
}

_ = PaymentClosureExporterImpl_1.prototype = PaymentClosureExporterImpl_0.prototype = PaymentClosureExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_242(){
  return Lnet_wacapps_napi_util_PaymentClosureExporterImpl_2_classLit;
}
;
_.onFailure_2 = function onFailure_3(a0, a1){
  $invoke_4(this.jso, a0, a1);
}
;
_.onSuccess_2 = function onSuccess_2(a0){
  $onSuccess_1(this, a0);
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.jso = null;
var exported_9 = false;
function $clinit_UUID(){
  $clinit_UUID = nullMethod;
  CHARS = $toCharArray('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz');
}

function UUID_0(){
  $clinit_UUID();
}

function uuid_0(len){
  $clinit_UUID();
  return uuid_1(len, CHARS.length);
}

function uuid_1(len, radix){
  $clinit_UUID();
  var i_0, uuid;
  if (radix > CHARS.length) {
    throw new IllegalArgumentException_0;
  }
  uuid = initDim(_3C_classLit, makeCastMap([Q$Serializable]), -1, len, 1);
  for (i_0 = 0; i_0 < len; ++i_0) {
    uuid[i_0] = CHARS[round_int(Math.random() * radix)];
  }
  return valueOf_1(uuid);
}

function uuid_2(){
  $clinit_UUID();
  var i_0, r, uuid;
  uuid = initDim(_3C_classLit, makeCastMap([Q$Serializable]), -1, 36, 1);
  uuid[8] = uuid[13] = uuid[18] = uuid[23] = 45;
  uuid[14] = 52;
  for (i_0 = 0; i_0 < 36; ++i_0) {
    if (uuid[i_0] == 0) {
      r = round_int(Math.random() * 16);
      uuid[i_0] = CHARS[i_0 == 19?r & 3 | 8:r & 15];
    }
  }
  return valueOf_1(uuid);
}

function UUID(){
}

_ = UUID_0.prototype = UUID.prototype = new Object_0;
_.getClass$ = function getClass_243(){
  return Lnet_wacapps_napi_util_UUID_2_classLit;
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
var CHARS;
function $export_10(){
  if (!exported_10) {
    exported_10 = true;
    $export0_10();
  }
}

function $export0_10(){
  var pkg = declarePackage('net.wacapps.napi.util.UUID');
  var __0;
  $wnd.net.wacapps.napi.util.UUID = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_util_UUID_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new UUID_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.util.UUID.prototype = new Object;
  $wnd.net.wacapps.napi.util.UUID.uuid = $entry(function(a0, a1){
    return runDispatch(null, Lnet_wacapps_napi_util_UUID_2_classLit, 0, arguments, true, false)[0];
  }
  );
  $wnd.net.wacapps.napi.util.UUID.randomUUID = $entry(function(){
    return $clinit_UUID() , uuid_2();
  }
  );
  registerDispatchMap(Lnet_wacapps_napi_util_UUID_2_classLit, {0:{0:[[uuid_2, null, undefined]], 1:[[uuid_0, null, undefined, 'number']], 2:[[uuid_1, null, undefined, 'number', 'number']]}}, true);
  addTypeMap(Lnet_wacapps_napi_util_UUID_2_classLit, $wnd.net.wacapps.napi.util.UUID);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.util.UUID[p] === undefined && ($wnd.net.wacapps.napi.util.UUID[p] = pkg[p]);
}

function UUIDExporterImpl_0(){
  $export_10();
}

function UUIDExporterImpl(){
}

_ = UUIDExporterImpl_0.prototype = UUIDExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_244(){
  return Lnet_wacapps_napi_util_UUIDExporterImpl_2_classLit;
}
;
var exported_10 = false;
function copyOfRange_0(bytes, len){
  var i_0, result;
  result = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, len, 1);
  for (i_0 = 0; i_0 < len && i_0 < bytes.length; ++i_0) {
    result[i_0] = bytes[i_0];
  }
  return result;
}

function repeat(b, nrRepeats){
  var result;
  result = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, nrRepeats, 1);
  fill_0(result, result.length, b);
  return result;
}

function toHexString(bytes){
  var b, b$index, b$max, builder;
  builder = new StringBuilder_0;
  for (b$index = 0 , b$max = bytes.length; b$index < b$max; ++b$index) {
    b = bytes[b$index];
    $append_4(builder, toPowerOfTwoString(b >> 4 & 15));
    $append_4(builder, toPowerOfTwoString(b & 15));
  }
  return builder.impl.string;
}

function $doFinal(this$static, input){
  var inner, result;
  $engineUpdate(this$static, input, input.length);
  return inner = $digest_3(this$static.digest.delegate) , alert_0('engineDoFinal() opad=' + toHexString(this$static.opad)) , $update_5(this$static.digest, this$static.opad) , alert_0('engineDoFinal() inner=' + toHexString(inner)) , result = $digest_2(this$static.digest, inner, inner.length) , alert_0('engineDoFinal() result=' + toHexString(result)) , this$static.digest.delegate = new Sha256_0 , $update_5(this$static.digest, this$static.ipad) , result;
}

function $engineUpdate(this$static, input, len){
  $engineUpdate_0(this$static.digest, input, len);
}

function $expandOrReduceKeyToBlocksize_0(this$static, inputKey){
  var result;
  inputKey.length > this$static.blockSize && (inputKey = $digest_1(this$static.digest, inputKey));
  result = copyOfRange_0(inputKey, this$static.blockSize);
  return result;
}

function xor_1(bytes, offset, bytesToMix, mixOffset, len){
  var bytesLength;
  bytesLength = offset + len;
  for (; offset < bytesLength; ++offset) {
    bytes[offset] = bytes[offset] ^ bytesToMix[mixOffset++];
  }
}

function xor_2(dest, bytesToMix){
  xor_1(dest, 0, bytesToMix, 0, dest.length);
}

function Hmac_1(){
}

_ = Hmac_1.prototype = new Object_0;
_.getClass$ = function getClass_245(){
  return Lnet_wacapps_napi_util_crypto_Hmac_2_classLit;
}
;
_.blockSize = 0;
_.digest = null;
_.ipad = null;
_.opad = null;
function Hmac$SHA1_2(){
  this.digest = new SHA256MessageDigest_2;
  this.blockSize = 64;
}

function Hmac$SHA1_1(){
}

_ = Hmac$SHA1_2.prototype = Hmac$SHA1_1.prototype = new Hmac_1;
_.getClass$ = function getClass_246(){
  return Lnet_wacapps_napi_util_crypto_Hmac$SHA1_2_classLit;
}
;
function $digest_1(this$static, input){
  return $digest_2(this$static, input, input.length);
}

function $digest_2(this$static, input, len){
  $engineUpdate_0(this$static, input, len);
  return $digest_3(this$static.delegate);
}

function $engineUpdate_0(this$static, input, len){
  var i_0, sb;
  sb = new StringBuffer_0;
  if (len <= 0)
    return;
  for (i_0 = 0; i_0 < len; ++i_0) {
    $append_0(sb.impl, ' ' + input[i_0]);
    $update_6(this$static.delegate, input[i_0]);
  }
  alert_0('SHA256MessageDigest delegateCalledWith:' + sb.impl.string);
}

function $update_5(this$static, input){
  $engineUpdate_0(this$static, input, input.length);
}

function SHA256MessageDigest_2(){
  this.delegate = new Sha256_0;
}

function SHA256MessageDigest_1(){
}

_ = SHA256MessageDigest_2.prototype = SHA256MessageDigest_1.prototype = new Object_0;
_.getClass$ = function getClass_247(){
  return Lnet_wacapps_napi_util_crypto_SHA256MessageDigest_2_classLit;
}
;
_.delegate = null;
function SecretKeySpec_2(key){
  this.key = key;
  this.algorithm = 'HMACSHA1';
}

function SecretKeySpec_1(){
}

_ = SecretKeySpec_2.prototype = SecretKeySpec_1.prototype = new Object_0;
_.equals$ = function equals_18(obj){
  var other;
  if (this === obj)
    return true;
  if (obj == null)
    return false;
  if (Lnet_wacapps_napi_util_crypto_SecretKeySpec_2_classLit != getClass__devirtual$(obj))
    return false;
  other = dynamicCast(obj, Q$SecretKeySpec_0);
  if (this.algorithm == null) {
    if (other.algorithm != null)
      return false;
  }
   else if (!$equals(this.algorithm, other.algorithm))
    return false;
  if (!equals_15(this.key, other.key))
    return false;
  return true;
}
;
_.getClass$ = function getClass_248(){
  return Lnet_wacapps_napi_util_crypto_SecretKeySpec_2_classLit;
}
;
_.hashCode$ = function hashCode_19(){
  var result;
  result = 31 + (this.algorithm == null?0:getHashCode_0(this.algorithm));
  result = 31 * result + hashCode_17(this.key);
  return result;
}
;
_.castableTypeMap$ = makeCastMap([Q$SecretKeySpec_0]);
_.algorithm = null;
_.key = null;
function $clinit_Sha256(){
  $clinit_Sha256 = nullMethod;
  k_1 = initValues(_3I_classLit, makeCastMap([Q$Serializable]), -1, [1116352408, 1899447441, -1245643825, -373957723, 961987163, 1508970993, -1841331548, -1424204075, -670586216, 310598401, 607225278, 1426881987, 1925078388, -2132889090, -1680079193, -1046744716, -459576895, -272742522, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, -1740746414, -1473132947, -1341970488, -1084653625, -958395405, -710438585, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, -2117940946, -1838011259, -1564481375, -1474664885, -1035236496, -949202525, -778901479, -694614492, -200395387, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, -2067236844, -1933114872, -1866530822, -1538233109, -1090935817, -965641998]);
  w_0 = initDim(_3I_classLit, makeCastMap([Q$Serializable]), -1, 64, 1);
}

function $digest_3(this$static){
  var result, tail, bits, bits0, bits16, bits24, bits32, bits40, bits48, bits56, bits8, n, padding, result_0;
  tail = (n = toInt(mod(this$static.count, P40_longLit)) , padding = n < 56?56 - n:120 - n , result_0 = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, padding + 8, 1) , result_0[0] = -128 , bits = shl(this$static.count, 3) , alert_0('Sha256.padBuffer() count=' + toString_11(this$static.count) + ' n=' + n + ' padding=' + padding + ' bits=' + toString_11(bits)) , bits56 = toInt(shru(bits, 56)) << 24 >> 24 , bits48 = toInt(shru(bits, 48)) << 24 >> 24 , bits40 = toInt(shru(bits, 40)) << 24 >> 24 , bits32 = toInt(shru(bits, 32)) << 24 >> 24 , bits24 = toInt(shru(bits, 24)) << 24 >> 24 , bits16 = toInt(shru(bits, 16)) << 24 >> 24 , bits8 = toInt(shru(bits, 8)) << 24 >> 24 , bits0 = toInt(bits) << 24 >> 24 , $wnd.alert('Sha256.padBuffer()  bits56=' + bits56 + ' bits48=' + bits48 + ' bits40=' + bits40 + ' bits32=' + bits32 + ' bits24=' + bits24 + ' bits16=' + bits16 + ' bits8=' + bits8 + ' bits0=' + bits0) , result_0[padding++] = bits56 , result_0[padding++] = bits48 , result_0[padding++] = bits40 , result_0[padding++] = bits32 , result_0[padding++] = bits24 , result_0[padding++] = bits16 , result_0[padding++] = bits8 , result_0[padding] = bits0 , alert_0('Sha256.padBuffer() result=' + toHexString(result_0)) , result_0);
  $update_7(this$static, tail, tail.length);
  result = initValues(_3B_classLit, makeCastMap([Q$Serializable]), -1, [this$static.h0 >>> 24 << 24 >> 24, this$static.h0 >>> 16 << 24 >> 24, this$static.h0 >>> 8 << 24 >> 24, this$static.h0 << 24 >> 24, this$static.h1 >>> 24 << 24 >> 24, this$static.h1 >>> 16 << 24 >> 24, this$static.h1 >>> 8 << 24 >> 24, this$static.h1 << 24 >> 24, this$static.h2 >>> 24 << 24 >> 24, this$static.h2 >>> 16 << 24 >> 24, this$static.h2 >>> 8 << 24 >> 24, this$static.h2 << 24 >> 24, this$static.h3 >>> 24 << 24 >> 24, this$static.h3 >>> 16 << 24 >> 24, this$static.h3 >>> 8 << 24 >> 24, this$static.h3 << 24 >> 24, this$static.h4 >>> 24 << 24 >> 24, this$static.h4 >>> 16 << 24 >> 24, this$static.h4 >>> 8 << 24 >> 24, this$static.h4 << 24 >> 24, this$static.h5 >>> 24 << 24 >> 24, this$static.h5 >>> 16 << 24 >> 24, this$static.h5 >>> 8 << 24 >> 24, this$static.h5 << 24 >> 24, this$static.h6 >>> 24 << 24 >> 24, this$static.h6 >>> 16 << 24 >> 24, this$static.h6 >>> 8 << 24 >> 24, this$static.h6 << 24 >> 24, this$static.h7 >>> 24 << 24 >> 24, this$static.h7 >>> 16 << 24 >> 24, this$static.h7 >>> 8 << 24 >> 24, this$static.h7 << 24 >> 24]);
  $reset(this$static);
  return result;
}

function $reset(this$static){
  var i_0;
  this$static.count = P0_longLit;
  for (i_0 = 0; i_0 < this$static.blockSize;) {
    this$static.buffer[i_0++] = 0;
  }
  $resetContext(this$static);
}

function $resetContext(this$static){
  this$static.h0 = 1779033703;
  this$static.h1 = -1150833019;
  this$static.h2 = 1013904242;
  this$static.h3 = -1521486534;
  this$static.h4 = 1359893119;
  this$static.h5 = -1694144372;
  this$static.h6 = 528734635;
  this$static.h7 = 1541459225;
}

function $transform(this$static, in_$, offset){
  var result;
  result = sha(this$static.h0, this$static.h1, this$static.h2, this$static.h3, this$static.h4, this$static.h5, this$static.h6, this$static.h7, in_$, offset);
  this$static.h0 = result[0];
  this$static.h1 = result[1];
  this$static.h2 = result[2];
  this$static.h3 = result[3];
  this$static.h4 = result[4];
  this$static.h5 = result[5];
  this$static.h6 = result[6];
  this$static.h7 = result[7];
}

function $update_6(this$static, b){
  var i_0;
  i_0 = toInt(mod(this$static.count, fromInt(this$static.blockSize)));
  this$static.count = add(this$static.count, P1_longLit);
  this$static.buffer[i_0] = b;
  i_0 == this$static.blockSize - 1 && $transform(this$static, this$static.buffer, 0);
}

function $update_7(this$static, b, len){
  var i_0, n, partLen;
  n = toInt(mod(this$static.count, fromInt(this$static.blockSize)));
  this$static.count = add(this$static.count, fromInt(len));
  partLen = this$static.blockSize - n;
  i_0 = 0;
  if (len >= partLen) {
    arraycopy(b, 0, this$static.buffer, n, partLen);
    $transform(this$static, this$static.buffer, 0);
    for (i_0 = partLen; i_0 + this$static.blockSize - 1 < len; i_0 += this$static.blockSize) {
      $transform(this$static, b, i_0);
    }
    n = 0;
  }
  i_0 < len && arraycopy(b, i_0, this$static.buffer, n, len - i_0);
}

function Sha256_0(){
  $clinit_Sha256();
  this.blockSize = 64;
  this.buffer = initDim(_3B_classLit, makeCastMap([Q$Serializable]), -1, 64, 1);
  $resetContext(this);
}

function sha(hh0, hh1, hh2, hh3, hh4, hh5, hh6, hh7, in_$, offset){
  var A, B, C, D, E, F, G, H, T, T2, r;
  A = hh0;
  B = hh1;
  C = hh2;
  D = hh3;
  E = hh4;
  F = hh5;
  G = hh6;
  H = hh7;
  for (r = 0; r < 16; ++r) {
    w_0[r] = in_$[offset++] << 24 | (in_$[offset++] & 255) << 16 | (in_$[offset++] & 255) << 8 | in_$[offset++] & 255;
  }
  for (r = 16; r < 64; ++r) {
    T = w_0[r - 2];
    T2 = w_0[r - 15];
    w_0[r] = ((T >>> 17 | T << 15) ^ (T >>> 19 | T << 13) ^ T >>> 10) + w_0[r - 7] + ((T2 >>> 7 | T2 << 25) ^ (T2 >>> 18 | T2 << 14) ^ T2 >>> 3) + w_0[r - 16];
  }
  for (r = 0; r < 64; ++r) {
    T = H + ((E >>> 6 | E << 26) ^ (E >>> 11 | E << 21) ^ (E >>> 25 | E << 7)) + (E & F ^ ~E & G) + k_1[r] + w_0[r];
    T2 = ((A >>> 2 | A << 30) ^ (A >>> 13 | A << 19) ^ (A >>> 22 | A << 10)) + (A & B ^ A & C ^ B & C);
    H = G;
    G = F;
    F = E;
    E = D + T;
    D = C;
    C = B;
    B = A;
    A = T + T2;
  }
  return initValues(_3I_classLit, makeCastMap([Q$Serializable]), -1, [hh0 + A, hh1 + B, hh2 + C, hh3 + D, hh4 + E, hh5 + F, hh6 + G, hh7 + H]);
}

function Sha256(){
}

_ = Sha256_0.prototype = Sha256.prototype = new Object_0;
_.getClass$ = function getClass_249(){
  return Lnet_wacapps_napi_util_crypto_Sha256_2_classLit;
}
;
_.blockSize = 0;
_.buffer = null;
_.count = P0_longLit;
_.h0 = 0;
_.h1 = 0;
_.h2 = 0;
_.h3 = 0;
_.h4 = 0;
_.h5 = 0;
_.h6 = 0;
_.h7 = 0;
var k_1, w_0;
function Application_0(){
}

function Application(){
}

_ = Application_0.prototype = Application.prototype = new Object_0;
_.getApplicationApis_0 = function getApplicationApis(){
  return this.applicationApis;
}
;
_.getApplicationIdentifier_0 = function getApplicationIdentifier(){
  return this.applicationIdentifier;
}
;
_.getApplicationOperators_0 = function getApplicationOperators(){
  return this.applicationOperators;
}
;
_.getClass$ = function getClass_250(){
  return Lnet_wacapps_napi_xdo_applications_Application_2_classLit;
}
;
_.getCredentials_0 = function getCredentials(){
  return this.credentials;
}
;
_.getDescription_0 = function getDescription_2(){
  return this.description;
}
;
_.getDeveloperName_0 = function getDeveloperName(){
  return this.developerName;
}
;
_.getId_0 = function getId(){
  return this.id;
}
;
_.getName_0 = function getName_0(){
  return this.name_0;
}
;
_.getProductItems_0 = function getProductItems(){
  return this.productItems;
}
;
_.getTitle_0 = function getTitle(){
  return this.title;
}
;
_.getType_0 = function getType(){
  return this.type;
}
;
_.getVersion_0 = function getVersion(){
  return this.version;
}
;
_.setApplicationApis_0 = function setApplicationApis(value){
  this.applicationApis = value;
}
;
_.setApplicationIdentifier_0 = function setApplicationIdentifier(value){
  this.applicationIdentifier = value;
}
;
_.setApplicationOperators_0 = function setApplicationOperators(value){
  this.applicationOperators = value;
}
;
_.setCredentials_0 = function setCredentials(value){
  this.credentials = value;
}
;
_.setDescription_0 = function setDescription_1(value){
  this.description = value;
}
;
_.setDeveloperName_0 = function setDeveloperName(value){
  this.developerName = value;
}
;
_.setId_0 = function setId(value){
  this.id = value;
}
;
_.setName_0 = function setName(value){
  this.name_0 = value;
}
;
_.setProductItems_0 = function setProductItems(value){
  this.productItems = value;
}
;
_.setTitle_0 = function setTitle(value){
  this.title = value;
}
;
_.setType_0 = function setType(value){
  this.type = value;
}
;
_.setVersion_0 = function setVersion(value){
  this.version = value;
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.applicationApis = null;
_.applicationIdentifier = null;
_.applicationOperators = null;
_.credentials = null;
_.description = null;
_.developerName = null;
_.id = null;
_.name_0 = null;
_.productItems = null;
_.title = null;
_.type = null;
_.version = null;
function $export_11(){
  if (!exported_11) {
    exported_11 = true;
    $export0_11();
  }
}

function $export0_11(){
  var pkg = declarePackage('net.wacapps.napi.xdo.applications.Application');
  var __0;
  $wnd.net.wacapps.napi.xdo.applications.Application = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_xdo_applications_Application_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new Application_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.xdo.applications.Application.prototype = new Object;
  __0.setCredentials = $entry(function(a0){
    this.g.setCredentials_0(gwtInstance(a0));
  }
  );
  __0.getDescription = $entry(function(){
    return this.g.getDescription_0();
  }
  );
  __0.setApplicationApis = $entry(function(a0){
    this.g.setApplicationApis_0(gwtInstance(a0));
  }
  );
  __0.getApplicationOperators = $entry(function(){
    return this.g.getApplicationOperators_0();
  }
  );
  __0.getApplicationIdentifier = $entry(function(){
    return this.g.getApplicationIdentifier_0();
  }
  );
  __0.getDeveloperName = $entry(function(){
    return this.g.getDeveloperName_0();
  }
  );
  __0.setVersion = $entry(function(a0){
    this.g.setVersion_0(a0);
  }
  );
  __0.setTitle = $entry(function(a0){
    this.g.setTitle_0(a0);
  }
  );
  __0.setApplicationOperators = $entry(function(a0){
    this.g.setApplicationOperators_0(gwtInstance(a0));
  }
  );
  __0.getCredentials = $entry(function(){
    return this.g.getCredentials_0();
  }
  );
  __0.setId = $entry(function(a0){
    this.g.setId_0(a0);
  }
  );
  __0.getName = $entry(function(){
    return this.g.getName_0();
  }
  );
  __0.getTitle = $entry(function(){
    return this.g.getTitle_0();
  }
  );
  __0.setApplicationIdentifier = $entry(function(a0){
    this.g.setApplicationIdentifier_0(a0);
  }
  );
  __0.setProductItems = $entry(function(a0){
    this.g.setProductItems_0(gwtInstance(a0));
  }
  );
  __0.getVersion = $entry(function(){
    return this.g.getVersion_0();
  }
  );
  __0.setType = $entry(function(a0){
    this.g.setType_0(a0);
  }
  );
  __0.setDescription = $entry(function(a0){
    this.g.setDescription_0(a0);
  }
  );
  __0.setName = $entry(function(a0){
    this.g.setName_0(a0);
  }
  );
  __0.getId = $entry(function(){
    return this.g.getId_0();
  }
  );
  __0.setDeveloperName = $entry(function(a0){
    this.g.setDeveloperName_0(a0);
  }
  );
  __0.getApplicationApis = $entry(function(){
    return this.g.getApplicationApis_0();
  }
  );
  __0.getProductItems = $entry(function(){
    return this.g.getProductItems_0();
  }
  );
  __0.getType = $entry(function(){
    return this.g.getType_0();
  }
  );
  addTypeMap(Lnet_wacapps_napi_xdo_applications_Application_2_classLit, $wnd.net.wacapps.napi.xdo.applications.Application);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.xdo.applications.Application[p] === undefined && ($wnd.net.wacapps.napi.xdo.applications.Application[p] = pkg[p]);
}

function ApplicationExporterImpl_0(){
  $export_11();
}

function ApplicationExporterImpl(){
}

_ = ApplicationExporterImpl_0.prototype = ApplicationExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_251(){
  return Lnet_wacapps_napi_xdo_applications_ApplicationExporterImpl_2_classLit;
}
;
var exported_11 = false;
function Credential_0(){
}

function Credential(){
}

_ = Credential_0.prototype = Credential.prototype = new Object_0;
_.getApiKeyId_0 = function getApiKeyId(){
  return this.apiKeyId;
}
;
_.getClass$ = function getClass_252(){
  return Lnet_wacapps_napi_xdo_applications_Credential_2_classLit;
}
;
_.getEnvironment_0 = function getEnvironment(){
  return this.environment;
}
;
_.getKey_1 = function getKey_3(){
  return this.key;
}
;
_.getSecret_0 = function getSecret(){
  return this.secret;
}
;
_.getStatus_0 = function getStatus(){
  return this.status_0;
}
;
_.setApiKeyId_0 = function setApiKeyId(value){
  this.apiKeyId = value;
}
;
_.setEnvironment_0 = function setEnvironment(value){
  this.environment = value;
}
;
_.setKey_0 = function setKey(value){
  this.key = value;
}
;
_.setSecret_0 = function setSecret(value){
  this.secret = value;
}
;
_.setStatus_0 = function setStatus(value){
  this.status_0 = value;
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.apiKeyId = null;
_.environment = null;
_.key = null;
_.secret = null;
_.status_0 = null;
function $export_12(){
  if (!exported_12) {
    exported_12 = true;
    $export0_12();
  }
}

function $export0_12(){
  var pkg = declarePackage('net.wacapps.napi.xdo.applications.Credential');
  var __0;
  $wnd.net.wacapps.napi.xdo.applications.Credential = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_xdo_applications_Credential_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new Credential_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.xdo.applications.Credential.prototype = new Object;
  __0.getKey = $entry(function(){
    return this.g.getKey_1();
  }
  );
  __0.setEnvironment = $entry(function(a0){
    this.g.setEnvironment_0(a0);
  }
  );
  __0.setApiKeyId = $entry(function(a0){
    this.g.setApiKeyId_0(gwtInstance(a0));
  }
  );
  __0.getStatus = $entry(function(){
    return this.g.getStatus_0();
  }
  );
  __0.getApiKeyId = $entry(function(){
    return this.g.getApiKeyId_0();
  }
  );
  __0.setKey = $entry(function(a0){
    this.g.setKey_0(a0);
  }
  );
  __0.setSecret = $entry(function(a0){
    this.g.setSecret_0(a0);
  }
  );
  __0.getEnvironment = $entry(function(){
    return this.g.getEnvironment_0();
  }
  );
  __0.getSecret = $entry(function(){
    return this.g.getSecret_0();
  }
  );
  __0.setStatus = $entry(function(a0){
    this.g.setStatus_0(a0);
  }
  );
  addTypeMap(Lnet_wacapps_napi_xdo_applications_Credential_2_classLit, $wnd.net.wacapps.napi.xdo.applications.Credential);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.xdo.applications.Credential[p] === undefined && ($wnd.net.wacapps.napi.xdo.applications.Credential[p] = pkg[p]);
}

function CredentialExporterImpl_0(){
  $export_12();
}

function CredentialExporterImpl(){
}

_ = CredentialExporterImpl_0.prototype = CredentialExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_253(){
  return Lnet_wacapps_napi_xdo_applications_CredentialExporterImpl_2_classLit;
}
;
var exported_12 = false;
function Developer_0(){
}

function Developer(){
}

_ = Developer_0.prototype = Developer.prototype = new Object_0;
_.getAddress_0 = function getAddress(){
  return this.address;
}
;
_.getClass$ = function getClass_254(){
  return Lnet_wacapps_napi_xdo_developer_Developer_2_classLit;
}
;
_.getEmail_0 = function getEmail(){
  return this.email;
}
;
_.getFirstName_0 = function getFirstName(){
  return this.firstName;
}
;
_.getId_1 = function getId_0(){
  return this.id;
}
;
_.getLastName_0 = function getLastName(){
  return this.lastName;
}
;
_.getLocale_0 = function getLocale(){
  return this.locale;
}
;
_.getOrganization_0 = function getOrganization(){
  return this.organization;
}
;
_.getStatus_0 = function getStatus_0(){
  return this.status_0;
}
;
_.getUserName_0 = function getUserName(){
  return this.userName;
}
;
_.setAddress_0 = function setAddress(value){
  this.address = value;
}
;
_.setEmail_0 = function setEmail(value){
  this.email = value;
}
;
_.setFirstName_0 = function setFirstName(value){
  this.firstName = value;
}
;
_.setId_1 = function setId_0(value){
  this.id = value;
}
;
_.setLastName_0 = function setLastName(value){
  this.lastName = value;
}
;
_.setLocale_0 = function setLocale(value){
  this.locale = value;
}
;
_.setOrganization_0 = function setOrganization(value){
  this.organization = value;
}
;
_.setStatus_0 = function setStatus_0(value){
  this.status_0 = value;
}
;
_.setUserName_0 = function setUserName(value){
  this.userName = value;
}
;
_.castableTypeMap$ = makeCastMap([Q$Exportable]);
_.address = null;
_.email = null;
_.firstName = null;
_.id = null;
_.lastName = null;
_.locale = null;
_.organization = null;
_.status_0 = null;
_.userName = null;
function $export_13(){
  if (!exported_13) {
    exported_13 = true;
    $export0_13();
  }
}

function $export0_13(){
  var pkg = declarePackage('net.wacapps.napi.xdo.developer.Developer');
  var __0;
  $wnd.net.wacapps.napi.xdo.developer.Developer = $entry(function(){
    var g, j = this;
    isAssignableToInstance(Lnet_wacapps_napi_xdo_developer_Developer_2_classLit, arguments)?(g = arguments[0]):arguments.length == 0 && (g = new Developer_0);
    j.g = g;
    setWrapper(g, j);
    return j;
  }
  );
  __0 = $wnd.net.wacapps.napi.xdo.developer.Developer.prototype = new Object;
  __0.setOrganization = $entry(function(a0){
    this.g.setOrganization_0(a0);
  }
  );
  __0.getOrganization = $entry(function(){
    return this.g.getOrganization_0();
  }
  );
  __0.setLocale = $entry(function(a0){
    this.g.setLocale_0(a0);
  }
  );
  __0.setLastName = $entry(function(a0){
    this.g.setLastName_0(a0);
  }
  );
  __0.setId = $entry(function(a0){
    this.g.setId_1(gwtInstance(a0));
  }
  );
  __0.getUserName = $entry(function(){
    return this.g.getUserName_0();
  }
  );
  __0.setUserName = $entry(function(a0){
    this.g.setUserName_0(a0);
  }
  );
  __0.getLastName = $entry(function(){
    return this.g.getLastName_0();
  }
  );
  __0.setStatus = $entry(function(a0){
    this.g.setStatus_0(a0);
  }
  );
  __0.getId = $entry(function(){
    return this.g.getId_1();
  }
  );
  __0.setEmail = $entry(function(a0){
    this.g.setEmail_0(a0);
  }
  );
  __0.getAddress = $entry(function(){
    return this.g.getAddress_0();
  }
  );
  __0.getStatus = $entry(function(){
    return this.g.getStatus_0();
  }
  );
  __0.setAddress = $entry(function(a0){
    this.g.setAddress_0(a0);
  }
  );
  __0.getEmail = $entry(function(){
    return this.g.getEmail_0();
  }
  );
  __0.getFirstName = $entry(function(){
    return this.g.getFirstName_0();
  }
  );
  __0.setFirstName = $entry(function(a0){
    this.g.setFirstName_0(a0);
  }
  );
  __0.getLocale = $entry(function(){
    return this.g.getLocale_0();
  }
  );
  addTypeMap(Lnet_wacapps_napi_xdo_developer_Developer_2_classLit, $wnd.net.wacapps.napi.xdo.developer.Developer);
  if (pkg)
    for (p in pkg)
      $wnd.net.wacapps.napi.xdo.developer.Developer[p] === undefined && ($wnd.net.wacapps.napi.xdo.developer.Developer[p] = pkg[p]);
}

function DeveloperExporterImpl_0(){
  $export_13();
}

function DeveloperExporterImpl(){
}

_ = DeveloperExporterImpl_0.prototype = DeveloperExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_255(){
  return Lnet_wacapps_napi_xdo_developer_DeveloperExporterImpl_2_classLit;
}
;
var exported_13 = false;
function ExportAllExporterImpl_0(){
  new CaptureClosureExporterImpl_0;
  new DoQueryClosureExporterImpl_0;
  new PaymentClosureExporterImpl_0;
  new WacNapiContextExporterImpl_0;
  new WacRestApiExporterImpl_0;
  new AmountTransactionExporterImpl_0;
  new ChargingInformationExporterImpl_0;
  new ItemExporterImpl_0;
  new PaymentAmountExporterImpl_0;
  new NAPIJSProxyExporterImpl_0;
  new UUIDExporterImpl_0;
  new ApplicationExporterImpl_0;
  new CredentialExporterImpl_0;
  new DeveloperExporterImpl_0;
}

function ExportAllExporterImpl(){
}

_ = ExportAllExporterImpl_0.prototype = ExportAllExporterImpl.prototype = new Object_0;
_.getClass$ = function getClass_256(){
  return Lorg_timepedia_exporter_client_ExportAllExporterImpl_2_classLit;
}
;
function ExporterBaseImpl(){
}

_ = ExporterBaseImpl.prototype = new Object_0;
_.getClass$ = function getClass_257(){
  return Lorg_timepedia_exporter_client_ExporterBaseImpl_2_classLit;
}
;
function $addTypeMap(this$static, type, exportedConstructor){
  this$static.typeMap.put(type, exportedConstructor);
}

function $computeVarArguments(len, args){
  var ret = [];
  for (i = 0; i < len - 1; i++)
    ret.push(args[i]);
  var alen = args.length;
  var p_0 = len - 1;
  if (alen >= len && Object.prototype.toString.apply(args[p_0]) === '[object Array]') {
    ret.push(args[p_0]);
  }
   else {
    var a = [];
    for (i = p_0; i < alen; i++)
      a.push(args[i]);
    ret.push(a);
  }
  return ret;
}

function $declarePackage(qualifiedExportName){
  var i_0, l_0, o, prefix, superPackages;
  superPackages = $split(qualifiedExportName, '\\.', 0);
  prefix = $wnd;
  i_0 = 0;
  for (l_0 = superPackages.length - 1; i_0 < l_0; ++i_0) {
    if (!$equals(superPackages[i_0], 'client')) {
      prefix[superPackages[i_0]] || (prefix[superPackages[i_0]] = {});
      prefix = prefix != null?prefix[superPackages[i_0]]:null;
    }
  }
  o = prefix != null?prefix[superPackages[i_0]]:null;
  return o;
}

function $getMaxArity(jsoMap, meth){
  var o = jsoMap[meth];
  var r = 0;
  for (k in o)
    r = Math.max(r, k);
  return r;
}

function $registerDispatchMap(this$static, clazz, dispMap, isStatic){
  var jso, map;
  map = isStatic?this$static.staticDispatchMap:this$static.dispatchMap;
  jso = dynamicCastJso(map.get_0(clazz));
  !jso?(jso = dispMap):mergeJso(jso, dispMap);
  map.put(clazz, jso);
}

function $runDispatch(instance, dmap, clazz, meth, arguments_0){
  var aFunc, i_0, jFunc, l_0, r, sig, sigs, wFunc, x;
  sigs = dynamicCastJso(dmap.get_0(clazz))[meth][arguments_0.length];
  jFunc = null;
  wFunc = null;
  aFunc = null;
  for (i_0 = 0 , l_0 = !sigs?0:sigs.length; i_0 < l_0; ++i_0) {
    sig = sigs[i_0];
    if ($matches(sig, arguments_0)) {
      jFunc = sig[0];
      wFunc = sig[1];
      aFunc = sig[2];
      break;
    }
  }
  if (!jFunc) {
    return null;
  }
   else {
    arguments_0 = aFunc?aFunc(instance, arguments_0):arguments_0;
    r = (x = jFunc.apply(instance, arguments_0) , [wFunc?wFunc(x):x]);
    return r;
  }
}

function $runDispatch_0(this$static, instance, clazz, meth, arguments_0, isStatic, isVarArgs){
  var args, dmap, i_0, l_0, ret;
  dmap = isStatic?this$static.staticDispatchMap:this$static.dispatchMap;
  if (isVarArgs) {
    for (l_0 = $getMaxArity(dynamicCastJso(dmap.get_0(clazz)), meth) , i_0 = l_0; i_0 >= 1; --i_0) {
      args = $computeVarArguments(i_0, arguments_0);
      ret = $runDispatch(instance, dmap, clazz, meth, args);
      if (!ret) {
        args = $unshift(instance, args);
        ret = $runDispatch(instance, dmap, clazz, meth, args);
      }
      if (ret) {
        return ret;
      }
    }
  }
   else {
    ret = $runDispatch(instance, dmap, clazz, meth, arguments_0);
    if (!ret) {
      arguments_0 = $unshift(instance, arguments_0);
      ret = $runDispatch(instance, dmap, clazz, meth, arguments_0);
    }
    if (ret) {
      return ret;
    }
  }
  throw new RuntimeException_0("Can't find exported method for given arguments: " + meth + ':' + arguments_0.length + '\n');
}

function $setWrapper(this$static, type){
  var cons, wrapper;
  if ((getClass__devirtual$(type).modifiers & 4) != 0) {
    return [];
  }
  cons = $typeConstructor(this$static, getClass__devirtual$(type));
  wrapper = cons && typeof cons == 'function'?new cons(type):type;
  type['__gwtex_wrap'] = wrapper;
  return wrapper;
}

function $toArrObject(j, ret){
  var i_0, l_0, o, s;
  s = j;
  l_0 = s.length;
  for (i_0 = 0; i_0 < l_0; ++i_0) {
    o = s[i_0];
    instanceOfJso(o) && getGwtInstance(dynamicCastJso(o)) != null && (o = getGwtInstance(dynamicCastJso(o)));
    setCheck(ret, i_0, o);
  }
  return ret;
}

function $toArrString(s){
  var i_0, l_0, ret;
  l_0 = s.length;
  ret = initDim(_3Ljava_lang_String_2_classLit, makeCastMap([Q$Serializable, Q$Serializable_$1, Q$CharSequence_$1, Q$Comparable_$1, Q$Object_$1, Q$String_$1]), Q$String, l_0, 0);
  for (i_0 = 0; i_0 < l_0; ++i_0) {
    ret[i_0] = s[i_0];
  }
  return ret;
}

function $typeConstructor(this$static, type){
  var o, sup;
  o = this$static.typeMap.get_0(type);
  sup = type.superclass;
  if (o == null && !!sup && sup != Ljava_lang_Object_2_classLit) {
    return $typeConstructor(this$static, sup);
  }
  return dynamicCastJso(o);
}

function $unshift(o, arr){
  var ret = [o];
  for (i = 0; i < arr.length; i++)
    ret.push(arr[i]);
  return ret;
}

function $wrap(this$static, type){
  var wrapper;
  if (type == null) {
    return null;
  }
  return wrapper = type['__gwtex_wrap'] , !wrapper && (wrapper = $setWrapper(this$static, type)) , wrapper;
}

function $wrap_0(this$static, type){
  var i_0, wrapperArray;
  if (type == null) {
    return null;
  }
  wrapperArray = [];
  for (i_0 = 0; i_0 < type.length; ++i_0) {
    wrapperArray[i_0] = $wrap(this$static, type[i_0]);
  }
  return wrapperArray;
}

function ExporterBaseActual_0(){
  this.typeMap = new HashMap_0;
  this.dispatchMap = new HashMap_0;
  this.staticDispatchMap = new HashMap_0;
}

function getGwtInstance(o){
  return o && o.g?o.g:null;
}

function isAssignableToClass(o, clazz){
  var sup;
  if (Ljava_lang_Object_2_classLit == clazz) {
    return true;
  }
  if (Lorg_timepedia_exporter_client_Exportable_2_classLit == clazz && instanceOf(o, Q$Exportable)) {
    return true;
  }
  if (o != null) {
    for (sup = getClass__devirtual$(o); !!sup && sup != Ljava_lang_Object_2_classLit; sup = sup.superclass) {
      if (sup == clazz) {
        return true;
      }
    }
  }
  return false;
}

function mergeJso(o1, o2){
  for (p in o2) {
    o1[p] = o2[p];
  }
}

function ExporterBaseActual(){
}

_ = ExporterBaseActual_0.prototype = ExporterBaseActual.prototype = new ExporterBaseImpl;
_.getClass$ = function getClass_258(){
  return Lorg_timepedia_exporter_client_ExporterBaseActual_2_classLit;
}
;
function $matches(this$static, arguments_0){
  var argJsType, gwt, i_0, isBoolean, isClass, isNumber, isPrimitive, jsType, l_0, o;
  for (i_0 = 0 , l_0 = arguments_0.length; i_0 < l_0; ++i_0) {
    jsType = this$static[i_0 + 3];
    argJsType = typeof_$(arguments_0, i_0);
    if ($equals(argJsType, jsType)) {
      continue;
    }
    if ($equals('string', jsType) && $equals('null', argJsType)) {
      continue;
    }
    isNumber = $equals('number', argJsType);
    isBoolean = $equals('boolean', argJsType);
    if (Ljava_lang_Object_2_classLit === jsType) {
      isNumber && (arguments_0[i_0] = new Double_0(arguments_0[i_0]) , undefined);
      isBoolean && (arguments_0[i_0] = ($clinit_Boolean() , arguments_0[i_0]?TRUE_0:FALSE_0) , undefined);
      continue;
    }
    isPrimitive = isNumber || isBoolean;
    isClass = !isPrimitive && jsType != null && getClass__devirtual$(jsType) == Ljava_lang_Class_2_classLit;
    if (isClass) {
      o = arguments_0[i_0];
      if (o == null || isAssignableToClass(o, dynamicCast(jsType, Q$Class))) {
        continue;
      }
      if (instanceOfJso(o)) {
        gwt = getGwtInstance(dynamicCastJso(o));
        if (gwt != null) {
          if (isAssignableToClass(gwt, dynamicCast(jsType, Q$Class))) {
            arguments_0[i_0] = gwt;
            continue;
          }
        }
      }
    }
    if ($equals('object', jsType) && !isNumber && !isBoolean) {
      continue;
    }
    return false;
  }
  return true;
}

function typeof_$(args, i_0){
  var o = args[i_0];
  var t = o == null?'null':typeof o;
  if (t == 'object') {
    return Object.prototype.toString.call(o) == '[object Array]' || typeof o.length == 'number'?'array':t;
  }
  return t;
}

function $clinit_ExporterUtil(){
  $clinit_ExporterUtil = nullMethod;
  impl = new ExporterBaseActual_0;
}

function addTypeMap(type, exportedConstructor){
  $clinit_ExporterUtil();
  $addTypeMap(impl, type, exportedConstructor);
}

function declarePackage(qualifiedExportName){
  $clinit_ExporterUtil();
  return $declarePackage(qualifiedExportName);
}

function gwtInstance(o){
  var g;
  $clinit_ExporterUtil();
  return o != null && instanceOfJso(o) && (g = getGwtInstance(dynamicCastJso(o))) != null?g:o;
}

function isAssignableToInstance(clazz, args){
  var o;
  $clinit_ExporterUtil();
  return o = args && args[0] && (typeof args[0] == 'object' || typeof args[0] == 'function')?args[0]:null , isAssignableToClass(o, clazz);
}

function registerDispatchMap(clazz, dispMap, isStatic){
  $clinit_ExporterUtil();
  $registerDispatchMap(impl, clazz, dispMap, isStatic);
}

function runDispatch(instance, clazz, meth, arguments_0, isStatic, isVarArgs){
  $clinit_ExporterUtil();
  return $runDispatch_0(impl, instance, clazz, meth, arguments_0, isStatic, isVarArgs);
}

function setWrapper(instance, wrapper){
  $clinit_ExporterUtil();
  instance['__gwtex_wrap'] = wrapper;
}

function wrap(type){
  $clinit_ExporterUtil();
  return $wrap(impl, type);
}

function wrap_0(type){
  $clinit_ExporterUtil();
  return $wrap_0(impl, type);
}

var impl;
var $entry = entry_0;
function gwtOnLoad(errFn, modName, modBase, softPermutationId){
  $moduleName = modName;
  $moduleBase = modBase;
  if (errFn)
    try {
      $entry(init)();
    }
     catch (e) {
      errFn(modName);
    }
   else {
    $entry(init)();
  }
}

var Ljava_lang_Object_2_classLit = createForClass('java.lang.', 'Object', null), Lcom_google_api_gwt_oauth2_client_Auth_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'Auth', Ljava_lang_Object_2_classLit), Lcom_google_api_gwt_oauth2_client_Auth$1_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'Auth$1', Ljava_lang_Object_2_classLit), Ljava_lang_String_2_classLit = createForClass('java.lang.', 'String', Ljava_lang_Object_2_classLit), _3Ljava_lang_String_2_classLit = createForArray('[Ljava.lang.', 'String;', Ljava_lang_String_2_classLit), Lcom_google_api_gwt_oauth2_client_Auth$CallbackWrapper_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'Auth$CallbackWrapper', Ljava_lang_Object_2_classLit), Lcom_google_api_gwt_oauth2_client_Auth$TokenInfo_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'Auth$TokenInfo', Ljava_lang_Object_2_classLit), Lcom_google_api_gwt_oauth2_client_AuthImpl_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'AuthImpl', Lcom_google_api_gwt_oauth2_client_Auth_2_classLit), Lcom_google_api_gwt_oauth2_client_AuthImpl$RealUrlCodex_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'AuthImpl$RealUrlCodex', Ljava_lang_Object_2_classLit), Lcom_google_api_gwt_oauth2_client_AuthRequest_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'AuthRequest', Ljava_lang_Object_2_classLit), Lcom_google_api_gwt_oauth2_client_TokenStoreImpl_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'TokenStoreImpl', Ljava_lang_Object_2_classLit), Lcom_google_api_gwt_oauth2_client_CookieStoreImpl_2_classLit = createForClass('com.google.api.gwt.oauth2.client.', 'CookieStoreImpl', Lcom_google_api_gwt_oauth2_client_TokenStoreImpl_2_classLit), Lcom_google_gwt_user_client_Timer_2_classLit = createForClass('com.google.gwt.user.client.', 'Timer', Ljava_lang_Object_2_classLit), Ljava_lang_Enum_2_classLit = createForClass('java.lang.', 'Enum', Ljava_lang_Object_2_classLit), Ljava_lang_Throwable_2_classLit = createForClass('java.lang.', 'Throwable', Ljava_lang_Object_2_classLit), Ljava_lang_Exception_2_classLit = createForClass('java.lang.', 'Exception', Ljava_lang_Throwable_2_classLit), Ljava_lang_RuntimeException_2_classLit = createForClass('java.lang.', 'RuntimeException', Ljava_lang_Exception_2_classLit), Lcom_google_gwt_core_client_JavaScriptException_2_classLit = createForClass('com.google.gwt.core.client.', 'JavaScriptException', Ljava_lang_RuntimeException_2_classLit), Lcom_google_gwt_core_client_JavaScriptObject_2_classLit = createForClass('com.google.gwt.core.client.', 'JavaScriptObject$', Ljava_lang_Object_2_classLit), Lcom_google_gwt_core_client_Scheduler_2_classLit = createForClass('com.google.gwt.core.client.', 'Scheduler', Ljava_lang_Object_2_classLit), I_classLit = createForPrimitive('int'), _3I_classLit = createForArray('', '[I', I_classLit), _3Ljava_lang_Object_2_classLit = createForArray('[Ljava.lang.', 'Object;', Ljava_lang_Object_2_classLit), Lcom_google_gwt_core_client_impl_SchedulerImpl_2_classLit = createForClass('com.google.gwt.core.client.impl.', 'SchedulerImpl', Lcom_google_gwt_core_client_Scheduler_2_classLit), Lcom_google_gwt_core_client_impl_SchedulerImpl$Flusher_2_classLit = createForClass('com.google.gwt.core.client.impl.', 'SchedulerImpl$Flusher', Ljava_lang_Object_2_classLit), Lcom_google_gwt_core_client_impl_SchedulerImpl$Rescuer_2_classLit = createForClass('com.google.gwt.core.client.impl.', 'SchedulerImpl$Rescuer', Ljava_lang_Object_2_classLit), Ljava_lang_StackTraceElement_2_classLit = createForClass('java.lang.', 'StackTraceElement', Ljava_lang_Object_2_classLit), _3Ljava_lang_StackTraceElement_2_classLit = createForArray('[Ljava.lang.', 'StackTraceElement;', Ljava_lang_StackTraceElement_2_classLit), Lcom_google_gwt_core_client_impl_StringBufferImpl_2_classLit = createForClass('com.google.gwt.core.client.impl.', 'StringBufferImpl', Ljava_lang_Object_2_classLit), Lcom_google_gwt_core_client_impl_StringBufferImplAppend_2_classLit = createForClass('com.google.gwt.core.client.impl.', 'StringBufferImplAppend', Lcom_google_gwt_core_client_impl_StringBufferImpl_2_classLit), Lcom_google_web_bindery_event_shared_Event_2_classLit = createForClass('com.google.web.bindery.event.shared.', 'Event', Ljava_lang_Object_2_classLit), Lcom_google_gwt_event_shared_GwtEvent_2_classLit = createForClass('com.google.gwt.event.shared.', 'GwtEvent', Lcom_google_web_bindery_event_shared_Event_2_classLit), Lcom_google_web_bindery_event_shared_Event$Type_2_classLit = createForClass('com.google.web.bindery.event.shared.', 'Event$Type', Ljava_lang_Object_2_classLit), Lcom_google_gwt_event_shared_GwtEvent$Type_2_classLit = createForClass('com.google.gwt.event.shared.', 'GwtEvent$Type', Lcom_google_web_bindery_event_shared_Event$Type_2_classLit), Lcom_google_gwt_event_logical_shared_CloseEvent_2_classLit = createForClass('com.google.gwt.event.logical.shared.', 'CloseEvent', Lcom_google_gwt_event_shared_GwtEvent_2_classLit), Lcom_google_gwt_event_shared_HandlerManager_2_classLit = createForClass('com.google.gwt.event.shared.', 'HandlerManager', Ljava_lang_Object_2_classLit), Lcom_google_web_bindery_event_shared_EventBus_2_classLit = createForClass('com.google.web.bindery.event.shared.', 'EventBus', Ljava_lang_Object_2_classLit), Lcom_google_web_bindery_event_shared_SimpleEventBus_2_classLit = createForClass('com.google.web.bindery.event.shared.', 'SimpleEventBus', Lcom_google_web_bindery_event_shared_EventBus_2_classLit), Lcom_google_gwt_event_shared_HandlerManager$Bus_2_classLit = createForClass('com.google.gwt.event.shared.', 'HandlerManager$Bus', Lcom_google_web_bindery_event_shared_SimpleEventBus_2_classLit), Lcom_google_gwt_event_shared_LegacyHandlerWrapper_2_classLit = createForClass('com.google.gwt.event.shared.', 'LegacyHandlerWrapper', Ljava_lang_Object_2_classLit), Lcom_google_web_bindery_event_shared_UmbrellaException_2_classLit = createForClass('com.google.web.bindery.event.shared.', 'UmbrellaException', Ljava_lang_RuntimeException_2_classLit), Lcom_google_gwt_event_shared_UmbrellaException_2_classLit = createForClass('com.google.gwt.event.shared.', 'UmbrellaException', Lcom_google_web_bindery_event_shared_UmbrellaException_2_classLit), Lcom_google_gwt_http_client_Request_2_classLit = createForClass('com.google.gwt.http.client.', 'Request', Ljava_lang_Object_2_classLit), Lcom_google_gwt_http_client_Response_2_classLit = createForClass('com.google.gwt.http.client.', 'Response', Ljava_lang_Object_2_classLit), Lcom_google_gwt_http_client_Request$1_2_classLit = createForClass('com.google.gwt.http.client.', 'Request$1', Lcom_google_gwt_http_client_Response_2_classLit), Lcom_google_gwt_http_client_Request$3_2_classLit = createForClass('com.google.gwt.http.client.', 'Request$3', Lcom_google_gwt_user_client_Timer_2_classLit), Lcom_google_gwt_http_client_RequestBuilder_2_classLit = createForClass('com.google.gwt.http.client.', 'RequestBuilder', Ljava_lang_Object_2_classLit), Lcom_google_gwt_http_client_RequestBuilder$1_2_classLit = createForClass('com.google.gwt.http.client.', 'RequestBuilder$1', Ljava_lang_Object_2_classLit), Lcom_google_gwt_http_client_RequestBuilder$Method_2_classLit = createForClass('com.google.gwt.http.client.', 'RequestBuilder$Method', Ljava_lang_Object_2_classLit), Lcom_google_gwt_http_client_RequestException_2_classLit = createForClass('com.google.gwt.http.client.', 'RequestException', Ljava_lang_Exception_2_classLit), Lcom_google_gwt_http_client_RequestPermissionException_2_classLit = createForClass('com.google.gwt.http.client.', 'RequestPermissionException', Lcom_google_gwt_http_client_RequestException_2_classLit), Lcom_google_gwt_http_client_RequestTimeoutException_2_classLit = createForClass('com.google.gwt.http.client.', 'RequestTimeoutException', Lcom_google_gwt_http_client_RequestException_2_classLit), Lcom_google_gwt_json_client_JSONValue_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONValue', Ljava_lang_Object_2_classLit), Lcom_google_gwt_json_client_JSONArray_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONArray', Lcom_google_gwt_json_client_JSONValue_2_classLit), Lcom_google_gwt_json_client_JSONBoolean_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONBoolean', Lcom_google_gwt_json_client_JSONValue_2_classLit), Lcom_google_gwt_json_client_JSONException_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONException', Ljava_lang_RuntimeException_2_classLit), Lcom_google_gwt_json_client_JSONNull_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONNull', Lcom_google_gwt_json_client_JSONValue_2_classLit), Lcom_google_gwt_json_client_JSONNumber_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONNumber', Lcom_google_gwt_json_client_JSONValue_2_classLit), Lcom_google_gwt_json_client_JSONObject_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONObject', Lcom_google_gwt_json_client_JSONValue_2_classLit), Ljava_util_AbstractCollection_2_classLit = createForClass('java.util.', 'AbstractCollection', Ljava_lang_Object_2_classLit), Ljava_util_AbstractSet_2_classLit = createForClass('java.util.', 'AbstractSet', Ljava_util_AbstractCollection_2_classLit), Lcom_google_gwt_json_client_JSONString_2_classLit = createForClass('com.google.gwt.json.client.', 'JSONString', Lcom_google_gwt_json_client_JSONValue_2_classLit), Lcom_google_gwt_lang_LongLibBase$LongEmul_2_classLit = createForClass('com.google.gwt.lang.', 'LongLibBase$LongEmul', Ljava_lang_Object_2_classLit), _3Lcom_google_gwt_lang_LongLibBase$LongEmul_2_classLit = createForArray('[Lcom.google.gwt.lang.', 'LongLibBase$LongEmul;', Lcom_google_gwt_lang_LongLibBase$LongEmul_2_classLit), Lcom_google_gwt_storage_client_Storage_2_classLit = createForClass('com.google.gwt.storage.client.', 'Storage', Ljava_lang_Object_2_classLit), Lcom_google_gwt_storage_client_Storage$StorageSupportDetector_2_classLit = createForClass('com.google.gwt.storage.client.', 'Storage$StorageSupportDetector', Ljava_lang_Object_2_classLit), Lcom_google_gwt_user_client_Timer$1_2_classLit = createForClass('com.google.gwt.user.client.', 'Timer$1', Ljava_lang_Object_2_classLit), Lcom_google_gwt_user_client_Window$ClosingEvent_2_classLit = createForClass('com.google.gwt.user.client.', 'Window$ClosingEvent', Lcom_google_gwt_event_shared_GwtEvent_2_classLit), Lcom_google_gwt_user_client_Window$WindowHandlers_2_classLit = createForClass('com.google.gwt.user.client.', 'Window$WindowHandlers', Lcom_google_gwt_event_shared_HandlerManager_2_classLit), Ljava_util_AbstractList_2_classLit = createForClass('java.util.', 'AbstractList', Ljava_util_AbstractCollection_2_classLit), Ljava_util_ArrayList_2_classLit = createForClass('java.util.', 'ArrayList', Ljava_util_AbstractList_2_classLit), C_classLit = createForPrimitive('char'), _3C_classLit = createForArray('', '[C', C_classLit), Lcom_google_web_bindery_event_shared_SimpleEventBus$1_2_classLit = createForClass('com.google.web.bindery.event.shared.', 'SimpleEventBus$1', Ljava_lang_Object_2_classLit), Lcom_google_web_bindery_event_shared_SimpleEventBus$2_2_classLit = createForClass('com.google.web.bindery.event.shared.', 'SimpleEventBus$2', Ljava_lang_Object_2_classLit), _3Ljava_lang_Throwable_2_classLit = createForArray('[Ljava.lang.', 'Throwable;', Ljava_lang_Throwable_2_classLit), Lcom_googlecode_cryptogwt_emul_java_security_GeneralSecurityException_2_classLit = createForClass('com.googlecode.cryptogwt.emul.java.security.', 'GeneralSecurityException', Ljava_lang_Exception_2_classLit), Lcom_googlecode_cryptogwt_emul_java_security_MessageDigest_2_classLit = createForClass('com.googlecode.cryptogwt.emul.java.security.', 'MessageDigest', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_java_security_MessageDigestSpi_2_classLit = createForClass('com.googlecode.cryptogwt.emul.java.security.', 'MessageDigestSpi', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_java_security_NoSuchAlgorithmException_2_classLit = createForClass('com.googlecode.cryptogwt.emul.java.security.', 'NoSuchAlgorithmException', Lcom_googlecode_cryptogwt_emul_java_security_GeneralSecurityException_2_classLit), Lcom_googlecode_cryptogwt_emul_java_security_Provider_2_classLit = createForClass('com.googlecode.cryptogwt.emul.java.security.', 'Provider', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_java_security_Provider$Service_2_classLit = createForClass('com.googlecode.cryptogwt.emul.java.security.', 'Provider$Service', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_java_security_SecureRandomSpi_2_classLit = createForClass('com.googlecode.cryptogwt.emul.java.security.', 'SecureRandomSpi', Ljava_lang_Object_2_classLit), B_classLit = createForPrimitive('byte'), _3B_classLit = createForArray('', '[B', B_classLit), _3Lcom_googlecode_cryptogwt_emul_java_security_Provider_2_classLit = createForArray('[Lcom.googlecode.cryptogwt.emul.java.security.', 'Provider;', Lcom_googlecode_cryptogwt_emul_java_security_Provider_2_classLit), Lcom_googlecode_cryptogwt_emul_javax_crypto_CipherSpi_2_classLit = createForClass('com.googlecode.cryptogwt.emul.javax.crypto.', 'CipherSpi', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_javax_crypto_Mac_2_classLit = createForClass('com.googlecode.cryptogwt.emul.javax.crypto.', 'Mac', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_javax_crypto_MacSpi_2_classLit = createForClass('com.googlecode.cryptogwt.emul.javax.crypto.', 'MacSpi', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_javax_crypto_SecretKeyFactorySpi_2_classLit = createForClass('com.googlecode.cryptogwt.emul.javax.crypto.', 'SecretKeyFactorySpi', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_emul_javax_crypto_spec_SecretKeySpec_2_classLit = createForClass('com.googlecode.cryptogwt.emul.javax.crypto.spec.', 'SecretKeySpec', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_provider_BlockCipher_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'BlockCipher', Lcom_googlecode_cryptogwt_emul_javax_crypto_CipherSpi_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider', Lcom_googlecode_cryptogwt_emul_java_security_Provider_2_classLit), Lcom_googlecode_cryptogwt_provider_SHA256MessageDigest_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'SHA256MessageDigest', Lcom_googlecode_cryptogwt_emul_java_security_MessageDigestSpi_2_classLit), Lcom_googlecode_cryptogwt_provider_MessageDigestSupport_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'MessageDigestSupport', Lcom_googlecode_cryptogwt_emul_java_security_MessageDigestSpi_2_classLit), Lcom_googlecode_cryptogwt_provider_SHA1MessageDigest_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'SHA1MessageDigest', Lcom_googlecode_cryptogwt_provider_MessageDigestSupport_2_classLit), Lcom_googlecode_cryptogwt_provider_FortunaSecureRandom_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'FortunaSecureRandom', Lcom_googlecode_cryptogwt_emul_java_security_SecureRandomSpi_2_classLit), Lcom_googlecode_cryptogwt_provider_Hmac_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'Hmac', Lcom_googlecode_cryptogwt_emul_javax_crypto_MacSpi_2_classLit), Lcom_googlecode_cryptogwt_provider_Hmac$SHA256_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'Hmac$SHA256', Lcom_googlecode_cryptogwt_provider_Hmac_2_classLit), Lcom_googlecode_cryptogwt_provider_Hmac$SHA1_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'Hmac$SHA1', Lcom_googlecode_cryptogwt_provider_Hmac_2_classLit), Lcom_googlecode_cryptogwt_provider_Pbkdf2_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'Pbkdf2', Lcom_googlecode_cryptogwt_emul_javax_crypto_SecretKeyFactorySpi_2_classLit), Lcom_googlecode_cryptogwt_provider_Pbkdf2$HmacSHA1_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'Pbkdf2$HmacSHA1', Lcom_googlecode_cryptogwt_provider_Pbkdf2_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$1_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider$1', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$2_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider$2', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$3_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider$3', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$4_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider$4', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$5_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider$5', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$6_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider$6', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_provider_CryptoGwtProvider$7_2_classLit = createForClass('com.googlecode.cryptogwt.provider.', 'CryptoGwtProvider$7', Ljava_lang_Object_2_classLit), Lcom_googlecode_cryptogwt_util_SpiFactoryService_2_classLit = createForClass('com.googlecode.cryptogwt.util.', 'SpiFactoryService', Lcom_googlecode_cryptogwt_emul_java_security_Provider$Service_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_IncompatibleObjectException_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'IncompatibleObjectException', Lcom_google_gwt_json_client_JSONException_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_SerializationException_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'SerializationException', Ljava_lang_RuntimeException_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer', Lcom_kfuntak_gwt_json_serialization_client_Serializer_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$AmountTransaction_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$AmountTransaction_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Apis_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Apis_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$AuthorizationApi_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$AuthorizationApi_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$AuthorizationUris_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$AuthorizationUris_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$ChargingInformation_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$ChargingInformation_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$CustomerReference_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$CustomerReference_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$GatewayError_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$GatewayError_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$GatewayResponse_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$GatewayResponse_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$GenericError_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$GenericError_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$InvalidRequestError_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$InvalidRequestError_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Item_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Item_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$MessageBody_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$MessageBody_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1AuthorizationProxyToken_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth1AuthorizationProxyToken_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1AuthorizationToken_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth1AuthorizationToken_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1AuthorizationVerifier_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth1AuthorizationVerifier_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1Authorization_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth1Authorization_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth1Token_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth1Token_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AccessToken_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth2AccessToken_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AuthenticationToken_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth2AuthenticationToken_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AuthorizationProxyToken_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth2AuthorizationProxyToken_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2AuthorizationToken_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth2AuthorizationToken_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2Authorization_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth2Authorization_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Oauth2ProtectedAuthorizationToken_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Oauth2ProtectedAuthorizationToken_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Operator_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Operator_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$PaymentAmount_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$PaymentAmount_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$PaymentApi_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$PaymentApi_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Payment_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Payment_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$PrepareAuthenticationIdentifier_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$PrepareAuthenticationIdentifier_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Product_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Product_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$QueryApi_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$QueryApi_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$RequestError_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$RequestError_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$ReservedTransaction_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$ReservedTransaction_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Response_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Response_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$ServiceException_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$ServiceException_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$TransactionArray_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$TransactionArray_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$TransactionList_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$TransactionList_SerializableImpl', Ljava_lang_Object_2_classLit), Lcom_kfuntak_gwt_json_serialization_client_Serializer_1TypeSerializer$Transaction_1SerializableImpl_2_classLit = createForClass('com.kfuntak.gwt.json.serialization.client.', 'Serializer_TypeSerializer$Transaction_SerializableImpl', Ljava_lang_Object_2_classLit), Ljava_lang_ArithmeticException_2_classLit = createForClass('java.lang.', 'ArithmeticException', Ljava_lang_RuntimeException_2_classLit), Ljava_lang_IndexOutOfBoundsException_2_classLit = createForClass('java.lang.', 'IndexOutOfBoundsException', Ljava_lang_RuntimeException_2_classLit), Ljava_lang_ArrayStoreException_2_classLit = createForClass('java.lang.', 'ArrayStoreException', Ljava_lang_RuntimeException_2_classLit), Ljava_lang_Boolean_2_classLit = createForClass('java.lang.', 'Boolean', Ljava_lang_Object_2_classLit), Ljava_lang_Number_2_classLit = createForClass('java.lang.', 'Number', Ljava_lang_Object_2_classLit), Ljava_lang_Class_2_classLit = createForClass('java.lang.', 'Class', Ljava_lang_Object_2_classLit), Ljava_lang_ClassCastException_2_classLit = createForClass('java.lang.', 'ClassCastException', Ljava_lang_RuntimeException_2_classLit), Ljava_lang_Double_2_classLit = createForClass('java.lang.', 'Double', Ljava_lang_Number_2_classLit), Ljava_lang_IllegalArgumentException_2_classLit = createForClass('java.lang.', 'IllegalArgumentException', Ljava_lang_RuntimeException_2_classLit), Ljava_lang_IllegalStateException_2_classLit = createForClass('java.lang.', 'IllegalStateException', Ljava_lang_RuntimeException_2_classLit), Ljava_lang_Integer_2_classLit = createForClass('java.lang.', 'Integer', Ljava_lang_Number_2_classLit), _3Ljava_lang_Integer_2_classLit = createForArray('[Ljava.lang.', 'Integer;', Ljava_lang_Integer_2_classLit), Ljava_lang_Long_2_classLit = createForClass('java.lang.', 'Long', Ljava_lang_Number_2_classLit), _3Ljava_lang_Long_2_classLit = createForArray('[Ljava.lang.', 'Long;', Ljava_lang_Long_2_classLit), Ljava_lang_NullPointerException_2_classLit = createForClass('java.lang.', 'NullPointerException', Ljava_lang_RuntimeException_2_classLit), Ljava_lang_NumberFormatException_2_classLit = createForClass('java.lang.', 'NumberFormatException', Ljava_lang_IllegalArgumentException_2_classLit), Ljava_lang_StringBuffer_2_classLit = createForClass('java.lang.', 'StringBuffer', Ljava_lang_Object_2_classLit), Ljava_lang_StringBuilder_2_classLit = createForClass('java.lang.', 'StringBuilder', Ljava_lang_Object_2_classLit), Ljava_lang_UnsupportedOperationException_2_classLit = createForClass('java.lang.', 'UnsupportedOperationException', Ljava_lang_RuntimeException_2_classLit), Ljava_util_AbstractMap_2_classLit = createForClass('java.util.', 'AbstractMap', Ljava_lang_Object_2_classLit), Ljava_util_AbstractHashMap_2_classLit = createForClass('java.util.', 'AbstractHashMap', Ljava_util_AbstractMap_2_classLit), Ljava_util_AbstractHashMap$EntrySet_2_classLit = createForClass('java.util.', 'AbstractHashMap$EntrySet', Ljava_util_AbstractSet_2_classLit), Ljava_util_AbstractHashMap$EntrySetIterator_2_classLit = createForClass('java.util.', 'AbstractHashMap$EntrySetIterator', Ljava_lang_Object_2_classLit), Ljava_util_AbstractMapEntry_2_classLit = createForClass('java.util.', 'AbstractMapEntry', Ljava_lang_Object_2_classLit), Ljava_util_AbstractHashMap$MapEntryNull_2_classLit = createForClass('java.util.', 'AbstractHashMap$MapEntryNull', Ljava_util_AbstractMapEntry_2_classLit), Ljava_util_AbstractHashMap$MapEntryString_2_classLit = createForClass('java.util.', 'AbstractHashMap$MapEntryString', Ljava_util_AbstractMapEntry_2_classLit), Ljava_util_AbstractList$IteratorImpl_2_classLit = createForClass('java.util.', 'AbstractList$IteratorImpl', Ljava_lang_Object_2_classLit), Ljava_util_AbstractList$ListIteratorImpl_2_classLit = createForClass('java.util.', 'AbstractList$ListIteratorImpl', Ljava_util_AbstractList$IteratorImpl_2_classLit), Ljava_util_AbstractMap$1_2_classLit = createForClass('java.util.', 'AbstractMap$1', Ljava_util_AbstractSet_2_classLit), Ljava_util_AbstractMap$1$1_2_classLit = createForClass('java.util.', 'AbstractMap$1$1', Ljava_lang_Object_2_classLit), Ljava_util_Collections$EmptyList_2_classLit = createForClass('java.util.', 'Collections$EmptyList', Ljava_util_AbstractList_2_classLit), Ljava_util_HashMap_2_classLit = createForClass('java.util.', 'HashMap', Ljava_util_AbstractHashMap_2_classLit), Ljava_util_HashSet_2_classLit = createForClass('java.util.', 'HashSet', Ljava_util_AbstractSet_2_classLit), Ljava_util_LinkedHashMap_2_classLit = createForClass('java.util.', 'LinkedHashMap', Ljava_util_HashMap_2_classLit), Ljava_util_MapEntryImpl_2_classLit = createForClass('java.util.', 'MapEntryImpl', Ljava_util_AbstractMapEntry_2_classLit), Ljava_util_LinkedHashMap$ChainEntry_2_classLit = createForClass('java.util.', 'LinkedHashMap$ChainEntry', Ljava_util_MapEntryImpl_2_classLit), Ljava_util_LinkedHashMap$EntrySet_2_classLit = createForClass('java.util.', 'LinkedHashMap$EntrySet', Ljava_util_AbstractSet_2_classLit), Ljava_util_LinkedHashMap$EntrySet$EntryIterator_2_classLit = createForClass('java.util.', 'LinkedHashMap$EntrySet$EntryIterator', Ljava_lang_Object_2_classLit), Ljava_util_LinkedHashSet_2_classLit = createForClass('java.util.', 'LinkedHashSet', Ljava_util_HashSet_2_classLit), Ljava_util_NoSuchElementException_2_classLit = createForClass('java.util.', 'NoSuchElementException', Ljava_lang_RuntimeException_2_classLit), Ljava_util_TreeMap_2_classLit = createForClass('java.util.', 'TreeMap', Ljava_util_AbstractMap_2_classLit), Ljava_util_TreeMap$EntryIterator_2_classLit = createForClass('java.util.', 'TreeMap$EntryIterator', Ljava_lang_Object_2_classLit), Ljava_util_TreeMap$EntrySet_2_classLit = createForClass('java.util.', 'TreeMap$EntrySet', Ljava_util_AbstractSet_2_classLit), Ljava_util_TreeMap$Node_2_classLit = createForClass('java.util.', 'TreeMap$Node', Ljava_lang_Object_2_classLit), _3Ljava_util_TreeMap$Node_2_classLit = createForArray('[Ljava.util.', 'TreeMap$Node;', Ljava_util_TreeMap$Node_2_classLit), Ljava_util_TreeMap$State_2_classLit = createForClass('java.util.', 'TreeMap$State', Ljava_lang_Object_2_classLit), Ljava_util_TreeMap$SubMapType_2_classLit = createForEnum('java.util.', 'TreeMap$SubMapType', Ljava_lang_Enum_2_classLit, values), _3Ljava_util_TreeMap$SubMapType_2_classLit = createForArray('[Ljava.util.', 'TreeMap$SubMapType;', Ljava_util_TreeMap$SubMapType_2_classLit), Ljava_util_TreeMap$SubMapType$1_2_classLit = createForEnum('java.util.', 'TreeMap$SubMapType$1', Ljava_util_TreeMap$SubMapType_2_classLit, null), Ljava_util_TreeMap$SubMapType$2_2_classLit = createForEnum('java.util.', 'TreeMap$SubMapType$2', Ljava_util_TreeMap$SubMapType_2_classLit, null), Ljava_util_TreeMap$SubMapType$3_2_classLit = createForEnum('java.util.', 'TreeMap$SubMapType$3', Ljava_util_TreeMap$SubMapType_2_classLit, null), Lnet_wacapps_napi_api_NameValuePair_2_classLit = createForClass('net.wacapps.napi.api.', 'NameValuePair', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_api_NapiException_2_classLit = createForClass('net.wacapps.napi.api.', 'NapiException', Ljava_lang_Exception_2_classLit), Lnet_wacapps_napi_api_WacEndpoints_2_classLit = createForClass('net.wacapps.napi.api.', 'WacEndpoints', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_api_WacEndpointsExporterImpl_2_classLit = createForClass('net.wacapps.napi.api.', 'WacEndpointsExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_api_WacNapiContext_2_classLit = createForClass('net.wacapps.napi.api.', 'WacNapiContext', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_api_WacNapiContextExporterImpl_2_classLit = createForClass('net.wacapps.napi.api.', 'WacNapiContextExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_api_WacRestApi_2_classLit = createForClass('net.wacapps.napi.api.', 'WacRestApi', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_api_WacRestApiExporterImpl_2_classLit = createForClass('net.wacapps.napi.api.', 'WacRestApiExporterImpl', Ljava_lang_Object_2_classLit), Lcom_google_gwt_http_client_RequestCallback_2_classLit = createForInterface('com.google.gwt.http.client.', 'RequestCallback'), Lnet_wacapps_napi_resource_jaxb_Operator_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Operator', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_AmountTransaction_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'AmountTransaction', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_AmountTransactionExporterImpl_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'AmountTransactionExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Apis_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Apis', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_AuthorizationApi_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'AuthorizationApi', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_AuthorizationUris_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'AuthorizationUris', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_ChargingInformation_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'ChargingInformation', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_ChargingInformationExporterImpl_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'ChargingInformationExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_CustomerReference_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'CustomerReference', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_GatewayError_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'GatewayError', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_GatewayResponse_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'GatewayResponse', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_GenericError_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'GenericError', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_InvalidRequestError_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'InvalidRequestError', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Item_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Item', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_ItemExporterImpl_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'ItemExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_MessageBody_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'MessageBody', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth1Authorization_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth1Authorization', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth1AuthorizationProxyToken_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth1AuthorizationProxyToken', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth1AuthorizationToken_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth1AuthorizationToken', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth1AuthorizationVerifier_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth1AuthorizationVerifier', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth1Token_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth1Token', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth2AccessToken_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth2AccessToken', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth2AuthenticationToken_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth2AuthenticationToken', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth2Authorization_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth2Authorization', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth2AuthorizationProxyToken_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth2AuthorizationProxyToken', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth2AuthorizationToken_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth2AuthorizationToken', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Oauth2ProtectedAuthorizationToken_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Oauth2ProtectedAuthorizationToken', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Payment_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Payment', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_PaymentAmount_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'PaymentAmount', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_PaymentAmountExporterImpl_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'PaymentAmountExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_PaymentApi_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'PaymentApi', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_PrepareAuthenticationIdentifier_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'PrepareAuthenticationIdentifier', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Product_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Product', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_QueryApi_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'QueryApi', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_RequestError_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'RequestError', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_ReservedTransaction_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'ReservedTransaction', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Response_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Response', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_ServiceException_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'ServiceException', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_Transaction_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'Transaction', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_TransactionArray_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'TransactionArray', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_resource_jaxb_TransactionList_2_classLit = createForClass('net.wacapps.napi.resource.jaxb.', 'TransactionList', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_CaptureClosureExporterImpl_2_classLit = createForClass('net.wacapps.napi.util.', 'CaptureClosureExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_CaptureClosure_2_classLit = createForInterface('net.wacapps.napi.util.', 'CaptureClosure'), Lnet_wacapps_napi_util_DoQueryClosureExporterImpl_2_classLit = createForClass('net.wacapps.napi.util.', 'DoQueryClosureExporterImpl', Ljava_lang_Object_2_classLit), _3Lnet_wacapps_napi_resource_jaxb_Item_2_classLit = createForArray('[Lnet.wacapps.napi.resource.jaxb.', 'Item;', Lnet_wacapps_napi_resource_jaxb_Item_2_classLit), Lnet_wacapps_napi_util_DoQueryClosure_2_classLit = createForInterface('net.wacapps.napi.util.', 'DoQueryClosure'), _3_3Ljava_lang_String_2_classLit = createForArray('[[Ljava.lang.', 'String;', _3Ljava_lang_String_2_classLit), Lnet_wacapps_napi_util_NAPIJSProxy_2_classLit = createForClass('net.wacapps.napi.util.', 'NAPIJSProxy', Ljava_lang_Object_2_classLit), _3Lnet_wacapps_napi_resource_jaxb_PaymentAmount_2_classLit = createForArray('[Lnet.wacapps.napi.resource.jaxb.', 'PaymentAmount;', Lnet_wacapps_napi_resource_jaxb_PaymentAmount_2_classLit), Lnet_wacapps_napi_util_NAPIJSProxy$1_2_classLit = createForClass('net.wacapps.napi.util.', 'NAPIJSProxy$1', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_NAPIJSProxy$3_2_classLit = createForClass('net.wacapps.napi.util.', 'NAPIJSProxy$3', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_NAPIJSProxy$4_2_classLit = createForClass('net.wacapps.napi.util.', 'NAPIJSProxy$4', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_NAPIJSProxyExporterImpl_2_classLit = createForClass('net.wacapps.napi.util.', 'NAPIJSProxyExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_PaymentClosureExporterImpl_2_classLit = createForClass('net.wacapps.napi.util.', 'PaymentClosureExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_PaymentClosure_2_classLit = createForInterface('net.wacapps.napi.util.', 'PaymentClosure'), Lnet_wacapps_napi_util_UUID_2_classLit = createForClass('net.wacapps.napi.util.', 'UUID', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_UUIDExporterImpl_2_classLit = createForClass('net.wacapps.napi.util.', 'UUIDExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_crypto_Hmac_2_classLit = createForClass('net.wacapps.napi.util.crypto.', 'Hmac', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_crypto_Hmac$SHA1_2_classLit = createForClass('net.wacapps.napi.util.crypto.', 'Hmac$SHA1', Lnet_wacapps_napi_util_crypto_Hmac_2_classLit), Lnet_wacapps_napi_util_crypto_SHA256MessageDigest_2_classLit = createForClass('net.wacapps.napi.util.crypto.', 'SHA256MessageDigest', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_crypto_SecretKeySpec_2_classLit = createForClass('net.wacapps.napi.util.crypto.', 'SecretKeySpec', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_util_crypto_Sha256_2_classLit = createForClass('net.wacapps.napi.util.crypto.', 'Sha256', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_xdo_applications_Application_2_classLit = createForClass('net.wacapps.napi.xdo.applications.', 'Application', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_xdo_applications_ApplicationExporterImpl_2_classLit = createForClass('net.wacapps.napi.xdo.applications.', 'ApplicationExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_xdo_applications_Credential_2_classLit = createForClass('net.wacapps.napi.xdo.applications.', 'Credential', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_xdo_applications_CredentialExporterImpl_2_classLit = createForClass('net.wacapps.napi.xdo.applications.', 'CredentialExporterImpl', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_xdo_developer_Developer_2_classLit = createForClass('net.wacapps.napi.xdo.developer.', 'Developer', Ljava_lang_Object_2_classLit), Lnet_wacapps_napi_xdo_developer_DeveloperExporterImpl_2_classLit = createForClass('net.wacapps.napi.xdo.developer.', 'DeveloperExporterImpl', Ljava_lang_Object_2_classLit), Lorg_timepedia_exporter_client_ExportAllExporterImpl_2_classLit = createForClass('org.timepedia.exporter.client.', 'ExportAllExporterImpl', Ljava_lang_Object_2_classLit), Lorg_timepedia_exporter_client_ExporterBaseImpl_2_classLit = createForClass('org.timepedia.exporter.client.', 'ExporterBaseImpl', Ljava_lang_Object_2_classLit), Lorg_timepedia_exporter_client_ExporterBaseActual_2_classLit = createForClass('org.timepedia.exporter.client.', 'ExporterBaseActual', Lorg_timepedia_exporter_client_ExporterBaseImpl_2_classLit), Lorg_timepedia_exporter_client_Exportable_2_classLit = createForInterface('org.timepedia.exporter.client.', 'Exportable');
$stats && $stats({moduleName:'net.wacapps.napi.JSNAPILibrary',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalEnd'});
if (net_wacapps_napi_JSNAPILibrary && net_wacapps_napi_JSNAPILibrary.onScriptLoad)net_wacapps_napi_JSNAPILibrary.onScriptLoad(gwtOnLoad);
})();
