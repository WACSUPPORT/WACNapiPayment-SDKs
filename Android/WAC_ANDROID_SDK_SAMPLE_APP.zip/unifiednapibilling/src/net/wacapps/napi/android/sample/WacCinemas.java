/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.android.sample;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.UUID;

import net.wacapps.napi.android.AndroidWacPaymentService;
import net.wacapps.napi.android.WacNapiContext;
import net.wacapps.napi.android.WacNapiPayment;
import net.wacapps.napi.api.NapiException;
import net.wacapps.napi.api.WacEndpoints;
import net.wacapps.napi.resource.jaxb.AmountTransaction;
import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.ReservedTransaction;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionList;
import net.wacapps.napi.util.crypto.DeviceTransactionStorage;
import net.wacapps.napi.util.crypto.SecureDeviceTransactionDatabase;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * WAC Cinemas is a sample application that demonstrates in-application billing/payment with
 * WAC NAPI SDK.
 * 
 * Funtionality:
 * WAC Cinemas has a simple UI that allows users to choose from a list of shows and then 
 * make a purchase using the WAC Payment option
 * 
 * Initialization:
 * - Load the wac.properties files that contains the developer registration information 
 * - Create an AndroidWacPaymentService object when the Activity's onCreate() is invoked
 * - Initialize the object with the information from wac.properties (InitializeWACTask())
 * - Set this AndroidWacPaymentService object in the WacNapiContext
 * 
 * Making a Payment using WAC:
 * - There are two options. 1) Reserve & Capture 2) Express Pay
 * - Reserve & Capture
 * 		- First reserve the payment - call reservePayment() on AndroidWacPaymentService - (See onClick(View))
 * 		- Once the purchase is done, get the reserved payment transaction and use
 * 		it to capture the payment (See onActivityResult(int, int, Intent))
 * 
 * 	- Express Pay (with Callback on delivery/fulfillment of purchase) 
 *  	- Invoke chargePayment() on AndroidWacPaymentService - (See onClick(View))
 * 		
 * Tracking Transactions:
 * User transactions are securely stored locally and can be retrieved using the following mechanism
 * - Initialize the secure data store, DeviceTransactionStorage (See - getTransactionStorage())
 * - Read transaction information from the secure data store and load into local variables - (See setupWidgets()) 
 * 
 * List Transactions:
 * - Load local variables with transaction details from secure data store and display (See setupWidgets())
 * 
 * Check Transactions:
 * - Invoke checkTransaction() on the AndroidWacPaymentService - (See setupWidgets()) 
 * 
 */
public class WacCinemas extends Activity implements OnClickListener,
		OnItemSelectedListener {

	private static final String WAC_APPID_KEY = "wac.appid";

	/** The Constant TAG. */
	private static final String TAG = "WACSAMPLE";

	/** Debug mode on */
	private static final boolean DEBUG = true;

	/** The m handler. */
	private Handler mHandler;
	
	/** The m buy button. */
	private Button mBuyButton;

	/** The m tx list button. */
	private Button mTxListButton;

	/** The m select item spinner. */
	private Spinner mSelectItemSpinner;

	/** The m owned items table. */
	private ListView mOwnedItemsTable;

	/** The m owned items. */
	private ArrayList<HashMap<String, String>> mOwnedItems = new ArrayList<HashMap<String, String>>();

	/** The m owned items tracker. */
	private ArrayList<Transaction> mOwnedItemsTracker = new ArrayList<Transaction>();

	/** List adaptor for owned items */
	private ListViewAdapter mOwnedItemsAdaptor;

	/** First Column in owned items list */
	private static final String FIRST_COLUMN = "Sku";

	/** Second column in owned items list */
	private static final String SECOND_COLUMN = "Amount";

	/** The Constant DIALOG_CANNOT_CONNECT_ID. */
	private static final int DIALOG_CANNOT_CONNECT_ID = 1;

	/** The Constant DIALOG_BILLING_NOT_SUPPORTED_ID. */
	private static final int DIALOG_BILLING_NOT_SUPPORTED_ID = 2;

	/** The Constant DIALOG_TRANSACTIONS_LIST_SUCCESS. */
	private static final int DIALOG_TRANSACTIONS_LIST_SUCCESS = 3;

	/** The Constant DIALOG_TRANSACTIONS_LIST_FAIL. */
	private static final int DIALOG_TRANSACTIONS_LIST_FAIL = 4;

	/** The Constant DIALOG_CHARGE_PAYMENT_FAIL. */
	private static final int DIALOG_CHARGE_PAYMENT_FAIL = 6;
	
	/** The Constant DIALOG_TRANSACTIONS_CHECK_SUCCESS. */
	private static final int DIALOG_TRANSACTIONS_CHECK_SUCCESS = 7;
	
	/** The pd. */
	private ProgressDialog pd = null;

	/** The mService. */
	private AndroidWacPaymentService mService = null;

	/** Wac specific properties and creds */
	private Properties mProps = null;
	
	/**
	 * The Class CatalogEntry.
	 */
	private static class CatalogEntry {

		/** The item id. */
		public String itemId;

		/** The name. */
		public String name;

		/**
		 * Instantiates a new catalog entry.
		 * 
		 * @param itemId
		 *            the item id
		 * @param nameId
		 *            the name id
		 * @param item
		 *            the item
		 */
		public CatalogEntry(String itemId, String nameId, Item item) {
			this.itemId = itemId;
			this.name = nameId;
		}
	}

	/**
	 * The Class ListViewAdapter.
	 */
	private static class ListViewAdapter extends BaseAdapter {
		public ArrayList<HashMap<String, String>> list;
		Activity activity;

		public ListViewAdapter(Activity activity,
				ArrayList<HashMap<String, String>> list) {
			super();
			this.activity = activity;
			this.list = list;
		}

		@Override
		public int getCount() {
			return list.size();
		}

		@Override
		public Object getItem(int position) {
			return list.get(position);
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		private class ViewHolder {
			TextView txtFirst;
			TextView txtSecond;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			LayoutInflater inflater = activity.getLayoutInflater();

			if (convertView == null) {
				convertView = inflater.inflate(R.layout.listview_row, null);
				holder = new ViewHolder();
				holder.txtFirst = (TextView) convertView
						.findViewById(R.id.FirstColumn);
				holder.txtSecond = (TextView) convertView
						.findViewById(R.id.SecondColumn);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			HashMap<String, String> map = list.get(position);
			holder.txtFirst.setText(map.get(FIRST_COLUMN));
			holder.txtSecond.setText(map.get(SECOND_COLUMN));

			return convertView;
		}
	}

	/**
	 * An array list of product list entries for the products that can be
	 * purchased.
	 */
	private static final ArrayList<CatalogEntry> catalog = new ArrayList<CatalogEntry>();

	/** The m item name. */
	private String mItemName;

	/** The m sku. */
	private String mSku;

	/** The m catalog adapter. */
	private CatalogAdapter mCatalogAdapter;

	/**
	 * Called when the activity is first created.
	 * 
	 * @param savedInstanceState
	 *            the saved instance state
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		mHandler = new Handler();

		// Read from the assets directory
		if (mProps == null) {
			try {
				InputStream inputStream = this.getResources().getAssets()
						.open("wac.properties");
				mProps = new Properties();
				mProps.load(inputStream);
				if (DEBUG)
					Log.d(TAG, "The properties are now loaded: " + mProps);
			} catch (IOException e) {
				System.err.println("Failed to open wac property file");
				e.printStackTrace();
			}
		}
		
		// Initialize WAC NAPI API
		if (WacNapiContext.getInstance().getPaymentService() == null) {
			WacNapiContext.getInstance().setEndPoints(
					new WacEndpoints(WacEndpoints.PRODUCTION));
			AndroidWacPaymentService.setDebug(DEBUG);
			
			// In order to test the application in a different geography, it is necessary for the NAPI invocation to originate from an IP in that geography.
			// IP spoofing is used to simulate this case as shown below.
			// Use following command line to spoof IP address:
			// ./adb shell am start -a android.intent.action.VIEW -c android.intent.category.DEFAULT -e debug.ip <ip_address> -e app.id <app_id> -n net.wacapps.napi.android.sample/.WacCinemas
			// Alternately, use the following statement to spoof IP address 
			WacNapiContext.getInstance().getEndPoints().setSpoofedDiscoverySourceIPForStaging(this.getIntent().getExtras(), (String)mProps.get(WAC_APPID_KEY));
			
			mService = new AndroidWacPaymentService();
			WacNapiContext.getInstance().setPaymentService(mService); 
			// Load available product items
			this.pd = ProgressDialog.show(this, "Working..",
					"Loading available Items...", true, false);
			//Initializing the AndroidWacPaymentService
			new InitializeWACTask().execute();
		} else {
			mService = WacNapiContext.getInstance().getPaymentService();
			//Create and initialize the application UI
			setupWidgets();
		}
	}

	/**
	 * Called when this activity becomes visible.
	 */
	@Override
	protected void onStart() {
		super.onStart();
	}

	/**
	 * Called when this activity is no longer visible.
	 */
	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	/**
	 * Save the context of the log so simple things like rotation will not
	 * result in the log being cleared.
	 * 
	 * @param outState
	 *            the out state
	 */
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}

	/**
	 * Restore the contents of the log if it has previously been saved.
	 * 
	 * @param savedInstanceState
	 *            the saved instance state
	 */
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	protected void onPrepareDialog(int id, Dialog dialog, Bundle b) {
		switch (id) {
		case DIALOG_TRANSACTIONS_LIST_SUCCESS:
			int size = 0;
			if (b != null)
				size = b.getInt("tSize");
			AlertDialog aDialog = (AlertDialog) dialog;
			aDialog.setMessage(String.format(
					getResources()
							.getString(R.string.list_txns_success_message),
					size));
			break;
		default:
			super.onPrepareDialog(id, dialog);
			break;
		}
	}
	
	/*
	 * Called when the dialog is created
	 * 
	 * @see android.app.Activity#onCreateDialog(int)
	 */
	@Override
	protected Dialog onCreateDialog(int id, Bundle b) {
		switch (id) {
		case DIALOG_CANNOT_CONNECT_ID:
			return createDialog(R.string.cannot_connect_title,
					R.string.cannot_connect_message);
		case DIALOG_BILLING_NOT_SUPPORTED_ID:
			return createDialog(R.string.billing_not_supported_title,
					R.string.billing_not_supported_message);
		case DIALOG_TRANSACTIONS_CHECK_SUCCESS:
			return createSuccessDialog(R.string.list_txns_success,
					R.string.check_txns_success);
		case DIALOG_TRANSACTIONS_LIST_SUCCESS:
			int size = 0;
			if (b != null)
				size = b.getInt("tSize");
			return createSuccessDialog(R.string.list_txns_success,
					R.string.list_txns_success_message, size);
		case DIALOG_TRANSACTIONS_LIST_FAIL:
		case DIALOG_CHARGE_PAYMENT_FAIL:
			String failMessage = "";
			if (b != null)
				failMessage = b.getString("failMessage");
			String helpUrl = replaceLanguageAndRegion(getString(R.string.help_url_wac));
			if (DEBUG) {
				Log.i(TAG, helpUrl);
			}
			final Uri helpUri = Uri.parse(helpUrl);
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Info")
					.setIcon(android.R.drawable.stat_sys_warning)
					.setMessage(failMessage)
					.setCancelable(false)
					.setPositiveButton(android.R.string.ok, null)
					.setNegativeButton(R.string.learn_more,
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									Intent intent = new Intent(
											Intent.ACTION_VIEW, helpUri);
									startActivity(intent);
								}
							});
			return builder.create();

		default:
			return null;
		}
	}

	private Dialog createSuccessDialog(int titleId, int messageId,
			Object... fillers) {
		String helpUrl = replaceLanguageAndRegion(getString(R.string.help_url_wac));
		if (DEBUG) {
			Log.i(TAG, helpUrl);
		}
		final Uri helpUri = Uri.parse(helpUrl);
		final Resources res = getResources();
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(titleId)
				.setIcon(android.R.drawable.stat_sys_download_done)
				.setMessage(String.format(res.getString(messageId), fillers))
				.setCancelable(false)
				.setPositiveButton(android.R.string.ok, null)
				.setNegativeButton(R.string.learn_more,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent(Intent.ACTION_VIEW,
										helpUri);
								startActivity(intent);
							}
						});
		return builder.create();
	}

	/**
	 * Creates the dialog.
	 * 
	 * @param titleId
	 *            the title id
	 * @param messageId
	 *            the message id
	 * @return the dialog
	 */
	private Dialog createDialog(int titleId, int messageId) {
		String helpUrl = replaceLanguageAndRegion(getString(R.string.help_url_wac));
		if (DEBUG) {
			Log.i(TAG, helpUrl);
		}
		final Uri helpUri = Uri.parse(helpUrl);

		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle(titleId)
				.setIcon(android.R.drawable.stat_sys_warning)
				.setMessage(messageId)
				.setCancelable(false)
				.setPositiveButton(android.R.string.ok, null)
				.setNegativeButton(R.string.learn_more,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent(Intent.ACTION_VIEW,
										helpUri);
								startActivity(intent);
							}
						});
		return builder.create();
	}

	/**
	 * Replaces the language and/or country of the device into the given string.
	 * The pattern "%lang%" will be replaced by the device's language code and
	 * the pattern "%region%" will be replaced with the device's country code.
	 * 
	 * @param str
	 *            the string to replace the language/country within
	 * @return a string containing the local language and region codes
	 */
	private String replaceLanguageAndRegion(String str) {
		// Substitute language and or region if present in string
		if (str.contains("%lang%") || str.contains("%region%")) {
			Locale locale = Locale.getDefault();
			str = str.replace("%lang%", locale.getLanguage().toLowerCase());
			str = str.replace("%region%", locale.getCountry().toLowerCase());
		}
		return str;
	}

	/**
	 * Called when an activity called by using startActivityForResult finishes.
	 * 
	 * @param requestCode
	 *            the request code
	 * @param resultCode
	 *            the result code
	 * @param data
	 *            the data
	 */
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.d(TAG, "onActivityResult called");
		final Bundle b = new Bundle();
		switch (resultCode) {
		case WacNapiPayment.RESULT_RESERVE_PAYMENT_OK:
			Log.d(TAG, "onActivityResult called + RESULT_RESERVE_PAYMENT_OK");
			ReservedTransaction reserve = mService.processReservePaymentResults(data);
			Log.d(TAG, "got reserve with token " + reserve.getAccessToken());
			
			//Add code here to fulfil the purchase
			
			try {
				mService.capturePayment(this, reserve);  //callback will come in RESULT_PAYMENT_OK
			} catch (NapiException e1) {
				e1.printStackTrace();
				b.putString("failMessage",
						"Capture payment failed!");
				mHandler.post(new Runnable() {
					public void run() {
						showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
					}
				});
			}
			Log.d(TAG, "Capture payment request sent");
			break;
		case WacNapiPayment.RESULT_CHECK_TRANSACTION_OK:
			Log.d(TAG, "onActivityResult called + RESULT_CHECK_TRANSACTION_OK");
			try {
				final Transaction checkTransaction = mService
						.processTransactionCheckResults(data);
				if(checkTransaction != null && checkTransaction.getAmountTransaction().getServerReferenceCode() != null) {
					if(DEBUG)
						Log.d(TAG, "Check Transaction Success!!! " + 
								checkTransaction.getAmountTransaction().getServerReferenceCode());
					showDialog(DIALOG_TRANSACTIONS_CHECK_SUCCESS);
				} else {
					b.putString("failMessage",
							"Invalid transaction!");
					mHandler.post(new Runnable() {
						public void run() {
							showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
						}
					});
				}
			} catch (Exception e) {
				e.printStackTrace();
				b.putString("failMessage",
						"Invaid transaction!");
				mHandler.post(new Runnable() {
					public void run() {
						showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
					}
				});
			}
			break;
		case WacNapiPayment.RESULT_PAYMENT_OK:
			Log.d(TAG, "onActivityResult called + RESULT_PAYMENT_OK");
			final Transaction transaction = mService
					.processChargePaymentTransactionResults(data);
			this.runOnUiThread(new Runnable() {
				public void run() {
					HashMap<String, String> temp = new HashMap<String, String>();
					temp.put(FIRST_COLUMN, transaction.getAmountTransaction().getPaymentAmount().getChargingInformation().getDescription());
					temp.put(SECOND_COLUMN, transaction.getAmountTransaction()
							.getPaymentAmount().getChargingInformation()
							.getAmount().toString());
					mOwnedItems.add(temp);
					mOwnedItemsAdaptor.notifyDataSetChanged();
					mOwnedItemsTracker.add(transaction);
				}
			});
			break;
		case WacNapiPayment.RESULT_TRANSACTION_LIST_OK:
			TransactionList list = mService.processTransactionListResults(data);
			int tSize = list.getPaymentTransactionList().getAmountTransaction()
					.size();
			Log.d(TAG, "TxList size " + tSize);
			b.putInt("tSize", tSize);
			mHandler.post(new Runnable() {
				public void run() {
					showDialog(DIALOG_TRANSACTIONS_LIST_SUCCESS, b);
				}
			});
			break;
		case WacNapiPayment.RESULT_OPERATOR_BAD:
			Log.d(TAG, "onActivityResult called + RESULT_OPERATOR_BAD");
			processError(data);
			break;
		case WacNapiPayment.RESULT_PAYMENT_BAD:
			Log.d(TAG, "onActivityResult called + RESULT_PAYMENT_BAD");
			processError(data);
			break;
		case WacNapiPayment.RESULT_TRANSACTION_LIST_BAD:
			Log.d(TAG, "onActivityResult called + RESULT_TRANSACTION_LIST_BAD");
			processError(data);
			break;
		default:
			break;
		}
	}
	
	/**
	 * Utility method for displaying errors
	 */
	private void processError(Intent data) {
		final Bundle b = new Bundle();
		if (data != null
				&& data.hasExtra("wacapps.net.payment.result.fail.message")) {
			String errorMessage = data
					.getStringExtra("wacapps.net.payment.result.fail.message");
			if (DEBUG)
				Log.d(TAG, "Error Message : " + errorMessage);
			b.putString("failMessage", errorMessage);
		} else {
			b.putString("failMessage",
					"Unable to communicate with WAC servers, please try again later.");
		}
		mHandler.post(new Runnable() {
			public void run() {
				showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
			}
		});

	}

	/**
	 * Sets up the UI.
	 */
	private void setupWidgets() {

		mBuyButton = (Button) findViewById(R.id.buy_button);
		mBuyButton.setOnClickListener(this);

		mTxListButton = (Button) findViewById(R.id.tx_list_button);
		mTxListButton.setOnClickListener(this);

		mSelectItemSpinner = (Spinner) findViewById(R.id.item_choices);
		mCatalogAdapter = new CatalogAdapter(this, catalog);
		mSelectItemSpinner.setAdapter(mCatalogAdapter);
		mSelectItemSpinner.setOnItemSelectedListener(this);

		mOwnedItemsTable = (ListView) findViewById(R.id.owned_items);
		mOwnedItemsAdaptor = new ListViewAdapter(this, mOwnedItems);
		mOwnedItemsTable.setAdapter(mOwnedItemsAdaptor);
		final Activity ctx = this;
		mOwnedItemsTable.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> a, View v, int position,
					long id) {
				AlertDialog.Builder adb = new AlertDialog.Builder(ctx);
				adb.setTitle("Transaction Check?");
				final Transaction t = mOwnedItemsTracker.get(position);
				adb.setMessage("Validate transaction with ref code " + t.getAmountTransaction().getServerReferenceCode() + " ?");
				adb.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						Log.d(TAG, "Running check transactions!");
						mService.checkTransaction(ctx, t.getAmountTransaction().getServerReferenceCode());
					}
				});
				adb.setNegativeButton("Cancel", null);
				adb.show();
			}
		});
		
		DeviceTransactionStorage pdb = null;
		try {
			pdb = getTransactionStorage();
			//Fetch the transaction list from local storage.
			TransactionList list = pdb.getTransactionList();
			pdb.close();
			for (AmountTransaction transaction : list
					.getPaymentTransactionList().getAmountTransaction()) {
				HashMap<String, String> temp = new HashMap<String, String>();
				temp.put(FIRST_COLUMN, transaction.getPaymentAmount().getChargingInformation().getDescription());
				String amount = transaction.getPaymentAmount().getChargingInformation().getAmount().toString();
				temp.put(SECOND_COLUMN, amount);
				mOwnedItems.add(temp);
				mOwnedItemsAdaptor.notifyDataSetChanged();
				Transaction tx = new Transaction();
				tx.setAmountTransaction(transaction);
				mOwnedItemsTracker.add(tx);
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			pdb.close();
		}
	}

	/**
	 * Called when a button is pressed.
	 * 
	 * @param v
	 *            the view that was clicked
	 */
	public void onClick(View v) {
		if (v == mBuyButton) {
			if (DEBUG) {
				Log.d(TAG, "buying: " + mItemName + " sku: " + mSku);
			}
			
			String refCode = UUID.randomUUID().toString().substring(0, 32);
			
			//use reserve and capture
			WacNapiContext.getInstance().getPaymentService().reservePayment(this, mProps.getProperty(WAC_APPID_KEY), mSku, refCode);			
		} else if (v == mTxListButton) {
			if (DEBUG) {
				Log.d(TAG, "Getting Tx List");
			}
			WacNapiContext.getInstance()
					.getPaymentService().getTransactionList(this);
		}
	}

	/**
	 * Called when an item in the spinner is selected.
	 * 
	 * @param parent
	 *            the parent
	 * @param view
	 *            the view
	 * @param position
	 *            the position
	 * @param id
	 *            the id
	 */
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		mItemName = catalog.get(position).name;
		mSku = catalog.get(position).itemId;
	}

	public void onNothingSelected(AdapterView<?> arg0) {
	}

	/**
	 * An adapter used for displaying a catalog of products.
	 */
	private static class CatalogAdapter extends ArrayAdapter<String> {

		/**
		 * Instantiates a new catalog adapter.
		 * 
		 * @param context
		 *            the context
		 * @param catalog
		 *            the catalog
		 */
		public CatalogAdapter(Context context, ArrayList<CatalogEntry> catalog) {
			super(context, android.R.layout.simple_spinner_item);
			for (CatalogEntry element : catalog) {
				add(element.name);
			}
			setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		}

		@Override
		public boolean areAllItemsEnabled() {
			return true;
		}

		@Override
		public boolean isEnabled(int position) {
			return true;
		}

		@Override
		public View getDropDownView(int position, View convertView,
				ViewGroup parent) {
			View view = super.getDropDownView(position, convertView, parent);
			view.setEnabled(isEnabled(position));
			return view;
		}
	}

	/**
	 * The Class InitializeWACTask is an AsyncTask to perform  background operations for initializing the android WAC payment service.
	 */
	private class InitializeWACTask extends AsyncTask<String, Void, Object> {

		protected Object doInBackground(String... args) {
			Log.d(TAG, "Background thread for initialize starting");
			try {
				mService.initialize(mProps.getProperty(WAC_APPID_KEY),
						mProps.getProperty("wac.credential"),
						mProps.getProperty("wac.secret"),
						mProps.getProperty("wac.devname"),
						mProps.getProperty("wac.redirectUriOAuth"));
			} catch (Exception e) {
				e.printStackTrace();
				final Bundle b = new Bundle();
				b.putString("failMessage",
						e.getMessage());
				mHandler.post(new Runnable() {
					public void run() {
						showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
					}
				});
				return null;
			}
			return mService;
		}

		protected void onPostExecute(Object result) {
			// dismiss progress dialogs
			if (WacCinemas.this.pd != null) {
				WacCinemas.this.pd.dismiss();
			}
			// quick sanity check
			if (result != null) {
				// add items to list adapter
				List<Item> items = mService.listProductItems();
				for (Item item : items) {
					catalog.add(new CatalogEntry(item.getItemId(), item
							.getDescription(), item));
				}
				// create UI components in the UI thread
				mHandler.post(new Runnable() {
					public void run() {
						setupWidgets();
					}
				});
			} else {
				Log.d(TAG, "Service setup failure!!!");
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection
		switch (item.getItemId()) {
		case R.id.exit:
			this.finish();
			return true;
		case R.id.check:
			Log.d(TAG, "Running a debug step!");
			//stuff you need to debug
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	/**
	 * Gets transaction database handle
	 */
	private DeviceTransactionStorage getTransactionStorage(){
		return new SecureDeviceTransactionDatabase(getApplicationContext(), mProps.getProperty(WAC_APPID_KEY));
	}

}
