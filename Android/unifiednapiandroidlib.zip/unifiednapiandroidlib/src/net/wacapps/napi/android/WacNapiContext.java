/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android;

import net.wacapps.napi.api.ContentDeliveryCallback;
import net.wacapps.napi.api.WacEndpoints;

/**
 * Singleton class for holding on to AndroidWacPaymentService instance.
 */
public class WacNapiContext {
	
	/**
	 * private constructor
	 */
	private WacNapiContext() {
		
	}
	
	/** The instance. */
	private static WacNapiContext instance = null;

	/** NAPI Endpoints for this context. */
	private WacEndpoints endPoints = null;
	
	/** NAPI payment service instance. */
	private AndroidWacPaymentService service = null;
	
	/** The content delivery confirmation call back. */
	private ContentDeliveryCallback callback = null;
	
	/**
	 * Gets the single instance of WacNapiContext.
	 *
	 * @return single instance of WacNapiContext
	 */
	public static synchronized WacNapiContext getInstance() {
		if(instance == null) {
			instance = new WacNapiContext();
		}
		return instance;
	}

	/**
	 * Sets the payment service.
	 *
	 * @param service the new payment service
	 */
	public void setPaymentService(AndroidWacPaymentService service) {
		this.service = service;
	}
	
	/**
	 * Gets the payment service.
	 *
	 * @return the payment service
	 */
	public AndroidWacPaymentService getPaymentService() {
		return service;
	}

	/**
	 * Gets the end points.
	 * 
	 * @return the end points
	 */
	public WacEndpoints getEndPoints() {
		return endPoints;
	}

	/**
	 * Sets the end points.
	 * 
	 * @param endPoints
	 *            the new end points
	 */
	public void setEndPoints(WacEndpoints endPoints) {
		this.endPoints = endPoints;
	}

	/**
	 * @return the callback
	 */
	public ContentDeliveryCallback getCallback() {
		return callback;
	}

	/**
	 * @param callback the callback to set
	 */
	public void setCallback(ContentDeliveryCallback callback) {
		this.callback = callback;
	}

}
