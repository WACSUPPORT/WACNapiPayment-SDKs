/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.android;

import net.wacapps.napi.api.ContentDeliveryCallback;
import net.wacapps.napi.api.NapiException;
import net.wacapps.napi.api.WacPaymentService;
import net.wacapps.napi.resource.jaxb.ReservedTransaction;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionList;
import net.wacapps.napi.util.NapiLog;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * AndroidWacPaymentService is used by Android applications to talk to Wac Napi
 * payment services.
 */

public class AndroidWacPaymentService extends WacPaymentService {

	/** Operation Mode CHARGE_PAYMENT. */
	public static final int CHARGE_PAYMENT = 678;
	
	/** Operation Mode LIST_PAYMENT. */
	public static final int LIST_PAYMENT = 679;
	
	/** Operation Mode PICK_OPERATOR. */
	public static final int PICK_OPERATOR = 680;

	/** Operation Mode LIST_PAYMENT. */
	public static final int CHECK_PAYMENT = 681;
	
	/** Operation Mode RESERVE_PAYMENT. */
	public static final int RESERVE_PAYMENT = 682;

	/** Operation Mode CAPTURE_PAYMENT. */
	public static final int CAPTURE_PAYMENT = 682;

	/**
	 * Generates the intent for making a payment. This intent is responsible for the payment operation to be performed.
	 *  
	 **/
	@Override
	public void chargePayment(Activity activity, String appID, String itemID,
			String refCode) {
		String apiType = getAPIVersion() == APIDOT2 ? "oauth20rev13" : operator.getApis()
				.getAuthorization().getType();
		Intent myIntent = new Intent(activity, WacNapiPayment.class);
		myIntent.putExtra("wacapps.net.payment.type", CHARGE_PAYMENT);
		myIntent.putExtra("wacapps.net.payment.method", apiType);
		myIntent.putExtra("wacapps.net.payment.appid", appID);
		myIntent.putExtra("wacapps.net.payment.itemid", itemID);
		myIntent.putExtra("wacapps.net.payment.refcode", refCode);
		NapiLog.d(TAG, "Starting WacNapiPayment activity with" + itemID + " : "
				+ refCode);
		activity.startActivityForResult(myIntent, 0);
	}

	/**
	 * Generates the intent for making a payment. This intent is responsible for the payment operation to be performed with Content Delivery Callback .
	 *  
	 **/
	@Override
	public void chargePayment(Activity activity, String appID, String itemID,
			String refCode, ContentDeliveryCallback deliveryCallback) {
		String apiType = getAPIVersion() == APIDOT2 ? "oauth20rev13" : operator.getApis()
				.getAuthorization().getType();
		Intent myIntent = new Intent(activity, WacNapiPayment.class);
		myIntent.putExtra("wacapps.net.payment.type", CHARGE_PAYMENT);
		myIntent.putExtra("wacapps.net.payment.method", apiType);
		myIntent.putExtra("wacapps.net.payment.appid", appID);
		myIntent.putExtra("wacapps.net.payment.itemid", itemID);
		myIntent.putExtra("wacapps.net.payment.refcode", refCode);
		NapiLog.d(TAG, "Starting WacNapiPayment activity with" + itemID + " : "
				+ refCode);
		WacNapiContext.getInstance().setCallback(deliveryCallback);
		activity.startActivityForResult(myIntent, 0);
	}

	/**
	 * Generates the intent for fetching transaction list.
	 *  
	 **/
	@Override
	public void getTransactionList(Activity activity) {
		if(getAPIVersion() == APIDOT1) {
			Intent myIntent = new Intent(activity, WacNapiPayment.class);
			myIntent.putExtra("wacapps.net.payment.appid", product.getApplicationId());
			myIntent.putExtra("wacapps.net.payment.type", LIST_PAYMENT);
			myIntent.putExtra("wacapps.net.payment.method", operator.getApis()
					.getAuthorization().getType());
			NapiLog.d(TAG, "Starting WacNapiPayment activity for Tx List");
			activity.startActivityForResult(myIntent, 0);
		} else {
			Intent myIntent = new Intent(activity, WacNapiPayment.class);
			myIntent.putExtra("wacapps.net.payment.appid", product.getApplicationId());
			myIntent.putExtra("wacapps.net.payment.type", LIST_PAYMENT);
			NapiLog.d(TAG, "Starting WacNapiPayment activity for Tx List");
			activity.startActivityForResult(myIntent, 0);
		}
	}

	/**
	 * Generates the intent for verifying a transaction.
	 *  
	 **/
	@Override
	public void checkTransaction(Activity activity ,String transactionId) {
		if(getAPIVersion() == APIDOT1) {
			Intent myIntent = new Intent(activity, WacNapiPayment.class);
			myIntent.putExtra("wacapps.net.payment.type", CHECK_PAYMENT);
			myIntent.putExtra("wacapps.net.payment.refcode", transactionId);
			myIntent.putExtra("wacapps.net.payment.method", operator.getApis()
					.getAuthorization().getType());
			myIntent.putExtra("wacapps.net.payment.appid", product.getApplicationId());
			NapiLog.d(TAG, "Starting WacNapiPayment activity for check Tx");
			activity.startActivityForResult(myIntent, 0);
		} else {
			Intent myIntent = new Intent(activity, WacNapiPayment.class);
			myIntent.putExtra("wacapps.net.payment.type", CHECK_PAYMENT);
			myIntent.putExtra("wacapps.net.payment.refcode", transactionId);
			myIntent.putExtra("wacapps.net.payment.appid", product.getApplicationId());
			NapiLog.d(TAG, "Starting WacNapiPayment activity for check Tx");
			activity.startActivityForResult(myIntent, 0);
		}
	}

	/**
	 * Processes the payment results after the purchase is through. Converts the obtained JSON data to a transaction object
	 *  
	 **/
	@Override
	public Transaction processChargePaymentTransactionResults(Intent data) {
		if (data != null && data.hasExtra("wacapps.net.payment.result")) {
			NapiLog.d(TAG, "Purchase through!  About to retrieve results...");
			String result = data.getStringExtra("wacapps.net.payment.result");
			GsonBuilder gsonb = new GsonBuilder();
			gsonb.setPrettyPrinting();
			Gson gson = gsonb.create();
			Transaction transaction = null;
			try {
				JSONObject j = new JSONObject(result);
				transaction = gson.fromJson(j.toString(), Transaction.class);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return transaction;
		} else {
			return null;
		}
	}
	
	/**
	 * Processes the results for list transaction. Converts the obtained JSON to a transaction list object
	 *  
	 **/
	@Override
	public TransactionList processTransactionListResults(Intent data) {
		if (data != null && data.hasExtra("wacapps.net.payment.result")) {
			NapiLog.d(TAG, "Txn List Request through!  About to retrieve results...");
			String result = data.getStringExtra("wacapps.net.payment.result");
			GsonBuilder gsonb = new GsonBuilder();
			gsonb.setPrettyPrinting();
			Gson gson = gsonb.create();
			TransactionList transactionList = null;
			try {
				JSONObject j = new JSONObject(result);
				transactionList = gson.fromJson(j.toString(), TransactionList.class);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return transactionList;
		} else {
			return null;
		}
	}

	/**
	 * Converts the obtained check results JSON data to a transaction object
	 *  
	 **/
	@Override
	public Transaction processTransactionCheckResults(Intent data) {
		if (data != null && data.hasExtra("wacapps.net.payment.result")) {
			NapiLog.d(TAG, "Txn Check Request through!  About to retrieve results...");
			String result = data.getStringExtra("wacapps.net.payment.result");
			GsonBuilder gsonb = new GsonBuilder();
			gsonb.setPrettyPrinting();
			Gson gson = gsonb.create();
			Transaction transaction = null;
			try {
				JSONObject j = new JSONObject(result);
				transaction = gson.fromJson(j.toString(), Transaction.class);
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return transaction;
		} else {
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see net.wacapps.napi.api.PaymentService#initialize(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void initialize(String applicationIdentifier, String operatorMCC,
			String operatorMNC, String credential, String secret,
			String developerID, String redirectUriOAuth) throws NapiException {
		initialize(applicationIdentifier, credential, secret, developerID, redirectUriOAuth);
		
	}

	/* (non-Javadoc)
	 * @see net.wacapps.napi.api.PaymentService#discoverOperator(android.content.Context, java.lang.String)
	 */
	@Override
	public void discoverOperator(Activity activity, String applicationID) {
		// Just a placeholder, this method may be removed in next version of the SDK
	}

	/**
	 * Generates the intent for reserving a payment. This intent is responsible for the reserving the payment.
	 * 
	 **/
	@Override
	public void reservePayment(Activity activity, String appID, String itemID,
			String refCode) {
		String apiType = getAPIVersion() == APIDOT2 ? "oauth20rev13" : operator.getApis()
				.getAuthorization().getType();
		Intent myIntent = new Intent(activity, WacNapiPayment.class);
		myIntent.putExtra("wacapps.net.payment.type", CHARGE_PAYMENT);
		myIntent.putExtra("wacapps.net.payment.reserve", RESERVE_PAYMENT);
		myIntent.putExtra("wacapps.net.payment.method", apiType);
		myIntent.putExtra("wacapps.net.payment.appid", appID);
		myIntent.putExtra("wacapps.net.payment.itemid", itemID);
		myIntent.putExtra("wacapps.net.payment.refcode", refCode);
		NapiLog.d(TAG, "Starting WacNapiPayment activity with" + itemID + " : "
				+ refCode);
		activity.startActivityForResult(myIntent, 0);
	}
	
	/**
	 * Processes the results for reserve payment transaction. Converts the obtained JSON to a Reserved Transaction object
	 *  
	 **/
	@Override
	public ReservedTransaction processReservePaymentResults(Intent data) {
		NapiLog.d(TAG, "In processReservePaymentResults" );
		String result = data.getStringExtra("wacapps.net.payment.result");
		NapiLog.d(TAG, "Result = " + result);
		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		ReservedTransaction reserve = null;
		try {
			JSONObject j = new JSONObject(result);
			reserve = gson.fromJson(j.toString(), ReservedTransaction.class);
			NapiLog.d(TAG, "ReservedTransaction object while processing Reserve Payment: " + reserve.toString());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return reserve;
	}

	/**
	 * Processes the results for capture payment transaction. Converts the obtained JSON to a Transaction object and persists the data to a local store 
	 *  
	 **/
	@Override
	public void capturePayment(Activity activity,
			ReservedTransaction reserve) throws NapiException {
		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		NapiLog.d(TAG, "ReservedTransaction object for capture payment: " + reserve.toString());
		String result = gson.toJson(reserve);
		Intent myIntent = new Intent(activity, WacNapiPayment.class);
		myIntent.putExtra("wacapps.net.payment.type", RESERVE_PAYMENT);
		myIntent.putExtra("wacapps.net.payment.reserveStr", result);
		NapiLog.d(TAG, "Starting WacNapiPayment activity for capture payment");
		activity.startActivityForResult(myIntent, 0);
	}
}
