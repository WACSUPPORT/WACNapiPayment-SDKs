/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.android;

import static net.wacapps.napi.api.Util.oEncode;
import static net.wacapps.napi.util.LocalizationHelper.getMessage;
import static net.wacapps.napi.util.LocalizationHelper.getMessageTranslationForMessage;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import net.wacapps.napi.api.ContentDeliveryCallback;
import net.wacapps.napi.api.NapiException;
import net.wacapps.napi.api.OSPair;
import net.wacapps.napi.api.SKSV;
import net.wacapps.napi.api.Util;
import net.wacapps.napi.api.WacHttpClient;
import net.wacapps.napi.api.WacPaymentService;
import net.wacapps.napi.api.WacRestApi;
import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.Oauth2AccessToken;
import net.wacapps.napi.resource.jaxb.Operator;
import net.wacapps.napi.resource.jaxb.ReservedTransaction;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionList;
import net.wacapps.napi.util.AllSSLSocketFactory;
import net.wacapps.napi.util.Base64;
import net.wacapps.napi.util.Hex;
import net.wacapps.napi.util.MobileDataSwitcher;
import net.wacapps.napi.util.NapiHttpHelper;
import net.wacapps.napi.util.NapiLog;
import net.wacapps.napi.util.ProxySettings;
import net.wacapps.napi.util.crypto.DeviceTransactionStorage;
import net.wacapps.napi.util.crypto.SecureDeviceTransactionDatabase;
import net.wacapps.napi.xdo.applications.Application;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.ProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.RedirectHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.RenderPriority;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Implementation of the WacNapiPayment process as an Android Activity.
 */
public class WacNapiPayment extends Activity {

	private static final double DEF_TRANS_AMOUNT = 0.0;
	private static final double DEF_AMOUNT = 1.1;

	private static final String SUCCESS_REF_CODE = "SUCCESS_REF_CODE";
	private static final String SUCCESS_CURRENCY = "SUCCESS_CURRENCY";

	/** The log TAG. */
	private static String TAG = "Wac";

	/** current application id. */
	private String applicationId = null;

	/** current item id. */
	private String itemId = null;

	/** purchase ref code. */
	private String refCode = null;

	/** The payment method. */
	private String paymentMethod = null;

	/** current request token. */
	private String requestToken = null;

	/** The oauth secret. */
	private String oauthSecret = null;

	/** The webview being used */
	private WebView webview = null;

	/** reference to self */
	private Activity mMySelf = null;

	/** Payment service instance */
	private AndroidWacPaymentService service = WacNapiContext.getInstance()
			.getPaymentService();

	/** The redirect URI. */
	public String redirectUriOAuth = service.getRedirectUriOAuth();

	/** The operation mode. */
	private int operationMode = 0;

	/** The operation mode. */
	private int reserveMode = -1;

	/** return flag RESULT_PAYMENT_OK. */
	public static final int RESULT_PAYMENT_OK = 2001;

	/** return flag RESULT_PAYMENT_BAD. */
	public static final int RESULT_PAYMENT_BAD = 2002;

	/** return flag RESULT_TRANSACTION_LIST_OK. */
	public static final int RESULT_TRANSACTION_LIST_OK = 2003;

	/** return flag RESULT_TRANSACTION_LIST_BAD. */
	public static final int RESULT_TRANSACTION_LIST_BAD = 2004;

	/** return flag RESULT_OPERATOR_OK. */
	public static final int RESULT_OPERATOR_OK = 2005;

	/** return flag RESULT_OPERATOR_BAD. */
	public static final int RESULT_OPERATOR_BAD = 2006;

	/** return flag RESULT_CHECK_TRANSACTION_OK. */
	public static final int RESULT_CHECK_TRANSACTION_OK = 2007;

	/** return flag RESULT_RESERVE_PAYMENT_OK. */
	public static final int RESULT_RESERVE_PAYMENT_OK = 2008;

	/** return flag RESULT_RESERVE_PAYMENT_BAD. */
	public static final int RESULT_RESERVE_PAYMENT_BAD = 2009;

	// code - implicit grant & token - code grant
	/** The oauth2mode. */
	private String oauth2mode = service.getTokenMode();

	/** The extras. */
	private Bundle extras = null;	

	/** The preferences. */
	SharedPreferences preferences = null;

	/** blocks back button while showing a payment success page */
	private boolean shouldBlockBackButton = false;

	/**
	 * http client instance to be used when .2 authorization redirects are done
	 * out of the webview
	 */
	final static DefaultHttpClient client = getClient();

	/** The time it takes for our client to timeout. */
	private static final int HTTP_TIMEOUT = 30 * 1000;

	/** progress dialog, used before the first auth flow page loads */
	private ProgressDialog pd = null;

	/** To be used for testing header injection */
	private static Map<String, String> extraHeaders = new HashMap<String, String>();
	
	/** The http proxy host, picked from APN settings */
	private HttpHost httpProxyHost = null;
	
	/** private webview cookie manager */
	private CookieManager cookieManager = null;

	/**
	 * Called when the activity is first created.
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		this.getWindow().requestFeature(Window.FEATURE_PROGRESS);
		mMySelf = this;
		
		preferences = PreferenceManager.getDefaultSharedPreferences(this);

		LinearLayout l = new LinearLayout(this);
		l.setOrientation(LinearLayout.VERTICAL);

		CookieStore cookieStore = new BasicCookieStore();
		HttpContext localContext = new BasicHttpContext();
		localContext.setAttribute(ClientContext.COOKIE_STORE, cookieStore);
		client.setCookieStore(cookieStore);
		client.setRedirectHandler(new RedirectHandler() {
			@Override
			public boolean isRedirectRequested(HttpResponse response,
					HttpContext context) {
				NapiLog.d(TAG, "In isRedirectRequested ");
				return false;
			}

			@Override
			public URI getLocationURI(HttpResponse response, HttpContext context)
					throws ProtocolException {
				NapiLog.d(TAG, "In getLocationURI ");
				return null;
			}
		});

		webview = new WebView(this) {
			public boolean onKeyDown(int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK) {
					NapiLog.d(TAG, "Ignoring back button presses");
					if (shouldBlockBackButton)
						return true;
				}
				return super.onKeyDown(keyCode, event);
			}
		};

		CookieSyncManager.createInstance(this);
		cookieManager = CookieManager.getInstance();

		NapiLog.d(TAG, "WebView = " + webview);
		webview.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				mMySelf.setTitle(getMessage("LOADING"));
				mMySelf.setProgress(progress * 100);
				if (progress == 100) {
					NapiLog.d(TAG, "Page load 100%");
					mMySelf.setTitle("");
					if (pd != null) {
						NapiLog.d(TAG, "Page load complete, dismissing progress dialog");
						pd.dismiss();
					}
				}
			}
		});
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setDomStorageEnabled(true);
		webview.getSettings().setPluginsEnabled(false);
		webview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
		webview.getSettings().setRenderPriority(RenderPriority.HIGH);
		webview.getSettings().setAppCacheEnabled(true);
		webview.setWebViewClient(new OAuthWebViewClient());
		webview.setLayoutParams(new LinearLayout.LayoutParams(
				android.view.ViewGroup.LayoutParams.FILL_PARENT,
				android.view.ViewGroup.LayoutParams.FILL_PARENT, 1));
		l.addView(webview);

		setContentView(l);

		NapiLog.d(TAG, "In WacNapiPayment activity");

		extras = getIntent().getExtras();

		startActivityFlow();
	}

	/**
	 * Start payment activity flow.
	 */
	private void startActivityFlow() {
		if (extras != null) {
			operationMode = extras.getInt("wacapps.net.payment.type");
			reserveMode = extras.getInt("wacapps.net.payment.reserve");
			paymentMethod = (paymentMethod == null) ? extras
					.getString("wacapps.net.payment.method") : paymentMethod;
			if (operationMode == AndroidWacPaymentService.CHARGE_PAYMENT
					&& service.getAPIVersion() == WacPaymentService.APIDOT2) {
				applicationId = extras.getString("wacapps.net.payment.appid");
				itemId = extras.getString("wacapps.net.payment.itemid");
				refCode = extras.getString("wacapps.net.payment.refcode");
				redirectUriOAuth = service.getRedirectUriOAuth();
				// do user and operator discovery
				try {
					String url = WacNapiContext.getInstance().getEndPoints()
							.getAuthorizationChargePath()
							+ "?client_id="
							+ service.getCredential()
							+ "&scope="
							+ URLEncoder.encode(WacRestApi.GET_POST_SCOPE
									+ "?code=" + itemId)
							+ "&response_type="
							+ oauth2mode + "&redirect_uri=" + redirectUriOAuth;
					showWebView(url);
				} catch (Exception e) {
					e.printStackTrace();
					Intent i = new Intent();
					mMySelf.setResult(RESULT_OPERATOR_BAD, i);
					i.putExtra("wacapps.net.payment.result.fail.message",
							e.getLocalizedMessage());
					mMySelf.finish();
					finish();
				}
			} else if (operationMode == AndroidWacPaymentService.CAPTURE_PAYMENT) {
				DeviceTransactionStorage pdb = null;
				String reserveStr =  extras.getString("wacapps.net.payment.reserveStr");
				ReservedTransaction reserve = null;
				GsonBuilder gsonb = new GsonBuilder();
				gsonb.setPrettyPrinting();
				Gson gson = gsonb.create();
				try {
					JSONObject j = new JSONObject(reserveStr);
					reserve = gson.fromJson(j.toString(), ReservedTransaction.class);
					NapiLog.d(TAG, "ReservedTransaction object in Capture Payment: " + reserve.toString());
				} catch (Exception e) {
					e.printStackTrace();
					NapiLog.d(TAG, "About to send down ERROR Intent");
					Intent i = new Intent();
					i.putExtra("wacapps.net.payment.result.fail.message", e.getLocalizedMessage());
					mMySelf.setResult(RESULT_PAYMENT_BAD, i);
					mMySelf.finish();
					return;
				}
				itemId = reserve.getItemId();
				redirectUriOAuth = "http://localhost/paymentsuccesspage";
				applicationId = reserve.getAppId();
				String paymentMethod = reserve.getPaymentMethod();
				NapiLog.d(TAG, "paymentMethod in capturePayment - " + paymentMethod);
				OSPair op = null;
				try {
					if ("oauth20rev13".equalsIgnoreCase(paymentMethod)) {
						NapiLog.d(TAG, "About to start oauth2 payment!");
						op = WacRestApi.doAOauth2Payment(reserve.getAccessToken(),
								reserve.getRefCode(), reserve.getServerReferenceCode(),
								reserve.getItemId(), reserve.getItemDesc(),
								reserve.getItemCurrency(), reserve.getItemPrice(),
								reserve.getOperatorMcc(), reserve.getOperatorMnc(),
								reserve.getPaymentUri(), reserve.getApiVersion());
					} else {
						NapiLog.d(TAG, "About to start oauth2 payment!");
						op = WacRestApi.doAOauth1Payment(reserve.getAccessToken(),
								reserve.getVerifier(), reserve.getOAuthSecret(),
								reserve.getServiceSecret(), reserve.getServiceCredential(),
								reserve.getRefCode(), reserve.getItemId(),
								reserve.getItemDesc(), reserve.getItemCurrency(),
								reserve.getItemPrice(), reserve.getOperatorMcc(),
								reserve.getOperatorMnc(), reserve.getPaymentUri());
					}
					Transaction t = (Transaction) op.o;
					pdb = getTransactionStorage();
					pdb.insert(t.getAmountTransaction().getServerReferenceCode(), op.s);
					if (reserve.getApiVersion() == WacPaymentService.APIDOT1) {
						displayHtmlSuccessPage(op);
					} else {
						NapiLog.d(TAG, "Sending down payment result");
						Intent i = new Intent();
						i.putExtra("wacapps.net.payment.type", operationMode);
						i.putExtra("wacapps.net.payment.result", op.s);
						mMySelf.setResult(RESULT_PAYMENT_OK, i);
						mMySelf.finish();
					}
					return;
				} catch (Exception e)  {
					e.printStackTrace();
					NapiLog.d(TAG, "About to send down ERROR Intent");
					Intent i = new Intent();
					i.putExtra("wacapps.net.payment.result.fail.message",
							e.getLocalizedMessage());
					mMySelf.setResult(RESULT_PAYMENT_BAD, i);
					mMySelf.finish();
					return;
				} finally {
					if (pdb != null) {
						pdb.close();
					}
				}
			} else if (operationMode == AndroidWacPaymentService.CHARGE_PAYMENT
					&& service.getAPIVersion() == WacPaymentService.APIDOT1) {
				NapiLog.d(TAG, "Payment Method : " + paymentMethod);
				itemId = extras.getString("wacapps.net.payment.itemid");
				refCode = extras.getString("wacapps.net.payment.refcode");
				applicationId = extras.getString("wacapps.net.payment.appid");
				NapiLog.d(TAG, "Retrieved params " + paymentMethod + " : "
						+ itemId + " : " + refCode);
				if ("oauth10a".equalsIgnoreCase(paymentMethod)) {
					NapiLog.d(TAG, "OAUTH1 Payment");
					doPaymentOauth();
				} else if ("oauth20rev13".equalsIgnoreCase(paymentMethod)) {
					NapiLog.d(TAG, "OAUTH2 Payment");
					Map<String, String> parameters = new HashMap<String, String>();
					parameters.put("client_id", service.getCredential());
					parameters.put("redirect_uri",
							Util.oEncode(redirectUriOAuth));
					parameters.put("response_type", oauth2mode);
					parameters.put("scope", oEncode(WacRestApi.POST_SCOPE
							+ "?code=" + itemId));
					parameters.put("x-mcc", service.getOperator().getMcc());
					parameters.put("x-mnc", service.getOperator().getMnc());

					String urlStr = NapiHttpHelper.formUrlString(service
							.getOperator().getApis().getAuthorization()
							.getUris().getAuthorize(), parameters);
					NapiLog.d("Wac", "Url is : " + urlStr);

					showWebView(urlStr);
				}
			} else if (operationMode == AndroidWacPaymentService.LIST_PAYMENT) {
				NapiLog.d(TAG, "Processing list Payment");
				if ("oauth10a".equalsIgnoreCase(paymentMethod)) {
					// oauth1 list payment business
					NapiLog.d(TAG, "List Payment - oAuth1");
					HashMap<String, String> resultMap = WacRestApi
							.getOAuth1RequestToken(service.getOperator(),
									service.getProductItem(itemId),
									service.getCredential(),
									service.getSecret(), redirectUriOAuth,
									WacRestApi.GET_SCOPE);
					requestToken = resultMap.get("oauth_token");
					oauthSecret = resultMap.get("oauth_token_secret");

					String urlStr = WacRestApi.formUrlStringForOAuth1(
							requestToken, service.getOperator(), service
									.getOperator().getApis().getAuthorization()
									.getUris().getAuthorize());
					NapiLog.d("Wac", "Opening webview for url : " + urlStr);
					showWebView(urlStr);
				} else if ("oauth20rev13".equalsIgnoreCase(paymentMethod)) {
					NapiLog.d(TAG, "List Payment - oAuth2");
					Map<String, String> parameters = new HashMap<String, String>();
					parameters.put("client_id", service.getCredential());
					parameters.put("redirect_uri",
							Util.oEncode(redirectUriOAuth));
					parameters.put("response_type", oauth2mode);
					parameters.put("scope", oEncode(WacRestApi.GET_SCOPE));
					parameters.put("x-mcc", service.getOperator().getMcc());
					parameters.put("x-mnc", service.getOperator().getMnc());

					String urlStr = NapiHttpHelper.formUrlString(service
							.getOperator().getApis().getAuthorization()
							.getUris().getAuthorize(), parameters);
					NapiLog.d("Wac", "Url is : " + urlStr);

					showWebView(urlStr);
				} else {
					NapiLog.d(TAG, "List Payment - Local");
					applicationId = extras
							.getString("wacapps.net.payment.appid");
					DeviceTransactionStorage pdb = getTransactionStorage();
					try {
						TransactionList list = pdb.getTransactionList();
						list.setFromLocalTransactionStorage(true);
						GsonBuilder gsonb = new GsonBuilder();
						gsonb.setPrettyPrinting();
						Gson gson = gsonb.create();
						try {
							String resp = gson.toJson(list);
							NapiLog.d(TAG,
									"Returning results from local list txn : "
											+ resp);
							Intent i = new Intent();
							i.putExtra("wacapps.net.payment.result", resp);
							mMySelf.setResult(RESULT_TRANSACTION_LIST_OK, i);
							mMySelf.finish();
						} catch (Exception e) {
							e.printStackTrace();
							NapiLog.d(TAG,
									"About to send down ERROR Intent from local list txn");
							Intent i = new Intent();
							i.putExtra(
									"wacapps.net.payment.result.fail.message",
									e.getLocalizedMessage());
							mMySelf.setResult(RESULT_PAYMENT_BAD, i);
							mMySelf.finish();
							return;
						}
					} finally {
						pdb.close();
					}
				}
			} else if (operationMode == AndroidWacPaymentService.CHECK_PAYMENT) {
				NapiLog.d(TAG, "In WacNapiPayment, Check Payment");
				if ("oauth10a".equalsIgnoreCase(paymentMethod)) {
					NapiLog.d(TAG, "Check Payment - oAuth1");
					itemId = extras.getString("wacapps.net.payment.itemid");
					refCode = extras.getString("wacapps.net.payment.refcode");
					HashMap<String, String> resultMap = WacRestApi
							.getOAuth1RequestToken(service.getOperator(),
									service.getProductItem(itemId),
									service.getCredential(),
									service.getSecret(), redirectUriOAuth,
									WacRestApi.GET_SCOPE);
					requestToken = resultMap.get("oauth_token");
					oauthSecret = resultMap.get("oauth_token_secret");

					String urlStr = WacRestApi.formUrlStringForOAuth1(
							requestToken, service.getOperator(), service
									.getOperator().getApis().getAuthorization()
									.getUris().getAuthorize());
					NapiLog.d("Wac", "Opening webview for url : " + urlStr);
					showWebView(urlStr);

				} else if ("oauth20rev13".equalsIgnoreCase(paymentMethod)) {
					NapiLog.d(TAG, "Check Payment - oAuth2");
					itemId = extras.getString("wacapps.net.payment.itemid");
					refCode = extras.getString("wacapps.net.payment.refcode");
					Map<String, String> parameters = new HashMap<String, String>();
					parameters.put("client_id", service.getCredential());
					parameters.put("redirect_uri",
							Util.oEncode(redirectUriOAuth));
					parameters.put("response_type", oauth2mode);
					parameters.put("scope", oEncode(WacRestApi.GET_SCOPE));
					parameters.put("x-mcc", service.getOperator().getMcc());
					parameters.put("x-mnc", service.getOperator().getMnc());
					String urlStr = NapiHttpHelper.formUrlString(service
							.getOperator().getApis().getAuthorization()
							.getUris().getAuthorize(), parameters);
					NapiLog.d("Wac", "Url is : " + urlStr);

					showWebView(urlStr);
				} else {
					applicationId = extras
							.getString("wacapps.net.payment.appid");
					itemId = extras.getString("wacapps.net.payment.itemid");
					refCode = extras.getString("wacapps.net.payment.refcode");
					NapiLog.d(TAG, "Check Payment - Local - with RefCode : "
							+ refCode);
					DeviceTransactionStorage pdb = getTransactionStorage();
					try {
						SKSV sksv = pdb.getTransaction(refCode);
						if (sksv != null) {
							NapiLog.d(TAG, "Retrieved locally stored Tx : "
									+ sksv.value);
							Intent i = new Intent();
							i.putExtra("wacapps.net.payment.result", sksv.value);
							mMySelf.setResult(RESULT_CHECK_TRANSACTION_OK, i);
							mMySelf.finish();
						} else {
							NapiLog.d(TAG, "About to send down ERROR Intent");
							Intent i = new Intent();
							i.putExtra(
									"wacapps.net.payment.result.fail.message",
									getMessage("NO_TRANSACTIONS"));
							mMySelf.setResult(RESULT_PAYMENT_BAD, i);
							mMySelf.finish();
						}
					} finally {
						pdb.close();
					}
				}
			}
		}

	}

	/*
	 * Called when the dialog is created
	 * 
	 * @see android.app.Activity#onCreateDialog(int)
	 */
	@Override
	protected Dialog onCreateDialog(int id, Bundle b) {
		switch (id) {
		default:
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onSearchRequested()
	 */
	@Override
	public boolean onSearchRequested() {
		return true;
	}

	/**
	 * Does the authorization process for payment process.
	 */
	private void doPaymentOauth() {
		HashMap<String, String> resultMap = WacRestApi.getOAuth1RequestToken(
				service.getOperator(), service.getProductItem(itemId),
				service.getCredential(), service.getSecret(), redirectUriOAuth,
				WacRestApi.POST_SCOPE);
		requestToken = resultMap.get("oauth_token");
		oauthSecret = resultMap.get("oauth_token_secret");

		String urlStr = WacRestApi.formUrlStringForOAuth1(requestToken,
				service.getOperator(), service.getOperator().getApis()
						.getAuthorization().getUris().getAuthorize());
		NapiLog.d("Wac", "Opening webview for url : " + urlStr);

		showWebView(urlStr);

	}

	/**
	 * Follow redirects, to bring the redirects out of the webview
	 *
	 * @param url the url
	 * @param proxyHost the proxy host
	 * @return the oS pair
	 */
	@Deprecated
	private OSPair followRedirects(String url, HttpHost proxyHost) {
		synchronized (client) {
			if (proxyHost != null) {
				NapiLog.d(TAG, "Setting proxy host on http client");
				client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY,
						proxyHost);
			}
			final HttpGet request = new HttpGet(url);
			Cookie cookie = null;
			Log.d(TAG, "In followRedirects url = " + url);
			HttpResponse response = null;
			try {
				response = client.execute(request);
				int statusCode = response.getStatusLine().getStatusCode();
				Log.d(TAG, "Status code is, " + statusCode);
				if (statusCode == HttpStatus.SC_MOVED_TEMPORARILY) {
					Header[] headers = response.getHeaders("Location");
					if (headers != null && headers.length != 0) {
						String newUrl = headers[headers.length - 1].getValue();
						NapiLog.d(TAG, "Following Redirect for " + url);
						return followRedirects(newUrl, proxyHost);
					}
				} else {
					NapiLog.d(TAG, "Returning cookies for " + url);
					List<Cookie> cookies = client.getCookieStore().getCookies();
					if (!cookies.isEmpty()) {
						for (int i = 0; i < cookies.size(); i++) {
							cookie = cookies.get(i);
							NapiLog.d(TAG, "found cookie " + cookie);
						}
					}
					return new OSPair(cookies, url);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
	}

	/**
	 * Show web view, authorization flow
	 * 
	 * @param url
	 *            the url
	 */
	private void showWebView(String url) {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		// move to mobile network, ignore any errors
		boolean isForceMobileConnectionForAddress = false;
		if (Util.isConnected(cm)) {
			if(!Util.isOnMobileData(cm)){
				try {
					if (WacNapiContext.getInstance().getEndPoints().isRouteThroughMobileRadio()) {
						NapiLog.d(TAG, "Routing data through mobile network");
						isForceMobileConnectionForAddress = MobileDataSwitcher.forceMobileConnectionForAddress(this, url);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (Util.isOnMobileData(cm) || isForceMobileConnectionForAddress) {
				NapiLog.d(TAG, "On mobile data, trying find and set APN proxy");
				httpProxyHost = Util.setAPNProxy(mMySelf);
			} else {
				NapiLog.d(TAG, "Not using mobile data, not using APN proxies");
				try {
					ProxySettings.resetProxy(mMySelf);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			NapiLog.d(TAG,
					"No active mobile data or wifi connections, shutting down payment request");
			Intent i = new Intent();
			i.putExtra("wacapps.net.payment.result.fail.message",
					getMessage("NO_INTERNET"));
			mMySelf.setResult(RESULT_PAYMENT_BAD, i);
			mMySelf.finish();
			return;
		}

		NapiLog.d(TAG, "Url is : " + url);		
		this.pd = ProgressDialog.show(mMySelf, "", getMessage("WORKING"), true, false);
		new LongOperation().execute(url, WacNapiContext.getInstance()
				.getPaymentService().getAPIVersion()
				+ "");

	}

	/**
	 * Used to move the initial part of AOC flow out of the UI thread
	 */
	private class LongOperation extends AsyncTask<String, Void, String> {
		@Override
		protected String doInBackground(String... params) {

			String url = params[0];

			android.os.Process
					.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);

			if (WacNapiContext.getInstance().getEndPoints()
					.useHttpClientForForwards()) {
				int apiVersion = Integer.parseInt(params[1]);
				OSPair op = null;
				if (apiVersion == WacPaymentService.APIDOT2)
					op = followRedirects(url, httpProxyHost);

				if (op != null && op.o != null) {
					url = op.s;
					@SuppressWarnings("unchecked")
					List<Cookie> cookieList = (List<Cookie>) op.o;
					for (Cookie c : cookieList) {
						cookieManager.removeSessionCookie();
						String cookieString = c.getName() + "=" + c.getValue()
								+ "; domain=" + c.getDomain();
						NapiLog.d(TAG, "Setting cooke on webview : "
								+ cookieString);
						cookieManager
								.setCookie("api.wacapps.net", cookieString);
						CookieSyncManager.getInstance().sync();
						NapiLog.d(TAG, "Delaying due to cookie sync");
						SystemClock.sleep(1000);
					}
				} else {
					NapiLog.d(TAG, "No cookies to sync");
				}
			}

			final String urlStr = url;

			mMySelf.runOnUiThread(new Runnable() {
				public void run() {
					android.os.Process
							.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
					webview.loadUrl(urlStr, extraHeaders);
					android.os.Process
							.setThreadPriority(android.os.Process.THREAD_PRIORITY_DEFAULT);
				}
			});

			return null;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(String result) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.os.AsyncTask#onPreExecute()
		 */
		@Override
		protected void onPreExecute() {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.os.AsyncTask#onProgressUpdate(Progress[])
		 */
		@Override
		protected void onProgressUpdate(Void... values) {
		}
	}

	/**
	 * Fetch the html content for the 0.1 Payment Success Page and store it in the service.
	 * Since this aync task is running background while doing the OAuth, no need of hitting the res server after the payment
	 * 
	 */
	private class InitializePaymentResponsePage extends AsyncTask<String, Void, Object> {
		
		protected Object doInBackground(String... arg0) {
			String responseJson = "{\"amountTransaction\": {\"endUserId\": \"acr:Authorization\",";
			responseJson += "\"paymentAmount\": {";
			responseJson +=  "\"chargingInformation\": {";
			responseJson +=   " \"amount\":" +  DEF_AMOUNT + ",";
			responseJson +=     "\"code\": \"dummy\",";
			responseJson +=    " \"currency\": \"" + SUCCESS_CURRENCY + "\",";
			responseJson +=   "  \"description\": \"dummy\"";
			responseJson +=  "  },";
			responseJson +=  "  \"totalAmountCharged\": \"" + DEF_TRANS_AMOUNT + "\"";
			responseJson +=  "},";
			responseJson +=   " \"referenceCode\": \"dummy\",";
			responseJson +=  " \"resourceURL\": \"https://api.wacapps.net/2/payment/acr:Authorization/transactions/amount/5bc9aae8-c7fa-4321-ae6e-2919a5b1b3e9\",";
			responseJson +=  " \"serverReferenceCode\": \"" + SUCCESS_REF_CODE + "\",";
			responseJson += "    \"transactionOperationStatus\": \"Charged\"";
			responseJson +=  " }";
			responseJson += " }";		
			try {
				service.setHtmlTemp(getHtmlSuccessPage(responseJson, "dummy"));
			} catch (Exception e) {				
				e.printStackTrace();
				NapiLog.d(TAG, "Exception when getting success page, setting page to null");
				service.setHtmlTemp(null);
			}
			return null;
		}
		
	}
	/**
	 * Show web view using str, used by payment success page display .1
	 * 
	 * @param htmlContent
	 *            the html content
	 * @param op
	 *            the op
	 */
	private void showWebViewUsingStr(String htmlContent, final OSPair op) {
		shouldBlockBackButton = true;
		WebViewClient wclient = new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				NapiLog.d(TAG, "In wclient shouldOverrideUrlLoading for url "
						+ url);
				return true;
			}

			@Override
			public void onLoadResource(WebView view, String url) {
				NapiLog.d(TAG, "In wclient onLoadResource for url " + url);
				if (url.startsWith(redirectUriOAuth)) {
					webview.setVisibility(View.INVISIBLE);
					NapiLog.d(TAG, "Sending down payment result");
					Intent i = new Intent();
					i.putExtra("wacapps.net.payment.type", operationMode);
					i.putExtra("wacapps.net.payment.result", op.s);
					mMySelf.setResult(RESULT_PAYMENT_OK, i);
					mMySelf.finish();
					shouldBlockBackButton = false;
				} else {
					NapiLog.d(TAG, "Letting page load, showWebViewUsingStr");
				}
			}
		};
		webview.setWebViewClient(wclient);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setAppCacheEnabled(true);
		webview.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		webview.getSettings().setRenderPriority(RenderPriority.HIGH);
		webview.getSettings().setPluginsEnabled(false);
		webview.loadDataWithBaseURL("http://localhost/success", htmlContent,
				"text/html", "base64", redirectUriOAuth
						+ "http://localhost/success");
	}


	/**
	 * Clean a webview of its cache and cookies.
	 * 
	 * @param view
	 *            the view
	 * @param cManager
	 *            the c manager
	 */
	@SuppressWarnings("unused")
	@Deprecated
	private void cleanWebView(WebView view, CookieManager cManager) {
		cManager.removeAllCookie();
		webview.clearFormData();
		webview.clearCache(true);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onKeyDown(int, android.view.KeyEvent)
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && webview.canGoBack()) {
			webview.goBack();
			return true;
		} else {
			finish();
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * The Class OAuthWebViewClient, used to handle redirect urls
	 */
	private class OAuthWebViewClient extends WebViewClient {

		/** The processed urls. */
		private HashSet<String> processedUrls = new HashSet<String>();

		/**
		 * Adds the to processed urls.
		 * 
		 * @param url
		 *            the url
		 * @return true, if successful
		 */
		private synchronized boolean addToProcessedUrls(String url) {
			boolean retVal = processedUrls.add(url);
			NapiLog.d(TAG, "adding url " + retVal + " - " + url);
			return retVal;
		}

		/**
		 * Checks if is url processed.
		 * 
		 * @param url
		 *            the url
		 * @return true, if is url processed
		 */
		private synchronized boolean isUrlProcessed(String url) {
			boolean retVal = processedUrls.contains(url);
			NapiLog.d(TAG, "checking for url " + retVal + " - " + url);
			return retVal;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * android.webkit.WebViewClient#shouldOverrideUrlLoading(android.webkit
		 * .WebView, java.lang.String)
		 */
		/**
		 * Should override url loading.
		 * 
		 * @param view
		 *            the view
		 * @param url
		 *            the url
		 * @return true, if successful
		 */
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			NapiLog.d(TAG, "shouldOverrideUrlLoading : " + url + " : "
					+ redirectUriOAuth);
			if (url.startsWith(redirectUriOAuth)) {
				if (!isUrlProcessed(url)) {
					addToProcessedUrls(url);
					NapiLog.d(TAG, "Done with Auth and returning url - " + url);
					processResult(url);
					return true;
				} else {
					NapiLog.d(TAG, "Url already processed, ignoring");
				}
				return false;
			} else if (url.contains("error=")) {
				try {
					if (pd != null)
						pd.dismiss();
					Map<String, List<String>> params = Util.getUrlParameters(
							url, "\\?");
					String error = params.get("error").get(0);
					Intent i = new Intent();
					if ("access_denied".equalsIgnoreCase(error)) {
						i.putExtra("wacapps.net.payment.result.fail.message",
								getMessage("TRANSACTION_CANCELLED"));
					} else {
						i.putExtra("wacapps.net.payment.result.fail.message",
								getMessageTranslationForMessage(error));
					}
					mMySelf.setResult(RESULT_PAYMENT_BAD, i);
					mMySelf.finish();
					return false;
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
					e.printStackTrace();
					Intent i = new Intent();
					i.putExtra("wacapps.net.payment.result.fail.message",
							e.getLocalizedMessage());
					mMySelf.setResult(RESULT_PAYMENT_BAD, i);
					mMySelf.finish();
					return false;
				}
			} else if (url.startsWith("tel:")) { 
                Intent intent = new Intent(Intent.ACTION_DIAL,
                        Uri.parse(url)); 
                startActivity(intent); 
			}
			else if (url.startsWith("mailto:")){
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse(url)); 
                startActivity(intent); 				
			} else {
				NapiLog.d(TAG, "Loading... " + url);
				view.loadUrl(url, extraHeaders);
			}
			return true;
		}

		/**
		 * On load resource.
		 * 
		 * @param view
		 *            the view
		 * @param url
		 *            the url
		 */
		@Override
		public void onLoadResource(WebView view, String url) {
			NapiLog.d(TAG, "Webview onLoadResource : " + url);
			super.onLoadResource(view, url);
		}

		/**
		 * On received error.
		 * 
		 * @param view
		 *            the view
		 * @param errorCode
		 *            the error code
		 * @param description
		 *            the description
		 * @param failingUrl
		 *            the failing url
		 */
		@Override
		public void onReceivedError(WebView view, int errorCode,
				String description, String failingUrl) {
			NapiLog.d(TAG, "Webview Error : " + errorCode + " : " + description
					+ " : " + failingUrl);
			super.onReceivedError(view, errorCode,
					getMessageTranslationForMessage(description), failingUrl);
		}

		/**
		 * On received ssl error.
		 * 
		 * @param view
		 *            the view
		 * @param handler
		 *            the handler
		 * @param error
		 *            the error
		 */
		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler,
				SslError error) {
			NapiLog.d(TAG, "Webview SSL Error : " + error.toString());
			handler.proceed();
		}

		/**
		 * On received http auth request.
		 * 
		 * @param view
		 *            the view
		 * @param handler
		 *            the handler
		 * @param host
		 *            the host
		 * @param realm
		 *            the realm
		 */
		@Override
		public void onReceivedHttpAuthRequest(WebView view,
				final HttpAuthHandler handler, final String host, String realm) {
			NapiLog.d(TAG, "Webview onReceivedHttpAuthRequest");

			new Dialog(mMySelf) {
				@Override
				protected void onCreate(Bundle savedInstanceState) {
					super.onCreate(savedInstanceState);
					setTitle(getMessage("LOGIN_TITLE") + " " + host);
					LinearLayout l = new LinearLayout(mMySelf);
					l.setOrientation(LinearLayout.VERTICAL);
					l.setPadding(20, 20, 20, 20);
					final EditText userName = new EditText(mMySelf);
					final EditText password = new EditText(mMySelf);
					l.setOrientation(LinearLayout.VERTICAL);
					LayoutParams params = new LayoutParams(
							LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
					l.setLayoutParams(params);
					LayoutParams textBoxParams = new LayoutParams(
							LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
					userName.setMinimumWidth(200);
					password.setMinimumWidth(200);
					textBoxParams.setMargins(0, 0, 0, 20);
					userName.setLayoutParams(textBoxParams);
					password.setLayoutParams(textBoxParams);
					password.setTransformationMethod(new PasswordTransformationMethod());
					password.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI);
					password.setTypeface(Typeface.MONOSPACE);
					userName.setText(preferences.getString("username", ""));
					password.setText(preferences.getString("password", ""));
					TextView userNameText = new TextView(mMySelf);
					userNameText.setText(getMessage("USERNAME"));
					userNameText.setTypeface(Typeface.DEFAULT_BOLD);
					TextView passwordText = new TextView(mMySelf);
					passwordText.setText(getMessage("PASSWORD"));
					passwordText.setTypeface(Typeface.DEFAULT_BOLD);
					l.addView(userNameText);
					l.addView(userName);
					l.addView(passwordText);
					l.addView(password);
					setContentView(l);
					Button button = new Button(mMySelf);
					button.setText(getMessage("LOGIN"));
					l.addView(button);

					button.setOnClickListener(new Button.OnClickListener() {
						public void onClick(View v) {
							String userName2 = userName.getText().toString();
							String password2 = password.getText().toString();
							Editor edit = preferences.edit();
							edit.putString("username", userName2);
							edit.putString("password", password2);
							edit.commit();
							NapiLog.d(TAG, "Logging in with " + userName2
									+ " : " + password2);
							handler.proceed(userName2, password2);
							dismiss();
						}
					});
				}

			}.show();
		}

		/**
		 * On scale changed.
		 * 
		 * @param view
		 *            the view
		 * @param oldScale
		 *            the old scale
		 * @param newScale
		 *            the new scale
		 */
		@Override
		public void onScaleChanged(WebView view, float oldScale, float newScale) {
			NapiLog.d(TAG, "Webview onScaleChanged");
			super.onScaleChanged(view, oldScale, newScale);
		}

		/**
		 * On too many redirects.
		 * 
		 * @param view
		 *            the view
		 * @param cancelMsg
		 *            the cancel msg
		 * @param continueMsg
		 *            the continue msg
		 */
		@Override
		public void onTooManyRedirects(WebView view, Message cancelMsg,
				Message continueMsg) {
			NapiLog.d(TAG, "Webview onTooManyRedirects");
			super.onTooManyRedirects(view, cancelMsg, continueMsg);
		}

		/**
		 * Do update visited history.
		 * 
		 * @param view
		 *            the view
		 * @param url
		 *            the url
		 * @param isReload
		 *            the is reload
		 */
		@Override
		public void doUpdateVisitedHistory(WebView view, String url,
				boolean isReload) {
			NapiLog.d(TAG, "Webview doUpdateVisitedHistory");
			super.doUpdateVisitedHistory(view, url, isReload);
		}

		/**
		 * On form resubmission.
		 * 
		 * @param view
		 *            the view
		 * @param dontResend
		 *            the dont resend
		 * @param resend
		 *            the resend
		 */
		@Override
		public void onFormResubmission(WebView view, Message dontResend,
				Message resend) {
			NapiLog.d(TAG, "Webview onFormResubmission");
			super.onFormResubmission(view, dontResend, resend);
		}

		/**
		 * On page finished.
		 * 
		 * @param view
		 *            the view
		 * @param url
		 *            the url
		 */
		@Override
		public void onPageFinished(WebView view, String url) {
			NapiLog.d(TAG, "Webview onPageFinished : " + url);
			if (pd != null) {
				pd.dismiss();
				android.os.Process
						.setThreadPriority(android.os.Process.THREAD_PRIORITY_DEFAULT);
			}
			super.onPageFinished(view, url);
		}

		/**
		 * On page started.
		 * 
		 * @param view
		 *            the view
		 * @param url
		 *            the url
		 * @param favicon
		 *            the favicon
		 */
		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			NapiLog.d(TAG, "Webview onPageStarted : " + url);
			if("google_sdk".equals( Build.PRODUCT ) || "sdk".equals(Build.PRODUCT)) {
				if (url.startsWith(redirectUriOAuth)) {
					if (!isUrlProcessed(url)) {
						addToProcessedUrls(url);
						NapiLog.d(TAG, "Done with Auth and returning url - " + url);
						processResult(url);
					} else {
						NapiLog.d(TAG,
								"In onPageStarted, url already processed, ignoring");
					}
				} else if (url.contains("error=")) {
					try {
						if (pd != null)
							pd.dismiss();
						Map<String, List<String>> params = Util.getUrlParameters(
								url, "\\?");
						String error = params.get("error").get(0);
						Intent i = new Intent();
						i.putExtra("wacapps.net.payment.result.fail.message",
								getMessageTranslationForMessage(error));
						mMySelf.setResult(RESULT_PAYMENT_BAD, i);
						mMySelf.finish();
						return;
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
						e.printStackTrace();
						Intent i = new Intent();
						i.putExtra("wacapps.net.payment.result.fail.message",
								e.getLocalizedMessage());
						mMySelf.setResult(RESULT_PAYMENT_BAD, i);
						mMySelf.finish();
						return;
					}
				} else {
					NapiLog.d(TAG, "onPageStarted... " + url);
					super.onPageStarted(view, url, favicon);
				}
			}
			return;
		}

		/**
		 * On unhandled key event.
		 * 
		 * @param view
		 *            the view
		 * @param event
		 *            the event
		 */
		@Override
		public void onUnhandledKeyEvent(WebView view, KeyEvent event) {
			NapiLog.d(TAG, "Webview onUnhandledKeyEvent");
			super.onUnhandledKeyEvent(view, event);
		}

		/**
		 * Should override key event.
		 * 
		 * @param view
		 *            the view
		 * @param event
		 *            the event
		 * @return true, if successful
		 */
		@Override
		public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
			return super.shouldOverrideKeyEvent(view, event);
		}
	}

	/**
	 * Process NAPI API call results.
	 * 
	 * @param url
	 *            the url
	 */
	private void processResult(String url) {
		NapiLog.d(TAG, "Processing API Result");
		if (operationMode == AndroidWacPaymentService.CHARGE_PAYMENT) {
			NapiLog.d(TAG, "In checkAndProcess with url " + url);
			try {
				if (url.contains("error=")) {
					Map<String, List<String>> params = Util.getUrlParameters(
							url, "\\?");
					String error = (params.get("error") != null && params.get(
							"error").size() > 0) ? params.get("error").get(0)
							: "";
					String errorDescription = (params.get("error_description") != null && params
							.get("error_description").size() > 0) ? params.get(
							"error_description").get(0) : error;
					NapiLog.d(TAG, "break in auth flow for url " + url);
					NapiLog.d(TAG, "error = " + error);
					NapiLog.d(TAG, "description = " + errorDescription);
					if (("unrecognized_operator".equalsIgnoreCase(error) && "0.1 operator network"
							.equalsIgnoreCase(errorDescription))) {
						String mcc = (params.get("x-mcc") != null && params
								.get("x-mcc").size() > 0) ? params.get("x-mcc")
								.get(0) : null;
						String mnc = (params.get("x-mnc") != null && params
								.get("x-mnc").size() > 0) ? params.get("x-mnc")
								.get(0) : null;
						if (mcc == null || mnc == null) {
							Intent i = new Intent();
							i.putExtra(
									"wacapps.net.payment.result.fail.message",
									getMessage("IDENTIFY_OP_FAIL"));
							mMySelf.setResult(RESULT_PAYMENT_BAD, i);
							mMySelf.finish();
							return;
						}
						//mcc = mnc = "000";
						NapiLog.d(TAG, "Identified mcc + mnc = " + mcc + " : "
								+ mnc);
						Operator o = new Operator();
						o.setMcc(mcc);
						o.setMnc(mnc);
						service.setOperator(o);	
						//Get the html content for the Payment Success page in asyn task
						new InitializePaymentResponsePage().execute();
						Application app = new Application();
						app.setApplicationIdentifier(applicationId);
						try {
							OSPair op = WacRestApi.doDiscoveryForOperator(app,
									o);
							service.setOperator((Operator) op.o);
							
							paymentMethod = service.getOperator().getApis()
									.getAuthorization().getType();
							NapiLog.d(TAG, "Payment algorithm now set to "
									+ paymentMethod);
						} catch (NapiException e) {
							e.printStackTrace();
							Intent i = new Intent();
							i.putExtra(
									"wacapps.net.payment.result.fail.message",
									e.getLocalizedMessage());
							mMySelf.setResult(RESULT_PAYMENT_BAD, i);
							mMySelf.finish();
							return;
						}
						service.setAPIVersion(WacPaymentService.APIDOT1);
						NapiLog.d(TAG,
								"calling start activity flow with beta .1 operator");
						if(pd != null) {
							pd.dismiss();
							NapiLog.d(TAG, "Dismissing progress dialog, right before start of .1 authorization flow");
						}
						startActivityFlow();
					} else if ("access_denied".equalsIgnoreCase(error)) {
						Intent i = new Intent();
						i.putExtra("wacapps.net.payment.result.fail.message",
								getMessage("TRANSACTION_CANCELLED"));
						mMySelf.setResult(RESULT_PAYMENT_BAD, i);
						mMySelf.finish();
					} else {
						Intent i = new Intent();
						i.putExtra(
								"wacapps.net.payment.result.fail.message",
								getMessageTranslationForMessage(errorDescription));
						mMySelf.setResult(RESULT_OPERATOR_BAD, i);
						mMySelf.finish();
					}
				} else {
					try {
						if ("oauth20rev13".equalsIgnoreCase(paymentMethod)) {
							processOAuth2PaymentResult(url);
						} else if ("oauth10a".equalsIgnoreCase(paymentMethod)) {
							processOAuth1PaymentResult(url);
						}
					} catch (Exception e) {
						e.printStackTrace();
						Intent i = new Intent();
						i.putExtra("wacapps.net.payment.result.fail.message",
								e.getLocalizedMessage());
						mMySelf.setResult(RESULT_PAYMENT_BAD, i);
						mMySelf.finish();
					}
				}
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
				Intent i = new Intent();
				i.putExtra("wacapps.net.payment.result.fail.message",
						e.getLocalizedMessage());
				mMySelf.setResult(RESULT_OPERATOR_BAD, i);
				mMySelf.finish();
			}
		} else if (operationMode == AndroidWacPaymentService.LIST_PAYMENT) {
			NapiLog.d(TAG,
					"Processing List payment results after authorization");
			try {
				if ("oauth20rev13".equalsIgnoreCase(paymentMethod)) {
					processOAuth2ListTransactionsResult(url);
				} else if ("oauth10a".equalsIgnoreCase(paymentMethod)) {
					processOAuth1ListTransactionsResult(url);
				}
			} catch (Exception e) {
				e.printStackTrace();
				Intent i = new Intent();
				i.putExtra("wacapps.net.payment.result.fail.message",
						e.getLocalizedMessage());
				mMySelf.setResult(RESULT_TRANSACTION_LIST_BAD, i);
				mMySelf.finish();
			}
		} else if (operationMode == AndroidWacPaymentService.CHECK_PAYMENT) {
			try {
				if ("oauth20rev13".equalsIgnoreCase(paymentMethod)) {
					processOAuth2CheckTransactionsResult(url);
				} else if ("oauth10a".equalsIgnoreCase(paymentMethod)) {
					processOAuth1CheckTransactionsResult(url);
				}
			} catch (Exception e) {
				e.printStackTrace();
				Intent i = new Intent();
				i.putExtra("wacapps.net.payment.result.fail.message",
						e.getLocalizedMessage());
				mMySelf.setResult(RESULT_TRANSACTION_LIST_BAD, i);
				mMySelf.finish();
			}
		}
	}

	/**
	 * Process o auth1 check transactions result.
	 * 
	 * @param url
	 *            the url
	 */
	private void processOAuth1CheckTransactionsResult(String url) {
		Map<String, List<String>> params;
		String verifier = null;
		try {
			params = Util.getUrlParameters(url, "\\?");
			verifier = params.get("oauth_verifier").get(0);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		HashMap<String, String> accessResultMap = WacRestApi
				.getOAuth1AccessToken(verifier, requestToken,
						service.getOperator(), service.getCredential(),
						service.getSecret(), oauthSecret);

		NapiLog.d(TAG, accessResultMap.get("oauth_token"));

		OSPair op = null;
		try {
			op = WacRestApi.doAOauth1CheckTransaction(
					accessResultMap.get("oauth_token"), verifier,
					accessResultMap.get("oauth_token_secret"),
					service.getSecret(), service.getCredential(),
					service.getOperator(), refCode);
		} catch (NapiException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getLocalizedMessage());
		}

		NapiLog.d(TAG, op.s);

		Intent i = new Intent();
		i.putExtra("wacapps.net.payment.result", op.s);
		mMySelf.setResult(RESULT_CHECK_TRANSACTION_OK, i);
		mMySelf.finish();
	}

	/**
	 * Process o auth2 check transactions result.
	 * 
	 * @param url
	 *            the url
	 */
	private void processOAuth2CheckTransactionsResult(String url) {
		NapiLog.d(TAG, "processOAuth2CheckTransactionsResult with url " + url);

		OSPair op = null;
		try {
			String accessToken = getAccessToken(url)[0];
			op = WacRestApi.doAOauth2CheckTransaction(accessToken,
					service.getOperator(), refCode);
		} catch (Exception e) {
			e.printStackTrace();
			NapiLog.d(TAG, "About to send down ERROR Intent");
			Intent i = new Intent();
			i.putExtra("wacapps.net.payment.result.fail.message",
					e.getLocalizedMessage());
			mMySelf.setResult(RESULT_PAYMENT_BAD, i);
			mMySelf.finish();
			return;
		}

		NapiLog.d(TAG, op.s);

		Intent i = new Intent();
		i.putExtra("wacapps.net.payment.result", op.s);
		mMySelf.setResult(RESULT_CHECK_TRANSACTION_OK, i);
		mMySelf.finish();
	}

	/**
	 * Process o auth2 list transactions result.
	 * 
	 * @param url
	 *            the url
	 * @throws NapiException
	 *             the napi exception
	 */
	private void processOAuth2ListTransactionsResult(String url)
			throws NapiException {
		NapiLog.d(TAG, "processOAuth2ListTransactionsResult with url " + url);

		OSPair op = null;
		try {
			String accessToken = getAccessToken(url)[0];
			op = WacRestApi.doAOauth2ListTransactions(accessToken,
					service.getOperator());
		} catch (Exception e) {
			e.printStackTrace();
			NapiLog.d(TAG, "About to send down ERROR Intent");
			Intent i = new Intent();
			i.putExtra("wacapps.net.payment.result.fail.message",
					e.getLocalizedMessage());
			mMySelf.setResult(RESULT_PAYMENT_BAD, i);
			mMySelf.finish();
			return;
		}

		NapiLog.d(TAG, op.s);

		Intent i = new Intent();
		i.putExtra("wacapps.net.payment.result", op.s);
		mMySelf.setResult(RESULT_TRANSACTION_LIST_OK, i);
		mMySelf.finish();

	}

	/**
	 * Gets the access token.
	 * 
	 * @param url
	 *            the url
	 * @return the access token
	 * @throws NapiException
	 *             the napi exception
	 */
	private String[] getAccessToken(String url) throws NapiException {
		String accessToken = null;
		String serverReferenceCode = null;
		Map<String, List<String>> params = null;
		if ("token".equals(oauth2mode)) {
			try {
				params = Util.getUrlParameters(url, "#");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			NapiLog.d(TAG, "Processing implicit grant results");
			try {
				accessToken = params.get("access_token").get(0);
				if (WacNapiContext.getInstance().getPaymentService()
						.getAPIVersion() == WacPaymentService.APIDOT2)
					serverReferenceCode = params.get("server_reference_code")
							.get(0);
				NapiLog.d(TAG, "token is " + accessToken);
			} catch (Exception e1) {
				throw new NapiException(getMessage("AUTHENTICATION_FAILED"));
			}
		} else if ("code".equals(oauth2mode)) {
			try {
				params = Util.getUrlParameters(url, "\\?");
				NapiLog.d(TAG, "Processing code grant results");
				String code = params.get("code").get(0);
				Oauth2AccessToken token = WacRestApi.getOAuth2AccessToken(
						service.getOperator(), service.getProductItem(itemId),
						service.getCredential(), service.getSecret(), code,
						redirectUriOAuth);
				accessToken = token.getAccessToken();
				serverReferenceCode = token.getServerReferenceCode();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (Exception ee) {
				ee.printStackTrace();
				throw new NapiException(getMessage("AUTHENTICATION_FAILED"));
			}
		}
		return new String[] { accessToken, serverReferenceCode };
	}

	/**
	 * Process oauth2 payment result.
	 * 
	 * @param url
	 *            the url
	 * @throws NapiException
	 *             the napi exception
	 */
	private void processOAuth2PaymentResult(String url) throws NapiException {
		NapiLog.d(TAG, "processOAuth2PaymentResult with url " + url);

		OSPair op = null;
		try {
			String[] tokens = getAccessToken(url);
			String accessToken = tokens[0];
			String serverReferenceCode = tokens[1];
			serverReferenceCode = serverReferenceCode == null ? refCode
					: serverReferenceCode;

			// do content delivery callback
			ContentDeliveryCallback callback = WacNapiContext.getInstance()
					.getCallback();
			if (reserveMode != AndroidWacPaymentService.RESERVE_PAYMENT) {
				NapiLog.d(TAG, "Checking callback status for oauth2");
				boolean callbackStatus = (callback != null && callback
						.deliverContent());
				NapiLog.d(TAG, "Found callback status - " + callbackStatus);
				if (!callbackStatus) {
					NapiLog.d(
							TAG,
							"Sending down payment failure, content delivery callback not set or returned false!");
					Intent i = new Intent();
					i.putExtra("wacapps.net.payment.type", operationMode);
					i.putExtra("wacapps.net.payment.result",
							getMessage("CALLBACK_NOT_SET"));
					mMySelf.setResult(RESULT_PAYMENT_BAD, i);
					mMySelf.finish();
					return;
				}
			}

			int apiVersion = WacNapiContext.getInstance().getPaymentService()
					.getAPIVersion();
			String paymentUri = (apiVersion == WacPaymentService.APIDOT2) ? WacNapiContext
					.getInstance().getEndPoints().getChargePaymentPath()
					: service.getOperator().getApis().getPayment().getUri();
			String mcc = null;
			String mnc = null;
			if (apiVersion == WacPaymentService.APIDOT1) {
				mcc = service.getOperator().getMcc();
				mnc = service.getOperator().getMnc();
			}
			Item item = service.getProductItem(itemId);
			double itemPrice = item.getPrice();
			String itemDesc = item.getDescription();
			String itemCurrency = item.getCurrency();

			// reserve mode
			if (reserveMode == AndroidWacPaymentService.RESERVE_PAYMENT) {
				NapiLog.d(TAG, "Sending down reserve success");
				Intent i = new Intent();
				ReservedTransaction reserve = new ReservedTransaction();
				reserve.setOperationMode(operationMode);
				reserve.setAccessToken(accessToken);
				reserve.setRefCode(refCode);
				reserve.setServerReferenceCode(serverReferenceCode);
				reserve.setItemId(itemId);
				reserve.setItemPrice(itemPrice);
				reserve.setItemCurrency(itemCurrency);
				reserve.setItemDesc(itemDesc);
				reserve.setOperatorMcc(mcc);
				reserve.setOperatorMnc(mnc);
				reserve.setPaymentUri(paymentUri);
				reserve.setApiVersion(apiVersion);
				reserve.setPaymentMethod(paymentMethod);
				reserve.setAppId(applicationId);

				GsonBuilder gsonb = new GsonBuilder();
				gsonb.setPrettyPrinting();
				Gson gson = gsonb.create();
				String result = gson.toJson(reserve);
				NapiLog.d(TAG, "returning with generated json - " + result);
				i.putExtra("wacapps.net.payment.result", result);
				mMySelf.setResult(RESULT_RESERVE_PAYMENT_OK, i);
				mMySelf.finish();
				return;
			} // else continue what we were doing

			op = WacRestApi.doAOauth2Payment(accessToken, refCode,
					serverReferenceCode, itemId, itemDesc, itemCurrency,
					itemPrice, mcc, mnc, paymentUri, apiVersion);
			NapiLog.d(TAG, "About to store transaction for app : "
					+ applicationId);
			Transaction t = (Transaction) op.o;
			DeviceTransactionStorage pdb = null;
			try {
				pdb = getTransactionStorage();
				pdb.insert(t.getAmountTransaction().getServerReferenceCode(),
						op.s);
			} finally {
				pdb.close();
			}
			if (apiVersion == WacPaymentService.APIDOT1) {
				displayHtmlSuccessPage(op);
			} else {
				NapiLog.d(TAG, "Sending down payment result");
				Intent i = new Intent();
				i.putExtra("wacapps.net.payment.type", operationMode);
				i.putExtra("wacapps.net.payment.result", op.s);
				mMySelf.setResult(RESULT_PAYMENT_OK, i);
				mMySelf.finish();
			}
		} catch (Exception e) {
			e.printStackTrace();
			NapiLog.d(TAG, "About to send down ERROR Intent");
			Intent i = new Intent();
			i.putExtra("wacapps.net.payment.result.fail.message",
					e.getLocalizedMessage());
			mMySelf.setResult(RESULT_PAYMENT_BAD, i);
			mMySelf.finish();
			return;
		}
	}

	private void displayHtmlSuccessPage(OSPair op ) {
		String html = service.getHtmlTemp();
		//0.1 success page placeholders will be replaced with the values from the payment response.
		if (html != null) {
			NapiLog.d(TAG, "DT success page placeholder transition START");
			Transaction t = (Transaction) op.o;			
			html = html.replace(String.valueOf(DEF_AMOUNT), t.getAmountTransaction().getPaymentAmount().getChargingInformation().getAmount().toString());
			html = html.replace(SUCCESS_CURRENCY, t.getAmountTransaction().getPaymentAmount().getChargingInformation().getCurrency());
			html = html.replace(String.valueOf(DEF_TRANS_AMOUNT), String.valueOf(t.getAmountTransaction().getPaymentAmount().getTotalAmountCharged()));
			html = html.replace(SUCCESS_REF_CODE, t.getAmountTransaction().getServerReferenceCode());
			NapiLog.d(TAG, "DT success page placeholder transition END");
		}	
		
		if (html != null && html.length() > 10) {
			showWebViewUsingStr(html, op);			
		} else {		
			NapiLog.d(
					TAG,
					"Did not get a proper succeess payment page from the server, not attempting to show it");
			NapiLog.d(TAG, "Sending down payment result");
			Intent i = new Intent();
			i.putExtra("wacapps.net.payment.type", operationMode);
			i.putExtra("wacapps.net.payment.result", op.s);
			mMySelf.setResult(RESULT_PAYMENT_OK, i);
			mMySelf.finish();
			shouldBlockBackButton = false;
		}
	}
	/**
	 * Process oauth1 list transactions result.
	 * 
	 * @param url
	 *            the url
	 */
	private void processOAuth1ListTransactionsResult(String url) {
		Map<String, List<String>> params;
		String verifier = null;

		try {
			params = Util.getUrlParameters(url, "\\?");
			verifier = params.get("oauth_verifier").get(0);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		HashMap<String, String> accessResultMap = WacRestApi
				.getOAuth1AccessToken(verifier, requestToken,
						service.getOperator(), service.getCredential(),
						service.getSecret(), oauthSecret);

		NapiLog.d(TAG, accessResultMap.get("oauth_token"));

		OSPair op = null;
		try {
			op = WacRestApi.doAOauth1ListTransactions(
					accessResultMap.get("oauth_token"), verifier,
					accessResultMap.get("oauth_token_secret"),
					service.getSecret(), service.getCredential(),
					service.getOperator());
		} catch (NapiException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getLocalizedMessage());
		}

		NapiLog.d(TAG, op.s);

		Intent i = new Intent();
		i.putExtra("wacapps.net.payment.result", op.s);
		mMySelf.setResult(RESULT_TRANSACTION_LIST_OK, i);
		mMySelf.finish();

	}

	/**
	 * Process oauth1 result.
	 * 
	 * @param url
	 *            the url
	 */
	private void processOAuth1PaymentResult(String url) {
		NapiLog.d(TAG, "Processing Charge Payment Result");
		Map<String, List<String>> params;
		String verifier = null;

		try {
			params = Util.getUrlParameters(url, "\\?");
			verifier = params.get("oauth_verifier").get(0);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		HashMap<String, String> accessResultMap = WacRestApi
				.getOAuth1AccessToken(verifier, requestToken,
						service.getOperator(), service.getCredential(),
						service.getSecret(), oauthSecret);

		// do content delivery callback
		ContentDeliveryCallback callback = WacNapiContext.getInstance()
				.getCallback();
		if (reserveMode != AndroidWacPaymentService.RESERVE_PAYMENT) {
			NapiLog.d(TAG, "Checking callback status for oauth1");
			boolean callbackStatus = (callback != null && callback
					.deliverContent());
			NapiLog.d(TAG, "Found callback status - " + callbackStatus);
			if (!callbackStatus) {
				NapiLog.d(
						TAG,
						"Sending down payment failure, content delivery callback not set or returned false!");
				Intent i = new Intent();
				i.putExtra("wacapps.net.payment.type", operationMode);
				i.putExtra("wacapps.net.payment.result",
						getMessage("CALLBACK_NOT_SET"));
				mMySelf.setResult(RESULT_PAYMENT_BAD, i);
				mMySelf.finish();
				return;
			}
		}

		Item item = service.getProductItem(itemId);
		double itemPrice = item.getPrice();
		String itemDesc = item.getDescription();
		String itemCurrency = item.getCurrency();
		String mcc = service.getOperator().getMcc();
		String mnc = service.getOperator().getMnc();
		String accessToken = accessResultMap.get("oauth_token");
		String oAuthsecret = accessResultMap.get("oauth_token_secret");
		String serviceSecret = service.getSecret();
		String serviceCredential = service.getCredential();
		String paymentUri = service.getOperator().getApis().getPayment()
				.getUri();

		// reserve mode
		if (reserveMode == AndroidWacPaymentService.RESERVE_PAYMENT) {
			NapiLog.d(TAG, "Sending down reserve success");
			Intent i = new Intent();
			ReservedTransaction reserve = new ReservedTransaction();
			reserve.setOperationMode(operationMode);
			reserve.setVerifier(verifier);
			reserve.setAccessToken(accessToken);
			reserve.setOAuthSecret(oAuthsecret);
			reserve.setRefCode(refCode);
			reserve.setServiceSecret(serviceSecret);
			reserve.setServiceCredential(serviceCredential);
			// reserve.setServerReferenceCode(serverReferenceCode);
			reserve.setItemId(itemId);
			reserve.setItemPrice(itemPrice);
			reserve.setItemCurrency(itemCurrency);
			reserve.setItemDesc(itemDesc);
			reserve.setOperatorMcc(mcc);
			reserve.setOperatorMnc(mnc);
			reserve.setPaymentUri(paymentUri);
			reserve.setApiVersion(service.getAPIVersion());
			reserve.setPaymentMethod(paymentMethod);
			reserve.setAppId(applicationId);

			GsonBuilder gsonb = new GsonBuilder();
			gsonb.setPrettyPrinting();
			Gson gson = gsonb.create();
			String result = gson.toJson(reserve);
			NapiLog.d(TAG, "returning with generated json - " + result);
			i.putExtra("wacapps.net.payment.result", result);
			mMySelf.setResult(RESULT_RESERVE_PAYMENT_OK, i);
			mMySelf.finish();
			return;
		} // else continue what we were doing

		OSPair op = null;
		try {
			op = WacRestApi.doAOauth1Payment(accessToken, verifier,
					oAuthsecret, serviceSecret, serviceCredential, refCode,
					itemId, itemDesc, itemCurrency, itemPrice, mcc, mnc,
					paymentUri);
			Transaction t = (Transaction) op.o;
			DeviceTransactionStorage pdb = null;
			try {
				pdb = getTransactionStorage();
				pdb.insert(t.getAmountTransaction().getServerReferenceCode(),
						op.s);
			} finally {
				if (pdb != null) {
					pdb.close();
				}
			}
			displayHtmlSuccessPage(op);
		} catch (NapiException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getLocalizedMessage());
		}
	}

	/**
	 * Gets the secured transaction storage handle.
	 * 
	 * @return the transaction storage
	 */
	private DeviceTransactionStorage getTransactionStorage() {
		NapiLog.d(TAG, "Calling getTransactionStorage with " + applicationId);
		return new SecureDeviceTransactionDatabase(getApplicationContext(),
				applicationId);
	}

	/**
	 * Creates a "Custom" HTTP client to be used for redirect handling
	 * 
	 * @return the DefaultHttpClient
	 */
	public static DefaultHttpClient getClient() {
		HttpParams params = new BasicHttpParams();
		HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
		HttpProtocolParams.setContentCharset(params, "utf-8");
		HttpConnectionParams.setConnectionTimeout(params, HTTP_TIMEOUT);
		HttpConnectionParams.setSoTimeout(params, HTTP_TIMEOUT);
		params.setBooleanParameter("http.protocol.expect-continue", true);

		// REGISTERS SCHEMES FOR BOTH HTTP AND HTTPS
		SchemeRegistry registry = new SchemeRegistry();
		registry.register(new Scheme("http", PlainSocketFactory
				.getSocketFactory(), 80));
		final SSLSocketFactory sslSocketFactory = AllSSLSocketFactory
				.getSocketFactory();
		sslSocketFactory
				.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		registry.register(new Scheme("https", sslSocketFactory, 443));

		ThreadSafeClientConnManager manager = new ThreadSafeClientConnManager(
				params, registry);
		DefaultHttpClient ret = new DefaultHttpClient(manager, params);
		ret.setKeepAliveStrategy(new ConnectionKeepAliveStrategy() {
			@Override
			public long getKeepAliveDuration(HttpResponse response,
					HttpContext context) {
				return 10000;
			}
		});
		return ret;
	}

	/**
	 * Gets the payment success page from the wac localization server
	 *
	 * @param responseJson the response json
	 * @param itemId the item id
	 * @return the html success page
	 * @throws NoSuchAlgorithmException the no such algorithm exception
	 * @throws UnsupportedEncodingException the unsupported encoding exception
	 * @throws InvalidKeyException the invalid key exception
	 */
	private String getHtmlSuccessPage(String responseJson, String itemId)
			throws NoSuchAlgorithmException, UnsupportedEncodingException,
			InvalidKeyException {
		NapiLog.d(TAG, "Getting success page from localization server");

		Long timeStamp = System.currentTimeMillis();

		byte[] keyBytes = itemId.getBytes("UTF-8");
		SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "HmacSHA256");

		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(secretKeySpec);

		String baseString = itemId + timeStamp + responseJson;
		mac.update(baseString.getBytes("UTF-8"));

		byte[] macBytes = mac.doFinal();
		byte[] base64Bytes = Base64.encode(macBytes).getBytes();
		String hexBytes = new String(Hex.encode(base64Bytes));

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Accept", "application/html");
		headers.put("Content-Type", "application/x-www-form-urlencoded");
		headers.put("Authorization", hexBytes);

		ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("amountTransactionJson", Base64
				.encode(responseJson.getBytes("UTF-8"))));
		params.add(new BasicNameValuePair("timeStamp", timeStamp + ""));
		params.add(new BasicNameValuePair("operatorMcc", service.getOperator()
				.getMcc()));
		params.add(new BasicNameValuePair("operatorMnc", service.getOperator()
				.getMnc()));
		params.add(new BasicNameValuePair("redirectUrl", "http://localhost/paymentsuccesspage"));

		String s = null;
		try {
			s = WacHttpClient.executeHttpPost(
					WacNapiContext.getInstance().getEndPoints().getLocalizationPathForSuccessPage(), params,
					NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			NapiLog.d(TAG, "Error getting success page, returning null");
			return null;
		}
		NapiLog.d(TAG, "Returned html for success page - " + s);
		return s;
	}

}
