/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

/**
 * Holds the itemId, description, price and currency related to product item.
 * 
 **/
public class Item
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The item id. */
    @SerializedName("item-id")
    protected String itemId;
    
    /** The description. */
    protected String description;
    
    /** The price. */
    protected double price;
    
    /** The currency. */
    protected String currency;
    
    /** The billing receipt. */
    @SerializedName("billing-receipt")
    protected String billingReceipt;

    /**
	 * Gets the value of the itemId property.
	 * 
	 * @return the item id possible object is {@link String }
	 */
    public String getItemId() {
        return itemId;
    }

    /**
     * Sets the value of the itemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemId(String value) {
        this.itemId = value;
    }

    /**
	 * Gets the value of the description property.
	 * 
	 * @return the description possible object is {@link String }
	 */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
	 * Gets the value of the price property.
	 * 
	 * @return the price
	 */
    public double getPrice() {
        return price;
    }

    /**
	 * Sets the value of the price property.
	 * 
	 * @param value
	 *            the new price
	 */
    public void setPrice(double value) {
        this.price = value;
    }

    /**
	 * Gets the value of the currency property.
	 * 
	 * @return the currency possible object is {@link String }
	 */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
	 * Gets the value of the billingReceipt property.
	 * 
	 * @return the billing receipt possible object is {@link String }
	 */
    public String getBillingReceipt() {
        return billingReceipt;
    }

    /**
     * Sets the value of the billingReceipt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingReceipt(String value) {
        this.billingReceipt = value;
    }

}
