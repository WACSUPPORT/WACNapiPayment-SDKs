/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * Holds the data related to Payment transactions
 */
public class AmountTransaction implements Serializable {

	/** The Constant serialVersionUID. */
	private final static long serialVersionUID = 1L;

	/** The client correlator. */
	protected String clientCorrelator;

	/** The end user id. */
	protected String endUserId;

	/** The payment amount. */
	protected PaymentAmount paymentAmount;

	/** The reference code. */
	protected String referenceCode;

	/** The server reference code. */
	protected String serverReferenceCode;

	/** The resource url. */
	protected String resourceURL;

	/** The transaction operation status. */
	protected String transactionOperationStatus;

	/**
	 * Gets the value of the clientCorrelator property.
	 * 
	 * @return the client correlator possible object is {@link String }
	 */
	public String getClientCorrelator() {
		return clientCorrelator;
	}

	/**
	 * Sets the value of the clientCorrelator property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setClientCorrelator(String value) {
		this.clientCorrelator = value;
	}

	/**
	 * Gets the value of the endUserId property.
	 * 
	 * @return the end user id possible object is {@link String }
	 */
	public String getEndUserId() {
		return endUserId;
	}

	/**
	 * Sets the value of the endUserId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setEndUserId(String value) {
		this.endUserId = value;
	}

	/**
	 * Gets the value of the paymentAmount property.
	 * 
	 * @return the payment amount possible object is {@link PaymentAmount }
	 */
	public PaymentAmount getPaymentAmount() {
		return paymentAmount;
	}

	/**
	 * Sets the value of the paymentAmount property.
	 * 
	 * @param value
	 *            allowed object is {@link PaymentAmount }
	 * 
	 */
	public void setPaymentAmount(PaymentAmount value) {
		this.paymentAmount = value;
	}

	/**
	 * Gets the value of the referenceCode property.
	 * 
	 * @return the reference code possible object is {@link String }
	 */
	public String getReferenceCode() {
		return referenceCode;
	}

	/**
	 * Sets the value of the referenceCode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setReferenceCode(String value) {
		this.referenceCode = value;
	}

	/**
	 * Gets the value of the serverReferenceCode property.
	 * 
	 * @return the server reference code possible object is {@link String }
	 */
	public String getServerReferenceCode() {
		return serverReferenceCode;
	}

	/**
	 * Sets the value of the serverReferenceCode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setServerReferenceCode(String value) {
		this.serverReferenceCode = value;
	}

	/**
	 * Gets the value of the resourceURL property.
	 * 
	 * @return the resource url possible object is {@link String }
	 */
	public String getResourceURL() {
		return resourceURL;
	}

	/**
	 * Sets the value of the resourceURL property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setResourceURL(String value) {
		this.resourceURL = value;
	}

	/**
	 * Gets the value of the transactionOperationStatus property.
	 * 
	 * @return the transaction operation status possible object is
	 *         {@link String }
	 */
	public String getTransactionOperationStatus() {
		return transactionOperationStatus;
	}

	/**
	 * Sets the value of the transactionOperationStatus property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setTransactionOperationStatus(String value) {
		this.transactionOperationStatus = value;
	}

}
