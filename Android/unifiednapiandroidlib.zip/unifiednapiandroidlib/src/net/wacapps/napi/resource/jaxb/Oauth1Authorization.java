/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Oauth1Authorization.
 */
public class Oauth1Authorization
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The oauth consumer key. */
    protected String oauthConsumerKey;
    
    /** The oauth signature method. */
    protected String oauthSignatureMethod;
    
    /** The oauth callback. */
    protected String oauthCallback;
    
    /** The oauth nonce. */
    protected String oauthNonce;
    
    /** The oauth scope. */
    protected String oauthScope;
    
    /** The oauth signature. */
    protected String oauthSignature;
    
    /** The oauth timestamp. */
    protected String oauthTimestamp;
    
    /** The oauth version. */
    protected String oauthVersion;
    
    /** The oauth token. */
    protected String oauthToken;
    
    /** The oauth verifier. */
    protected String oauthVerifier;
    
    /** The request type. */
    protected String requestType;

    /**
	 * Gets the value of the oauthConsumerKey property.
	 * 
	 * @return the oauth consumer key possible object is {@link String }
	 */
    public String getOauthConsumerKey() {
        return oauthConsumerKey;
    }

    /**
     * Sets the value of the oauthConsumerKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthConsumerKey(String value) {
        this.oauthConsumerKey = value;
    }

    /**
	 * Gets the value of the oauthSignatureMethod property.
	 * 
	 * @return the oauth signature method possible object is {@link String }
	 */
    public String getOauthSignatureMethod() {
        return oauthSignatureMethod;
    }

    /**
     * Sets the value of the oauthSignatureMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthSignatureMethod(String value) {
        this.oauthSignatureMethod = value;
    }

    /**
	 * Gets the value of the oauthCallback property.
	 * 
	 * @return the oauth callback possible object is {@link String }
	 */
    public String getOauthCallback() {
        return oauthCallback;
    }

    /**
     * Sets the value of the oauthCallback property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthCallback(String value) {
        this.oauthCallback = value;
    }

    /**
	 * Gets the value of the oauthNonce property.
	 * 
	 * @return the oauth nonce possible object is {@link String }
	 */
    public String getOauthNonce() {
        return oauthNonce;
    }

    /**
     * Sets the value of the oauthNonce property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthNonce(String value) {
        this.oauthNonce = value;
    }

    /**
	 * Gets the value of the oauthScope property.
	 * 
	 * @return the oauth scope possible object is {@link String }
	 */
    public String getOauthScope() {
        return oauthScope;
    }

    /**
     * Sets the value of the oauthScope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthScope(String value) {
        this.oauthScope = value;
    }

    /**
	 * Gets the value of the oauthSignature property.
	 * 
	 * @return the oauth signature possible object is {@link String }
	 */
    public String getOauthSignature() {
        return oauthSignature;
    }

    /**
     * Sets the value of the oauthSignature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthSignature(String value) {
        this.oauthSignature = value;
    }

    /**
	 * Gets the value of the oauthTimestamp property.
	 * 
	 * @return the oauth timestamp possible object is {@link String }
	 */
    public String getOauthTimestamp() {
        return oauthTimestamp;
    }

    /**
     * Sets the value of the oauthTimestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthTimestamp(String value) {
        this.oauthTimestamp = value;
    }

    /**
	 * Gets the value of the oauthVersion property.
	 * 
	 * @return the oauth version possible object is {@link String }
	 */
    public String getOauthVersion() {
        return oauthVersion;
    }

    /**
     * Sets the value of the oauthVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthVersion(String value) {
        this.oauthVersion = value;
    }

    /**
	 * Gets the value of the oauthToken property.
	 * 
	 * @return the oauth token possible object is {@link String }
	 */
    public String getOauthToken() {
        return oauthToken;
    }

    /**
     * Sets the value of the oauthToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthToken(String value) {
        this.oauthToken = value;
    }

    /**
	 * Gets the value of the oauthVerifier property.
	 * 
	 * @return the oauth verifier possible object is {@link String }
	 */
    public String getOauthVerifier() {
        return oauthVerifier;
    }

    /**
     * Sets the value of the oauthVerifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthVerifier(String value) {
        this.oauthVerifier = value;
    }

    /**
	 * Gets the value of the requestType property.
	 * 
	 * @return the request type possible object is {@link String }
	 */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

}
