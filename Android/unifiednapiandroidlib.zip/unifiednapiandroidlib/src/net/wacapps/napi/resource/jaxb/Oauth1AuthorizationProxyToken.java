/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Oauth1AuthorizationProxyToken.
 */
public class Oauth1AuthorizationProxyToken
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The uri. */
    protected String uri;
    
    /** The oauth token. */
    protected String oauthToken;
    
    /** The oauth token secret. */
    protected String oauthTokenSecret;
    
    /** The oauth callback confirmed. */
    protected String oauthCallbackConfirmed;

    /**
	 * Gets the value of the uri property.
	 * 
	 * @return the uri possible object is {@link String }
	 */
    public String getUri() {
        return uri;
    }

    /**
     * Sets the value of the uri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUri(String value) {
        this.uri = value;
    }

    /**
	 * Gets the value of the oauthToken property.
	 * 
	 * @return the oauth token possible object is {@link String }
	 */
    public String getOauthToken() {
        return oauthToken;
    }

    /**
     * Sets the value of the oauthToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthToken(String value) {
        this.oauthToken = value;
    }

    /**
	 * Gets the value of the oauthTokenSecret property.
	 * 
	 * @return the oauth token secret possible object is {@link String }
	 */
    public String getOauthTokenSecret() {
        return oauthTokenSecret;
    }

    /**
     * Sets the value of the oauthTokenSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthTokenSecret(String value) {
        this.oauthTokenSecret = value;
    }

    /**
	 * Gets the value of the oauthCallbackConfirmed property.
	 * 
	 * @return the oauth callback confirmed possible object is {@link String }
	 */
    public String getOauthCallbackConfirmed() {
        return oauthCallbackConfirmed;
    }

    /**
     * Sets the value of the oauthCallbackConfirmed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthCallbackConfirmed(String value) {
        this.oauthCallbackConfirmed = value;
    }

}
