/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class InvalidRequestError.
 */
public class InvalidRequestError
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The request error. */
    protected RequestError requestError;

    /**
	 * Gets the value of the requestError property.
	 * 
	 * @return the request error possible object is {@link RequestError }
	 */
    public RequestError getRequestError() {
        return requestError;
    }

    /**
     * Sets the value of the requestError property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequestError }
     *     
     */
    public void setRequestError(RequestError value) {
        this.requestError = value;
    }

}
