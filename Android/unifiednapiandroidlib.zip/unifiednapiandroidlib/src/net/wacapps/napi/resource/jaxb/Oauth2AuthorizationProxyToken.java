/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Oauth2AuthorizationProxyToken.
 */
public class Oauth2AuthorizationProxyToken
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The uri. */
    protected String uri;
    
    /** The oauth2 authorization token. */
    protected Oauth2AuthorizationToken oauth2AuthorizationToken;
    
    /** The proxy session token. */
    protected String proxySessionToken;

    /**
	 * Gets the value of the uri property.
	 * 
	 * @return the uri possible object is {@link String }
	 */
    public String getUri() {
        return uri;
    }

    /**
     * Sets the value of the uri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUri(String value) {
        this.uri = value;
    }

    /**
	 * Gets the value of the oauth2AuthorizationToken property.
	 * 
	 * @return the oauth2 authorization token possible object is
	 *         {@link Oauth2AuthorizationToken }
	 */
    public Oauth2AuthorizationToken getOauth2AuthorizationToken() {
        return oauth2AuthorizationToken;
    }

    /**
     * Sets the value of the oauth2AuthorizationToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth2AuthorizationToken }
     *     
     */
    public void setOauth2AuthorizationToken(Oauth2AuthorizationToken value) {
        this.oauth2AuthorizationToken = value;
    }

    /**
	 * Gets the value of the proxySessionToken property.
	 * 
	 * @return the proxy session token possible object is {@link String }
	 */
    public String getProxySessionToken() {
        return proxySessionToken;
    }

    /**
     * Sets the value of the proxySessionToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProxySessionToken(String value) {
        this.proxySessionToken = value;
    }

}
