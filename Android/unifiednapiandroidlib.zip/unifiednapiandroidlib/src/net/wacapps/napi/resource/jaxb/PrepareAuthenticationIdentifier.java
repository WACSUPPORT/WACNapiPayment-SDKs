/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class PrepareAuthenticationIdentifier.
 */
public class PrepareAuthenticationIdentifier
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The api identifier. */
    protected String apiIdentifier;
    
    /** The api key. */
    protected String apiKey;
    
    /** The user id. */
    protected String userId;

    /**
	 * Gets the value of the apiIdentifier property.
	 * 
	 * @return the api identifier possible object is {@link String }
	 */
    public String getApiIdentifier() {
        return apiIdentifier;
    }

    /**
     * Sets the value of the apiIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApiIdentifier(String value) {
        this.apiIdentifier = value;
    }

    /**
	 * Gets the value of the apiKey property.
	 * 
	 * @return the api key possible object is {@link String }
	 */
    public String getApiKey() {
        return apiKey;
    }

    /**
     * Sets the value of the apiKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApiKey(String value) {
        this.apiKey = value;
    }

    /**
	 * Gets the value of the userId property.
	 * 
	 * @return the user id possible object is {@link String }
	 */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }

}
