/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * QueryApi allows developer to get information about products and prices for a given application.
 */
public class QueryApi
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The type of query, this can only be 'products' within current scope. */
    protected String type;
    
    /** The uri of the Query API. */
    protected String uri;

    /**
	 * Gets the value of the type property.
	 * 
	 * @return the type possible object is {@link String }
	 */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
	 * Gets the value of the uri property.
	 * 
	 * @return the uri possible object is {@link String }
	 */
    public String getUri() {
        return uri;
    }

    /**
     * Sets the value of the uri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUri(String value) {
        this.uri = value;
    }

}
