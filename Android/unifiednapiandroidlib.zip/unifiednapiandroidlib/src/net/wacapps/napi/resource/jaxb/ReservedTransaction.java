/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * Holds the data related to reserved payment transactions.
 */
public class ReservedTransaction implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1468307464986022649L;
	
	/**
	 * Gets the operation mode.
	 *
	 * @return the operation mode
	 */
	public int getOperationMode() {
		return operationMode;
	}
	
	/**
	 * Sets the operation mode.
	 *
	 * @param operationMode the new operation mode
	 */
	public void setOperationMode(int operationMode) {
		this.operationMode = operationMode;
	}
	
	/**
	 * Gets the access token.
	 *
	 * @return the access token
	 */
	public String getAccessToken() {
		return accessToken;
	}
	
	/**
	 * Sets the access token.
	 *
	 * @param accessToken the new access token
	 */
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	/**
	 * Gets the ref code.
	 *
	 * @return the ref code
	 */
	public String getRefCode() {
		return refCode;
	}
	
	/**
	 * Sets the ref code.
	 *
	 * @param refCode the new ref code
	 */
	public void setRefCode(String refCode) {
		this.refCode = refCode;
	}
	
	/**
	 * Gets the server reference code.
	 *
	 * @return the server reference code
	 */
	public String getServerReferenceCode() {
		return serverReferenceCode;
	}
	
	/**
	 * Sets the server reference code.
	 *
	 * @param serverReferenceCode the new server reference code
	 */
	public void setServerReferenceCode(String serverReferenceCode) {
		this.serverReferenceCode = serverReferenceCode;
	}
	
	/**
	 * Gets the item id.
	 *
	 * @return the item id
	 */
	public String getItemId() {
		return itemId;
	}
	
	/**
	 * Sets the item id.
	 *
	 * @param itemId the new item id
	 */
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	/**
	 * Gets the item desc.
	 *
	 * @return the item desc
	 */
	public String getItemDesc() {
		return itemDesc;
	}
	
	/**
	 * Sets the item desc.
	 *
	 * @param itemDesc the new item desc
	 */
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	
	/**
	 * Gets the item price.
	 *
	 * @return the item price
	 */
	public double getItemPrice() {
		return itemPrice;
	}
	
	/**
	 * Sets the item price.
	 *
	 * @param itemPrice the new item price
	 */
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}
	
	/**
	 * Gets the item currency.
	 *
	 * @return the item currency
	 */
	public String getItemCurrency() {
		return itemCurrency;
	}
	
	/**
	 * Sets the item currency.
	 *
	 * @param itemCurrency the new item currency
	 */
	public void setItemCurrency(String itemCurrency) {
		this.itemCurrency = itemCurrency;
	}
	
	/**
	 * Gets the operator mcc.
	 *
	 * @return the operator mcc
	 */
	public String getOperatorMcc() {
		return operatorMcc;
	}
	
	/**
	 * Sets the operator mcc.
	 *
	 * @param operatorMcc the new operator mcc
	 */
	public void setOperatorMcc(String operatorMcc) {
		this.operatorMcc = operatorMcc;
	}
	
	/**
	 * Gets the operator mnc.
	 *
	 * @return the operator mnc
	 */
	public String getOperatorMnc() {
		return operatorMnc;
	}
	
	/**
	 * Sets the operator mnc.
	 *
	 * @param operatorMnc the new operator mnc
	 */
	public void setOperatorMnc(String operatorMnc) {
		this.operatorMnc = operatorMnc;
	}
	
	/**
	 * Gets the payment uri.
	 *
	 * @return the payment uri
	 */
	public String getPaymentUri() {
		return paymentUri;
	}
	
	/**
	 * Sets the payment uri.
	 *
	 * @param paymentUri the new payment uri
	 */
	public void setPaymentUri(String paymentUri) {
		this.paymentUri = paymentUri;
	}
	
	/**
	 * Gets the api version.
	 *
	 * @return the api version
	 */
	public int getApiVersion() {
		return apiVersion;
	}
	
	/**
	 * Sets the api version.
	 *
	 * @param apiVersion the new api version
	 */
	public void setApiVersion(int apiVersion) {
		this.apiVersion = apiVersion;
	}
	
	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod() {
		return paymentMethod;
	}

	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	/**
	 * @return the verifier
	 */
	public String getVerifier() {
		return verifier;
	}

	/**
	 * @param verifier the verifier to set
	 */
	public void setVerifier(String verifier) {
		this.verifier = verifier;
	}

	/**
	 * @return the secret
	 */
	public String getOAuthSecret() {
		return oAuthSecret;
	}

	/**
	 * @param secret the secret to set
	 */
	public void setOAuthSecret(String secret) {
		this.oAuthSecret = secret;
	}

	/**
	 * @return the credential
	 */
	public String getCredential() {
		return credential;
	}

	/**
	 * @param credential the credential to set
	 */
	public void setCredential(String credential) {
		this.credential = credential;
	}

	/**
	 * @return the serviceSecret
	 */
	public String getServiceSecret() {
		return serviceSecret;
	}

	/**
	 * @param serviceSecret the serviceSecret to set
	 */
	public void setServiceSecret(String serviceSecret) {
		this.serviceSecret = serviceSecret;
	}

	/**
	 * @return the serviceCredential
	 */
	public String getServiceCredential() {
		return serviceCredential;
	}

	/**
	 * @param serviceCredential the serviceCredential to set
	 */
	public void setServiceCredential(String serviceCredential) {
		this.serviceCredential = serviceCredential;
	}

	/**
	 * @return the appId
	 */
	public String getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(String appId) {
		this.appId = appId;
	}
	
	@Override
	public String toString() {

		StringBuilder result = new StringBuilder();
		String NEW_LINE = System.getProperty("line.separator");

		result.append(this.getClass().getSimpleName() + " Object {" + NEW_LINE);
		result.append(" operationMode: " + operationMode + NEW_LINE);
		result.append(" accessToken: " + accessToken + NEW_LINE);
		result.append(" refCode: " + refCode + NEW_LINE);
		result.append(" serverReferenceCode: " + serverReferenceCode
				+ NEW_LINE);
		result.append(" itemId: " + itemId + NEW_LINE);
		result.append(" itemDesc: " + itemDesc + NEW_LINE);
		result.append(" itemPrice: " + itemPrice + NEW_LINE);
		result.append(" itemCurrency: " + itemCurrency + NEW_LINE);
		result.append(" operatorMcc: " + operatorMcc + NEW_LINE);
		result.append(" operatorMnc: " + operatorMnc + NEW_LINE);
		result.append(" paymentUri: " + paymentUri + NEW_LINE);
		result.append(" apiVersion: " + apiVersion + NEW_LINE);
		result.append(" paymentMethod: " + paymentMethod + NEW_LINE);
		result.append(" verifier: " + verifier + NEW_LINE);
		result.append(" oAuthSecret: " + oAuthSecret + NEW_LINE);
		result.append(" credential: " + credential + NEW_LINE);
		result.append(" serviceSecret: " + serviceSecret + NEW_LINE);
		result.append(" serviceCredential: " + serviceCredential + NEW_LINE);
		result.append(" appId: " + appId + NEW_LINE);
		result.append("}");

		return result.toString();
	}

	/** The operation mode. */
	private int operationMode;
	
	/** The access token. */
	private String accessToken;
	
	/** The ref code. */
	private String refCode;
	
	/** The server reference code. */
	private String serverReferenceCode;
	
	/** The item id. */
	private String itemId;
	
	/** The item desc. */
	private String itemDesc;
	
	/** The item price. */
	private double itemPrice;
	
	/** The item currency. */
	private String itemCurrency;
	
	/** The operator mcc. */
	private String operatorMcc;
	
	/** The operator mnc. */
	private String operatorMnc;
	
	/** The payment uri. */
	private String paymentUri;
	
	/** The api version. */
	private int apiVersion;
	
	private String paymentMethod;
	
	private String verifier;
	
	private String oAuthSecret;
	
	private String credential;
	
	private String serviceSecret;
	
	private String serviceCredential;

	private String appId;
}
