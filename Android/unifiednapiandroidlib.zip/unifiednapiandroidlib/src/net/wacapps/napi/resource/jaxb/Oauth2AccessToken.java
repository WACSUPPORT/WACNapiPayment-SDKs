/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;


/**
 * The Class Oauth2AccessToken.
 */
public class Oauth2AccessToken
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The access token. */
    @SerializedName(value = "access_token") 
    protected String accessToken;
    
    /** The expires in. */
    @SerializedName(value = "expires_in")
    protected String expiresIn;
    
    /** The token type. */
    @SerializedName(value = "token_type")
    protected String tokenType;
    
    /** The secret. */
    protected String secret;
    
    /** The algorithm. */
    protected String algorithm;
    
    /** The state. */
    protected String state;
    
    /** The scope. */
    protected String scope;
    
    /** The refresh token. */
    @SerializedName(value = "refresh_token")
    protected String refreshToken;

    /** The server reference code. */
    @SerializedName(value = "server_reference_code")
	private String serverReferenceCode;

    /**
	 * Gets the value of the accessToken property.
	 * 
	 * @return the access token possible object is {@link String }
	 */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * Sets the value of the accessToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessToken(String value) {
        this.accessToken = value;
    }

    /**
	 * Gets the value of the expiresIn property.
	 * 
	 * @return the expires in possible object is {@link String }
	 */
    public String getExpiresIn() {
        return expiresIn;
    }

    /**
     * Sets the value of the expiresIn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpiresIn(String value) {
        this.expiresIn = value;
    }

    /**
	 * Gets the value of the tokenType property.
	 * 
	 * @return the token type possible object is {@link String }
	 */
    public String getTokenType() {
        return tokenType;
    }

    /**
     * Sets the value of the tokenType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenType(String value) {
        this.tokenType = value;
    }

    /**
	 * Gets the value of the secret property.
	 * 
	 * @return the secret possible object is {@link String }
	 */
    public String getSecret() {
        return secret;
    }

    /**
     * Sets the value of the secret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecret(String value) {
        this.secret = value;
    }

    /**
	 * Gets the value of the algorithm property.
	 * 
	 * @return the algorithm possible object is {@link String }
	 */
    public String getAlgorithm() {
        return algorithm;
    }

    /**
     * Sets the value of the algorithm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlgorithm(String value) {
        this.algorithm = value;
    }

    /**
	 * Gets the value of the state property.
	 * 
	 * @return the state possible object is {@link String }
	 */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
	 * Gets the value of the scope property.
	 * 
	 * @return the scope possible object is {@link String }
	 */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    /**
	 * Gets the value of the refreshToken property.
	 * 
	 * @return the refresh token possible object is {@link String }
	 */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * Sets the value of the refreshToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefreshToken(String value) {
        this.refreshToken = value;
    }

	/**
	 * @return the serverReferenceCode
	 */
	public String getServerReferenceCode() {
		return serverReferenceCode;
	}

	/**
	 * @param serverReferenceCode the serverReferenceCode to set
	 */
	public void setServerReferenceCode(String serverReferenceCode) {
		this.serverReferenceCode = serverReferenceCode;
	}

}
