/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * Holds the transaction list fetched from storage.
 */
public class TransactionList
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 2L;
    
    /** originating from local transaction storage. */
    private boolean fromLocalTransactionStorage=false;
    
    /** The payment transaction list. */
    protected TransactionArray paymentTransactionList;

    /**
	 * Gets the value of the paymentTransactionList property.
	 * 
	 * @return the payment transaction list possible object is
	 *         {@link TransactionArray }
	 */
    public TransactionArray getPaymentTransactionList() {
        return paymentTransactionList;
    }

    /**
     * Sets the value of the paymentTransactionList property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionArray }
     *     
     */
    public void setPaymentTransactionList(TransactionArray value) {
        this.paymentTransactionList = value;
    }

	public void setFromLocalTransactionStorage(boolean fromLocalTransactionStorage) {
		this.fromLocalTransactionStorage = fromLocalTransactionStorage;
	}

	/**
	 * This method returns true if transaction list has been retrieved from local storage otherwise returns false
	 * @return boolean
	 */
	public boolean isFromLocalTransactionStorage() {
		return fromLocalTransactionStorage;
	}

}
