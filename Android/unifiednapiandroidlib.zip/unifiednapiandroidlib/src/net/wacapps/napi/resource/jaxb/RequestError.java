/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class RequestError.
 */
public class RequestError
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The service exception. */
    protected ServiceException serviceException;

    /**
	 * Gets the value of the serviceException property.
	 * 
	 * @return the service exception possible object is {@link ServiceException }
	 */
    public ServiceException getServiceException() {
        return serviceException;
    }

    /**
     * Sets the value of the serviceException property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceException }
     *     
     */
    public void setServiceException(ServiceException value) {
        this.serviceException = value;
    }

}
