/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Oauth2ProtectedAuthorizationToken.
 */
public class Oauth2ProtectedAuthorizationToken
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The type. */
    protected String type;
    
    /** The token. */
    protected String token;
    
    /** The timestamp. */
    protected String timestamp;
    
    /** The nonce. */
    protected String nonce;
    
    /** The signature. */
    protected String signature;

    /**
	 * Gets the value of the type property.
	 * 
	 * @return the type possible object is {@link String }
	 */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
	 * Gets the value of the token property.
	 * 
	 * @return the token possible object is {@link String }
	 */
    public String getToken() {
        return token;
    }

    /**
     * Sets the value of the token property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

    /**
	 * Gets the value of the timestamp property.
	 * 
	 * @return the timestamp possible object is {@link String }
	 */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimestamp(String value) {
        this.timestamp = value;
    }

    /**
	 * Gets the value of the nonce property.
	 * 
	 * @return the nonce possible object is {@link String }
	 */
    public String getNonce() {
        return nonce;
    }

    /**
     * Sets the value of the nonce property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNonce(String value) {
        this.nonce = value;
    }

    /**
	 * Gets the value of the signature property.
	 * 
	 * @return the signature possible object is {@link String }
	 */
    public String getSignature() {
        return signature;
    }

    /**
     * Sets the value of the signature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignature(String value) {
        this.signature = value;
    }

}
