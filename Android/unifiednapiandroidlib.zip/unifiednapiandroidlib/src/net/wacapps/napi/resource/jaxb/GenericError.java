/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class GenericError.
 */
public class GenericError
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The code. */
    protected int code;
    
    /** The message. */
    protected String message;

    /**
	 * Gets the value of the code property.
	 * 
	 * @return the code
	 */
    public int getCode() {
        return code;
    }

    /**
	 * Sets the value of the code property.
	 * 
	 * @param value
	 *            the new code
	 */
    public void setCode(int value) {
        this.code = value;
    }

    /**
	 * Gets the value of the message property.
	 * 
	 * @return the message possible object is {@link String }
	 */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

}
