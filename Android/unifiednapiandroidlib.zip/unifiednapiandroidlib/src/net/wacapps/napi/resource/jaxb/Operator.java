/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Operator.
 */
public class Operator
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The name. */
    protected String name;
    
    /** The mcc. */
    protected String mcc;
    
    /** The mnc. */
    protected String mnc;
    
    /** The apis. */
    protected Apis apis;

    /**
	 * Gets the value of the name property.
	 * 
	 * @return the name possible object is {@link String }
	 */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
	 * Gets the value of the mcc property.
	 * 
	 * @return the mcc possible object is {@link String }
	 */
    public String getMcc() {
        return mcc;
    }

    /**
     * Sets the value of the mcc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMcc(String value) {
        this.mcc = value;
    }

    /**
	 * Gets the value of the mnc property.
	 * 
	 * @return the mnc possible object is {@link String }
	 */
    public String getMnc() {
        return mnc;
    }

    /**
     * Sets the value of the mnc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMnc(String value) {
        this.mnc = value;
    }

    /**
	 * Gets the value of the apis property.
	 * 
	 * @return the apis possible object is {@link Apis }
	 */
    public Apis getApis() {
        return apis;
    }

    /**
     * Sets the value of the apis property.
     * 
     * @param value
     *     allowed object is
     *     {@link Apis }
     *     
     */
    public void setApis(Apis value) {
        this.apis = value;
    }

}
