/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Payment.
 */
public class Payment
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The end user id. */
    protected String endUserId;
    
    /** The reference code. */
    protected String referenceCode;
    
    /** The transaction operation status. */
    protected String transactionOperationStatus;
    
    /** The description. */
    protected String description;
    
    /** The currency. */
    protected String currency;
    
    /** The amount. */
    protected double amount;
    
    /** The code. */
    protected String code;
    
    /** The client correlator. */
    protected String clientCorrelator;
    
    /** The on behalf of. */
    protected String onBehalfOf;
    
    /** The purchase category code. */
    protected String purchaseCategoryCode;
    
    /** The channel. */
    protected String channel;
    
    /** The tax amount. */
    protected double taxAmount;
    
    /** The service id. */
    protected String serviceID;
    
    /** The product id. */
    protected String productID;

    /**
	 * Gets the value of the endUserId property.
	 * 
	 * @return the end user id possible object is {@link String }
	 */
    public String getEndUserId() {
        return endUserId;
    }

    /**
     * Sets the value of the endUserId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndUserId(String value) {
        this.endUserId = value;
    }

    /**
	 * Gets the value of the referenceCode property.
	 * 
	 * @return the reference code possible object is {@link String }
	 */
    public String getReferenceCode() {
        return referenceCode;
    }

    /**
     * Sets the value of the referenceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceCode(String value) {
        this.referenceCode = value;
    }

    /**
	 * Gets the value of the transactionOperationStatus property.
	 * 
	 * @return the transaction operation status possible object is
	 *         {@link String }
	 */
    public String getTransactionOperationStatus() {
        return transactionOperationStatus;
    }

    /**
     * Sets the value of the transactionOperationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionOperationStatus(String value) {
        this.transactionOperationStatus = value;
    }

    /**
	 * Gets the value of the description property.
	 * 
	 * @return the description possible object is {@link String }
	 */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
	 * Gets the value of the currency property.
	 * 
	 * @return the currency possible object is {@link String }
	 */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
	 * Gets the value of the amount property.
	 * 
	 * @return the amount
	 */
    public double getAmount() {
        return amount;
    }

    /**
	 * Sets the value of the amount property.
	 * 
	 * @param value
	 *            the new amount
	 */
    public void setAmount(double value) {
        this.amount = value;
    }

    /**
	 * Gets the value of the code property.
	 * 
	 * @return the code possible object is {@link String }
	 */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
	 * Gets the value of the clientCorrelator property.
	 * 
	 * @return the client correlator possible object is {@link String }
	 */
    public String getClientCorrelator() {
        return clientCorrelator;
    }

    /**
     * Sets the value of the clientCorrelator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientCorrelator(String value) {
        this.clientCorrelator = value;
    }

    /**
	 * Gets the value of the onBehalfOf property.
	 * 
	 * @return the on behalf of possible object is {@link String }
	 */
    public String getOnBehalfOf() {
        return onBehalfOf;
    }

    /**
     * Sets the value of the onBehalfOf property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOnBehalfOf(String value) {
        this.onBehalfOf = value;
    }

    /**
	 * Gets the value of the purchaseCategoryCode property.
	 * 
	 * @return the purchase category code possible object is {@link String }
	 */
    public String getPurchaseCategoryCode() {
        return purchaseCategoryCode;
    }

    /**
     * Sets the value of the purchaseCategoryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurchaseCategoryCode(String value) {
        this.purchaseCategoryCode = value;
    }

    /**
	 * Gets the value of the channel property.
	 * 
	 * @return the channel possible object is {@link String }
	 */
    public String getChannel() {
        return channel;
    }

    /**
     * Sets the value of the channel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannel(String value) {
        this.channel = value;
    }

    /**
	 * Gets the value of the taxAmount property.
	 * 
	 * @return the tax amount
	 */
    public double getTaxAmount() {
        return taxAmount;
    }

    /**
	 * Sets the value of the taxAmount property.
	 * 
	 * @param value
	 *            the new tax amount
	 */
    public void setTaxAmount(double value) {
        this.taxAmount = value;
    }

    /**
	 * Gets the value of the serviceID property.
	 * 
	 * @return the service id possible object is {@link String }
	 */
    public String getServiceID() {
        return serviceID;
    }

    /**
     * Sets the value of the serviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceID(String value) {
        this.serviceID = value;
    }

    /**
	 * Gets the value of the productID property.
	 * 
	 * @return the product id possible object is {@link String }
	 */
    public String getProductID() {
        return productID;
    }

    /**
     * Sets the value of the productID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductID(String value) {
        this.productID = value;
    }

}
