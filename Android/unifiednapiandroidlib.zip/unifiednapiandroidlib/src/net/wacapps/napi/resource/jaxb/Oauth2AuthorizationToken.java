/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Oauth2AuthorizationToken.
 */
public class Oauth2AuthorizationToken
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The client id. */
    protected String clientId;
    
    /** The redirect uri. */
    protected String redirectUri;
    
    /** The response type. */
    protected String responseType;
    
    /** The scope. */
    protected String scope;
    
    /** The state. */
    protected String state;

    /**
	 * Gets the value of the clientId property.
	 * 
	 * @return the client id possible object is {@link String }
	 */
    public String getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientId(String value) {
        this.clientId = value;
    }

    /**
	 * Gets the value of the redirectUriOAuth2 property.
	 * 
	 * @return the redirect uri possible object is {@link String }
	 */
    public String getRedirectUri() {
        return redirectUri;
    }

    /**
     * Sets the value of the redirectUriOAuth2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRedirectUri(String value) {
        this.redirectUri = value;
    }

    /**
	 * Gets the value of the responseType property.
	 * 
	 * @return the response type possible object is {@link String }
	 */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
	 * Gets the value of the scope property.
	 * 
	 * @return the scope possible object is {@link String }
	 */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    /**
	 * Gets the value of the state property.
	 * 
	 * @return the state possible object is {@link String }
	 */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

}
