/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class PaymentAmount.
 */
public class PaymentAmount
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The charging information. */
    protected ChargingInformation chargingInformation;
    
    /** The total amount charged. */
    protected double totalAmountCharged = -1;

    /**
	 * Gets the value of the chargingInformation property.
	 * 
	 * @return the charging information possible object is
	 *         {@link ChargingInformation }
	 */
    public ChargingInformation getChargingInformation() {
        return chargingInformation;
    }

    /**
     * Sets the value of the chargingInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link ChargingInformation }
     *     
     */
    public void setChargingInformation(ChargingInformation value) {
        this.chargingInformation = value;
    }

    /**
	 * Gets the value of the totalAmountCharged property.
	 * 
	 * @return the total amount charged
	 */
    public double getTotalAmountCharged() {
        return totalAmountCharged;
    }

    /**
	 * Sets the value of the totalAmountCharged property.
	 * 
	 * @param value
	 *            the new total amount charged
	 */
    public void setTotalAmountCharged(double value) {
        this.totalAmountCharged = value;
    }

}
