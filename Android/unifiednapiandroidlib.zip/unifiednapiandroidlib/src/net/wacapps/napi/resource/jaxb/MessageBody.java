/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class MessageBody.
 */
public class MessageBody
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The payment. */
    protected Payment payment;
    
    /** The transaction. */
    protected Transaction transaction;
    
    /** The invalid request error. */
    protected InvalidRequestError invalidRequestError;
    
    /** The generic error. */
    protected GenericError genericError;
    
    /** The transaction list. */
    protected TransactionList transactionList;
    
    /** The prepare authentication identifier. */
    protected PrepareAuthenticationIdentifier prepareAuthenticationIdentifier;
    
    /** The customer reference. */
    protected CustomerReference customerReference;
    
    /** The gateway response. */
    protected GatewayResponse gatewayResponse;
    
    /** The oauth2 authorization token. */
    protected Oauth2AuthorizationToken oauth2AuthorizationToken;
    
    /** The oauth2 authorization. */
    protected Oauth2Authorization oauth2Authorization;
    
    /** The oauth2 authorization proxy token. */
    protected Oauth2AuthorizationProxyToken oauth2AuthorizationProxyToken;
    
    /** The oauth2 authentication token. */
    protected Oauth2AuthenticationToken oauth2AuthenticationToken;
    
    /** The oauth2 access token. */
    protected Oauth2AccessToken oauth2AccessToken;
    
    /** The oauth1 authorization. */
    protected Oauth1Authorization oauth1Authorization;
    
    /** The oauth1 token. */
    protected Oauth1Token oauth1Token;
    
    /** The oauth1 authorization token. */
    protected Oauth1AuthorizationToken oauth1AuthorizationToken;
    
    /** The oauth1 authorization proxy token. */
    protected Oauth1AuthorizationProxyToken oauth1AuthorizationProxyToken;
    
    /** The oauth1 authorization verifier. */
    protected Oauth1AuthorizationVerifier oauth1AuthorizationVerifier;

    /**
	 * Gets the value of the payment property.
	 * 
	 * @return the payment possible object is {@link Payment }
	 */
    public Payment getPayment() {
        return payment;
    }

    /**
     * Sets the value of the payment property.
     * 
     * @param value
     *     allowed object is
     *     {@link Payment }
     *     
     */
    public void setPayment(Payment value) {
        this.payment = value;
    }

    /**
	 * Gets the value of the transaction property.
	 * 
	 * @return the transaction possible object is {@link Transaction }
	 */
    public Transaction getTransaction() {
        return transaction;
    }

    /**
     * Sets the value of the transaction property.
     * 
     * @param value
     *     allowed object is
     *     {@link Transaction }
     *     
     */
    public void setTransaction(Transaction value) {
        this.transaction = value;
    }

    /**
	 * Gets the value of the invalidRequestError property.
	 * 
	 * @return the invalid request error possible object is
	 *         {@link InvalidRequestError }
	 */
    public InvalidRequestError getInvalidRequestError() {
        return invalidRequestError;
    }

    /**
     * Sets the value of the invalidRequestError property.
     * 
     * @param value
     *     allowed object is
     *     {@link InvalidRequestError }
     *     
     */
    public void setInvalidRequestError(InvalidRequestError value) {
        this.invalidRequestError = value;
    }

    /**
	 * Gets the value of the genericError property.
	 * 
	 * @return the generic error possible object is {@link GenericError }
	 */
    public GenericError getGenericError() {
        return genericError;
    }

    /**
     * Sets the value of the genericError property.
     * 
     * @param value
     *     allowed object is
     *     {@link GenericError }
     *     
     */
    public void setGenericError(GenericError value) {
        this.genericError = value;
    }

    /**
	 * Gets the value of the transactionList property.
	 * 
	 * @return the transaction list possible object is {@link TransactionList }
	 */
    public TransactionList getTransactionList() {
        return transactionList;
    }

    /**
     * Sets the value of the transactionList property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionList }
     *     
     */
    public void setTransactionList(TransactionList value) {
        this.transactionList = value;
    }

    /**
	 * Gets the value of the prepareAuthenticationIdentifier property.
	 * 
	 * @return the prepare authentication identifier possible object is
	 *         {@link PrepareAuthenticationIdentifier }
	 */
    public PrepareAuthenticationIdentifier getPrepareAuthenticationIdentifier() {
        return prepareAuthenticationIdentifier;
    }

    /**
     * Sets the value of the prepareAuthenticationIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link PrepareAuthenticationIdentifier }
     *     
     */
    public void setPrepareAuthenticationIdentifier(PrepareAuthenticationIdentifier value) {
        this.prepareAuthenticationIdentifier = value;
    }

    /**
	 * Gets the value of the customerReference property.
	 * 
	 * @return the customer reference possible object is
	 *         {@link CustomerReference }
	 */
    public CustomerReference getCustomerReference() {
        return customerReference;
    }

    /**
     * Sets the value of the customerReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerReference }
     *     
     */
    public void setCustomerReference(CustomerReference value) {
        this.customerReference = value;
    }

    /**
	 * Gets the value of the gatewayResponse property.
	 * 
	 * @return the gateway response possible object is {@link GatewayResponse }
	 */
    public GatewayResponse getGatewayResponse() {
        return gatewayResponse;
    }

    /**
     * Sets the value of the gatewayResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link GatewayResponse }
     *     
     */
    public void setGatewayResponse(GatewayResponse value) {
        this.gatewayResponse = value;
    }

    /**
	 * Gets the value of the oauth2AuthorizationToken property.
	 * 
	 * @return the oauth2 authorization token possible object is
	 *         {@link Oauth2AuthorizationToken }
	 */
    public Oauth2AuthorizationToken getOauth2AuthorizationToken() {
        return oauth2AuthorizationToken;
    }

    /**
     * Sets the value of the oauth2AuthorizationToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth2AuthorizationToken }
     *     
     */
    public void setOauth2AuthorizationToken(Oauth2AuthorizationToken value) {
        this.oauth2AuthorizationToken = value;
    }

    /**
	 * Gets the value of the oauth2Authorization property.
	 * 
	 * @return the oauth2 authorization possible object is
	 *         {@link Oauth2Authorization }
	 */
    public Oauth2Authorization getOauth2Authorization() {
        return oauth2Authorization;
    }

    /**
     * Sets the value of the oauth2Authorization property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth2Authorization }
     *     
     */
    public void setOauth2Authorization(Oauth2Authorization value) {
        this.oauth2Authorization = value;
    }

    /**
	 * Gets the value of the oauth2AuthorizationProxyToken property.
	 * 
	 * @return the oauth2 authorization proxy token possible object is
	 *         {@link Oauth2AuthorizationProxyToken }
	 */
    public Oauth2AuthorizationProxyToken getOauth2AuthorizationProxyToken() {
        return oauth2AuthorizationProxyToken;
    }

    /**
     * Sets the value of the oauth2AuthorizationProxyToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth2AuthorizationProxyToken }
     *     
     */
    public void setOauth2AuthorizationProxyToken(Oauth2AuthorizationProxyToken value) {
        this.oauth2AuthorizationProxyToken = value;
    }

    /**
	 * Gets the value of the oauth2AuthenticationToken property.
	 * 
	 * @return the oauth2 authentication token possible object is
	 *         {@link Oauth2AuthenticationToken }
	 */
    public Oauth2AuthenticationToken getOauth2AuthenticationToken() {
        return oauth2AuthenticationToken;
    }

    /**
     * Sets the value of the oauth2AuthenticationToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth2AuthenticationToken }
     *     
     */
    public void setOauth2AuthenticationToken(Oauth2AuthenticationToken value) {
        this.oauth2AuthenticationToken = value;
    }

    /**
	 * Gets the value of the oauth2AccessToken property.
	 * 
	 * @return the oauth2 access token possible object is
	 *         {@link Oauth2AccessToken }
	 */
    public Oauth2AccessToken getOauth2AccessToken() {
        return oauth2AccessToken;
    }

    /**
     * Sets the value of the oauth2AccessToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth2AccessToken }
     *     
     */
    public void setOauth2AccessToken(Oauth2AccessToken value) {
        this.oauth2AccessToken = value;
    }

    /**
	 * Gets the value of the oauth1Authorization property.
	 * 
	 * @return the oauth1 authorization possible object is
	 *         {@link Oauth1Authorization }
	 */
    public Oauth1Authorization getOauth1Authorization() {
        return oauth1Authorization;
    }

    /**
     * Sets the value of the oauth1Authorization property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth1Authorization }
     *     
     */
    public void setOauth1Authorization(Oauth1Authorization value) {
        this.oauth1Authorization = value;
    }

    /**
	 * Gets the value of the oauth1Token property.
	 * 
	 * @return the oauth1 token possible object is {@link Oauth1Token }
	 */
    public Oauth1Token getOauth1Token() {
        return oauth1Token;
    }

    /**
     * Sets the value of the oauth1Token property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth1Token }
     *     
     */
    public void setOauth1Token(Oauth1Token value) {
        this.oauth1Token = value;
    }

    /**
	 * Gets the value of the oauth1AuthorizationToken property.
	 * 
	 * @return the oauth1 authorization token possible object is
	 *         {@link Oauth1AuthorizationToken }
	 */
    public Oauth1AuthorizationToken getOauth1AuthorizationToken() {
        return oauth1AuthorizationToken;
    }

    /**
     * Sets the value of the oauth1AuthorizationToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth1AuthorizationToken }
     *     
     */
    public void setOauth1AuthorizationToken(Oauth1AuthorizationToken value) {
        this.oauth1AuthorizationToken = value;
    }

    /**
	 * Gets the value of the oauth1AuthorizationProxyToken property.
	 * 
	 * @return the oauth1 authorization proxy token possible object is
	 *         {@link Oauth1AuthorizationProxyToken }
	 */
    public Oauth1AuthorizationProxyToken getOauth1AuthorizationProxyToken() {
        return oauth1AuthorizationProxyToken;
    }

    /**
     * Sets the value of the oauth1AuthorizationProxyToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth1AuthorizationProxyToken }
     *     
     */
    public void setOauth1AuthorizationProxyToken(Oauth1AuthorizationProxyToken value) {
        this.oauth1AuthorizationProxyToken = value;
    }

    /**
	 * Gets the value of the oauth1AuthorizationVerifier property.
	 * 
	 * @return the oauth1 authorization verifier possible object is
	 *         {@link Oauth1AuthorizationVerifier }
	 */
    public Oauth1AuthorizationVerifier getOauth1AuthorizationVerifier() {
        return oauth1AuthorizationVerifier;
    }

    /**
     * Sets the value of the oauth1AuthorizationVerifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link Oauth1AuthorizationVerifier }
     *     
     */
    public void setOauth1AuthorizationVerifier(Oauth1AuthorizationVerifier value) {
        this.oauth1AuthorizationVerifier = value;
    }

}
