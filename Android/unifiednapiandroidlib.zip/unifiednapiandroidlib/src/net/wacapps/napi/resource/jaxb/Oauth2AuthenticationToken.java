/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Oauth2AuthenticationToken.
 */
public class Oauth2AuthenticationToken
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The code. */
    protected String code;
    
    /** The client id. */
    protected String clientId;
    
    /** The client secret. */
    protected String clientSecret;
    
    /** The redirect uri. */
    protected String redirectUri;
    
    /** The grant type. */
    protected String grantType;
    
    /** The username. */
    protected String username;
    
    /** The password. */
    protected String password;
    
    /** The refresh token. */
    protected String refreshToken;

    /**
	 * Gets the value of the code property.
	 * 
	 * @return the code possible object is {@link String }
	 */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
	 * Gets the value of the clientId property.
	 * 
	 * @return the client id possible object is {@link String }
	 */
    public String getClientId() {
        return clientId;
    }

    /**
     * Sets the value of the clientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientId(String value) {
        this.clientId = value;
    }

    /**
	 * Gets the value of the clientSecret property.
	 * 
	 * @return the client secret possible object is {@link String }
	 */
    public String getClientSecret() {
        return clientSecret;
    }

    /**
     * Sets the value of the clientSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientSecret(String value) {
        this.clientSecret = value;
    }

    /**
	 * Gets the value of the redirectUriOAuth2 property.
	 * 
	 * @return the redirect uri possible object is {@link String }
	 */
    public String getRedirectUri() {
        return redirectUri;
    }

    /**
     * Sets the value of the redirectUriOAuth2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRedirectUri(String value) {
        this.redirectUri = value;
    }

    /**
	 * Gets the value of the grantType property.
	 * 
	 * @return the grant type possible object is {@link String }
	 */
    public String getGrantType() {
        return grantType;
    }

    /**
     * Sets the value of the grantType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGrantType(String value) {
        this.grantType = value;
    }

    /**
	 * Gets the value of the username property.
	 * 
	 * @return the username possible object is {@link String }
	 */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the value of the username property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsername(String value) {
        this.username = value;
    }

    /**
	 * Gets the value of the password property.
	 * 
	 * @return the password possible object is {@link String }
	 */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the value of the password property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassword(String value) {
        this.password = value;
    }

    /**
	 * Gets the value of the refreshToken property.
	 * 
	 * @return the refresh token possible object is {@link String }
	 */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * Sets the value of the refreshToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefreshToken(String value) {
        this.refreshToken = value;
    }

}
