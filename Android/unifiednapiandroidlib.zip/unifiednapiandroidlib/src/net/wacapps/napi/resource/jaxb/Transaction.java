/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * Holds the data related to payment transactions. For now, this is used to get and set amount transaction
 * 
 */
public class Transaction
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The amount transaction. */
    protected AmountTransaction amountTransaction;

    /**
	 * Gets the value of the amountTransaction property.
	 * 
	 * @return the amount transaction possible object is
	 *         {@link AmountTransaction }
	 */
    public AmountTransaction getAmountTransaction() {
        return amountTransaction;
    }

    /**
     * Sets the value of the amountTransaction property.
     * 
     * @param value
     *     allowed object is
     *     {@link AmountTransaction }
     *     
     */
    public void setAmountTransaction(AmountTransaction value) {
        this.amountTransaction = value;
    }

}
