/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class CustomerReference.
 */
public class CustomerReference
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The acr. */
    protected String acr;

    /**
	 * Gets the value of the acr property.
	 * 
	 * @return the acr possible object is {@link String }
	 */
    public String getAcr() {
        return acr;
    }

    /**
     * Sets the value of the acr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcr(String value) {
        this.acr = value;
    }

}
