/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;


/**
 * The Class Oauth1AuthorizationVerifier.
 */
public class Oauth1AuthorizationVerifier
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The oauth verifier. */
    protected String oauthVerifier;
    
    /** The oauth token. */
    protected String oauthToken;

    /**
	 * Gets the value of the oauthVerifier property.
	 * 
	 * @return the oauth verifier possible object is {@link String }
	 */
    public String getOauthVerifier() {
        return oauthVerifier;
    }

    /**
     * Sets the value of the oauthVerifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthVerifier(String value) {
        this.oauthVerifier = value;
    }

    /**
	 * Gets the value of the oauthToken property.
	 * 
	 * @return the oauth token possible object is {@link String }
	 */
    public String getOauthToken() {
        return oauthToken;
    }

    /**
     * Sets the value of the oauthToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOauthToken(String value) {
        this.oauthToken = value;
    }

}
