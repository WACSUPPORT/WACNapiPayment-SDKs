/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class Response.
 */
public class Response
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The operator. */
    protected Operator operator;
    
    /** The operators. */
    protected List<Operator> operators;
    
    /** The product. */
    protected Product product;

    /**
	 * Gets the value of the operator property.
	 * 
	 * @return the operator possible object is {@link Operator }
	 */
    public Operator getOperator() {
        return operator;
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Operator }
     *     
     */
    public void setOperator(Operator value) {
        this.operator = value;
    }

    /**
	 * Gets the value of the operators property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the operators property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getOperators().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * 
	 * @return the operators {@link Operator }
	 */
    public List<Operator> getOperators() {
        if (operators == null) {
            operators = new ArrayList<Operator>();
        }
        return this.operators;
    }

    /**
	 * Gets the value of the product property.
	 * 
	 * @return the product possible object is {@link Product }
	 */
    public Product getProduct() {
        return product;
    }

    /**
     * Sets the value of the product property.
     * 
     * @param value
     *     allowed object is
     *     {@link Product }
     *     
     */
    public void setProduct(Product value) {
        this.product = value;
    }

}
