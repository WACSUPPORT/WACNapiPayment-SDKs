/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class PaymentApi.
 */
public class PaymentApi
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The uri. */
    protected String uri;
    
    /** The pos. */
    protected boolean pos;
    
    /** The currency. */
    protected String currency;

    /**
	 * Gets the value of the uri property.
	 * 
	 * @return the uri possible object is {@link String }
	 */
    public String getUri() {
        return uri;
    }

    /**
     * Sets the value of the uri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUri(String value) {
        this.uri = value;
    }

    /**
	 * Gets the value of the pos property.
	 * 
	 * @return true, if is pos
	 */
    public boolean isPos() {
        return pos;
    }

    /**
	 * Sets the value of the pos property.
	 * 
	 * @param value
	 *            the new pos
	 */
    public void setPos(boolean value) {
        this.pos = value;
    }

    /**
	 * Gets the value of the currency property.
	 * 
	 * @return the currency possible object is {@link String }
	 */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

}
