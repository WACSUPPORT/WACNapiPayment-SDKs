/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class ChargingInformation.
 */
public class ChargingInformation
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The amount. */
    protected Double amount;
    
    /** The code. */
    protected String code;
    
    /** The currency. */
    protected String currency;
    
    /** The description. */
    protected String description;

    /**
	 * Gets the value of the amount property.
	 * 
	 * @return the amount possible object is {@link Double }
	 */
    public Double getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setAmount(Double value) {
        this.amount = value;
    }

    /**
	 * Gets the value of the code property.
	 * 
	 * @return the code possible object is {@link String }
	 */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
	 * Gets the value of the currency property.
	 * 
	 * @return the currency possible object is {@link String }
	 */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
	 * Gets the value of the description property.
	 * 
	 * @return the description possible object is {@link String }
	 */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

}
