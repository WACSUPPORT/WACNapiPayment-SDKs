/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class Apis.
 */
public class Apis
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The uri. */
    protected String uri;
    
    /** The authorization. */
    protected AuthorizationApi authorization;
    
    /** The query. */
    protected QueryApi query;
    
    /** The payment. */
    protected PaymentApi payment;

    /**
	 * Gets the value of the uri property.
	 * 
	 * @return the uri possible object is {@link String }
	 */
    public String getUri() {
        return uri;
    }

    /**
     * Sets the value of the uri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUri(String value) {
        this.uri = value;
    }

    /**
	 * Gets the value of the authorization property.
	 * 
	 * @return the authorization possible object is {@link AuthorizationApi }
	 */
    public AuthorizationApi getAuthorization() {
        return authorization;
    }

    /**
     * Sets the value of the authorization property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuthorizationApi }
     *     
     */
    public void setAuthorization(AuthorizationApi value) {
        this.authorization = value;
    }

    /**
	 * Gets the value of the query property.
	 * 
	 * @return the query possible object is {@link QueryApi }
	 */
    public QueryApi getQuery() {
        return query;
    }

    /**
     * Sets the value of the query property.
     * 
     * @param value
     *     allowed object is
     *     {@link QueryApi }
     *     
     */
    public void setQuery(QueryApi value) {
        this.query = value;
    }

    /**
	 * Gets the value of the payment property.
	 * 
	 * @return the payment possible object is {@link PaymentApi }
	 */
    public PaymentApi getPayment() {
        return payment;
    }

    /**
     * Sets the value of the payment property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentApi }
     *     
     */
    public void setPayment(PaymentApi value) {
        this.payment = value;
    }

}
