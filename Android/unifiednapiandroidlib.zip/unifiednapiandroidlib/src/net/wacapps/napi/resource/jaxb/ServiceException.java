/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.resource.jaxb;

import java.io.Serializable;

/**
 * The Class ServiceException.
 */
public class ServiceException
    implements Serializable
{

    /** The Constant serialVersionUID. */
    private final static long serialVersionUID = 1L;
    
    /** The message id. */
    protected String messageId;
    
    /** The text. */
    protected String text;
    
    /** The variables. */
    protected String variables;

    /**
	 * Gets the value of the messageId property.
	 * 
	 * @return the message id possible object is {@link String }
	 */
    public String getMessageId() {
        return messageId;
    }

    /**
     * Sets the value of the messageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageId(String value) {
        this.messageId = value;
    }

    /**
	 * Gets the value of the text property.
	 * 
	 * @return the text possible object is {@link String }
	 */
    public String getText() {
        return text;
    }

    /**
     * Sets the value of the text property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

    /**
	 * Gets the value of the variables property.
	 * 
	 * @return the variables possible object is {@link String }
	 */
    public String getVariables() {
        return variables;
    }

    /**
     * Sets the value of the variables property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVariables(String value) {
        this.variables = value;
    }

}
