/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.xdo.developer;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class Developers.
 */
public class Developers {

    /** The developer. */
    protected List<Developer> developer;

    /**
	 * Gets the value of the developer property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the developer property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getDeveloper().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * 
	 * @return the developer {@link Developer }
	 */
    public List<Developer> getDeveloper() {
        if (developer == null) {
            developer = new ArrayList<Developer>();
        }
        return this.developer;
    }

}
