/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
/*
 * 
 */
package net.wacapps.napi.xdo.operator;

/**
 * The Class Api.
 */
public class Api {

    /** The endpoints. */
    protected Endpoints endpoints;
    
    /** The properties. */
    protected Properties properties;
    
    /** The discoverable. */
    protected boolean discoverable;
    
    /** The name. */
    protected String name;
    
    /** The proxy. */
    protected boolean proxy;
    
    /** The status. */
    protected String status;

    /**
     * Gets the value of the endpoints property.
     *
     * @return the endpoints
     * possible object is
     * {@link Endpoints }
     */
    public Endpoints getEndpoints() {
        return endpoints;
    }

    /**
     * Sets the value of the endpoints property.
     * 
     * @param value
     *     allowed object is
     *     {@link Endpoints }
     *     
     */
    public void setEndpoints(Endpoints value) {
        this.endpoints = value;
    }

    /**
     * Gets the value of the properties property.
     *
     * @return the properties
     * possible object is
     * {@link Properties }
     */
    public Properties getProperties() {
        return properties;
    }

    /**
     * Sets the value of the properties property.
     * 
     * @param value
     *     allowed object is
     *     {@link Properties }
     *     
     */
    public void setProperties(Properties value) {
        this.properties = value;
    }

    /**
     * Gets the value of the discoverable property.
     *
     * @return true, if is discoverable
     */
    public boolean isDiscoverable() {
        return discoverable;
    }

    /**
     * Sets the value of the discoverable property.
     *
     * @param value the new discoverable
     */
    public void setDiscoverable(boolean value) {
        this.discoverable = value;
    }

    /**
     * Gets the value of the name property.
     *
     * @return the name
     * possible object is
     * {@link String }
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the proxy property.
     *
     * @return true, if is proxy
     */
    public boolean isProxy() {
        return proxy;
    }

    /**
     * Sets the value of the proxy property.
     *
     * @param value the new proxy
     */
    public void setProxy(boolean value) {
        this.proxy = value;
    }

    /**
     * Gets the value of the status property.
     *
     * @return the status
     * possible object is
     * {@link String }
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
