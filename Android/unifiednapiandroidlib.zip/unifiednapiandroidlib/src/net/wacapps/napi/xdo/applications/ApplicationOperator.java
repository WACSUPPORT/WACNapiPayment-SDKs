/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.xdo.applications;

/**
 * The Class ApplicationOperator.
 */
public class ApplicationOperator {

    /** The mcc. */
    protected String mcc;
    
    /** The mnc. */
    protected String mnc;
    
    /** The status. */
    protected String status;

    /**
	 * Gets the value of the mcc property.
	 * 
	 * @return the mcc possible object is {@link String }
	 */
    public String getMcc() {
        return mcc;
    }

    /**
     * Sets the value of the mcc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMcc(String value) {
        this.mcc = value;
    }

    /**
	 * Gets the value of the mnc property.
	 * 
	 * @return the mnc possible object is {@link String }
	 */
    public String getMnc() {
        return mnc;
    }

    /**
     * Sets the value of the mnc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMnc(String value) {
        this.mnc = value;
    }

    /**
	 * Gets the value of the status property.
	 * 
	 * @return the status possible object is {@link String }
	 */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

}
