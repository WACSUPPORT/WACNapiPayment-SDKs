/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.xdo.applications;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The Class Pricepoint.
 */
public class Pricepoint {

    /** The currency. */
    protected String currency;
    
    /** The id. */
    protected BigInteger id;
    
    /** The locale. */
    protected String locale;
    
    /** The mcc. */
    protected BigInteger mcc;
    
    /** The mnc. */
    protected BigInteger mnc;
    
    /** The operator name. */
    protected String operatorName;
    
    /** The operator reference. */
    protected String operatorReference;
    
    /** The price. */
    protected BigDecimal price;
    
    /** The receipt. */
    protected String receipt;
    
    /** The text. */
    protected String text;

    /**
	 * Gets the value of the currency property.
	 * 
	 * @return the currency possible object is {@link String }
	 */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
	 * Gets the value of the id property.
	 * 
	 * @return the id possible object is {@link BigInteger }
	 */
    public BigInteger getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setId(BigInteger value) {
        this.id = value;
    }

    /**
	 * Gets the value of the locale property.
	 * 
	 * @return the locale possible object is {@link String }
	 */
    public String getLocale() {
        return locale;
    }

    /**
     * Sets the value of the locale property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocale(String value) {
        this.locale = value;
    }

    /**
	 * Gets the value of the mcc property.
	 * 
	 * @return the mcc possible object is {@link BigInteger }
	 */
    public BigInteger getMcc() {
        return mcc;
    }

    /**
     * Sets the value of the mcc property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMcc(BigInteger value) {
        this.mcc = value;
    }

    /**
	 * Gets the value of the mnc property.
	 * 
	 * @return the mnc possible object is {@link BigInteger }
	 */
    public BigInteger getMnc() {
        return mnc;
    }

    /**
     * Sets the value of the mnc property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMnc(BigInteger value) {
        this.mnc = value;
    }

    /**
	 * Gets the value of the operatorName property.
	 * 
	 * @return the operator name possible object is {@link String }
	 */
    public String getOperatorName() {
        return operatorName;
    }

    /**
     * Sets the value of the operatorName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorName(String value) {
        this.operatorName = value;
    }

    /**
	 * Gets the value of the operatorReference property.
	 * 
	 * @return the operator reference possible object is {@link String }
	 */
    public String getOperatorReference() {
        return operatorReference;
    }

    /**
     * Sets the value of the operatorReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatorReference(String value) {
        this.operatorReference = value;
    }

    /**
	 * Gets the value of the price property.
	 * 
	 * @return the price possible object is {@link BigDecimal }
	 */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPrice(BigDecimal value) {
        this.price = value;
    }

    /**
	 * Gets the value of the receipt property.
	 * 
	 * @return the receipt possible object is {@link String }
	 */
    public String getReceipt() {
        return receipt;
    }

    /**
     * Sets the value of the receipt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceipt(String value) {
        this.receipt = value;
    }

    /**
	 * Gets the value of the text property.
	 * 
	 * @return the text possible object is {@link String }
	 */
    public String getText() {
        return text;
    }

    /**
     * Sets the value of the text property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

}
