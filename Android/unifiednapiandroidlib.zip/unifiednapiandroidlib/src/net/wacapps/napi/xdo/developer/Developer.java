/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
/*
 * 
 */
package net.wacapps.napi.xdo.developer;

import java.math.BigInteger;

/**
 * The Class Developer.
 * 
 * The Class Developer records the details of a developer.
 * The details are used for payment purpose by WAC.
 * 
 */
public class Developer {

    /** The id. */
    protected BigInteger id;
    
    /** The first name. */
    protected String firstName;
    
    /** The last name. */
    protected String lastName;
    
    /** The email. */
    protected String email;
    
    /** The user name. */
    protected String userName;
    
    /** The status. */
    protected String status;
    
    /** The locale. */
    protected String locale;
    
    /** The organization. */
    protected String organization;
    
    /** The address. */
    protected String address;

    /**
	 * Gets the value of the id property.
	 * 
	 * @return the id possible object is {@link BigInteger }
	 */
    public BigInteger getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setId(BigInteger value) {
        this.id = value;
    }

    /**
	 * Gets the value of the firstName property.
	 * 
	 * @return the first name possible object is {@link String }
	 */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
	 * Gets the value of the lastName property.
	 * 
	 * @return the last name possible object is {@link String }
	 */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
	 * Gets the value of the email property.
	 * 
	 * @return the email possible object is {@link String }
	 */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
	 * Gets the value of the userName property.
	 * 
	 * @return the user name possible object is {@link String }
	 */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserName(String value) {
        this.userName = value;
    }

    /**
	 * Gets the value of the status property.
	 * 
	 * @return the status possible object is {@link String }
	 */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
	 * Gets the value of the locale property.
	 * 
	 * @return the locale possible object is {@link String }
	 */
    public String getLocale() {
        return locale;
    }

    /**
     * Sets the value of the locale property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocale(String value) {
        this.locale = value;
    }

    /**
	 * Gets the value of the organization property.
	 * 
	 * @return the organization possible object is {@link String }
	 */
    public String getOrganization() {
        return organization;
    }

    /**
     * Sets the value of the organization property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganization(String value) {
        this.organization = value;
    }

    /**
	 * Gets the value of the address property.
	 * 
	 * @return the address possible object is {@link String }
	 */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

}
