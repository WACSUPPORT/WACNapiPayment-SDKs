/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.xdo.applications;

import java.math.BigInteger;

/**
 * The Class Application.
 */
public class Application {

    /** The id. */
    protected String id;
    
    /** The name. */
    protected String name;
    
    /** The version. */
    protected String version;
    
    /** The application identifier. */
    protected String applicationIdentifier;
    
    /** The title. */
    protected String title;
    
    /** The description. */
    protected String description;
    
    /** The type. */
    protected String type;
    
    /** The developer name. */
    protected String developerName;
    
    /** The product items. */
    protected ProductItems productItems;
    
    /** The application apis. */
    protected ApplicationApis applicationApis;
    
    /** The application operators. */
    protected ApplicationOperators applicationOperators;
    
    /** The credentials. */
    protected Credentials credentials;

    /**
	 * Gets the value of the id property.
	 * 
	 * @return the id possible object is {@link String }
	 */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
	 * Gets the value of the name property.
	 * 
	 * @return the name possible object is {@link String }
	 */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
	 * Gets the value of the version property.
	 * 
	 * @return the version possible object is {@link String }
	 */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
	 * Gets the value of the applicationIdentifier property.
	 * 
	 * @return the application identifier possible object is {@link String }
	 */
    public String getApplicationIdentifier() {
        return applicationIdentifier;
    }

    /**
     * Sets the value of the applicationIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationIdentifier(String value) {
        this.applicationIdentifier = value;
    }

    /**
	 * Gets the value of the title property.
	 * 
	 * @return the title possible object is {@link String }
	 */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
	 * Gets the value of the description property.
	 * 
	 * @return the description possible object is {@link String }
	 */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
	 * Gets the value of the type property.
	 * 
	 * @return the type possible object is {@link String }
	 */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
	 * Gets the value of the developerName property.
	 * 
	 * @return the developer name possible object is {@link String }
	 */
    public String getDeveloperName() {
        return developerName;
    }

    /**
     * Sets the value of the developerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeveloperName(String value) {
        this.developerName = value;
    }

    /**
	 * Gets the value of the productItems property.
	 * 
	 * @return the product items possible object is {@link ProductItems }
	 */
    public ProductItems getProductItems() {
        return productItems;
    }

    /**
     * Sets the value of the productItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductItems }
     *     
     */
    public void setProductItems(ProductItems value) {
        this.productItems = value;
    }

    /**
	 * Gets the value of the applicationApis property.
	 * 
	 * @return the application apis possible object is {@link ApplicationApis }
	 */
    public ApplicationApis getApplicationApis() {
        return applicationApis;
    }

    /**
     * Sets the value of the applicationApis property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationApis }
     *     
     */
    public void setApplicationApis(ApplicationApis value) {
        this.applicationApis = value;
    }

    /**
	 * Gets the value of the applicationOperators property.
	 * 
	 * @return the application operators possible object is
	 *         {@link ApplicationOperators }
	 */
    public ApplicationOperators getApplicationOperators() {
        return applicationOperators;
    }

    /**
     * Sets the value of the applicationOperators property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationOperators }
     *     
     */
    public void setApplicationOperators(ApplicationOperators value) {
        this.applicationOperators = value;
    }

    /**
	 * Gets the value of the credentials property.
	 * 
	 * @return the credentials possible object is {@link Credentials }
	 */
    public Credentials getCredentials() {
        return credentials;
    }

    /**
     * Sets the value of the credentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link Credentials }
     *     
     */
    public void setCredentials(Credentials value) {
        this.credentials = value;
    }

}
