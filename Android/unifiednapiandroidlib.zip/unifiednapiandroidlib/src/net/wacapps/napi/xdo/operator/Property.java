/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
/*
* Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
* The use of this SDK is subject to the terms and conditions in license.txt 
*/

package net.wacapps.napi.xdo.operator;

/**
 * The Class Property.
 */
public class Property {

    /** The name. */
    protected String name;
    
    /** The value. */
    protected String value;

    /**
     * Gets the value of the name property.
     *
     * @return the name
     * possible object is
     * {@link String }
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the value property.
     *
     * @return the value
     * possible object is
     * {@link String }
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

}
