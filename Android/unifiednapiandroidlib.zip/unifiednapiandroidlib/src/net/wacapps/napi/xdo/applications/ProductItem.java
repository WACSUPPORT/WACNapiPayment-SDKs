/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.xdo.applications;

/**
 * The Class ProductItem.
 */
public class ProductItem {

    /** The name. */
    protected String name;
    
    /** The product identifier. */
    protected String productIdentifier;
    
    /** The pricepoints. */
    protected Pricepoints pricepoints;

    /**
	 * Gets the value of the name property.
	 * 
	 * @return the name possible object is {@link String }
	 */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
	 * Gets the value of the productIdentifier property.
	 * 
	 * @return the product identifier possible object is {@link String }
	 */
    public String getProductIdentifier() {
        return productIdentifier!=null ? productIdentifier.trim() :  null;
    }

    /**
     * Sets the value of the productIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductIdentifier(String value) {
        this.productIdentifier = value;
    }

    /**
	 * Gets the value of the pricepoints property.
	 * 
	 * @return the pricepoints possible object is {@link Pricepoints }
	 */
    public Pricepoints getPricepoints() {
        return pricepoints;
    }

    /**
     * Sets the value of the pricepoints property.
     * 
     * @param value
     *     allowed object is
     *     {@link Pricepoints }
     *     
     */
    public void setPricepoints(Pricepoints value) {
        this.pricepoints = value;
    }

}
