/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
/*
 * 
 */

package net.wacapps.napi.xdo.operator;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * The Class Operator.
 */
public class Operator {

    /** The api. */
    protected List<Api> api;
    
    /** The mcc. */
    protected BigInteger mcc;
    
    /** The mnc. */
    protected BigInteger mnc;
    
    /** The name. */
    protected String name;
    
    /** The updated date. */
    protected String updatedDate;

    /**
     * Gets the value of the api property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the api property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     * getApi().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     *
     * @return the api
     * {@link Api }
     */
    public List<Api> getApi() {
        if (api == null) {
            api = new ArrayList<Api>();
        }
        return this.api;
    }

    /**
     * Gets the value of the mcc property.
     *
     * @return the mcc
     * possible object is
     * {@link BigInteger }
     */
    public BigInteger getMcc() {
        return mcc;
    }

    /**
     * Sets the value of the mcc property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMcc(BigInteger value) {
        this.mcc = value;
    }

    /**
     * Gets the value of the mnc property.
     *
     * @return the mnc
     * possible object is
     * {@link BigInteger }
     */
    public BigInteger getMnc() {
        return mnc;
    }

    /**
     * Sets the value of the mnc property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMnc(BigInteger value) {
        this.mnc = value;
    }

    /**
     * Gets the value of the name property.
     *
     * @return the name
     * possible object is
     * {@link String }
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the updatedDate property.
     *
     * @return the updated date
     * possible object is
     * {@link String }
     */
    public String getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the value of the updatedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedDate(String value) {
        this.updatedDate = value;
    }

}
