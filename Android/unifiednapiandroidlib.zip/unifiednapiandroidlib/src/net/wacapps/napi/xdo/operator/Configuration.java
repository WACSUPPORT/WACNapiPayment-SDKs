/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
/*
 * 
 */

package net.wacapps.napi.xdo.operator;

import java.util.ArrayList;
import java.util.List;


/**
 * The Class Configuration.
 */
public class Configuration {
 
    /** The operator. */
    protected List<Operator> operator;
    
    /** The environment. */
    protected String environment;

    /**
     * Gets the value of the operator property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the operator property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     * getOperator().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     *
     * @return the operator
     * {@link Operator }
     */
    public List<Operator> getOperator() {
        if (operator == null) {
            operator = new ArrayList<Operator>();
        }
        return this.operator;
    }

    /**
     * Gets the value of the environment property.
     *
     * @return the environment
     * possible object is
     * {@link String }
     */
    public String getEnvironment() {
        return environment;
    }

    /**
     * Sets the value of the environment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnvironment(String value) {
        this.environment = value;
    }

}
