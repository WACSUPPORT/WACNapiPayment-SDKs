/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
/*
 * 
 */
package net.wacapps.napi.xdo.operator;

/**
 * The Class Endpoint.
 */
public class Endpoint {

    /** The allowed methods. */
    protected String allowedMethods;
    
    /** The name. */
    protected String name;
    
    /** The uri. */
    protected String uri;

    /**
     * Gets the value of the allowedMethods property.
     *
     * @return the allowed methods
     * possible object is
     * {@link String }
     */
    public String getAllowedMethods() {
        return allowedMethods;
    }

    /**
     * Sets the value of the allowedMethods property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllowedMethods(String value) {
        this.allowedMethods = value;
    }

    /**
     * Gets the value of the name property.
     *
     * @return the name
     * possible object is
     * {@link String }
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the uri property.
     *
     * @return the uri
     * possible object is
     * {@link String }
     */
    public String getUri() {
        return uri;
    }

    /**
     * Sets the value of the uri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUri(String value) {
        this.uri = value;
    }

}
