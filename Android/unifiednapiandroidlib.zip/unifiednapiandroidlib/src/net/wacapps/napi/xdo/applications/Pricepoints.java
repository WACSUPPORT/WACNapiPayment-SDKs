/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.xdo.applications;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class Pricepoints.
 */
public class Pricepoints {

    /** The pricepoint. */
    protected List<Pricepoint> pricepoint;

    /**
	 * Gets the value of the pricepoint property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the pricepoint property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getPricepoint().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list
	 * 
	 * @return the pricepoint {@link Pricepoint }
	 */
    public List<Pricepoint> getPricepoint() {
        if (pricepoint == null) {
            pricepoint = new ArrayList<Pricepoint>();
        }
        return this.pricepoint;
    }

}
