/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

/**
 * The Interface ContentDeliveryCallback.
 * Implemented by calling applications so that NAPI SDK knows when content delivery is finished
 */
public interface ContentDeliveryCallback {
	
	/**
	 * Deliver content.
	 *
	 * @return true, if successful
	 */
	public abstract boolean deliverContent();

}
