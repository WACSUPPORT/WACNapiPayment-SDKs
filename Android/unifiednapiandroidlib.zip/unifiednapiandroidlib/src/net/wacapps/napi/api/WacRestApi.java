/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

import static net.wacapps.napi.api.Util.oEncode;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import net.wacapps.napi.android.WacNapiContext;
import net.wacapps.napi.resource.jaxb.GatewayError;
import net.wacapps.napi.resource.jaxb.GatewayResponse;
import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.Oauth2AccessToken;
import net.wacapps.napi.resource.jaxb.Operator;
import net.wacapps.napi.resource.jaxb.Product;
import net.wacapps.napi.resource.jaxb.RequestError;
import net.wacapps.napi.resource.jaxb.ServiceException;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionList;
import net.wacapps.napi.util.Base64;
import static net.wacapps.napi.util.LocalizationHelper.getMessage;
import static net.wacapps.napi.util.LocalizationHelper.getMessageTranslationForMessage;
import net.wacapps.napi.util.NapiHttpHelper;
import net.wacapps.napi.util.NapiLog;
import net.wacapps.napi.xdo.applications.Application;
import net.wacapps.napi.xdo.applications.Credential;
import net.wacapps.napi.xdo.applications.ProductItem;
import net.wacapps.napi.xdo.developer.Developer;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * The Class WacRestApi.
 * 
 * This utility class allows running WAC APIs' like Discovery, Query, OAuth1
 * Payment.
 */

public class WacRestApi {

	/** The TAG is used to identify the name of a module in logs. */
	private static String TAG = "Wac";

	/** The master scope. */
	public static final String GET_POST_SCOPE = "GET,POST-/payment/acr:Authorization/transactions/amount";

	/** The rw scope. */
	public static final String POST_SCOPE = "POST-/payment/acr:Authorization/transactions/amount";

	/** The ro scope. */
	public static final String GET_SCOPE = "GET-/payment/acr:Authorization/transactions/amount";

	/**
	 * Retrieves an access token.
	 * 
	 * @param verifier
	 *            the verifier
	 * @param requestToken
	 *            the request token
	 * @param operator
	 *            the operator
	 * @param cred
	 *            the user credentials
	 * @param secret
	 *            the consumer secret
	 * @param oAuthSecret
	 *            the oAuth request token secret
	 * @param optionals
	 *            the optionals
	 * @return the OAuth1 access token
	 */
	public static HashMap<String, String> getOAuth1AccessToken(String verifier, String requestToken, Operator operator,
			String cred, String secret, String oAuthSecret, String... optionals) {

		NapiLog.d(TAG, "Verifier is : " + verifier);
		NapiLog.d(TAG, "Token is : " + requestToken);

		String sigBaseUrl = operator.getApis().getAuthorization().getUris().getAccessToken();

		String generatedNonce = UUID.randomUUID().toString();
		String timeStamp = String.valueOf(System.currentTimeMillis() / 1000L);

		String signatureBaseString1 = ("POST&" + Util.oEncode(sigBaseUrl) + "&");

		Map<String, String> params = new TreeMap<String, String>();

		params.put("oauth_consumer_key", cred);
		params.put("oauth_nonce", generatedNonce);
		params.put("oauth_signature_method", "HMAC-SHA1");
		params.put("oauth_timestamp", timeStamp);
		params.put("oauth_token", requestToken);
		params.put("oauth_verifier", verifier);
		params.put("oauth_version", "1.0");

		String signatureBaseString2 = NapiHttpHelper.keyValueParameters(params, ",");
		String signatureBaseString = signatureBaseString1 + oEncode(signatureBaseString2);
		NapiLog.d(TAG, "Sig String is : " + signatureBaseString);
		final String keyString;
		keyString = Util.oauthEncode(secret + "&" + oAuthSecret);
		NapiLog.d(TAG, "key string is : " + secret + "&" + oAuthSecret);
		SecretKey key = null;
		try {
			key = new SecretKeySpec(keyString.getBytes("UTF-8"), "HmacSHA1");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		String encodedString = null;
		try {
			final Mac mac = Mac.getInstance("HmacSHA1");
			mac.init(key);
			encodedString = new String(Base64.encode(mac.doFinal(signatureBaseString.getBytes("UTF-8"))));
			encodedString = Util.oauthEncode(encodedString);
			NapiLog.d(TAG, "Encoded String is " + encodedString);
		} catch (InvalidKeyException e) {
			throw new RuntimeException(getMessage("KEY_NOT_SUPPORTED"), e);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(getMessage("UNEXPECTED"), e);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		Map<String, String> oAuthHeaderParams = new HashMap<String, String>();

		oAuthHeaderParams.put("oauth_consumer_key", cred);
		oAuthHeaderParams.put("oauth_signature_method", oEncode("HMAC-SHA1"));
		oAuthHeaderParams.put("oauth_version", "1.0");
		oAuthHeaderParams.put("oauth_nonce", oEncode(generatedNonce));
		oAuthHeaderParams.put("oauth_timestamp", oEncode(timeStamp));
		oAuthHeaderParams.put("oauth_token", oEncode(requestToken));
		oAuthHeaderParams.put("oauth_verifier", oEncode(verifier));
		oAuthHeaderParams.put("oauth_signature", encodedString);

		String oAuthHeader = "OAuth " + NapiHttpHelper.keyValueParameters(oAuthHeaderParams, ",", true);

		NapiLog.d(TAG, "Authorization Header : " + oAuthHeader);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", oAuthHeader);
		headers.put("x-mnc", operator.getMnc());
		headers.put("x-mcc", operator.getMcc());

		String s = null;
		NapiLog.d(TAG, "URL for access token : " + sigBaseUrl);

		try {
			s = WacHttpClient.executeHttpPost(sigBaseUrl, new ArrayList<NameValuePair>(), NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
		}
		NapiLog.d(TAG, s);
		if (s.contains("error"))
			return null;

		HashMap<String, String> valHash = new HashMap<String, String>();
		try {
			String[] valArr = s.split("&");
			for (String val : valArr) {
				String myKey = Util.substringBefore(val, "=");
				String myVal = Util.substringAfter(val, "=");
				valHash.put(myKey, myVal);
				NapiLog.d(TAG, myKey + " : " + myVal);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// just return an empty hash, for the caller to figure out the rest.
		}
		return valHash;
	}

	/**
	 * Returns the OAuth2 access token.
	 * 
	 * @param operator
	 *            the operator
	 * @param item
	 *            ProductItem with valid price points
	 * @param cred
	 *            Credentials for relevant evnvironment information along with
	 *            key and secret.
	 * @param secret
	 *            the request token secret
	 * @param code
	 *            the code
	 * @param redirectUri
	 *            the redirect uri
	 * @return OAuth2 access token
	 * @throws NapiException
	 */
	public static Oauth2AccessToken getOAuth2AccessToken(Operator operator, Item item, String cred, String secret, String code,
			String redirectUri) throws NapiException {
		NapiLog.d(TAG, "In getOAuth2AccessToken");
		NapiLog.d(TAG, "code = " + code);
		NapiLog.d(TAG, "rediret uri = " + redirectUri);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Accept", "application/json");
		headers.put("Content-Type", "application/x-www-form-urlencoded");

		if (WacNapiContext.getInstance().getPaymentService().getAPIVersion() == WacPaymentService.APIDOT1) {
			headers.put("x-mnc", operator.getMnc());
			headers.put("x-mcc", operator.getMcc());
		}

		ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("client_id", cred));
		params.add(new BasicNameValuePair("client_secret", secret));
		params.add(new BasicNameValuePair("code", code));
		params.add(new BasicNameValuePair("grant_type", "authorization_code"));
		params.add(new BasicNameValuePair("redirect_uri", redirectUri));

		String accessTokenUrl = (WacNapiContext.getInstance().getPaymentService().getAPIVersion() == WacPaymentService.APIDOT2) ? WacNapiContext
				.getInstance().getEndPoints().getAccessTokenPath()
				: operator.getApis().getAuthorization().getUris().getAccessToken();

		String s = null;
		try {
			s = WacHttpClient.executeHttpPost(accessTokenUrl, params, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
		}

		NapiLog.d(TAG, "OAUTH2 RESP - " + s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		Oauth2AccessToken token = null;
		try {
			checkForResponseErrors(s);
			JSONObject j = new JSONObject(s);
			token = gson.fromJson(j.toString(), Oauth2AccessToken.class);
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, gson.toJson(token));
		return token;

	}

	/**
	 * Retrieves an access token.
	 * 
	 * @param operator
	 *            the operator
	 * @param item
	 *            the item
	 * @param cred
	 *            the credentials for relevant evnvironment information along
	 *            with key and secret.
	 * @param secret
	 *            the secret
	 * @param redirectUri
	 *            the redirect uri
	 * @return the oAuth1 request token
	 */
	public static HashMap<String, String> getOAuth1RequestToken(Operator operator, Item item, String cred, String secret,
			String redirectUri, String scope) {

		String sigBaseUrl = operator.getApis().getAuthorization().getUris().getRequestToken();

		String scopeStr = GET_SCOPE.equals(scope) ? scope : scope + "?code=" + item.getItemId();

		String generatedNonce = UUID.randomUUID().toString();
		String timeStamp = String.valueOf(System.currentTimeMillis() / 1000L);

		String signatureBaseString1 = Util.oauthEncode("POST&" + sigBaseUrl + "&");

		// order matters
		Map<String, String> params = new TreeMap<String, String>();

		params.put("oauth_callback", Util.oauthEncode(redirectUri));
		params.put("oauth_consumer_key", cred);
		params.put("oauth_nonce", generatedNonce);
		params.put("oauth_scope", Util.oauthEncode(scopeStr));
		params.put("oauth_signature_method", "HMAC-SHA1");
		params.put("oauth_timestamp", timeStamp);
		params.put("oauth_version", "1.0");
		String signatureBaseString2 = NapiHttpHelper.keyValueParameters(params, ",");

		NapiLog.d(TAG, "signatureBaseString2" + signatureBaseString2);

		String signatureBaseString = signatureBaseString1 + oEncode(signatureBaseString2);

		NapiLog.d("Wac", "bse string = " + signatureBaseString);
		NapiLog.d("Wac", "secret = " + secret);
		final String keyString;
		keyString = Util.oauthEncode(secret + "&");
		SecretKey key = null;
		try {
			key = new SecretKeySpec(keyString.getBytes("UTF-8"), "HmacSHA1");
			NapiLog.d("Wac", "key = " + key.getEncoded());
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		String encodedString = null;
		try {
			final Mac mac = Mac.getInstance("HmacSHA1");
			mac.init(key);
			encodedString = new String(Base64.encode(mac.doFinal(signatureBaseString.getBytes("UTF-8"))));
			encodedString = oEncode(encodedString);
		} catch (InvalidKeyException e) {
			throw new RuntimeException(getMessage("KEY_NOT_SUPPORTED"), e);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(getMessage("UNEXPECTED"), e);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// order matters
		Map<String, String> parameters = new TreeMap<String, String>();

		parameters.put("oauth_callback", Util.oauthEncode(redirectUri));
		parameters.put("oauth_consumer_key", cred);
		parameters.put("oauth_scope", Util.oauthEncode(scopeStr));
		parameters.put("oauth_signature_method", "HMAC-SHA1");
		parameters.put("oauth_version", "1.0");
		parameters.put("oauth_nonce", generatedNonce);
		parameters.put("oauth_timestamp", timeStamp);
		parameters.put("oauth_signature", encodedString);

		String oAuthHeader = "OAuth " + NapiHttpHelper.keyValueParameters(parameters, ",", true);

		NapiLog.d(TAG, "URL is : " + sigBaseUrl);
		NapiLog.d(TAG, "OAUTH AUTH HEADER " + oAuthHeader);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", oAuthHeader);
		headers.put("x-mnc", operator.getMnc());
		headers.put("x-mcc", operator.getMcc());

		String s = null;
		try {
			s = WacHttpClient.executeHttpPost(sigBaseUrl, new ArrayList<NameValuePair>(), NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
		}
		NapiLog.d(TAG, s);

		HashMap<String, String> valHash = new HashMap<String, String>();
		try {
			checkForResponseErrors(s);
			String[] valArr = s.split("&");
			for (String val : valArr) {
				String[] keyValArr = val.split("=");
				valHash.put(keyValArr[0], keyValArr[1]);
				NapiLog.d(TAG, keyValArr[0] + " : " + keyValArr[1]);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: cleanup
		}
		return valHash;
	}

	public static OSPair doAOauth1ListTransactions(String token, String verifier, String tokenSecret, String clientSecret,
			String cred, Operator operator) throws NapiException {

		NapiLog.d(TAG, "Making a list txn request");
		NapiLog.d(TAG, "Access token : " + token);
		NapiLog.d(TAG, "Verfier : " + verifier);
		NapiLog.d(TAG, "client secret : " + clientSecret);
		NapiLog.d(TAG, "token secret : " + tokenSecret);

		String sigBaseUrl = operator.getApis().getPayment().getUri();

		String generatedNonce = UUID.randomUUID().toString();
		String timeStamp = String.valueOf(System.currentTimeMillis() / 1000L);

		String signatureBaseString1 = Util.oauthEncode("GET&" + sigBaseUrl + "&");

		// OrderMatters
		Map<String, String> sign2Param = new TreeMap<String, String>();

		sign2Param.put("oauth_consumer_key", cred);
		sign2Param.put("oauth_nonce", generatedNonce);
		sign2Param.put("oauth_signature_method", "HMAC-SHA1");
		sign2Param.put("oauth_timestamp", timeStamp);
		sign2Param.put("oauth_token", Util.oauthEncode(token));
		sign2Param.put("oauth_verifier", Util.oauthEncode(verifier));
		sign2Param.put("oauth_version", "1.0");

		String signatureBaseString2 = NapiHttpHelper.keyValueParameters(sign2Param, ",");

		String signatureBaseString = signatureBaseString1 + oEncode(signatureBaseString2);
		NapiLog.d(TAG, "Sig String is : " + signatureBaseString);

		final String keyString;
		keyString = Util.oauthEncode(clientSecret + "&" + URLDecoder.decode(tokenSecret));
		NapiLog.d(TAG, "key string is : " + keyString);

		SecretKey key = null;
		try {
			key = new SecretKeySpec(keyString.getBytes("UTF-8"), "HmacSHA1");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}
		String encodedString = null;
		try {
			final Mac mac = Mac.getInstance("HmacSHA1");
			mac.init(key);
			encodedString = new String(Base64.encode(mac.doFinal(signatureBaseString.getBytes("UTF-8"))));
			encodedString = Util.oauthEncode(encodedString);
			NapiLog.d(TAG, "Encoded String is " + encodedString);
		} catch (InvalidKeyException e) {
			throw new NapiException(e.getLocalizedMessage());
		} catch (NoSuchAlgorithmException e) {
			throw new NapiException(e.getLocalizedMessage());
		} catch (IllegalStateException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}

		Map<String, String> oAuthHeaderParams = new TreeMap<String, String>();

		oAuthHeaderParams.put("oauth_signature", encodedString);
		oAuthHeaderParams.put("oauth_version", "1.0");
		oAuthHeaderParams.put("oauth_nonce", Util.oauthEncode(generatedNonce));
		oAuthHeaderParams.put("oauth_signature_method", "HMAC-SHA1");
		oAuthHeaderParams.put("oauth_consumer_key", cred);
		oAuthHeaderParams.put("oauth_timestamp", timeStamp);
		oAuthHeaderParams.put("oauth_token", Util.oauthEncode(token));
		oAuthHeaderParams.put("oauth_verifier", Util.oauthEncode(verifier));

		String oAuthHeader = "OAuth " + NapiHttpHelper.keyValueParameters(oAuthHeaderParams, ",", true);

		NapiLog.d(TAG, "Authorization Header : " + oAuthHeader);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", oAuthHeader);
		headers.put("x-mnc", operator.getMnc());
		headers.put("x-mcc", operator.getMcc());

		NapiLog.d(TAG, "URL for purchase  : " + sigBaseUrl);
		OSPair op = null;
		try {
			op = WacHttpClient.executeHttpGet(sigBaseUrl, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}
		NapiLog.d(TAG, op.s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		TransactionList transactionList = null;
		try {
			checkForResponseErrors(op.s);
			JSONObject j = new JSONObject(op.s);
			transactionList = gson.fromJson(j.toString(), TransactionList.class);
			NapiLog.d(TAG, "Got Tx List with " + transactionList.getPaymentTransactionList().getAmountTransaction().size()
					+ " objects");
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, gson.toJson(transactionList));
		return new OSPair(transactionList, gson.toJson(transactionList));
	}

	/**
	 * Do an oauth2 list transaction.
	 * 
	 * @param token
	 *            the token
	 * @param operator
	 *            the operator
	 * @return the oS pair
	 * @throws NapiException
	 *             the napi exception
	 */
	public static OSPair doAOauth2ListTransactions(String token, Operator operator) throws NapiException {

		NapiLog.d(TAG, "Making an oauth2 List Txn");
		NapiLog.d(TAG, "Access token : " + token);

		String sigBaseUrl = operator.getApis().getPayment().getUri();

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "BEARER " + token);
		headers.put("x-mnc", operator.getMnc());
		headers.put("x-mcc", operator.getMcc());
		headers.put("Accept", "application/json");

		NapiLog.d(TAG, "URL for list txn  : " + sigBaseUrl);
		OSPair op = null;
		try {
			op = WacHttpClient.executeHttpGet(sigBaseUrl, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, op.s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		TransactionList transactionList = null;
		try {
			checkForResponseErrors(op.s);
			JSONObject j = new JSONObject(op.s);
			transactionList = gson.fromJson(j.toString(), TransactionList.class);
			NapiLog.d(TAG, "Got Tx List with " + transactionList.getPaymentTransactionList().getAmountTransaction().size()
					+ " objects");
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, gson.toJson(transactionList));
		return new OSPair(transactionList, gson.toJson(transactionList));
	}

	/**
	 * Do a oauth1 check transaction.
	 * 
	 * @param token
	 *            the token
	 * @param verifier
	 *            the verifier
	 * @param tokenSecret
	 *            the token secret
	 * @param clientSecret
	 *            the client secret
	 * @param cred
	 *            the cred
	 * @param operator
	 *            the operator
	 * @param referenceCode
	 *            the reference code
	 * @return the oS pair
	 * @throws NapiException
	 *             the napi exception
	 */
	public static OSPair doAOauth1CheckTransaction(String token, String verifier, String tokenSecret, String clientSecret,
			String cred, Operator operator, String referenceCode) throws NapiException {

		NapiLog.d(TAG, "Making a check txn request");
		NapiLog.d(TAG, "Access token : " + token);
		NapiLog.d(TAG, "Verfier : " + verifier);
		NapiLog.d(TAG, "client secret : " + clientSecret);
		NapiLog.d(TAG, "token secret : " + tokenSecret);

		String sigBaseUrl = operator.getApis().getPayment().getUri() + "/" + referenceCode;

		String generatedNonce = UUID.randomUUID().toString();
		String timeStamp = String.valueOf(System.currentTimeMillis() / 1000L);

		String signatureBaseString1 = Util.oauthEncode("GET&" + sigBaseUrl + "&");

		// OrderMatters
		Map<String, String> sign2Param = new TreeMap<String, String>();

		sign2Param.put("oauth_consumer_key", cred);
		sign2Param.put("oauth_nonce", generatedNonce);
		sign2Param.put("oauth_signature_method", "HMAC-SHA1");
		sign2Param.put("oauth_timestamp", timeStamp);
		sign2Param.put("oauth_token", Util.oauthEncode(token));
		sign2Param.put("oauth_verifier", Util.oauthEncode(verifier));
		sign2Param.put("oauth_version", "1.0");

		String signatureBaseString2 = NapiHttpHelper.keyValueParameters(sign2Param, ",");

		String signatureBaseString = signatureBaseString1 + oEncode(signatureBaseString2);
		NapiLog.d(TAG, "Sig String is : " + signatureBaseString);

		final String keyString;
		keyString = Util.oauthEncode(clientSecret + "&" + URLDecoder.decode(tokenSecret));
		NapiLog.d(TAG, "key string is : " + keyString);

		SecretKey key = null;
		try {
			key = new SecretKeySpec(keyString.getBytes("UTF-8"), "HmacSHA1");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		String encodedString = null;
		try {
			final Mac mac = Mac.getInstance("HmacSHA1");
			mac.init(key);
			encodedString = new String(Base64.encode(mac.doFinal(signatureBaseString.getBytes("UTF-8"))));
			encodedString = Util.oauthEncode(encodedString);
			NapiLog.d(TAG, "Encoded String is " + encodedString);
		} catch (InvalidKeyException e) {
			throw new NapiException(e.getLocalizedMessage());
		} catch (NoSuchAlgorithmException e) {
			throw new NapiException(e.getLocalizedMessage());
		} catch (IllegalStateException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}

		Map<String, String> oAuthHeaderParams = new TreeMap<String, String>();

		oAuthHeaderParams.put("oauth_signature", encodedString);
		oAuthHeaderParams.put("oauth_version", "1.0");
		oAuthHeaderParams.put("oauth_nonce", Util.oauthEncode(generatedNonce));
		oAuthHeaderParams.put("oauth_signature_method", "HMAC-SHA1");
		oAuthHeaderParams.put("oauth_consumer_key", cred);
		oAuthHeaderParams.put("oauth_timestamp", timeStamp);
		oAuthHeaderParams.put("oauth_token", Util.oauthEncode(token));
		oAuthHeaderParams.put("oauth_verifier", Util.oauthEncode(verifier));

		String oAuthHeader = "OAuth " + NapiHttpHelper.keyValueParameters(oAuthHeaderParams, ",", true);

		NapiLog.d(TAG, "Authorization Header : " + oAuthHeader);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", oAuthHeader);
		headers.put("x-mnc", operator.getMnc());
		headers.put("x-mcc", operator.getMcc());

		NapiLog.d(TAG, "URL for purchase  : " + sigBaseUrl);
		OSPair op = null;
		try {
			op = WacHttpClient.executeHttpGet(sigBaseUrl, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, op.s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		Transaction transaction = null;
		try {
			checkForResponseErrors(op.s);
			JSONObject j = new JSONObject(op.s);
			transaction = gson.fromJson(j.toString(), Transaction.class);
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}
		NapiLog.d(TAG, gson.toJson(transaction));

		return new OSPair(transaction, gson.toJson(transaction));
	}

	/**
	 * Do a oauth2 check transaction.
	 * 
	 * @param token
	 *            the token
	 * @param operator
	 *            the operator
	 * @param transactionId
	 *            the transaction id
	 * @return the oS pair
	 * @throws NapiException
	 *             the napi exception
	 */
	public static OSPair doAOauth2CheckTransaction(String token, Operator operator, String transactionId) throws NapiException {

		NapiLog.d(TAG, "Making an oauth2 Check Txn");
		NapiLog.d(TAG, "Access token : " + token);

		String sigBaseUrl = operator.getApis().getPayment().getUri();

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Accept", "application/json");
		headers.put("Authorization", "BEARER " + token);
		headers.put("x-mnc", operator.getMnc());
		headers.put("x-mcc", operator.getMcc());

		sigBaseUrl = sigBaseUrl + "/" + transactionId;

		NapiLog.d(TAG, "URL for check txn  : " + sigBaseUrl);
		OSPair op = null;
		try {
			op = WacHttpClient.executeHttpGet(sigBaseUrl, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, op.s);
		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		Transaction transaction = null;
		try {
			checkForResponseErrors(op.s);
			JSONObject j = new JSONObject(op.s);
			transaction = gson.fromJson(j.toString(), Transaction.class);
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, gson.toJson(transaction));

		return new OSPair(transaction, gson.toJson(transaction));
	}

	/**
	 * Do a oauth1 payment.
	 * 
	 * @param token
	 *            the token
	 * @param verifier
	 *            the verifier
	 * @param tokenSecret
	 *            the token secret
	 * @param clientSecret
	 *            the client secret
	 * @param cred
	 *            the credentials
	 * @param refCode
	 *            transaction refcode
	 * @param itemId
	 *            the item id
	 * @param itemDesc
	 *            the item desc
	 * @param itemCurrency
	 *            the item currency
	 * @param itemPrice
	 *            the item price
	 * @param mcc
	 *            operator mcc
	 * @param mnc
	 *            operator mnc
	 * @param paymentUri
	 *            the payment uri
	 * @return the Transaction on the JSON String
	 * @throws NapiException
	 *             the napi exception
	 */
	public static OSPair doAOauth1Payment(String token, String verifier, String tokenSecret, String clientSecret, String cred,
			String refCode, String itemId, String itemDesc, String itemCurrency, double itemPrice, String mcc, String mnc,
			String paymentUri) throws NapiException {

		// TODO: validate refCode and other params

		NapiLog.d(TAG, "Making an oauth1 purchase");
		NapiLog.d(TAG, "Access token : " + token);
		NapiLog.d(TAG, "Verfier : " + verifier);
		NapiLog.d(TAG, "client secret : " + clientSecret);
		NapiLog.d(TAG, "token secret : " + tokenSecret);

		String sigBaseUrl = paymentUri;

		String generatedNonce = UUID.randomUUID().toString();
		String timeStamp = String.valueOf(System.currentTimeMillis() / 1000L);

		String signatureBaseString1 = Util.oauthEncode("POST&" + sigBaseUrl + "&");

		// OrderMatters
		Map<String, String> sign2Param = new TreeMap<String, String>();

		sign2Param.put("code", itemId);
		sign2Param.put("description", Util.oauthEncode(itemDesc));
		sign2Param.put("endUserId", Util.oauthEncode("acr:Authorization"));
		sign2Param.put("oauth_consumer_key", cred);
		sign2Param.put("oauth_nonce", generatedNonce);
		sign2Param.put("oauth_signature_method", "HMAC-SHA1");
		sign2Param.put("oauth_timestamp", timeStamp);
		sign2Param.put("oauth_token", Util.oauthEncode(token));
		sign2Param.put("oauth_verifier", Util.oauthEncode(verifier));
		sign2Param.put("oauth_version", "1.0");
		sign2Param.put("referenceCode", refCode);
		sign2Param.put("transactionOperationStatus", "Charged");

		String signatureBaseString2 = NapiHttpHelper.keyValueParameters(sign2Param, ",");

		String signatureBaseString = signatureBaseString1 + oEncode(signatureBaseString2);
		NapiLog.d(TAG, "Sig String is : " + signatureBaseString);

		final String keyString;
		keyString = Util.oauthEncode(clientSecret + "&" + URLDecoder.decode(tokenSecret));
		NapiLog.d(TAG, "key string is : " + keyString);

		SecretKey key = null;
		try {
			key = new SecretKeySpec(keyString.getBytes("UTF-8"), "HmacSHA1");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		String encodedString = null;
		try {
			final Mac mac = Mac.getInstance("HmacSHA1");
			mac.init(key);
			encodedString = new String(Base64.encode(mac.doFinal(signatureBaseString.getBytes("UTF-8"))));
			encodedString = Util.oauthEncode(encodedString);
			NapiLog.d(TAG, "Encoded String is " + encodedString);
		} catch (InvalidKeyException e) {
			throw new NapiException(e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			throw new NapiException(e.getMessage());
		} catch (IllegalStateException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}

		Map<String, String> oAuthHeaderParams = new TreeMap<String, String>();

		oAuthHeaderParams.put("oauth_signature", encodedString);
		oAuthHeaderParams.put("oauth_version", "1.0");
		oAuthHeaderParams.put("oauth_nonce", Util.oauthEncode(generatedNonce));
		oAuthHeaderParams.put("oauth_signature_method", "HMAC-SHA1");
		oAuthHeaderParams.put("oauth_consumer_key", cred);
		oAuthHeaderParams.put("oauth_timestamp", timeStamp);
		oAuthHeaderParams.put("oauth_token", Util.oauthEncode(token));
		oAuthHeaderParams.put("oauth_verifier", Util.oauthEncode(verifier));

		String oAuthHeader = "OAuth " + NapiHttpHelper.keyValueParameters(oAuthHeaderParams, ",", true);

		NapiLog.d(TAG, "Authorization Header : " + oAuthHeader);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", oAuthHeader);
		headers.put("x-mnc", mnc);
		headers.put("x-mcc", mcc);

		ArrayList<NameValuePair> postParams = new ArrayList<NameValuePair>();
		postParams.add(new BasicNameValuePair("endUserId", "acr:Authorization"));
		postParams.add(new BasicNameValuePair("referenceCode", refCode));
		postParams.add(new BasicNameValuePair("transactionOperationStatus", "Charged"));
		postParams.add(new BasicNameValuePair("description", itemDesc));
		postParams.add(new BasicNameValuePair("code", itemId));

		String s = null;
		NapiLog.d(TAG, "URL for purchase  : " + sigBaseUrl);

		try {
			s = WacHttpClient.executeHttpPost(sigBaseUrl, postParams, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		Transaction transaction = null;
		try {
			checkForResponseErrors(s);
			JSONObject j = new JSONObject(s);
			transaction = gson.fromJson(j.toString(), Transaction.class);
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}

		NapiLog.d(TAG, gson.toJson(transaction));
		return new OSPair(transaction, gson.toJson(transaction));
	}

	/**
	 * Do a oauth2 payment.
	 * 
	 * @param token
	 *            oauth token
	 * @param refCode
	 *            the transaction ref code
	 * @param serverReferenceCode
	 *            the server reference code
	 * @param itemId
	 *            the item id
	 * @param itemDesc
	 *            the item desc
	 * @param itemCurrency
	 *            the item currency
	 * @param itemPrice
	 *            the item price
	 * @param mcc
	 *            operator mcc
	 * @param mnc
	 *            operator mnc
	 * @param paymentUri
	 *            the payment uri
	 * @param apiVersion
	 *            the api version
	 * @return Transaction and its String representation
	 * @throws NapiException
	 *             the napi exception
	 */
	public static OSPair doAOauth2Payment(String token, String refCode, String serverReferenceCode, String itemId, String itemDesc,
			String itemCurrency, double itemPrice, String mcc, String mnc, String paymentUri, int apiVersion) throws NapiException {

		NapiLog.d(TAG, "Making an oauth2 purchase");
		NapiLog.d(TAG, "Access token : " + token);

		NapiLog.d(TAG, "RefCode : " + refCode);

		String sigBaseUrl = paymentUri;

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Accept", "application/json");
		headers.put("Authorization", "BEARER " + token);
		if (apiVersion == WacPaymentService.APIDOT1) {
			headers.put("x-mnc", mnc);
			headers.put("x-mcc", mcc);
		}

		ArrayList<NameValuePair> postParams = new ArrayList<NameValuePair>();
		postParams.add(new BasicNameValuePair("endUserId", "acr:Authorization"));
		postParams.add(new BasicNameValuePair("referenceCode", refCode));
		postParams.add(new BasicNameValuePair("serverReferenceCode", serverReferenceCode));

		postParams.add(new BasicNameValuePair("transactionOperationStatus", "Charged"));
		postParams.add(new BasicNameValuePair("description", itemDesc));
		postParams.add(new BasicNameValuePair("code", itemId));
		postParams.add(new BasicNameValuePair("currency", itemCurrency));
		postParams.add(new BasicNameValuePair("amount", "" + itemPrice));

		String s = null;
		NapiLog.d(TAG, "URL for purchase  : " + sigBaseUrl);

		try {
			s = WacHttpClient.executeHttpPost(sigBaseUrl, postParams, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		Transaction transaction = null;
		try {
			checkForResponseErrors(s);
			JSONObject j = new JSONObject(s);
			transaction = gson.fromJson(j.toString(), Transaction.class);
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}

		NapiLog.d(TAG, gson.toJson(transaction));

		return new OSPair(transaction, gson.toJson(transaction));

	}

	/**
	 * Do discovery.
	 * 
	 * @param applicationID
	 *            the application ID
	 * @return the oS pair
	 * @throws NapiException
	 */
	public static List<Operator> doDiscovery(String applicationID) throws NapiException {

		String queryPath = WacNapiContext.getInstance().getEndPoints().getDiscoveryPath() + applicationID;

		NapiLog.d(TAG, "Discover Path = " + queryPath);
		List<Operator> list = null;
		OSPair op = null;
		try {
			Map<String, String> header = new HashMap<String, String>();
			op = WacHttpClient.executeHttpGet(queryPath, NapiHttpHelper.formHeaders(header));
		} catch (UnknownHostException uhe) {
			uhe.printStackTrace();
			throw new NapiException("Unable to connect to " + uhe.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, "Response JSON : " + op.s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		try {
			checkForResponseErrors(op.s);
			JSONObject j = new JSONObject(op.s);
			GatewayResponse resp = gson.fromJson(j.toString(), GatewayResponse.class);
			Operator o = resp.getResponse().getOperator();
			if (o == null) {
				NapiLog.d(TAG, "Operator not identified!!!");
				list = resp.getResponse().getOperators();
			} else {
				NapiLog.d(TAG, "Operator identified!!!");
				list = new ArrayList<Operator>();
				list.add(o);
			}
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}
		return list;
	}

	/**
	 * Do discovery for operator.
	 * 
	 * @param app
	 *            the application
	 * @param operator
	 *            the operator
	 * @return the operator details in Object and String pair
	 * @throws NapiException
	 */
	public static OSPair doDiscoveryForOperator(Application app, Operator operator) throws NapiException {

		String queryPath = WacNapiContext.getInstance().getEndPoints().getDiscoveryPath() + app.getApplicationIdentifier()
				+ "?x-mnc=" + operator.getMnc() + "&x-mcc=" + operator.getMcc();
		NapiLog.d(TAG, "Discovery For Operator Path = " + queryPath);
		Operator o = null;
		OSPair op = null;
		try {
			op = WacHttpClient.executeHttpGet(queryPath, NapiHttpHelper.formHeaders(new HashMap<String, String>()));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, "Response JSON : " + op.s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		try {
			checkForResponseErrors(op.s);
			JSONObject j = new JSONObject(op.s);
			GatewayResponse resp = gson.fromJson(j.toString(), GatewayResponse.class);
			o = resp.getResponse().getOperator();
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}
		return new OSPair(o, gson.toJson(o));
	}

	/**
	 * Do query.
	 * 
	 * @param app
	 *            application instance
	 * @param item
	 *            product item
	 * @param cred
	 *            credential
	 * @param developer
	 *            developer id
	 * @param secret
	 *            secret
	 * @return GatewayResponse and its JSON
	 * @throws NapiException
	 *             the napi exception
	 */
	public static OSPair doQuery(Application app, ProductItem item, Credential cred, Developer developer, String secret)
			throws NapiException {

		Long timeStamp = System.currentTimeMillis();

		String signature = null;
		Product p = null;
		try {
			signature = Util.getBase64HmacSHA256(secret, app.getApplicationIdentifier(), developer.getUserName(), timeStamp);
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}

		NapiLog.d(TAG, "Secret is : " + secret);

		String queryPath = WacNapiContext.getInstance().getEndPoints().getQueryPath();

		String uriParams = "/" + app.getApplicationIdentifier();
		uriParams += item == null ? "" : "/" + item.getProductIdentifier();

		String requestParams = "?client_id=" + cred.getKey() + "&timestamp=" + timeStamp;

		queryPath += uriParams + requestParams;

		NapiLog.d(TAG, "Query is : " + queryPath);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Accept", "application/json");
		headers.put("Authorization", "Signature " + signature);
		WacNapiContext.getInstance().getEndPoints();
		if (WacEndpoints.getSpoofedDiscoverySourceIPForStaging() != null) {
			WacNapiContext.getInstance().getEndPoints();
			NapiLog.d(TAG, "Setting spoofed IP - " + WacEndpoints.getSpoofedDiscoverySourceIPForStaging());
			WacNapiContext.getInstance().getEndPoints();
			headers.put("x-source-ip", WacEndpoints.getSpoofedDiscoverySourceIPForStaging());
		} else {
			NapiLog.d(TAG, "Query source IP set naturalelle");
		}
		NapiLog.d(TAG, "Header is : " + headers.toString());
		OSPair op = null;
		try {
			op = WacHttpClient.executeHttpGet(queryPath, NapiHttpHelper.formHeaders(headers));
		} catch (Exception e) {
			e.printStackTrace();
			throw new NapiException(e.getMessage());
		}
		NapiLog.d(TAG, "Response JSON is : " + op.s);

		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		try {
			checkForBadQueryResponsCodes((HttpResponse) op.o);
			checkForResponseErrors(op.s);
			JSONObject j = new JSONObject(op.s);
			GatewayResponse resp = gson.fromJson(j.toString(), GatewayResponse.class);
			p = resp.getResponse().getProduct();
		} catch (JSONException e) {
			e.printStackTrace();
			throw new NapiException(e.getLocalizedMessage());
		}
		return new OSPair(p, gson.toJson(p));
	}

	private static void checkForBadQueryResponsCodes(HttpResponse response) throws NapiException {
		switch (response.getStatusLine().getStatusCode()) {
		case HttpStatus.SC_BAD_REQUEST:
			throw new NapiException(getMessage("BAD_REQUEST"));
		case HttpStatus.SC_NOT_FOUND:
			throw new NapiException(getMessage("INVALID_APP"));
		case HttpStatus.SC_UNAUTHORIZED:
			throw new NapiException(getMessage("SIG_VALIDATE_FAIL"));
		case HttpStatus.SC_INTERNAL_SERVER_ERROR:
			throw new NapiException(getMessage("SERVER_ERR"));
		default:
			break;
		}
	}

	protected static void checkForResponseErrors(String result) throws NapiException {
		if (result != null && result.length() > 1 && (result.contains("\"requestError\":") || result.contains("\"error\":"))) {
			GsonBuilder gsonb = new GsonBuilder();
			gsonb.setPrettyPrinting();
			Gson gson = gsonb.create();
			JSONObject j = null;
			if (result.contains("\"requestError\":")) {
				try {
					j = new JSONObject(result);
					String reqErr = j.getString("requestError");
					RequestError err = gson.fromJson(reqErr, RequestError.class);
					ServiceException se = err.getServiceException();
					if (se != null && se.getText() != null) {
						String messageTemplate = se.getText();
						String messageTemplateTranslated = getMessageTranslationForMessage(messageTemplate);
						String variablesList = se.getVariables();
						// Do variable replacement, iff any
						if (variablesList != null && variablesList.length() > 0) {
							String[] vars = variablesList.split(",");
							int i = 1;
							for (String var : vars) {
								String marker = "%" + i++;
								int pos = messageTemplateTranslated.indexOf(marker);
								if (pos > -1) {
									String varTranslated = getMessageTranslationForMessage(var);
									messageTemplateTranslated = messageTemplateTranslated.replace(marker, varTranslated);
								} else {
									break;
								}
							}
						}
						throw new NapiException(messageTemplateTranslated);
					} else
						throw new NapiException(getMessageTranslationForMessage(result));
				} catch (JSONException e) {
					e.printStackTrace();
					throw new NapiException(e.getLocalizedMessage());
				}
			} else if (result.contains("\"error\":")) {
				try {
					j = new JSONObject(result);
					GatewayError err = gson.fromJson(j.toString(), GatewayError.class);
					if (err.getErrorDescription() != null && err.getErrorDescription().length() > 0)
						throw new NapiException(getMessageTranslationForMessage(err.getErrorDescription()));
					else
						throw new NapiException(err.getError());
				} catch (JSONException e) {
					e.printStackTrace();
					throw new NapiException(e.getLocalizedMessage());
				}
			}			
		}
	}

	/**
	 * Form payment url for OAuth1.
	 * 
	 * @param requestToken
	 *            the request token
	 * @param operator
	 *            the operator
	 * @param url
	 *            the url
	 * @return the payment url with parametres in the form of a string
	 */
	public static String formUrlStringForOAuth1(String requestToken, Operator operator, String url) {

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("oauth_token", requestToken);
		parameters.put("x-mcc", operator.getMcc());
		parameters.put("x-mnc", operator.getMnc());

		return NapiHttpHelper.formUrlString(url, parameters);
	}

}
