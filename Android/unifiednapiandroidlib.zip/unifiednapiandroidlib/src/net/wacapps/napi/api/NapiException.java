/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

/**
 * The exception Class to handle all the Napi Exceptions.
 */
public class NapiException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Instantiates a new napi exception.
	 */
	public NapiException(String message) {
		super(message);
	}


	@Override
	public String getMessage() {
		return super.getMessage();
	}
	
	

}
