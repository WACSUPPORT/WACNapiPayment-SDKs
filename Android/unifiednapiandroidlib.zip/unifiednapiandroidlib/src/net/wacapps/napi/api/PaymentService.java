/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

import java.util.List;

import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.ReservedTransaction;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionList;
import android.app.Activity;
import android.content.Intent;

/**
 * 
 * PaymentService contains methods to query product list, make payments and list transactions
 * 1. Get product details
 * 2. Charge payments
 * 3. List transactions
 * 4. Check transaction status
 * 
 */
public interface PaymentService {

	/**
	 * Initializes the payment service.
	 * 
	 * @param applicationIdentifier
	 *            the application identifier
	 * @param credential
	 *            the authentication credential
	 * @param secret
	 *            the secret
	 * @param developerID
	 *            the developer id
	 * @param redirectUriOAuth           
	 * @throws NapiException 
	 */
	public void initialize(String applicationIdentifier,
			String credential,
			String secret, String developerID, String redirectUriOAuth) throws NapiException;
	
	
	/**
	 * Initializes the payment service.
	 * 
	 * @param applicationIdentifier
	 *            the application identifier
	 * @param operatorMCC
	 *            the operator Mobile County Code
	 * @param operatorMNC
	 *            the operator Mobile Network Code
	 * @param credential
	 *            the authentication credential
	 * @param secret
	 *            the secret
	 * @param developerID
	 *            the developer id
	 * @throws NapiException 
	 */
	@Deprecated
	public void initialize(String applicationIdentifier,
			String operatorMCC, String operatorMNC, String credential,
			String secret, String developerID, String redirectUriOAuth) throws NapiException;
	
	/**
	 * List product items in current application
	 * 
	 * @return the list
	 */
	public List<Item> listProductItems();

	/**
	 * Returns true if WAC billing is available else returns false
	 * 
	 * @param applicationIdentifier
	 *            the application identifier
	 * @param credential
	 *            the authentication credential
	 * @param secret
	 *            the secret
	 * @param developerID
	 *            the developer id
	 * 
	 * @return true if wac billing is available
	 */
	public boolean checkBillingAvailability(String applicationIdentifier,
			String credential, String secret, String developerID);

	/**
	 * Gets the product item.
	 * 
	 * @param itemID
	 *            the item id
	 * @return the product item
	 */
	public Item getProductItem(String itemID);
		
	/**
	 * Generate payment intent.
	 * 
	 * @param context
	 *            the context
	 * @param itemID
	 *            the item id
	 * @param refCode
	 *            the ref code
	 */
	@Deprecated
	public void chargePayment(Activity activity, String appID, String itemID, String refCode);

	/**
	 * Generate payment intent.
	 *
	 * @param context the context
	 * @param appID the app id
	 * @param itemID the item id
	 * @param refCode the ref code
	 * @param deliveryCallback the delivery callback
	 */
	public void chargePayment(Activity activity, String appID, String itemID, String refCode, ContentDeliveryCallback deliveryCallback);

	/**
	 * Reserve the funds. This call is used together with {@link #capturePayment(Context, ReservedTransaction)}capturePayment
	 * 
	 * @param context the context
	 * @param appID the app id
	 * @param itemID the item id
	 * @param refCo the ref co
	 */
	public void reservePayment(Activity activity, String appID, String itemID, String refCo);

	/**
	 * Capture the funds, usually called after successful content delivery
	 *
	 * @param context the context
	 * @param reserve the reserve
	 * @throws NapiException 
	 */
	public void capturePayment(Activity activity, ReservedTransaction reserve) throws NapiException;

	/**
	 * Generate Transaction List intent.
	 * 
	 * @param context
	 *            the context
	 */
	public void getTransactionList(Activity activity);

	/**
	 * Generate transaction check intent.
	 *
	 * @param context the context
	 */
	public void checkTransaction(Activity activity, String applicationId);
	
	/**
	 * Process charge payment transaction results.
	 *
	 * @param data the data
	 * @return the transaction
	 */
	public Transaction processChargePaymentTransactionResults(Intent data);
	
	/**
	 * Process reserve payment results.
	 *
	 * @param data the data
	 */
	public ReservedTransaction processReservePaymentResults(Intent data);
	
	/**
	 * Process transaction list results.
	 *
	 * @param data the data
	 * @return the transaction list
	 */
	public TransactionList processTransactionListResults(Intent data);
	
	/**
	 * Process transaction check results.
	 *
	 * @param data the data
	 * @return the transaction
	 */
	public Transaction processTransactionCheckResults(Intent data);
	
	/**
	 * Generate operator discovery intent.
	 * Please do not use anymore, method may be removed in next version of SDK
	 * @param context the context
	 * @param applicationID the application id
	 */
	@Deprecated
	public void discoverOperator(Activity activity, String applicationID);

}
