/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

import java.io.Serializable;

/**
 * Internal Class SKSV is used for storing a Serializable Key, Value pair.
 */
public class SKSV implements Serializable{

	private static final long serialVersionUID = -4183266375364707145L;

	/** The key. */
	public String key;
	
	/** The value. */
	public String value;
	
	/**
	 * Instantiates a new iKSV.
	 * 
	 * @param key
	 *            the key
	 * @param value
	 *            the value
	 */
	public SKSV(String key, String value) {
		this.key = key;
		this.value = value;
	}
}
