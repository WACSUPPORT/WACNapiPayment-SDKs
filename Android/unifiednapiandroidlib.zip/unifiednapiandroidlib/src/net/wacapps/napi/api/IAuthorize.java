/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

/**
 * The Interface IAuthorize, to be implemented by applications wishing to do their own oAuth
 * authorization.
 */
public interface IAuthorize {

	/**
	 * Authorize.
	 * 
	 * @param authUrl
	 *            the authorization url
	 * @param userName
	 *            the user name
	 * @param password
	 *            the password
	 * @return the string
	 */
	public String authorize(String authUrl, String userName, String password);
	
}
