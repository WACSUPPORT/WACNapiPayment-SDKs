/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

/**
 * Internal utility class used to hold return values
 */
public class OSPair {
	
	/** an object */
	public Object o;
	
	/** a string */
	public String s;
	
	/**
	 * Instantiates a new oS pair.
	 * 
	 * @param o
	 *            the o
	 * @param s
	 *            the s
	 */
	public OSPair(Object o, String s) {
		this.o = o;
		this.s = s;
	}

}
