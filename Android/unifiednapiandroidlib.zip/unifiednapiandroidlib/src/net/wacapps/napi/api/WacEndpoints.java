/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

import static net.wacapps.napi.util.LocalizationHelper.getMessage;
import android.os.Bundle;
import android.util.Log;


/**
 * The Class WacEndpoints contains all the end point URL's to connect to NAPI gateway and localization server.
 */
public class WacEndpoints {

	private static final String APP_ID_KEY = "app.id";

	private static final String DEBUG_IP = "debug.ip";

	/** The base url http r1. */
	private String baseUrlHttpR1 = "http://pro1.api.wacapps.net";
	
	/** The base url https r1. */
	private String baseUrlHttpsR1 = "https://pro1.api.wacapps.net";
	
	/** The discovery path r1. */
	private String discoveryPathR1 = baseUrlHttpR1 + "/discovery/operator/";
		
	/** The base url https r2. */
	private String baseUrlHttpsR2Staging = "https://staging.api.wacapps.net/";
		
	/** The base url https r2. */
	private static String baseUrlHttpsR2Production = "https://api.wacapps.net/";
	
	/** The query path r2. */
	private String queryPathR2 = null;
	
	/** The charge payment path r2. */
	private String authorizationChargePathR2 = null;
	
	/** The charge payment path. */
	private String chargePaymentPathR2 = null;

	/** The charge payment path. */
	private String accessTokenPathR2 = null;
	
	/** The Constant localizationPathDev. */
	private static final String localizationPathDev= "http://dev8.wacapps.net/i18n/";	
	
	/** The Constant localizationPathSandbox. */
	private static final String localizationPathSandbox= "http://res.api.wacapps.net/stage/i18n/";
	
	/** The Constant localizationPathProduction. */
	private static final String localizationPathProduction= "http://res.api.wacapps.net/i18n/";
	
	private String localizationPathSuccessPage = "https://res.api.wacapps.net/payment/confirm";

	/** The localization path. */
	private String localizationPath= localizationPathProduction;
	
	/** The spoofed source ip for staging. */
	private static String spoofedSourceIP = null;

	/** The Constant GERMAN_IP_STR. */
	public static final String GERMAN_IP_STR = "139.7.147.49";

	/** configure to PRODUCTION. */
	public final static int PRODUCTION = 10111;
	
	/** configure to STAGING. */
	public final static int STAGING = 10112;
	
	/** Deafault configuration. */
	public final static int DEFAULT = 10114;
	
	private int currentEnv = -1;
	
	/** configure to SANDBOX. */
	public final static int SANDBOX = 10115;
	
	/** Route through mobile radio when true. */
	private boolean routeThroughMobileRadio = true;
	
	private boolean useHttpClientForRedirects = false;
	
	/**
	 * Instantiates a new wac endpoints.
	 *
	 * @param httpBaseUrl the http base url
	 * @param httpsBaseUrl the https base url
	 * @param discoveryPath the discovery path
	 */
	@Deprecated
	public WacEndpoints(String httpBaseUrl, String httpsBaseUrl,
			String discoveryPath) {
		this.baseUrlHttpR1 = httpBaseUrl;
		this.baseUrlHttpsR1 = httpsBaseUrl;
		this.discoveryPathR1 = discoveryPath;
	}

	/**
	 * Instantiates a new wac endpoints.
	 *
	 * @param env the env
	 */
	public WacEndpoints(int env) {
		currentEnv = env;
		switch (env) {
		case PRODUCTION:
			baseUrlHttpR1 = "http://pro1.api.wacapps.net";
			baseUrlHttpsR1 = "https://pro1.api.wacapps.net";
			discoveryPathR1 = baseUrlHttpR1 + "/discovery/operator/";
			localizationPath = localizationPathProduction;
			queryPathR2 = baseUrlHttpsR2Production + "products";
			authorizationChargePathR2 = baseUrlHttpsR2Production + "/2/oauth/authorize";
			chargePaymentPathR2 = baseUrlHttpsR2Production + "/2/payment/acr:Authorization/transactions/amount";
			accessTokenPathR2 = baseUrlHttpsR2Production + "/2/oauth/access-token";
			break;
		case STAGING:
			baseUrlHttpR1 = "http://prostage.api.wacapps.net";
			baseUrlHttpsR1 = "https://prostage.api.wacapps.net";
			discoveryPathR1 = baseUrlHttpR1 + "/discovery/operator/";
			localizationPath = localizationPathDev;
			queryPathR2 = baseUrlHttpsR2Staging + "products";
			authorizationChargePathR2 = baseUrlHttpsR2Staging + "/2/oauth/authorize";
			chargePaymentPathR2 = baseUrlHttpsR2Staging + "/2/payment/acr:Authorization/transactions/amount";
			accessTokenPathR2 = baseUrlHttpsR2Staging + "/2/oauth/access-token";
			break;
		case SANDBOX:
			baseUrlHttpR1 = "http://prosbx.api.wacapps.net";
			baseUrlHttpsR1 = "https://prosbx.api.wacapps.net";
			discoveryPathR1 = baseUrlHttpR1 + "/discovery/operator/";
			localizationPath = localizationPathSandbox;
			queryPathR2 = baseUrlHttpsR2Production + "products";
			authorizationChargePathR2 = baseUrlHttpsR2Production + "/2/oauth/authorize";
			chargePaymentPathR2 = baseUrlHttpsR2Production + "/2/payment/acr:Authorization/transactions/amount";
			accessTokenPathR2 = baseUrlHttpsR2Production + "/2/oauth/access-token";
			break;
		case DEFAULT:
		default:
			throw new UnsupportedOperationException(getMessage("ENV_NOT_SUPPORTED"));
		}
	}

	/**
	 * Gets the base url http.
	 *
	 * @return the base url http
	 */
	public String getBaseUrlHttp() {
		return baseUrlHttpR1;
	}

	/**
	 * Sets the base url http.
	 *
	 * @param baseUrlHttp the new base url http
	 */
	public void setBaseUrlHttp(String baseUrlHttp) {
		this.baseUrlHttpR1 = baseUrlHttp;
	}

	/**
	 * Gets the base url https.
	 *
	 * @return the base url https
	 */
	public String getBaseUrlHttps() {
		return baseUrlHttpsR1;
	}

	/**
	 * Sets the base url https.
	 *
	 * @param baseUrlHttps the new base url https
	 */
	public void setBaseUrlHttps(String baseUrlHttps) {
		this.baseUrlHttpsR1 = baseUrlHttps;
	}

	/**
	 * Gets the discovery path.
	 *
	 * @return the discovery path
	 */
	public String getDiscoveryPath() {
		return discoveryPathR1;
	}

	/**
	 * Sets the discovery path.
	 *
	 * @param discoveryPath the new discovery path
	 */
	public void setDiscoveryPath(String discoveryPath) {
		this.discoveryPathR1 = discoveryPath;
	}

	/**
	 * Gets the query path.
	 *
	 * @return the query path
	 */
	public String getQueryPath() {
		return queryPathR2;
	}

	/**
	 * Sets the query path.
	 *
	 * @param queryPathR2 the new query path
	 */
	public void setQueryPath(String queryPathR2) {
		this.queryPathR2 = queryPathR2;
	}

	/**
	 * Gets the charge payment path.
	 *
	 * @return the chargePaymentPathR2
	 */
	public String getAuthorizationChargePath() {
		return authorizationChargePathR2;
	}

	/**
	 * Sets the charge payment path.
	 *
	 * @param chargePaymentPathR2 the chargePaymentPathR2 to set
	 */
	public void setAuthorizationChargePath(String chargePaymentPathR2) {
		this.authorizationChargePathR2 = chargePaymentPathR2;
	}

	/**
	 * Gets the charge payment path.
	 *
	 * @return the chargePaymentPath
	 */
	public String getChargePaymentPath() {
		return chargePaymentPathR2;
	}

	/**
	 * Sets the charge payment path.
	 *
	 * @param chargePaymentPath the chargePaymentPath to set
	 */
	public void setChargePaymentPath(String chargePaymentPath) {
		this.chargePaymentPathR2 = chargePaymentPath;
	}

	/**
	 * Gets the access token path.
	 *
	 * @return the accessTokenPathR2
	 */
	public String getAccessTokenPath() {
		return accessTokenPathR2;
	}

	/**
	 * Sets the access token path.
	 *
	 * @param accessTokenPathR2 the accessTokenPathR2 to set
	 */
	public void setAccessTokenPath(String accessTokenPathR2) {
		this.accessTokenPathR2 = accessTokenPathR2;
	}
	
	/**
	 * Returns localizaion server url.
	 *
	 * @return the localization path
	 */
	public String getLocalizationPath() {
		return localizationPath;
	}

	/**
	 * Sets localization path.
	 *
	 * @param localizationPath the new localization path
	 */
	public void setLocalizationPath(String localizationPath) {
		this.localizationPath = localizationPath;
	}

	/**
	 * Gets the spoofed source ip for staging.
	 *
	 * @return the spoofedSourceIPForStaging
	 */
	public static String getSpoofedDiscoverySourceIPForStaging() {
		return spoofedSourceIP;
	}

	/**
	 * Sets the spoofed source ip for staging.
	 *
	 * @param spoofedSourceIPForStaging the spoofedSourceIPForStaging to set
	 */
	public static void setSpoofedDiscoverySourceIPForStaging(String spoofedSourceIPForStaging) {
		spoofedSourceIP = spoofedSourceIPForStaging;
	}
	
	/**
	 * Sets the spoofed source ip for staging.
	 *
	 * @param extras 
	 * @param applicatonId must match the applicationID internal setting
	 */
	public void setSpoofedDiscoverySourceIPForStaging(Bundle extras, String applicatonId) {
		if (extras != null) {
			String debugIP = (String)extras.get(DEBUG_IP);
			String appID = (String)extras.get(APP_ID_KEY);
			if(debugIP!=null && appID!=null && appID.equals(applicatonId)){
				Log.d("SPOOF_IP", APP_ID_KEY+"="+debugIP+" "+APP_ID_KEY+"="+appID);
				spoofedSourceIP = debugIP;				
			}
		}
	}
	
	
	/**
	 * Checks if is route through mobile radio.
	 *
	 * @return true, if is route through mobile radio
	 */
	@SuppressWarnings("unused")
	public boolean isRouteThroughMobileRadio() {
		return routeThroughMobileRadio;
	}

	/**
	 * Sets the route through mobile radio.
	 *
	 * @param routeThroughMobileRadio the new route through mobile radio
	 */
	@SuppressWarnings("unused")
	private void setRouteThroughMobileRadio(boolean routeThroughMobileRadio) {
		this.routeThroughMobileRadio = routeThroughMobileRadio;
	}

	/**
	 * @return true if in production
	 */
	public boolean inProduction() {
		return currentEnv == PRODUCTION;
	}

	/**
	 * Use http client for forwards.
	 *
	 * @return true, if successful
	 */
	public boolean useHttpClientForForwards() {
		return useHttpClientForRedirects;
	}

	/**
	 * @param useHttpClientForRedirects the useHttpClientForRedirects to set
	 */
	public void setUseHttpClientForRedirects(boolean useHttpClientForRedirects) {
		this.useHttpClientForRedirects = useHttpClientForRedirects;
	}

	/**
	 * @return the localizationPathSuccessPage
	 */
	public String getLocalizationPathForSuccessPage() {
		return localizationPathSuccessPage;
	}

	/**
	 * @param localizationPathSuccessPage the localizationPathSuccessPage to set
	 */
	public void setLocalizationPathForSuccessPage(
			String localizationPathSuccessPage) {
		this.localizationPathSuccessPage = localizationPathSuccessPage;
	}

	public static String getBaseUrlHttpsR2Production() {
		return baseUrlHttpsR2Production;
	}

}