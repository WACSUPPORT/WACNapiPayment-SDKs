/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

import java.util.List;

import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.Operator;
import net.wacapps.napi.resource.jaxb.Product;
import net.wacapps.napi.util.LocalizationHelper;
import net.wacapps.napi.util.NapiLog;
import net.wacapps.napi.xdo.applications.Application;
import net.wacapps.napi.xdo.applications.Credential;
import net.wacapps.napi.xdo.developer.Developer;

/**
 * The Class WacPaymentService.
 */
public abstract class WacPaymentService implements PaymentService {
	
	/** implicit grant mode. */
	public static String TOKEN_MODE_IMPLICIT = "token";
	
	/** code grant mode. */
	public static String TOKEN_MODE_CODE = "code";
	
	/** API Version .2 */
	public static int APIDOT2 = 2002;
	
	/** API Version .1 */
	public static int APIDOT1 = 2001;
	
	/** The current API Version being talked. */
	protected int API_VER = APIDOT2;

	/** Debug flag. */
	protected static boolean debug = false;
	
	/** The Log TAG. */
	protected static String TAG = "Wac";
	
	/** Internal operator object */
	protected Operator operator;
	
	/** Internal product instance */
	protected Product product;
	
	/** Current developer credentials */
	protected String credential;
	
	/** The redirection URI. */
	protected String redirectUriOAuth;
	
	/** default to implicit grant. */
	protected String tokenMode = TOKEN_MODE_IMPLICIT;
	
	/** The secret. */
	protected String secret;
	
	/** html content for 0.1 success page*/
	protected String htmlTemp;

	public String getHtmlTemp() {
		return htmlTemp;
	}

	public void setHtmlTemp(String htmlTemp) {
		this.htmlTemp = htmlTemp;
	}

	/** Localization helper instance. */
	@SuppressWarnings("unused")
	private static LocalizationHelper localizationHelperInstance;
	
	
	/**
	 * Gets the access token mode.
	 *
	 * @return the token mode
	 */
	public String getTokenMode() {
		return tokenMode;
	}

	/**
	 * Sets the access token mode. Defaults to TOKEN_MODE_CODE
	 *
	 * @param tokenMode the new token mode
	 */
	public void setTokenMode(String tokenMode) {
		this.tokenMode = tokenMode;
	}

	/**
	 * Gets the operator.
	 * 
	 * @return the operator
	 */
	public Operator getOperator() {
		return operator;
	}

	/**
	 * Sets the operator.
	 * 
	 * @param operator
	 *            the new operator
	 */
	public void setOperator(Operator operator) {
		this.operator = operator;
	}

	/**
	 * Gets the product.
	 * 
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * Sets the product.
	 * 
	 * @param product
	 *            the new product
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * Gets the credential.
	 * 
	 * @return the credential
	 */
	public String getCredential() {
		return credential;
	}

	/**
	 * Sets the credential.
	 * 
	 * @param credential
	 *            the new credential
	 */
	public void setCredential(String credential) {
		this.credential = credential;
	}

	/**
	 * Gets the secret.
	 * 
	 * @return the secret
	 */
	public String getSecret() {
		return secret;
	}

	/**
	 * Gets the operator.
	 * 
	 * @return the operator
	 */
	public String getRedirectUriOAuth() {
		return redirectUriOAuth;
	}
	
	/**
	 * Sets the secret.
	 * 
	 * @param secret
	 *            the new secret
	 */
	public void setSecret(String secret) {
		this.secret = secret;
	}

	/** 
	 * Initializes the objects required to process the payment (application ID, credential, secret, developer ID redirectURI and product information). 
	 * This data is obtained when the application is registered with WAC.
	 * 
	 **/
	@Override
	public void initialize(String applicationIdentifier, String credential, String secret, 
			String developerID, String redirectURI) throws NapiException {
		
		this.credential = credential;
		this.secret = secret;
		this.redirectUriOAuth = redirectURI;
		this.htmlTemp = null;
		
		Application app = new Application();
		app.setApplicationIdentifier(applicationIdentifier);

		Credential cred = new Credential();
		cred.setKey(credential);
		
		Developer dev = new Developer();
		dev.setUserName(developerID);
		
		OSPair op = WacRestApi.doQuery(app, null, cred, dev, secret);
		NapiLog.d(TAG, op.s);
		this.product = (Product) op.o;
		NapiLog.d(TAG, "In initialize, product app id now set to " + product.getApplicationId());
		localizationHelperInstance = new LocalizationHelper();
	}
	
	/* (non-Javadoc)
	 * @see net.wacapps.napi.api.PaymentService#listProductItems()
	 */
	@Override
	public List<Item> listProductItems() {
		return product.getItems();
	}

	public boolean checkBillingAvailability(String applicationIdentifier,
			String credential, String secret, String developerID) {

		this.credential = credential;
		this.secret = secret;
		this.htmlTemp = null;

		Application app = new Application();
		app.setApplicationIdentifier(applicationIdentifier);

		Credential cred = new Credential();
		cred.setKey(credential);

		Developer dev = new Developer();
		dev.setUserName(developerID);
		
		try {
			WacRestApi.doQuery(app, null, cred, dev, secret);
			return true;
		} catch (Exception e) {
			NapiLog.d(TAG, e.toString());
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see net.wacapps.napi.api.PaymentService#getProductItem(java.lang.String)
	 */
	@Override
	public Item getProductItem(String itemID) {
		for(Item i : product.getItems()) {
			if(i.getItemId().equals(itemID))
				return i;
		}
		return null;
	}
	
	/**
	 * Checks if is debug.
	 * 
	 * @return true, if is debug
	 */
	public static boolean isDebug() {
		return debug;
	}

	/**
	 * Sets the debug.
	 * 
	 * @param debug
	 *            the new debug
	 */
	public static void setDebug(boolean debug) {
		WacPaymentService.debug = debug;
	}

	/**
	 * Gets the current API version.
	 *
	 * @return the API version
	 */
	public int getAPIVersion() {
		return API_VER;
	}

	/**
	 * Sets the current API version.
	 *
	 * @param APIVersion the new API version
	 */
	public void setAPIVersion(int APIVersion) {
		this.API_VER = APIVersion;
	}
		
}
