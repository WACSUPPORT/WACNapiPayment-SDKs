/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.api;

import static net.wacapps.napi.util.LocalizationHelper.getMessage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import net.wacapps.napi.util.Base64;
import net.wacapps.napi.util.Hex;
import net.wacapps.napi.util.NapiLog;
import net.wacapps.napi.util.ProxySettings;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;

import android.app.Activity;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;

/**
 * Contains the utility methods for String handling, encoding/decoding, hashing and HTTP redirection.
 */
public class Util {

	/** The HMACSH a256_ algorithm. */
	private static String HMACSHA256_ALGORITHM = "HmacSHA256";

	/** The Constant HEX_DIGITS. */
	private static final char[] HEX_DIGITS = "0123456789ABCDEF".toCharArray();

	private static final String TAG = "WAC";

	/**
	 * Checks if the string is blank.
	 * 
	 * @param str
	 *            the str
	 * @return true, if is blank
	 */
	public static boolean isBlank(String str) {
		int strLen;
		if (str == null || (strLen = str.length()) == 0)
			return true;
		for (int i = 0; i < strLen; i++)
			if (!Character.isWhitespace(str.charAt(i)))
				return false;

		return true;
	}

	/**
	 * Returns the Substring before the separator.
	 * 
	 * @param str
	 *            the str
	 * @param separator
	 *            the separator
	 * @return the string
	 */
	public static String substringBefore(String str, String separator) {
		if (isBlank(str) || separator == null)
			return str;
		if (separator.length() == 0)
			return "";
		int pos = str.indexOf(separator);
		if (pos == -1)
			return str;
		else
			return str.substring(0, pos);
	}

	/**
	 * Returns the Substring after the separator.
	 * 
	 * @param str
	 *            the str
	 * @param separator
	 *            the separator
	 * @return the string
	 */
	public static String substringAfter(String str, String separator) {
		if (isBlank(str))
			return str;
		if (separator == null)
			return "";
		int pos = str.indexOf(separator);
		if (pos == -1)
			return "";
		else
			return str.substring(pos + separator.length());
	}

	/**
	 * gets the base64 encoded and hashed message authentication code using sha256.
	 * 
	 * @param sharedSecret
	 *            the shared secret
	 * @param applicationIdentifier
	 *            the application identifier
	 * @param userName
	 *            the user name
	 * @param timeStamp
	 *            the time stamp
	 * @return the base64 hmac sh a256
	 * @throws Exception
	 *             the exception
	 */
	public static String getBase64HmacSHA256(String sharedSecret,
			String applicationIdentifier, String userName, long timeStamp)
			throws Exception {

		byte[] keyBytes = sharedSecret.getBytes("UTF-8");
		SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes,
				HMACSHA256_ALGORITHM);

		Mac mac = Mac.getInstance(HMACSHA256_ALGORITHM);
		mac.init(secretKeySpec);

		String baseString = userName + applicationIdentifier + timeStamp;
		mac.update(baseString.getBytes("UTF-8"));

		byte[] macBytes = mac.doFinal();
		byte[] base64Bytes = Base64.encode(macBytes).getBytes();
		String hexBytes = new String(Hex.encode(base64Bytes));
		return hexBytes;
	}

	/**
	 * Oauth encode.
	 * 
	 * @param input
	 *            the input
	 * @return the string
	 */
	public static String oauthEncode(String input) {
		if ((input == null) || "".equals(input)) {
			return "";
		}
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i < input.length(); i++) {
			final char ch = input.charAt(i);
			// Unreserved character set
			if (Character.isLetter(ch) || Character.isDigit(ch) || (ch == '-')
					|| (ch == '.') || (ch == '_') || (ch == '&') || (ch == '~')) {
				// Character as-is
				sb.append(ch);
			} else {
				if (ch > 256) {
					throw new IllegalArgumentException(getMessage("CHARACTER_OUT_OF_RANGE"));
				}
				// %XX where XX are uppercase hex characters
				sb.append('%');
				sb.append(HEX_DIGITS[ch >> 4]);
				sb.append(HEX_DIGITS[ch & 0x0F]);
			}
		}
		return sb.toString();
	}

	/**
	 * O encode.
	 * 
	 * @param str
	 *            the str
	 * @return the string
	 */
	public static String oEncode(String str) {
		return oEncode1(str);
	}

	// ! * ' ( ) ; : @ & = + $ , / ? % # [ ]
	// %21 %2A %27 %28 %29 %3B %3A %40 %26 %3D %2B %24 %26 %2F %3F %25 %23 %5B
	// %5D
	/**
	 * O encode1.
	 * 
	 * @param str
	 *            the str
	 * @return the string
	 */
	public static String oEncode1(String str) {
		StringBuilder sb = new StringBuilder();
		for (char c : str.toCharArray()) {
			switch (c) {
			case '!':
				sb.append("%21");
				break;
			case '*':
				sb.append("%2A");
				break;
			case '\'':
				sb.append("%27");
				break;
			case '(':
				sb.append("%28");
				break;
			case ')':
				sb.append("%29");
				break;
			case ';':
				sb.append("%3B");
				break;
			case ':':
				sb.append("%3A");
				break;
			case '@':
				sb.append("%40");
				break;
			case '&':
				sb.append("%26");
				break;
			case '=':
				sb.append("%3D");
				break;
			case '+':
				sb.append("%2B");
				break;
			case '$':
				sb.append("%24");
				break;
			case ',':
				sb.append("%26");
				break;
			case '/':
				sb.append("%2F");
				break;
			case '?':
				sb.append("%3F");
				break;
			case '%':
				sb.append("%25");
				break;
			case '#':
				sb.append("%23");
				break;
			case '[':
				sb.append("%5B");
				break;
			case ']':
				sb.append("%5D");
				break;

			default:
				sb.append(c);
				break;
			}
		}
		return sb.toString();
	}

	/**
	 * Send a HTTP GET or POST, and expect a redirect.
	 * 
	 * @param httpClient
	 *            the http client
	 * @param httpMethod
	 * 			  GET or POST
	 * @param url
	 *            the url
	 * @param mcc
	 *            mcc, or null to omit
	 * @param mnc
	 *            mnc, or null to omit
	 * @return the string
	 */
	public static String httpSendRedirectUrl(HttpClient httpClient,
			String httpMethod, String url, String mcc, String mnc) {
		// Construct the GET out of the URL and the headers
		final HttpUriRequest httpUriRequest;
		if ("get".equalsIgnoreCase(httpMethod)) {
			httpUriRequest = new HttpGet(url);
		} else if ("post".equalsIgnoreCase(httpMethod)) {
			throw new IllegalArgumentException(
					getMessage("INVALID_HTTP_METHOD") + " " + httpMethod);
		} else {
			throw new IllegalArgumentException(
					getMessage("INVALID_HTTP_METHOD") + " " + httpMethod);
		}

		if (mcc != null) {
			httpUriRequest.setHeader("x-mcc", mcc);
		}

		if (mnc != null) {
			httpUriRequest.setHeader("x-mcc", mnc);
		}

		// Disable automatic following redirect
		final HttpParams httpParams = new BasicHttpParams();
		HttpClientParams.setRedirecting(httpParams, false);
		httpUriRequest.setParams(httpParams);

		HttpResponse httpResponse = null;

		try {
			httpResponse = httpClient.execute(httpUriRequest);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		final int httpCode = httpResponse.getStatusLine().getStatusCode();

		if (httpCode == 401 || httpCode == 400) {
			return null;
		} else {
			final Header[] headers = httpResponse.getHeaders("Location");
			return headers[0].getValue();
		}
	}

	/**
	 * Gets the url parameters from a valid URL based on the splitter provided. 
	 * 
	 * @param url
	 *            the url
	 * @return the url parameters
	 * @throws UnsupportedEncodingException
	 *             the unsupported encoding exception
	 */
	public static Map<String, List<String>> getUrlParameters(String url,
			String splitter) throws UnsupportedEncodingException {
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String[] urlParts = url.split(splitter);
		if (urlParts.length > 1) {
			String query = urlParts[1];
			for (String param : query.split("&")) {
				// String pair[] = param.split("=");
				int i = param.indexOf("=");
				String paramName = param.substring(0, i);
				String paramValue = param.substring(i + 1, param.length());
				String key = URLDecoder.decode(paramName, "UTF-8");
				String value = URLDecoder.decode(paramValue, "UTF-8");
				List<String> values = params.get(key);
				if (values == null) {
					values = new ArrayList<String>();
					params.put(key, values);
				}
				values.add(value);
			}
		}
		return params;
	}

	/**
	 * Calculates the sha1 hash of str using the US Secure Hash Algorithm 1, and returns the hex converted hash.
	 * 
	 * @param text
	 * @return SHA1 of the input String
	 * @throws NoSuchAlgorithmException
	 * @throws UnsupportedEncodingException
	 */
	public static String SHA1(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MessageDigest md;
		md = MessageDigest.getInstance("SHA-1");
		byte[] sha1hash = new byte[40];
		md.update(text.getBytes("iso-8859-1"), 0, text.length());
		sha1hash = md.digest();
		return convertToHex(sha1hash);
	}
	
	/**
	 * Converts a byte array to hex string
	 * 
	 * @param data
	 * @return a string converted to Hex
	 */
	private static String convertToHex(byte[] data) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < data.length; i++) {
			int halfbyte = (data[i] >>> 4) & 0x0F;
			int two_halfs = 0;
			do {
				if ((0 <= halfbyte) && (halfbyte <= 9))
					buf.append((char) ('0' + halfbyte));
				else
					buf.append((char) ('a' + (halfbyte - 10)));
				halfbyte = data[i] & 0x0F;
			} while (two_halfs++ < 1);
		}
		return buf.toString();
	}
	
	/**
	 * Checks if is on mobile data, can handle lack of permissions.
	 *
	 * @param cm the ConnectivityManager instance
	 * @return true, if is on mobile data
	 */
	public static boolean isOnMobileData(ConnectivityManager cm) {
		try {
			NetworkInfo info = cm.getActiveNetworkInfo();
			if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
				NapiLog.d(TAG, "Network on mobile data" + info.getType()+"::"+ ConnectivityManager.TYPE_MOBILE);
				return true;
			} else {
				NapiLog.d(TAG, "Network not on mobile data" + info.getType()+"::"+ConnectivityManager.TYPE_MOBILE);
				return false;
			} 
		} catch (SecurityException e) {
			// probably app does not have permissions, lets return false
			NapiLog.d(TAG,
					"probably app does not have permissions, lets return false");
			return false;
		}
	}

	/**
	 * Checks if is connected, can handle lack of permissions.
	 *
	 * @param cm the ConnectivityManager instance
	 * @return true, if is connected
	 */
	public static boolean isConnected(ConnectivityManager cm) {
		try {
			NetworkInfo ni = cm.getActiveNetworkInfo();
			if (ni != null && ni.isAvailable() && ni.isConnected()) {
				return true;
			} else {
				return false;
			}
		} catch (SecurityException e) {
			// app does not have permissions for this, lets try returning true
			NapiLog.d(TAG,
					"probably app does not have permissions, lets return true");
			return true;
		}
	}

	/**
	 * Sets the Access Point Name (APN) proxy.
	 *
	 * @param app the app
	 * @return the http host
	 */
	public static HttpHost setAPNProxy(Activity app) {
		Log.d(TAG, "In set proxy");
		String proxy = null;
		int port = 80;
		//String user;
		//String password;
		Uri uri = Uri.parse("content://telephony/carriers/preferapn");
		Cursor cursor = app.managedQuery(uri, new String[] { "proxy", "port",
				"user", "password", "current" }, null, null, null);

		if (cursor.moveToNext()) {
			proxy = cursor.getString(0);
			int tempPort = cursor.getInt(1);
			port = (tempPort > 0) ? tempPort : port;
			//user = cursor.getString(2);
			//password = cursor.getString(3);
		} else {
			NapiLog.d(TAG, "No APNs found, and none used");
			return null;
		}
		NapiLog.d(TAG, "queried APN settings - proxy=" + proxy + ", port="
				+ port);
		if (proxy != null && proxy.length() > 1) {
			NapiLog.d(TAG, "Setting proxy settings!!!");
			ProxySettings.setProxy(app, proxy, port);
			HttpHost proxyHost = new HttpHost(proxy, port);
			return proxyHost;
		} else {
			NapiLog.d(TAG, "Not doing proxy settings, none found");
			return null;
		}
	}
}
