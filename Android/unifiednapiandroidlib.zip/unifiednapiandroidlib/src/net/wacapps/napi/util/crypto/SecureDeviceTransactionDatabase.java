/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.util.crypto;

import java.util.List;

import net.wacapps.napi.api.SKSV;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionArray;
import net.wacapps.napi.resource.jaxb.TransactionList;
import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Provides an implementaion for secured device transaction storage 
 * 
 **/
public class SecureDeviceTransactionDatabase implements DeviceTransactionStorage {

	private static final String TAG = "Wac";
	private SecureDatabase pd;
	private Context context;
	private String appId;

	public SecureDeviceTransactionDatabase(Context context, String appId) {
		this.context = context;
		this.appId = appId;
		pd = new SecureDatabase(context);
	}

	public void insert(String tXID, String payload) {
		try {
			pd.insertOrUpdateObject(context, appId, tXID, new SKSV(tXID, payload), System.currentTimeMillis());
		} catch (Exception err) {
			Log.e(TAG, "Failed to store transaction", err);
		}
	}

	public void deleteAll() {
		pd.deleteAll();
	}

	public SKSV getTransaction(String tXID) {
		try {
			return (SKSV) pd.getObject(context, appId, tXID, Long.MAX_VALUE);
		} catch (Exception err) {
			Log.e(TAG, "Failed to get transaction", err);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public TransactionList getTransactionList() {
		TransactionList list = new TransactionList();
		list.setPaymentTransactionList(new TransactionArray());
		List<SKSV> listInternal = (List<SKSV>) pd.getAllObjects(context, appId, Long.MAX_VALUE);
		GsonBuilder gsonb = new GsonBuilder();
		gsonb.setPrettyPrinting();
		Gson gson = gsonb.create();
		for (SKSV item : listInternal) {
			Transaction tx = gson.fromJson(item.value, Transaction.class);
			list.getPaymentTransactionList().getAmountTransaction().add(tx.getAmountTransaction());
		}
		return list;
	}

	public void close() {
		pd.close();
	}

}
