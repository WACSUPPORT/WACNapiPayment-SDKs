/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.util;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Encode and decode byte arrays (typically from binary to 7-bit ASCII 
 * encodings).
 */
public interface Encoder {
    
    /**
	 * Encode.
	 * 
	 * @param data
	 *            the data
	 * @param off
	 *            the off
	 * @param length
	 *            the length
	 * @param out
	 *            the out
	 * @return the int
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
    int encode(byte[] data, int off, int length, OutputStream out)
            throws IOException;

    /**
	 * Decode.
	 * 
	 * @param data
	 *            the data
	 * @param off
	 *            the off
	 * @param length
	 *            the length
	 * @param out
	 *            the out
	 * @return the int
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
    int decode(byte[] data, int off, int length, OutputStream out)
            throws IOException;

    /**
	 * Decode.
	 * 
	 * @param data
	 *            the data
	 * @param out
	 *            the out
	 * @return the int
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
    int decode(String data, OutputStream out) throws IOException;
}
