/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.util.crypto;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public enum PermissionID {
	TELEPHONY_SERVICE("TELEPHONY_SERVICE"), 
	ANDROID_ID("ANDROID_ID"), 
	WIFI_SERVICE("WIFI_SERVICE"), 
	BT_SERVICE("BT_SERVICE");

	private static final String SEP = ",";
	private String text;

	PermissionID(String text) {
		this.text = text;
	}

	public String getText() {
		return this.text;
	}

	public static PermissionID fromString(String text) {
		if (text != null) {
			for (PermissionID b : PermissionID.values()) {
				if (text.equalsIgnoreCase(b.text)) {
					return b;
				}
			}
		}
		return null;
	}
	
	public static String permissionSetToString(Set<PermissionID> permissions){
		Iterator<PermissionID> iter= permissions.iterator();
		StringBuffer result= new StringBuffer();
		while(iter.hasNext()){
			PermissionID permission= iter.next();
			result.append(permission.getText());
			if(iter.hasNext()){
				result.append(SEP);
			}
		}
		return result.toString();
	}
	
	public static Set<PermissionID> stringToPermssionSet(
			String commaSeparatedPermissions) {
		Set<PermissionID> result = new HashSet<PermissionID>();
		if (commaSeparatedPermissions != null) {
			String[] permStrings = commaSeparatedPermissions.split(SEP);
			for (String permissionString : permStrings) {
				PermissionID permissionID = fromString(permissionString);
				if(permissionID!=null){
					result.add(permissionID);
				}
			}
		}
		return result;
	}
}