/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.util;

import android.util.Log;
import net.wacapps.napi.api.WacPaymentService;

/**
 * Utility class for NAPI logger.
 */
public class NapiLog {
	
	/**
	 * D.
	 * 
	 * @param tag
	 *            the tag
	 * @param message
	 *            the message
	 */
	public static void d(String tag, String message) {
		if(WacPaymentService.isDebug())
			Log.d(tag, message);
	}

}
