/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.util.crypto;

import net.wacapps.napi.api.SKSV;
import net.wacapps.napi.resource.jaxb.TransactionList;

/**
 * Physical storage of persistent objects. Transaction Objects are stored.
 */
public interface DeviceTransactionStorage {
	
	/**
	 * Insert transaction data.
	 * 
	 * @param tXID
	 * @param payload
	 */
	public void insert(String tXID, String payload);

	/**
	 * Deletes all the records from database
	 * 
	 */
	public void deleteAll();
	
	/**
	 * Get a Transaction from storage using transaction ID.
	 * 
	 * @param tXID
	 * @return String key and String value pair
	 */
	public SKSV getTransaction(String tXID);
	
	/**
	 * Fetches list of transactions from storage. 
	 * 
	 * @return transaction list
	 */
	public TransactionList getTransactionList();

	/**
	 * Close database/storage connection
	 * 
	 */
	public void close();
}
