/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/
package net.wacapps.napi.util;

import java.io.IOException;
import java.lang.reflect.Field;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.scheme.LayeredSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.HttpParams;

/**
 * Contains utilities to build form headers, URL strings
 */
public class NapiHttpHelper {

	/** The Constant EMPTY_STRING. */
	public static final String EMPTY_STRING = "";
	
	/** The Constant QUESTION_MARK. */
	public static final String QUESTION_MARK = "?";
	
	/** The Constant AMPERSAND. */
	public static final String AMPERSAND = "&";
	
	/** The Constant EQUAL_TO. */
	public static final String EQUAL_TO = "=";

	private static final int ICS_VERSION_CODE = 14;
	
	private static final boolean PATCH_PRE_ICS_DNS=true;

	/**
	 * Constructs a basic header array. Each header field consists of a name followed by a colon (":") and the field value.
	 * Field names are case-insensitive. 
	 * 
	 * @param headers
	 *            the headers
	 * @return the basic header[]
	 */
	public static BasicHeader[] formHeaders(Map<String, String> headers) {
		List<BasicHeader> result = new ArrayList<BasicHeader>();
		if (headers.size() > 0) {
			for (Map.Entry<String, String> header : headers.entrySet()) {
				result.add(new BasicHeader(header.getKey(), header.getValue()));
			}
		}

		return result.toArray(new BasicHeader[result.size()]);
	}

	/**
	 * Forms a valid URL string.
	 * 
	 * @param baseUrl
	 *            the base url
	 * @param params
	 *            the params
	 * @return the string
	 */
	public static String formUrlString(String baseUrl,
			Map<String, String> params) {
		StringBuilder result = new StringBuilder();
		result.append(baseUrl).append(QUESTION_MARK)
				.append(keyValueParameters(params));

		return result.toString();
	}

	/**
	 * Key value parameters.
	 * 
	 * @param params
	 *            the params
	 * @return the string
	 */
	public static String keyValueParameters(Map<String, String> params) {
		return keyValueParameters(params, AMPERSAND);
	}

	/**
	 * Key value parameters.
	 * 
	 * @param params
	 *            the params
	 * @param separator
	 *            the separator
	 * @return the string
	 */
	public static String keyValueParameters(Map<String, String> params,
			String separator) {
		return keyValueParameters(params, separator, false);
	}

	/**
	 * Key value parameters.
	 * 
	 * @param params
	 *            the params
	 * @param separator
	 *            the separator
	 * @param doubleQuotedValues
	 *            the double quoted values
	 * @return the string
	 */
	public static String keyValueParameters(Map<String, String> params,
			String separator, boolean doubleQuotedValues) {
		StringBuilder result = new StringBuilder();

		boolean firstParam = true;

		for (Map.Entry<String, String> entry : params.entrySet()) {
			String value = entry.getValue();
			result.append(firstParam ? EMPTY_STRING : separator)
					.append(entry.getKey())
					.append(EQUAL_TO)
					.append(doubleQuotedValues ? addDoubleQuotes(value) : value);
			firstParam = false;
		}
		return result.toString();
	}

	/**
	 * Adds the double quotes.
	 * 
	 * @param string
	 *            the string
	 * @return the string
	 */
	public static String addDoubleQuotes(String string) {
		return "\"" + string + "\"";
	}
	
	public static void workAroundReverseDnsBugForNonICSDevices(HttpClient client) {
		// Android had a bug where HTTPS made reverse DNS lookups (fixed in Ice
		// Cream Sandwich)
		// http://code.google.com/p/android/issues/detail?id=13117
		if (PATCH_PRE_ICS_DNS && android.os.Build.VERSION.SDK_INT <ICS_VERSION_CODE) {
			SocketFactory socketFactory = new LayeredSocketFactory() {
				SSLSocketFactory delegate = SSLSocketFactory.getSocketFactory();

				public Socket createSocket() throws IOException {
					return delegate.createSocket();
				}

				public Socket connectSocket(Socket sock, String host, int port, InetAddress localAddress, int localPort,
						HttpParams params) throws IOException {
					return delegate.connectSocket(sock, host, port, localAddress, localPort, params);
				}

				public boolean isSecure(Socket sock) throws IllegalArgumentException {
					return delegate.isSecure(sock);
				}

				public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException {
					injectHostname(socket, host);
					return delegate.createSocket(socket, host, port, autoClose);
				}

				private void injectHostname(Socket socket, String host) {
					try {
						Field field = InetAddress.class.getDeclaredField("hostName");
						field.setAccessible(true);
						field.set(socket.getInetAddress(), host);
					} catch (Exception ignored) {
					}
				}

			};
			client.getConnectionManager().getSchemeRegistry().register(new Scheme("https", socketFactory, 443));
		}
	}

}
