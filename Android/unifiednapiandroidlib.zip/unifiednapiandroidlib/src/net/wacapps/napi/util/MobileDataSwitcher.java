/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.util;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo.State;
import android.text.TextUtils;
import android.util.Log;

/**
 * The Class MobileDataSwitcher.
 * Used to route traffic through the mobile radio network
 */
public class MobileDataSwitcher {
	
	/** The log TAG. */
	private static String TAG_LOG = "Wac";
	
	/**
	 * Enable mobile connection for a specific address.
	 *
	 * @param context a Context (application or activity)
	 * @param address the address to enable
	 * @return true for success, else false
	 */
	public static boolean forceMobileConnectionForAddress(Context context, String address) {
	    ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NapiLog.d(TAG_LOG, "In forceMobileConnectionForAddress");
	    if (null == connectivityManager) {
	        NapiLog.d(TAG_LOG, "ConnectivityManager is null, cannot try to force a mobile connection");
	        return false;
	    }

	    //check if mobile connection is available and connected
	    State state = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE_HIPRI).getState();
	    NapiLog.d(TAG_LOG, "TYPE_MOBILE_HIPRI network state: " + state);
	    if (0 == state.compareTo(State.CONNECTED) || 0 == state.compareTo(State.CONNECTING)) {
	        return true;
	    }

	    //activate mobile connection in addition to other connection already activated
	    int resultInt = connectivityManager.startUsingNetworkFeature(ConnectivityManager.TYPE_MOBILE, "enableHIPRI");
	    NapiLog.d(TAG_LOG, "startUsingNetworkFeature for enableHIPRI result: " + resultInt);

	    //-1 means errors
	    // 0 means already enabled
	    // 1 means enabled
	    // other values can be returned, because this method is vendor specific
	    if (-1 == resultInt) {
	        Log.e(TAG_LOG, "Wrong result of startUsingNetworkFeature, maybe problems");
	        return false;
	    }
	    if (0 == resultInt) {
	        NapiLog.d(TAG_LOG, "No need to perform additional network settings");
	        return true;
	    }

	    //find the host name to route
	    String hostName = extractAddressFromUrl(address);
	    NapiLog.d(TAG_LOG, "Source address: " + address);
	    NapiLog.d(TAG_LOG, "Destination host address to route: " + hostName);
	    if (TextUtils.isEmpty(hostName)) hostName = address;

	    //create a route for the specified address
	    int hostAddress = lookupHost(hostName);
	    if (-1 == hostAddress) {
	        Log.e(TAG_LOG, "Wrong host address transformation, result was -1");
	        return false;
	    }
	    //wait some time needed to connection manager for waking up
	    try {
	        for (int counter=0; counter<30; counter++) {
	            State checkState = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE_HIPRI).getState();
	            if (0 == checkState.compareTo(State.CONNECTED))
	                break;
	            Thread.sleep(1000);
	        }
	    } catch (InterruptedException e) {
	        //nothing to do
	    }
	    boolean resultBool = connectivityManager.requestRouteToHost(ConnectivityManager.TYPE_MOBILE_HIPRI, hostAddress);
	    NapiLog.d(TAG_LOG, "requestRouteToHost result: " + resultBool);
	    if (!resultBool)
	        Log.e(TAG_LOG, "Wrong requestRouteToHost result: expected true, but was false");

	    return resultBool;
	}
	
	/**
	 * Utility to check if the gateway is reachable.
	 *
	 * @param url eg. http://some.where.com:8080/sync
	 * @return true if the server is reachable and false if the server is not reachable
	 */	
	public static boolean isServerReachable(String address) {
		boolean result = false;

		HttpURLConnection connection = null;
		HttpURLConnection connectionRedir = null;
		try {
			connection = (HttpURLConnection) new URL(address).openConnection();
			System.out.println(connection.getHeaderFields());
			if (connection != null && connection.getResponseCode() == 302) {
				connectionRedir = (HttpURLConnection) new URL(
						connection.getHeaderField("Location")).openConnection();
			} else {
				return result;
			}
			if (connectionRedir != null
					&& connectionRedir.getResponseCode() != 200) {
				return result;
			} else {
				result = true;
				return result;
			}
		} catch (MalformedURLException e) {
			return result;
		} catch (IOException e) {
			return result;
		}
	}
	
	/**
	 * This method extracts from address the hostname.
	 *
	 * @param url eg. http://some.where.com:8080/sync
	 * @return some.where.com
	 */
	public static String extractAddressFromUrl(String url) {
	    String urlToProcess = null;

	    //find protocol
	    int protocolEndIndex = url.indexOf("://");
	    if(protocolEndIndex>0) {
	        urlToProcess = url.substring(protocolEndIndex + 3);
	    } else {
	        urlToProcess = url;
	    }

	    // If we have port number in the address we strip everything
	    // after the port number
	    int pos = urlToProcess.indexOf(':');
	    if (pos >= 0) {
	        urlToProcess = urlToProcess.substring(0, pos);
	    }

	    // If we have resource location in the address then we strip
	    // everything after the '/'
	    pos = urlToProcess.indexOf('/');
	    if (pos >= 0) {
	        urlToProcess = urlToProcess.substring(0, pos);
	    }

	    // If we have ? in the address then we strip
	    // everything after the '?'
	    pos = urlToProcess.indexOf('?');
	    if (pos >= 0) {
	        urlToProcess = urlToProcess.substring(0, pos);
	    }
	    return urlToProcess;
	}

	/**
	 * Transform host name in int value used by {@link ConnectivityManager.requestRouteToHost}
	 * method
	 *
	 * @param hostname the hostname
	 * @return -1 if the host doesn't exists, elsewhere its translation
	 * to an integer
	 */
	private static int lookupHost(String hostname) {
	    InetAddress inetAddress;
	    try {
	        inetAddress = InetAddress.getByName(hostname);
	    } catch (UnknownHostException e) {
	        return -1;
	    }
	    byte[] addrBytes;
	    int addr;
	    addrBytes = inetAddress.getAddress();
	    addr = ((addrBytes[3] & 0xff) << 24)
	            | ((addrBytes[2] & 0xff) << 16)
	            | ((addrBytes[1] & 0xff) << 8 )
	            |  (addrBytes[0] & 0xff);
	    return addr;
	}

}
