/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.util.crypto;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import net.wacapps.napi.util.Base64;
import net.wacapps.napi.util.Base64DecoderException;
import static net.wacapps.napi.util.LocalizationHelper.getMessage;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * An encrypted database
 */
public class SecureDatabase {
	/** The Constant TAG. */
	private static final String TAG = "NapiDatabase";

	/** The Constant DATABASE_NAME. */
	private static final String DATABASE_NAME = "napi.db";

	/** The Constant DATABASE_VERSION. */
	private static final int DATABASE_VERSION = 1;

	/** The Constant NAPI_TABLE_NAME. */
	private static final String NAPI_TABLE_NAME = "napiitems";

	// These are the column names for the transaction history table. We need a
	// column named "_id" if we want to use a CursorAdapter. The primary key is
	// the code (from ChargingInformation)
	/** The Constant NAPI_ID_COL. */
	static final String NAPI_ID_COL = "_id";

	/** The Constant STORAGE_TIME_COL. */
	static final String STORAGE_TIME_COL = "storageTime";

	/** The Constant PAYLOAD_COL. */
	static final String PAYLOAD_COL = "developerPayload";

	static final String SECURITY_PERMISSIONS_COL = "securityPerm";

	private SQLiteDatabase mDb;
	private DatabaseHelper mDatabaseHelper;

	public SecureDatabase(Context context) {
		mDatabaseHelper = new DatabaseHelper(context);
		mDb = mDatabaseHelper.getWritableDatabase();
	}

	public void close() {
		mDatabaseHelper.close();
	}

	/**
	 * Inserts/Updates an encrypted and serialized amountTransaction into DB.
	 * There can be only single row per product code in database.
	 */
	public void insertOrUpdateObject(Context context, String appId, String code, Serializable transactionInfo, long purchaseTime)
			throws Exception {
		synchronized (mDb) {
			ContentValues values = new ContentValues();
			values.put(NAPI_ID_COL, DeviceSecureCrypto.encrypt(context, code, appId));
			values.put(STORAGE_TIME_COL, DeviceSecureCrypto.encrypt(context, code, "" + purchaseTime));
			values.put(SECURITY_PERMISSIONS_COL,
					PermissionID.permissionSetToString(DeviceUuidHelper.getCurrentPermissions(context)));
			values.put(PAYLOAD_COL, doSerializeAndEncrypt(context, appId, transactionInfo));
			mDb.replace(NAPI_TABLE_NAME, null, values);
		}
	}

	/**
	 * Returns object that was stored with given key
	 * 
	 * @param context
	 * @param appId
	 * @param code
	 * @param notBefore
	 * @return retrieved object
	 * @throws Exception
	 */
	public Object getObject(Context context, String appId, String code, Long notBefore) throws Exception {
		synchronized (mDb) {
			Cursor cursor = null;
			try {
				String query = "select " + PAYLOAD_COL + "," + STORAGE_TIME_COL + "," + SECURITY_PERMISSIONS_COL + " from "
						+ NAPI_TABLE_NAME + " where " + NAPI_ID_COL + " = \"" + DeviceSecureCrypto.encrypt(context, code, appId)
						+ "\"";

				cursor = mDb.rawQuery(query, null);
				Set<PermissionID> currentPermissions = DeviceUuidHelper.getCurrentPermissions(context);
				if (cursor != null && cursor.moveToNext()) {
					Set<PermissionID> encryptionTimePermissions = PermissionID.stringToPermssionSet(cursor.getString(2));
					if (currentPermissions.containsAll(encryptionTimePermissions)) {
						return fromString(DeviceSecureCrypto
								.decrypt(context, cursor.getString(0), appId, encryptionTimePermissions));
					} else {
						throw new SecurityException(getMessage("DECRYPTION_FAIL")
								+ PermissionID.permissionSetToString(encryptionTimePermissions) + getMessage("PERMISSIONS")
								+ PermissionID.permissionSetToString(currentPermissions));
					}
				}
			} finally {
				if (cursor != null && !cursor.isClosed()) {
					cursor.close();
				}
			}
		}
		return null;
	}

	/**
	 * Returns all objects that were stored
	 * 
	 * @param context
	 * @param appId
	 * @param notBefore
	 * @return list of objects
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List getAllObjects(Context context, String appId, Long notBefore) {
		synchronized (mDb) {
			Cursor cursor = null;
			ArrayList result = new ArrayList();
			try {
				Set<PermissionID> currentPermissions = DeviceUuidHelper.getCurrentPermissions(context);
				Set<PermissionID> encryptionTimePermissions = null;
				String query = "select " + PAYLOAD_COL + "," + STORAGE_TIME_COL + "," + SECURITY_PERMISSIONS_COL + " from "
						+ NAPI_TABLE_NAME + ";";
				cursor = mDb.rawQuery(query, null);
				while (!cursor.isAfterLast()) {
					if (cursor.moveToNext()) {
						encryptionTimePermissions = PermissionID.stringToPermssionSet(cursor.getString(2));
						if (currentPermissions.containsAll(encryptionTimePermissions)) {
							try {
								result.add(fromString(DeviceSecureCrypto.decrypt(context, cursor.getString(0), appId,
										encryptionTimePermissions)));
							} catch (Exception e) {
								Log.e(TAG, "Failed to retrieve object");
							}
						} else {
							Log.i(TAG,
									"Failed to decrypt due to lacking permissions required:"
											+ PermissionID.permissionSetToString(encryptionTimePermissions)
											+ " current permissions are:" + PermissionID.permissionSetToString(currentPermissions));
						}
					}
				}
			} finally {
				if (cursor != null && !cursor.isClosed()) {
					cursor.close();
				}
			}
			return result;
		}
	}

	private static String doSerializeAndEncrypt(Context context, String appId, Serializable transactionInfo) {
		try {
			return DeviceSecureCrypto.encrypt(context, toString(transactionInfo), appId);
		} catch (IOException e) {
			return null;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * This is a standard helper class for constructing the database.
	 */
	private class DatabaseHelper extends SQLiteOpenHelper {
		public DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			createPurchaseTable(db);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// Production-quality upgrade code should modify the tables when
			// the database version changes instead of dropping the tables and
			// re-creating them.
			if (newVersion != DATABASE_VERSION) {
				Log.w(TAG, "Database upgrade from old: " + oldVersion + " to: " + newVersion);
				db.execSQL("DROP TABLE IF EXISTS " + NAPI_TABLE_NAME);
				createPurchaseTable(db);
				return;
			}
		}

		private void createPurchaseTable(SQLiteDatabase db) {
			db.execSQL("CREATE TABLE " + NAPI_TABLE_NAME + "(" + NAPI_ID_COL + " TEXT PRIMARY KEY, " + PAYLOAD_COL + " TEXT, "
					+ SECURITY_PERMISSIONS_COL + " TEXT, " + STORAGE_TIME_COL + " TEXT)");
		}
	}

	/** Read the object from Base64 string. */
	private static Object fromString(String s) throws IOException, ClassNotFoundException, Base64DecoderException {
		byte[] data;
		data = Base64.decode(s);
		ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
		Object o = ois.readObject();
		ois.close();
		return o;
	}

	public void deleteAll() {
		// Not implemented
	}

	/** Write the object to a Base64 string. */
	private static String toString(Serializable o) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(o);
		oos.close();
		return new String(Base64.encode(baos.toByteArray()));
	}
}
