package net.wacapps.napi.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringBufferInputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import net.wacapps.napi.android.WacNapiContext;
import net.wacapps.napi.api.Util;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Environment;
import android.util.Log;

/**
 * Helper functions supporting the processing of localized property files.
 * 
 */
public class LocalizationHelper {
	private static final String DEFAULT_ENCODIG = "UTF-8";
	// File name pattern is: messages_<locale>.properties
	private static final String FILE_NAME_PREFIX = "messages_";
	private static final String FILE_NAME_SUFFIX = ".properties";
	private static final String PACKAGE_PATH = "/" + LocalizationHelper.class.getPackage().getName().replace(".", "/") + "/";
	private static final HashMap<String, Utf8Properties> loadedProps = new HashMap<String, Utf8Properties>();
	private static final String TAG = "NAPI_LOC";
	// Application specific storage folder
	private static final String FILE_FOLDER = "WAC_Messages";
	private static final int BUFFER_SIZE = 8192;
	// Update every day
	private static final long UPDATE_PERIOD_MILIS = 3600 * 1000 * 24 * 1;
	private static final int CONNECT_TIMEOUT = 2500;
	private static final int TIMEOUT = 2500;

	private static final String LOCALIZATION_SERVER_DEBUG_URL = "https://sites.google.com/site/waclocaleendpoint/";
	private static final boolean debugLocalization = false;
	private static long SDKBuiltON = (new Date("25-JAN-2012")).getTime();

	static {
		loadPropertyFileFromJar(Locale.US.toString());
		if (!loadPropertyFileFromJar(Locale.getDefault().toString())) {
			if (!loadPropertyFileFromServer(Locale.getDefault().toString(), null)) {
				loadSimilarPropertyFromJar(Locale.getDefault().toString());
			}
		}
	}

	/**
	 * Initializes localization helper for the locale this may trigger property
	 * file
	 * 
	 * @param locale
	 * @param context
	 */
	static public void init(String locale, Context context) {
		SDKBuiltON = getBuidTimestamp(context);
		loadPropertyFileFromServer(locale, context);
	}

	private static boolean loadSimilarPropertyFromJar(String string) {
		// TODO Should we fallback to the language only ?
		return false;
	}

	static private String getClassPathForLocale(String locale) {
		return PACKAGE_PATH + FILE_NAME_PREFIX + locale + FILE_NAME_SUFFIX;
	}

	static private boolean loadPropertyFileFromJar(String locale) {
		if (loadedProps.containsKey(locale)) {
			return true;
		}
		if (!serverHasFreshGoods(locale, new File(getClassPathForLocale(locale)))) {
			Utf8Properties locale_props = new Utf8Properties();
			String path = getClassPathForLocale(locale);
			try {
				InputStream is = LocalizationHelper.class.getResourceAsStream(path);
				locale_props.load(is);
				if (locale_props != null && locale_props.size() > 0) {
					loadedProps.put(locale, locale_props);
					return true;
				}
			} catch (Throwable err) {
				Log.w(TAG, "Cannot find:" + path);
			}
		}
		return false;
	}

	/**
	 * Returns message localized to current system locale
	 * 
	 * @param messageKey
	 * @return localized message
	 */
	public static String getMessage(String messageKey) {
		return getMessage(messageKey, Locale.getDefault().toString());
	}

	private static final long getBuidTimestamp(Context ctx) {
		if (ctx != null) {
			try {
				ApplicationInfo ai = ctx.getPackageManager().getApplicationInfo(ctx.getPackageName(), 0);
				ZipFile zf = new ZipFile(ai.sourceDir);
				ZipEntry ze = zf.getEntry("classes.dex");
				long time = ze.getTime();
				return time;
			} catch (Exception e) {
				Log.e(TAG, "Could not get application build time", e);
			}
		}
		return SDKBuiltON;
	}

	/**
	 * Returns message that is SHA1 match for existing originalMessage
	 * @param originalMessage in us_EN
	 * @return Translated message according to current locale
	 */
	public static String getMessageTranslationForMessage(String originalMessage) {
		return getMessageTranslationForMessage(originalMessage, Locale.getDefault().toString());
	}

	public static String stripAllNonAlphaNum(String original) {
		if (original != null) {
			String s = original.toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
			return s;
		}
		return original;
	}

	/**
	 * Returns message that is SHA1 match for existing originalMessage and locale
	 * @param originalMessage in us_EN
	 * @return Translated message according to requested locale
	 */
	public static String getMessageTranslationForMessage(String originalMessage, String locale) {
		String key = null;
		try {
			key = Util.SHA1(stripAllNonAlphaNum(originalMessage));
		} catch (Throwable e) {
			Log.wtf("Cannot SHA1 the key", e);
		}
		if (key != null && (getMessage(key, locale) != key)) {
			return getMessage(key, locale);
		} else {
			return originalMessage;
		}
	}

	/**
	 * Returns message for given key while using fallback strategy returns
	 * messageKey from Locale.US (if exists) or returns the orginal messageKey
	 * 
	 * @param mesageKey
	 *            key for the message to be fetched
	 * @param locale
	 *            string for locale
	 */
	public static String getMessage(String messageKey, String locale) {
		String result = null;
		Utf8Properties localized_property_file = loadedProps.get(locale);
		if (localized_property_file != null) {
			result = localized_property_file.getProperty(messageKey);
		}
		if (result == null) {
			Utf8Properties backup_property_file = loadedProps.get(Locale.US.toString());
			if (backup_property_file != null) {
				result = backup_property_file.getProperty(messageKey);
			}
		}
		if (result == null) {
			return messageKey;
		}
		return result;
	}

	private static String getLocalizedFileName(String locale) {
		return FILE_NAME_PREFIX + locale + FILE_NAME_SUFFIX;
	}

	private static String getFileUrl(String locale) {
		if (debugLocalization) {
			return LOCALIZATION_SERVER_DEBUG_URL + getLocalizedFileName(locale);
		} else {
			return WacNapiContext.getInstance().getEndPoints().getLocalizationPath() + getLocalizedFileName(locale);
		}
	}

	private static File getWritableFileLocation(Context context, String locale) {
		// Check if we can store files on external storage
		boolean externalStorageWriteable = false;
		String state = Environment.getExternalStorageState();

		if (Environment.MEDIA_MOUNTED.equals(state)) {
			// We can read and write the media
			externalStorageWriteable = true;
		} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
			// We can only read the media
			externalStorageWriteable = false;
		} else {
			// Something else is wrong. It may be one of many other states, but
			// all we need
			// to know is we can neither read nor write
			externalStorageWriteable = false;
		}
		File fileDirectory = null;
		if (externalStorageWriteable) {
			fileDirectory = Environment.getExternalStoragePublicDirectory(FILE_FOLDER);
			fileDirectory.mkdirs();

		}
		if (fileDirectory != null && !fileDirectory.exists() && context != null) {
			fileDirectory = context.getDir(FILE_FOLDER, 0);
			fileDirectory.mkdirs();
		}
		File currentFile = new File(fileDirectory, getLocalizedFileName(locale));
		return currentFile;
	}

	private static long getLastModified(HttpResponse httpResponse) {
		Header header = httpResponse.getFirstHeader("last-modified");
		Header[] headers = httpResponse.getAllHeaders();
		// Some servers use alternative spelling of header
		if (header == null) {
			header = httpResponse.getFirstHeader("Last-Modified");
		}
		if (header != null) {
			// Retrieve just the last modified header value.
			String lastModified = header.getValue();
			if (lastModified != null) {
				try {
					long result = Date.parse(lastModified);
					return result;
				} catch (Exception err) {
					Log.e(TAG, "Could not parse Last-Modified header:" + lastModified);
				}
			}
		}
		return 0L;
	}

	private static boolean serverHasFreshGoods(String locale, File currentFile) {
		HttpHead httpHead = new HttpHead(getFileUrl(locale));
		HttpParams httpParameters = new BasicHttpParams();
		// Set the timeout in milliseconds until a connection is
		// established.
		HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECT_TIMEOUT);
		// Set the default socket timeout (SO_TIMEOUT)
		// in milliseconds which is the timeout for waiting for data.
		HttpConnectionParams.setSoTimeout(httpParameters, TIMEOUT);
		DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);

		long currentFileTimestamp = Math.max(currentFile.lastModified(), SDKBuiltON);
		long lastModified = 0;
		long fileSize = currentFile.length();
		// Do not check too often, it is expensive, too
		if ((System.currentTimeMillis() - currentFileTimestamp) > UPDATE_PERIOD_MILIS) {
			HttpResponse headResponse = null;
			try {
				headResponse = httpClient.execute(httpHead);
			} catch (Exception err) {
				Log.e(TAG, "failed to check the last-updated timestam on server", err);
			}
			if (headResponse != null) {
				if (headResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
					return false;
				}
				lastModified = getLastModified(headResponse);
				return lastModified > currentFileTimestamp;
			}
		}
		return false;
	}

	@SuppressWarnings({ "unused", "deprecation" })
	private static synchronized boolean loadPropertyFileFromServer(String locale, Context context) {
		// First try to load properties from JAR
		if (loadPropertyFileFromJar(locale)) {
			return true;
		}
		// Get the local file (even if it does not exist)
		File currentFile = getWritableFileLocation(context, locale);
		try {
			// URL url = new URL(getFileUrl(locale));
			HttpHead httpHead = new HttpHead(getFileUrl(locale));
			HttpGet httpGet = new HttpGet(getFileUrl(locale));
			HttpParams httpParameters = new BasicHttpParams();
			// Set the timeout in milliseconds until a connection is
			// established.
			HttpConnectionParams.setConnectionTimeout(httpParameters, CONNECT_TIMEOUT);
			// Set the default socket timeout (SO_TIMEOUT)
			// in milliseconds which is the timeout for waiting for data.
			HttpConnectionParams.setSoTimeout(httpParameters, TIMEOUT);
			DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);

			long lastDownloaded = currentFile.lastModified();
			long lastModified = 0;
			long fileSize = currentFile.length();
			// Do not check too often, it is expensive, too
			if ((System.currentTimeMillis() - lastDownloaded) > UPDATE_PERIOD_MILIS || fileSize == 0) {
				HttpResponse headResponse = httpClient.execute(httpHead);
				if (headResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
					return false;
				}
				lastModified = getLastModified(headResponse);
			}
			// Check if we need to update local database
			InputStream is = null;
			if (currentFile.length() == 0 || (lastModified > lastDownloaded)) {
				HttpResponse response = httpClient.execute(httpGet);
				InputStream in = new BufferedInputStream(response.getEntity().getContent());
				try {
					if (currentFile.exists()) {
						currentFile.delete();
					}
					boolean fileCreated = currentFile.createNewFile();
				} catch (IOException err) {
					Log.d(TAG, "Problems on re-creating file, continuing");
				}
				// If storage is possible, store it in the file
				if (currentFile.exists() && currentFile.canWrite()) {
					OutputStream out = new BufferedOutputStream(new FileOutputStream(currentFile));
					byte[] buffer = new byte[BUFFER_SIZE];
					int bytesRead = 0;
					while ((bytesRead = in.read(buffer)) > 0) {
						if (bytesRead == buffer.length) {
							out.write(buffer);
						} else {
							byte[] partialBuffer = new byte[bytesRead];
							System.arraycopy(buffer, 0, partialBuffer, 0, bytesRead);
							out.write(partialBuffer);
						}
					}

					// Load the property file
					is = new FileInputStream(currentFile);
					out.close();
					in.close();
				} else {
					// No storage possible? No problem we catch this into the
					// string and then load the props from it
					StringBuffer propertyFileAsString = new StringBuffer();
					// TODO get encoding from stream
					String encoding = null;
					if (encoding == null || encoding.length() == 0) {
						encoding = DEFAULT_ENCODIG;
					}
					byte[] buffer = new byte[BUFFER_SIZE];
					int bytesRead = 0;
					while ((bytesRead = in.read(buffer)) > 0) {
						if (bytesRead == buffer.length) {
							propertyFileAsString.append(new String(buffer, encoding));
						} else {
							byte[] partialBuffer = new byte[bytesRead];
							System.arraycopy(buffer, 0, partialBuffer, 0, bytesRead);
							propertyFileAsString.append(new String(partialBuffer, encoding));
						}
					}
					is = new StringBufferInputStream(propertyFileAsString.toString());
				}
			} else {
				is = new BufferedInputStream(new FileInputStream(currentFile));
			}
			Utf8Properties locale_props = new Utf8Properties();
			locale_props.load(is);
			loadedProps.put(locale, locale_props);
			is.close();
			return true;
		} catch (Throwable err) {
			Log.wtf("PropertyFile load failed", err);
		} finally {
			// Do housekeeping if needed
		}
		return false;
	}

}
