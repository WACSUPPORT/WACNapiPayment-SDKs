/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.util.crypto;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Set;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;

/**
 * Device UUID helper will calculate an "as unique as possible" deviceID.
 * Furthermore calculated deviceID will be digested to thwart the
 * reverse-engineering
 * 
 * For best results do NOT store result of the getDeviceUUid call in any
 * variables.
 * 
 * Security permissions are important factor in adding uniqueness to deviceUUID.
 * Please note that following permissions are advisable (but not required):
 * 
 * <uses-permission android:name="android.permission.READ_PHONE_STATE" />
 * <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
 * <uses-permission android:name="android.permission.BLUETOOTH" />
 * 
 * From the moment that application is built and released in order to ensure
 * that UUID stays stable DO NOT add/remove any of the above uses-permission
 * lines in your application manifest.
 * 
 * @author dejan.curcic
 * 
 */
public class DeviceUuidHelper {

	private static final String DUMMY_MAC = "FFFFFFFF";
	private static final String DUMMY_IMEI = "00000000000000";
	private static final String DUMMY_ANDROID = "AEAEAFAEAF";

	protected static String getDeviceUuid(Context context){
		return getDeviceUuid(context, null);
	}
	
	// private static Set availablePermissions=
	protected static String getDeviceUuid(Context context, Set<PermissionID> permissions) {
		// IMEI, requires READ_PHONE_STATE permission, if permission is not
		// present will use dummy value
		String IMEI;
		if (permissions == null
				|| permissions.contains(PermissionID.TELEPHONY_SERVICE)) {
			TelephonyManager tm = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
			try {
				IMEI = tm.getDeviceId();
			} catch (SecurityException se) {
				IMEI = DUMMY_IMEI;
			}
		} else {
			IMEI = DUMMY_IMEI;
		}
		// Device build ID
		String deviceBuildID = "35" + Build.BOARD.length() % 10
				+ Build.BRAND.length() % 10 + Build.CPU_ABI.length() % 10
				+ Build.DEVICE.length() % 10 + Build.DISPLAY.length() % 10
				+ Build.HOST.length() % 10 + Build.ID.length() % 10
				+ Build.MANUFACTURER.length() % 10 + Build.MODEL.length() % 10
				+ Build.PRODUCT.length() % 10 + Build.TAGS.length() % 10
				+ Build.TYPE.length() % 10 + Build.USER.length() % 10;

		// Android ID
		String androidID;
		if (permissions == null
				|| permissions.contains(PermissionID.ANDROID_ID)) {
			androidID = Secure.getString(context.getContentResolver(),
					Secure.ANDROID_ID);
		} else {
			androidID = DUMMY_ANDROID;
		}
		// WiFi manager, read MAC address - requires
		// android.permission.ACCESS_WIFI_STATE, will use dummy value if there
		// is no permission
		WifiManager wfm;
		wfm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
		String wlanMAC;
		if (permissions == null
				|| permissions.contains(PermissionID.WIFI_SERVICE)) {
			if (wfm != null) {
				try {
					wlanMAC = wfm.getConnectionInfo().getMacAddress();
				} catch (SecurityException se) {
					wlanMAC = DUMMY_MAC;
				}
			} else {
				wlanMAC = DUMMY_MAC;
			}
		} else {
			wlanMAC = DUMMY_MAC;
		}
		// Bluetooth MAC address android.permission.BLUETOOTH required, will use
		// dummy value if there is no permission
		BluetoothAdapter btAdapter = null;
		btAdapter = BluetoothAdapter.getDefaultAdapter();
		String btMAC = DUMMY_MAC;
		if (permissions == null
				|| permissions.contains(PermissionID.BT_SERVICE)) {
			if (btAdapter != null) {
				try {
					btMAC = btAdapter.getAddress();
				} catch (Exception ignored) {}
			}
		}
		// UUID is best done using all of the above
		String longDeviceID = IMEI + deviceBuildID + androidID + wlanMAC
				+ btMAC;
		MessageDigest m = null;
		try {
			m = MessageDigest.getInstance("SHA256");
		} catch (NoSuchAlgorithmException nsaSHA256) {
			try {
				// Fall back to MD5
				m = MessageDigest.getInstance("MD5");
			} catch (NoSuchAlgorithmException nsaMD5) {
				// Well that is a damn shame, no message digest of ANY kind?!
			}
		}
		if (m != null) {
			m.update(longDeviceID.getBytes(), 0, longDeviceID.length());
			byte md5Bytes[] = m.digest();

			String digestedDeviceID = new String();
			for (int i = 0; i < md5Bytes.length; i++) {
				int b = (0xFF & md5Bytes[i]);
				if (b <= 0xF)
					digestedDeviceID += "0";
				digestedDeviceID += Integer.toHexString(b);
			}
			return digestedDeviceID.toUpperCase();
		} else {
			// Go with plain, non digested
			return longDeviceID;
		}
	}

	@SuppressWarnings("unused")
	protected static Set<PermissionID> getCurrentPermissions(Context context) {
		HashSet<PermissionID> result = new HashSet<PermissionID>();
		result.add(PermissionID.ANDROID_ID);
		TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		try {
			String IMEI = tm.getDeviceId();
			result.add(PermissionID.TELEPHONY_SERVICE);
		} catch (SecurityException se) {
		}
		WifiManager wfm;
		wfm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
		if (wfm != null) {
			try {
				String wlanMAC = wfm.getConnectionInfo().getMacAddress();
				result.add(PermissionID.WIFI_SERVICE);
			} catch (SecurityException se) {
			}
		}

		BluetoothAdapter btAdapter = null;
		try {
			btAdapter = BluetoothAdapter.getDefaultAdapter();
			if (btAdapter != null) {
					String btMAC = btAdapter.getAddress();
					result.add(PermissionID.BT_SERVICE);
			}	
		} catch(Exception ignored) {}
		return result;
	}
}