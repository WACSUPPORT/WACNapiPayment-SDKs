/*******************************************************************************
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 ******************************************************************************/

package net.wacapps.napi.util.crypto;

import java.security.SecureRandom;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import android.content.Context;

/**
 * This class is device-specific crypto. Key is determined based on device information and appId.
 * 
 * Usage:
 * 
 * <pre>
 * String crypto = DeviceSecureCrypto(context, cleartext)
 * ...
 * String cleartext = DeviceSecureCrypto(context, crypto)
 * </pre>
 * @author dejan.curcic
 */
public class DeviceSecureCrypto {
	
	
	/**
	 * Encrypts clear text.
	 *
	 * @param context the context
	 * @param cleartext text to be encrypted
	 * @param appId applicationId, if null is used all apps on same device built with WAC API will be able to decrypt the text
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String encrypt(Context context, String cleartext, String appId) throws Exception{
		return encrypt(DeviceUuidHelper.getDeviceUuid(context, null)+appId, cleartext);
	}
	
	/**
	 * Returns decrypted text.
	 *
	 * @param context the context
	 * @param encrypted the encrypted
	 * @param appId the app id
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String decrypt(Context context, String encrypted, String appId) throws Exception{
		return decrypt(DeviceUuidHelper.getDeviceUuid(context, null)+appId, encrypted);
	}

	/**
	 * Decrypt.
	 *
	 * @param context the context
	 * @param encrypted the encrypted
	 * @param appId the app id
	 * @param permissions the permissions
	 * @return the string
	 * @throws Exception the exception
	 */
	public static String decrypt(Context context, String encrypted, String appId, Set<PermissionID> permissions) throws Exception{
		return decrypt(DeviceUuidHelper.getDeviceUuid(context, permissions)+appId, encrypted);
	}
	
	/**
	 * Encrypt.
	 *
	 * @param seed the seed
	 * @param cleartext the cleartext
	 * @return the string
	 * @throws Exception the exception
	 */
	private static String encrypt(String seed, String cleartext)
			throws Exception {
		byte[] rawKey = getRawKey(seed.getBytes());
		byte[] result = encrypt(rawKey, cleartext.getBytes());
		return toHex(result);
	}

	/**
	 * Decrypt.
	 *
	 * @param seed the seed
	 * @param encrypted the encrypted
	 * @return the string
	 * @throws Exception the exception
	 */
	private static String decrypt(String seed, String encrypted)
			throws Exception {
		byte[] rawKey = getRawKey(seed.getBytes());
		byte[] enc = toByte(encrypted);
		byte[] result = decrypt(rawKey, enc);
		return new String(result);
	}

	/**
	 * Gets the raw key.
	 *
	 * @param seed the seed
	 * @return the raw key
	 * @throws Exception the exception
	 */
	private static byte[] getRawKey(byte[] seed) throws Exception {
		KeyGenerator kgen = KeyGenerator.getInstance("AES");
		SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
		sr.setSeed(seed);
		// Use the 256bit, 192bit or fall back to 128bit - go as high as possible
		try {
			kgen.init(256, sr);
		} catch (Throwable notavail256) {
			try{
				kgen.init(192, sr);
			}catch(Throwable notavail192){
				kgen.init(128, sr); // 192 and 256 bits may not be available
			}
		}	
		SecretKey skey = kgen.generateKey();
		byte[] raw = skey.getEncoded();
		return raw;
	}

	/**
	 * Encrypt.
	 *
	 * @param raw the raw
	 * @param clear the clear
	 * @return the byte[]
	 * @throws Exception the exception
	 */
	private static byte[] encrypt(byte[] raw, byte[] clear) throws Exception {
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(clear);
		return encrypted;
	}

	/**
	 * Decrypt.
	 *
	 * @param raw the raw
	 * @param encrypted the encrypted
	 * @return the byte[]
	 * @throws Exception the exception
	 */
	private static byte[] decrypt(byte[] raw, byte[] encrypted)
			throws Exception {
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		byte[] decrypted = cipher.doFinal(encrypted);
		return decrypted;
	}


	/**
	 * To byte.
	 *
	 * @param hexString the hex string
	 * @return the byte[]
	 */
	private static byte[] toByte(String hexString) {
		int len = hexString.length() / 2;
		byte[] result = new byte[len];
		for (int i = 0; i < len; i++)
			result[i] = Integer.valueOf(hexString.substring(2 * i, 2 * i + 2),
					16).byteValue();
		return result;
	}

	/**
	 * To hex.
	 *
	 * @param buf the buf
	 * @return the string
	 */
	private static String toHex(byte[] buf) {
		if (buf == null)
			return "";
		StringBuffer result = new StringBuffer(2 * buf.length);
		for (int i = 0; i < buf.length; i++) {
			appendHex(result, buf[i]);
		}
		return result.toString();
	}

	/** The Constant HEX. */
	private final static String HEX = "0123456789ABCDEF";

	/**
	 * Append hex.
	 *
	 * @param sb the sb
	 * @param b the b
	 */
	private static void appendHex(StringBuffer sb, byte b) {
		sb.append(HEX.charAt((b >> 4) & 0x0f)).append(HEX.charAt(b & 0x0f));
	}

}