****************************
Android SDK for WAC Payments
****************************

About the Android SDK for WAC REST API
**************************************
The WAC's Android Software Developer Kit (SDK) makes the process of integrating WAC's payment services into Android applications easy.

This software is intended for use by Android application developers.

******************************
Developer Portal Prerequisites
******************************
1. Register with WAC as a developer: http://www.wacapps.net/register
2. Create Applications: http://www.wacapps.net/napi-application
3. Manage Applications: http://www.wacapps.net/manage-payment-api

*********************************************
WAC API Integration with Android applications
*********************************************

Release Notes
*************
Whats new in NAPI SDK beta 1.0 ?

* Support for In band and out of band transactions.
* Improved End user identification flow for out of band transaction.
* Fast in band transactions
* Query prices based on country
* Support for reserve and capture model for payments, in additions to quick pay.
* SQLite based and encrypted Android data store for storing previous transactions.
* Support for APN proxies
* Basic authorization support
* User friendly error messages
* Localization support for all major markets and locales.

Whats new in NAPI SDK beta 1.0.1 ?

* Localization updates
* Full UTF-8 capability.
* Documentation update

Whats new in NAPI SDK beta 1.0.2 ?

* New checkBillingAvailability() API has been added to check if Wac billing is available.
* Bug fixes related to localization.
* Performance enhancements for payment success screen.

Required Software
*****************
J2SE 1.6.x SDK - http://www.oracle.com/technetwork/java/javase/downloads/jdk-6u30-download-1377139.html
Apache Ant 1.8.2 - http://ant.apache.org/bindownload.cgi
Eclipse Classic (recommended) // As in Android spec - http://eclipse.org/downloads/
Android SDK - version >= 2.2 - http://developer.android.com/sdk/index.html
Android plugin for eclipse - http://developer.android.com/sdk/eclipse-adt.html#downloading

Downloading and updating
************************
http://www.wacapps.net/sdks

Import the application as an android application.  Run the application as Android application in eclipse.

Getting started guide
*********************
http://www.wacapps.net/getting-started

Known Issues
************
7091 - broken authorization flow.
7133 - .1 protocol issue, the cancel payment button does not work
7210 - Different transaction IDs displayed.
7452 - Transaction failed page does not have an exit button
7718 - Some devices display 404 page after a successful transaction.
* No server side support for list or check transactions
* Query only shows prices per country, and not per operator when in out of band

FAQs
****
http://www.wacapps.net/payment-api-faqs

Feed Back
*********
If you have feedback on this document, or any other developer related issues, please get in touch via support@wacapps.net

Integrating WAC in-application payments/billing API
***************************************************
Steps to integrate the WacPaymentService with android application.
1. Modify workspace to include the WAC SDK files.
       Extract WAC_ANDROID_SDK_SAMPLE_APP.zip file.
       After extraction, the WAC android SDK and  the dependent libraries can be copied from  "/unifiednapibilling/libs" folder.
       The libs folder contains "wac-1.0.2.jar" and "gson-2.1.jar"
       These dependency jars should be added to 'libs' folder of the application for using WAC Android SDK.
    
       Include libs folder in build path. To do this in Eclipse, follow the steps below.
           -Select project in package explorer and choose Refresh from the context menu.
           -The newly extracted library files and resource files will be visible within the package explorer.
           -Open Project Properties. Select "Java Build Path" and the "Libraries" tab.
           -Now click on "Add JARs" button. In the pop up, select the newly added JARs under the libs subfolder.
           -Click OK to apply changes.
        
2. Add required permissions to AndroidManifest.xml file.
       The following permission needs to be added to the manifest element. The INTERNET permission is used by payment methods.
            <uses-permission android:name="android.permission.INTERNET" />
            
       The following permissions if provided will allow the SDK to make intelligent choices.
            <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
            <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />
			<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
     
3. Modify code to call the WacPaymentService which will take care of all payment process and return you back the transaction result.

       Create a AndroidWacPaymentService object and initialize this Payment object.
	   AndroidWacPaymentService provides two options for making a payment.
	   1. Reserve and capture (2 phase payment)
		  During authorization, initiate the reserve amount transaction and reserve fund with the operator.
		  To capture the previously reserved fund, developer can invoke capturePayment after fulfillment of purchase (service or content) is successful.  
	   2. Express Pay with ContentDeliveryCallback
	      Callback can be implemented by calling applications as a part of chargePayment, so that NAPI SDK knows when content delivery is finished.
	   
4. Import the right Payment objects as mentioned below. The AndroidWacPaymentService is the primary payment object required for all payment methods.
The code snippet below details all the potential objects you might need.

Importing the necessary objects:
********************************
import net.wacapps.napi.android.AndroidWacPaymentService;
import net.wacapps.napi.android.WacNapiContext;
import net.wacapps.napi.android.WacNapiPayment;
import net.wacapps.napi.api.NapiException;
import net.wacapps.napi.api.WacEndpoints;
import net.wacapps.napi.resource.jaxb.AmountTransaction;
import net.wacapps.napi.resource.jaxb.Item;
import net.wacapps.napi.resource.jaxb.ReservedTransaction;
import net.wacapps.napi.resource.jaxb.Transaction;
import net.wacapps.napi.resource.jaxb.TransactionList;
import net.wacapps.napi.util.crypto.DeviceTransactionStorage;
import net.wacapps.napi.util.crypto.SecureDeviceTransactionDatabase;

Initialize the payment service
******************************
  
/**
	 * Called when the activity is first created.
	 * 
	 * @param savedInstanceState
	 *            the saved instance state
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		mHandler = new Handler();

		// Read from the assets directory
		if (mProps == null) {
			try {
				InputStream inputStream = this.getResources().getAssets()
						.open("wac.properties");
				mProps = new Properties();
				mProps.load(inputStream);
				if (DEBUG)
					Log.d(TAG, "The properties are now loaded: " + mProps);
			} catch (IOException e) {
				System.err.println("Failed to open wac property file");
				e.printStackTrace();
			}
		}
		
		// Initialize WAC NAPI API
		if (WacNapiContext.getInstance().getPaymentService() == null) {
			WacNapiContext.getInstance().setEndPoints(
					new WacEndpoints(WacEndpoints.PRODUCTION));
			AndroidWacPaymentService.setDebug(DEBUG);

			mService = new AndroidWacPaymentService();
			WacNapiContext.getInstance().setPaymentService(mService);
			// Load available product items
			this.pd = ProgressDialog.show(this, "Working..",
					"Loading available Items...", true, false);
			new InitializeWACTask().execute();
		} else {
			mService = WacNapiContext.getInstance().getPaymentService();
			setupWidgets();
		}
	}

    /**
	 * The Class InitializeWACTask is an AsyncTask to perform  background operations for initializing the android WAC payment service.
	 */
	private class InitializeWACTask extends AsyncTask<String, Void, Object> {

		protected Object doInBackground(String... args) {
			Log.d(TAG, "Background thread for initialize starting");
			try {
				mService.initialize(mProps.getProperty(WAC_APPID_KEY),
						mProps.getProperty("wac.credential"),
						mProps.getProperty("wac.secret"),
						mProps.getProperty("wac.devname"),
						mProps.getProperty("wac.redirectUriOAuth"));
			} catch (Exception e) {
				e.printStackTrace();
				final Bundle b = new Bundle();
				b.putString("failMessage",
						e.getMessage());
				mHandler.post(new Runnable() {
					public void run() {
						showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
					}
				});
				return null;
			}
			return mService;
		}

		protected void onPostExecute(Object result) {
			// dismiss progress dialogs
			if (WacCinemas.this.pd != null) {
				WacCinemas.this.pd.dismiss();
			}
			// quick sanity check
			if (result != null) {
				// add items to list adapter
				List<Item> items = mService.listProductItems();
				for (Item item : items) {
					catalog.add(new CatalogEntry(item.getItemId(), item
							.getDescription(), item));
				}
				// create UI components in the UI thread
				mHandler.post(new Runnable() {
					public void run() {
						setupWidgets();
					}
				});
			} else {
				Log.d(TAG, "Service setup failure!!!");
			}
		}
	}

Create payment intent and start activity
****************************************
/**
	 * Called when a button is pressed.
	 * 
	 * @param v
	 *            the view that was clicked
	 */
	public void onClick(View v) {
		if (v == mBuyButton) {
			if (DEBUG) {
				Log.d(TAG, "buying: " + mItemName + " sku: " + mSku);
			}
			
			String refCode = UUID.randomUUID().toString().substring(0, 32);

			//express pay with callback
//			WacNapiContext
//					.getInstance()
//					.getPaymentService()
//					.chargePayment(this,
//							mProps.getProperty(WAC_APPID_KEY), mSku, refCode,
//							new ContentDeliveryCallback() {
//								@Override
//								public boolean deliverContent() {
//									// deliver content before returning true
//									if (DEBUG)
//										Log.d(TAG,
//												"In content delivery callback --- returning TRUE");
//									return true;
//								}
//							});
			
			//use reserve and capture
			WacNapiContext.getInstance().getPaymentService().reservePayment(this, mProps.getProperty(WAC_APPID_KEY), mSku, refCode);			
		} else if (v == mTxListButton) {
			if (DEBUG) {
				Log.d(TAG, "Getting Tx List");
			}
			WacNapiContext.getInstance()
					.getPaymentService().getTransactionList(this);
		}
	}

Process charge payment transaction
**********************************
   /**
	 * Called when an activity called by using startActivityForResult finishes.
	 * 
	 * @param requestCode
	 *            the request code
	 * @param resultCode
	 *            the result code
	 * @param data
	 *            the data
	 */
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.d(TAG, "onActivityResult called");
		final Bundle b = new Bundle();
		switch (resultCode) {
		case WacNapiPayment.RESULT_RESERVE_PAYMENT_OK:
			Log.d(TAG, "onActivityResult called + RESULT_RESERVE_PAYMENT_OK");
			ReservedTransaction reserve = mService.processReservePaymentResults(data);
			Log.d(TAG, "got reserve with token " + reserve.getAccessToken());
			
			//Do things to fulfil order
			
			try {
				mService.capturePayment(this, reserve);  //callback will come in RESULT_PAYMENT_OK
			} catch (NapiException e1) {
				e1.printStackTrace();
				b.putString("failMessage",
						"Capture payment failed!");
				mHandler.post(new Runnable() {
					public void run() {
						showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
					}
				});
			}
			Log.d(TAG, "Capture payment request sent");
			break;
		case WacNapiPayment.RESULT_CHECK_TRANSACTION_OK:
			Log.d(TAG, "onActivityResult called + RESULT_CHECK_TRANSACTION_OK");
			try {
				final Transaction checkTransaction = mService
						.processTransactionCheckResults(data);
				if(checkTransaction != null && checkTransaction.getAmountTransaction().getServerReferenceCode() != null) {
					if(DEBUG)
						Log.d(TAG, "Check Transaction Success!!! " + 
								checkTransaction.getAmountTransaction().getServerReferenceCode());
					showDialog(DIALOG_TRANSACTIONS_CHECK_SUCCESS);
				} else {
					b.putString("failMessage",
							"Invalid transaction!");
					mHandler.post(new Runnable() {
						public void run() {
							showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
						}
					});
				}
			} catch (Exception e) {
				e.printStackTrace();
				b.putString("failMessage",
						"Invaid transaction!");
				mHandler.post(new Runnable() {
					public void run() {
						showDialog(DIALOG_CHARGE_PAYMENT_FAIL, b);
					}
				});
			}
			break;
		case WacNapiPayment.RESULT_PAYMENT_OK:
			Log.d(TAG, "onActivityResult called + RESULT_PAYMENT_OK");
			final Transaction transaction = mService
					.processChargePaymentTransactionResults(data);
			this.runOnUiThread(new Runnable() {
				public void run() {
					HashMap<String, String> temp = new HashMap<String, String>();
					temp.put(FIRST_COLUMN, transaction.getAmountTransaction().getPaymentAmount().getChargingInformation().getDescription());
					temp.put(SECOND_COLUMN, transaction.getAmountTransaction()
							.getPaymentAmount().getChargingInformation()
							.getAmount().toString());
					mOwnedItems.add(temp);
					mOwnedItemsAdaptor.notifyDataSetChanged();
					mOwnedItemsTracker.add(transaction);
				}
			});
			break;
		case WacNapiPayment.RESULT_TRANSACTION_LIST_OK:
			TransactionList list = mService.processTransactionListResults(data);
			int tSize = list.getPaymentTransactionList().getAmountTransaction()
					.size();
			Log.d(TAG, "TxList size " + tSize);
			b.putInt("tSize", tSize);
			mHandler.post(new Runnable() {
				public void run() {
					showDialog(DIALOG_TRANSACTIONS_LIST_SUCCESS, b);
				}
			});
			break;
		case WacNapiPayment.RESULT_OPERATOR_BAD:
			Log.d(TAG, "onActivityResult called + RESULT_OPERATOR_BAD");
			processError(data);
			break;
		case WacNapiPayment.RESULT_PAYMENT_BAD:
			Log.d(TAG, "onActivityResult called + RESULT_PAYMENT_BAD");
			processError(data);
			break;
		case WacNapiPayment.RESULT_TRANSACTION_LIST_BAD:
			Log.d(TAG, "onActivityResult called + RESULT_TRANSACTION_LIST_BAD");
			processError(data);
			break;
		default:
			break;
		}
	}

Get database handle for DeviceTransactionStorage
***************************************
  	/**
	 * Gets transaction database handle
	 */
	private DeviceTransactionStorage getTransactionStorage(){
		return new SecureDeviceTransactionDatabase(getApplicationContext(), mProps.getProperty(WAC_APPID_KEY));
	}

Fetch transaction data from DeviceTransactionStorage
****************************************************
    /**
	 * Sets up the UI.
	 */
	private void setupWidgets() {

		mBuyButton = (Button) findViewById(R.id.buy_button);
		mBuyButton.setOnClickListener(this);

		mTxListButton = (Button) findViewById(R.id.tx_list_button);
		mTxListButton.setOnClickListener(this);

		mSelectItemSpinner = (Spinner) findViewById(R.id.item_choices);
		mCatalogAdapter = new CatalogAdapter(this, catalog);
		mSelectItemSpinner.setAdapter(mCatalogAdapter);
		mSelectItemSpinner.setOnItemSelectedListener(this);

		mOwnedItemsTable = (ListView) findViewById(R.id.owned_items);
		mOwnedItemsAdaptor = new ListViewAdapter(this, mOwnedItems);
		mOwnedItemsTable.setAdapter(mOwnedItemsAdaptor);
		final Activity ctx = this;
		mOwnedItemsTable.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> a, View v, int position,
					long id) {
				AlertDialog.Builder adb = new AlertDialog.Builder(ctx);
				adb.setTitle("Transaction Check?");
				final Transaction t = mOwnedItemsTracker.get(position);
				adb.setMessage("Validate transaction with ref code " + t.getAmountTransaction().getServerReferenceCode() + " ?");
				adb.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						Log.d(TAG, "Running check transactions!");
						mService.checkTransaction(ctx, t.getAmountTransaction().getServerReferenceCode());
					}
				});
				adb.setNegativeButton("Cancel", null);
				adb.show();
			}
		});
		
		DeviceTransactionStorage pdb = null;
		try {
			pdb = getTransactionStorage();
			TransactionList list = pdb.getTransactionList();
			pdb.close();
			for (AmountTransaction transaction : list
					.getPaymentTransactionList().getAmountTransaction()) {
				HashMap<String, String> temp = new HashMap<String, String>();
				temp.put(FIRST_COLUMN, transaction.getPaymentAmount().getChargingInformation().getDescription());
				String amount = transaction.getPaymentAmount().getChargingInformation().getAmount().toString();
				temp.put(SECOND_COLUMN, amount);
				mOwnedItems.add(temp);
				mOwnedItemsAdaptor.notifyDataSetChanged();
				Transaction tx = new Transaction();
				tx.setAmountTransaction(transaction);
				mOwnedItemsTracker.add(tx);
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			pdb.close();
		}
	}

Use the following API to check if WAC billing is available
**********************************************************
AndroidWacPaymentService has the "checkBillingAvailability" API which returns boolean "TRUE" if the WAC payment service is available.
Usage:
WacNapiContext.getInstance().setEndPoints(new WacEndpoints(WacEndpoints.PRODUCTION));
AndroidWacPaymentService mService = new AndroidWacPaymentService();
WacNapiContext.getInstance().setPaymentService(mService);
boolean check = mService.checkBillingAvailability(mProps.getProperty("wac.appid"), mProps.getProperty("wac.credential"),  mProps.getProperty("wac.secret"),  mProps.getProperty("wac.devname"));

Limitations of this method: At the point of calling this method WAC have not yet checked the individual user. 
In the case the user is out-of-band (e.g. WiFi), we have not yet identified the operator either because we want to avoid having to ask the user for their phone number when this method is called. 
This means that this method behaves as follows:
* In-band flow, app not LIVE or not published to this operator: will return "false"
* Out-of-band flow, app not LIVE or not published in the country of the access point IP address: will return "false"
* Out-of-band flow, app published in the country of the access point IP address but not the operator of the user: will return "true"
* Individual user can't use WAC even if other users of this operator can, e.g. user blacklisted, user doesn't have enough credit etc.: will return "false"
* App is LIVE, published to this operator and individual user can use WAC: will return "true"

Configuring the sample application with the details obtained by developer
*************************************************************************
Edit 'wac.properties' file in workspace to fill the following
wac.appid = <Identifier>
wac.credential = <API Key>
wac.secret = <Shared Secret>
wac.devname = <User ID>
wac.redirectUriOAuth= <redirection URL>

Configuring the sample application to work with a different test environment
****************************************************************************
The sample app is currently configured to work with the WAC Sandbox environment.
Testing against an operator endpoint can be done but will require approval from both WAC and the operator in question.

Sandbox Availability
********************
While WAC Operations and Support works hard to keep the Developer Sandbox available 24 hours a day, 7 days a week, occasional system downtime may occur. 
To check the real-time status of the sandbox at any time, just click here - http://status.wacapps.net/19627/228798/0.2-Payment-API-Service---Dev-Sandbox

Dependency Jar files
********************
gson-2.1.jar is a Java library that can be used to convert Java Objects into their JSON representation.
It can also be used to convert a JSON string to an equivalent Java object. Gson can work with arbitrary.
This is packaged with sample application or can be downloaded from http://code.google.com/p/google-gson/downloads/detail?name=google-gson-2.1-release.zip&can=2&q= 
