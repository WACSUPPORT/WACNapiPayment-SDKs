<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title> WAC-Cinemas </title>
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
	<meta name="apple-mobile-web-app-capable" content="yes" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="icon" type="image/png" href="modules/wac_logo.png" />
    <link href="modules/stylesheet.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="modules/script.js"> </script>
</head>
<body>
	<img class="logo" src="modules/wac_logo.png" /><br /><br /><br />
	<h2 class="heading1">WAC Cinemas</h2><h4 class="heading"><br /> (Sample Application to demonstrate PHP NAPI SDK)</h4><br /><br />
    <div class="homeBtn"><a href="index.php" id="links"> Home </a></div>
    <br /><br />

<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/** Include SDK files in application */
require_once 'wac/wac.php';

/** Include Application files */
require_once 'app_constants.php';
require_once 'modules/app_ui.php';

/** Create a Application UI instance */
$ui=new app_ui();

if(isset($_COOKIE['pro_key'])){
	/**  Fetch product key [ItemID for List Transactions] from cookie */
	$appProductKey = base64_decode($_COOKIE['pro_key']);
}

/** Create a WacPaymentService instance */
$consumer = new WacPaymentService();

/**
* Specify WAC Environment URL to be used by library [DEFAULT,PRODUCTION,STAGING]
*/
$environment = 'PRODUCTION';

/**
* Initializes the application credentials to process the payment (environment, consumerKey, consumerSecret, appID, appUserName,redirectURI).
* This data is obtained when the application is registered with WAC.
*
* @param string Type of Environment URL
* @param string Developer ID/Consumer Key given by WAC
* @param string Developer Secret
* @param string Application string Identifier for a given Application
* @param string Username of the developer registered with WAC
* @param string Callback URI for the application
*/
$consumer->initService($environment,$consumerKey,$consumerSecret,$appID,$appUserName,$redirectURI);

if(isset($_COOKIE['payment_function'])){
	/** Get selected function by user */
	$func = $_COOKIE['payment_function'];
}

// For demonstration, "wacUser" is used as userID. Actual userID should be passed in this place.
$userID = "wacUser";

switch($func)
{
    case "pay":
    
        try
        {	
           	// Reserve the payment
            $reserved = $consumer->reservePayment($appProductKey);
            
            // Capture the reserved payment, userID can be used for storing transactions for a given user.
            // For demonstration, "wacUser" is used as userID. Actual userID should be passed in this place.
            $res = $consumer->capturePayment($reserved, $userID);
            
            $consumer->showPaymentSuccessPage($callback="http://localhost/wac_cinemas/index.php");
            $ui->ui_app_result($consumer,$res,"PAY");
        }
        catch(Exception $e)
        {
            echo '<pre>';
            var_dump($e);
        }
        break;
    
    case "check":

            try
            {
                if(isset($_COOKIE['ref_code']))
                {
                    $ref_code = $_COOKIE['ref_code'];
                    // check transaction, userID can be used for fetching transactions for a given user.
                    // For demonstration, "wacUser" is used as userID. Actual userID should be passed in this place.
                    $res = $consumer->checkTransactions($ref_code, $userID);
                    $ui->ui_app_result($consumer,$res,"CHECK");
                }
            }
            catch(Exception $e)
            {
                echo '<pre>';
                var_dump($e);
            }
            break;

    case "list":

            try
            {
            	// List transaction, userID can be used for fetching transactions for a given user.
            	// For demonstration, "wacUser" is used as userID. Actual userID should be passed in this place.
            	$res = $consumer->listTransactions($userID);
                $ui->ui_app_result($consumer,$res,"LIST");
            }
            catch(Exception $e)
            {
                echo '<pre>';
                var_dump($e);
            }
            break;

    default:
            echo "Error: Provided parameter is wrong, Please select any of the following functions : Pay, Check, List.";
            exit();
}
?>
</body>
</html>
