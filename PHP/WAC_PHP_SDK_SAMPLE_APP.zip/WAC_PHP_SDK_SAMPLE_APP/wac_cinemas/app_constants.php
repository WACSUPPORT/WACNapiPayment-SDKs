<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
*/

// Production - Test Mode
// Developer Consumer Key and Consumer Secret
$consumerKey    = 'wac-45d57aca2d4df2fcfb0e143c3bbeb5a915c97194';
$consumerSecret = '22823e0ee89e0b24bba1313e8c2345bf473327f2';

// Application ID
$appID       = 'wac-637212d8-0191-4718-aed2-4a1133a17086';
// Application User/ Developer Name
$appUserName = 'developer1';

// Application Callback URL
$redirectURI = "http://localhost/wac_cinemas/wac_billing_callback.php";

// Production - Live Mode
// Developer Consumer Key and Consumer Secret
/* $consumerKey    = 'wac-b4493a4d42db5de3cf86d41b71d1a1dda5553c51';
$consumerSecret = 'cd0bc75f7bb05db1b4b7760a5bdddb3f5760b44c';

// Application ID
$appID       = 'wac-84c5ffaf-5fdf-4920-bc73-1b855bf0501d';
// Application User/ Developer Name
$appUserName = 'developer1';

// Application Callback URL
$redirectURI = "http://localhost/wac_cinemas/wac_billing_callback.php"; */

?>

