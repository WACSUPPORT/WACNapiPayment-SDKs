<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

require_once 'error_utils.php';
require_once 'i18n_utils.php';

/**
* Utility methods 
*/
class Utils
{	
	function Utils()
	{
		$this->errorfunc = new ErrorUtils();
		$this->i18nfunc = new I18nUtils();
	}
	
	function checkFunctionExists(){
		/** Check if cURL is Installed in your system. */
		if(!function_exists("curl_init"))
		{
			$error = $this->i18nfunc->getSDKMessageForLocale("CURL_ERROR");
			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
		}
		/** Check if HASH is enabled in your system. */
		if(!function_exists("hash_hmac") && !function_exists("mhash"))
		{
			$error = $this->i18nfunc->getSDKMessageForLocale("ENABLE_MHASH");
			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
		}
		
		/** Check if sqlite is enabled in your system. */
		if(!function_exists("sqlite_open")  && !in_array("sqlite3", get_loaded_extensions()))
		{
			$error = "Please enable sqlite extension in your machine.";
			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
		}
		
		if(!function_exists("mcrypt_module_open"))
		{
			$error = "Please enable mcrypt extension in your machine.";
			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
		}
	}
	
	/** Check if JSON is valid.
	 * 
	 * @param json JSON Data to be validated
	 */
	function isValidJSON($json)
	{
		if($json["code"]!="ok")
		{
			$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("SERVER_ERROR");
			ErrorUtils::handle_error(ErrorUtils::$tag, $error, $json);
		}
	}
	
	/** use this function to handle / parse JSON to a two dimensional array
	 * 
	 * @param json JSON Data to be decoded 
	 */
	function decode_json($json)
	{
		$this->errorfunc->checkForResponseErrors($json);
		if(!preg_match('~^({ ( (?>[^{}]+) | (?1) )* })$~x',$json))
		{
			$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("UNABLE_TO_REACH_SERVER");
			ErrorUtils::handle_error(ErrorUtils::$tag, $error, $json);
		}
		else
		{
			return $this->errorfunc->handle_json($json);
		}
	}
	
	/**
	* Utiliy for Encoding a string
	*
	* @param str string string to be encoded
	*/
	public function oEncode($str) {
		$sb = '';
		$chars = str_split($str);
		for($i=0; $i<count($chars);$i++) {
			$c = $chars[$i];
	
			switch ($c) {
				case '!':
					$sb = $sb."%21";
					break;
				case '*':
					$sb = $sb."%2A";
					break;
				case '\'':
					$sb = $sb."%27";
					break;
				case '(':
					$sb = $sb."%28";
					break;
				case ')':
					$sb = $sb."%29";
					break;
				case ';':
					$sb = $sb."%3B";
					break;
				case ':':
					$sb = $sb."%3A";
					break;
				case '@':
					$sb = $sb."%40";
					break;
				case '&':
					$sb = $sb."%26";
					break;
				case '=':
					$sb = $sb."%3D";
					break;
				case '+':
					$sb = $sb."%2B";
					break;
				case '$':
					$sb = $sb."%24";
					break;
				case ',':
					$sb = $sb."%26";
					break;
				case '/':
					$sb = $sb."%2F";
					break;
				case '?':
					$sb = $sb."%3F";
					break;
				case '%':
					$sb = $sb."%25";
					break;
				case '#':
					$sb = $sb."%23";
					break;
				case '[':
					$sb = $sb."%5B";
					break;
				case ']':
					$sb = $sb."%5D";
					break;
	
				default:
					$sb = $sb.$c;
				break;
			}
		}
		return $sb;
	}
}

?>
