<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/**
 * Contains all the SDK functions to handle HTTP Request and Response
 */
class HTTPUtils
{	
    /** Convert a string to its Hexadecimal representation
     * 
     * @param string string String to be converted to hex
     */
    function strToHex($string)
    {
        $hex = '';
        for($i = 0; $i < strlen($string); $i++)
        {
        	$hex .= dechex(ord($string[$i]));
        }
        return $hex;
    }

    function hextostr($hex)
    {
    	$str='';
    	for ($i=0; $i < strlen($hex)-1; $i+=2)
    	{
    		$str .= chr(hexdec($hex[$i].$hex[$i+1]));
    	}
    	return $str;
    }
    
    /** Build parameters for oAuth Authorization 
     * 
     * @param string oAuthString Authorization string
     * @param string seperator 
     */
    function prepareOAuthParameterForAuthorization($oAuthString, $separator = ",")
    {
        /**	prepare result */
        $result = "";
        /**	parse to array */
        parse_str($oAuthString, $oAuthArray);
        /**	check for valid array */
        if(count($oAuthArray) > 0)
        {
            foreach($oAuthArray as $key => $value)
            {
                $value = urlencode($value);
                $result .= $key.'="'.$value.'"'.$separator;
            }
              $result = substr($result, 0, (strlen($separator) * -1));
         }
        return $result;
    }
    
    /**	Build oAuth header with Authorization parameter */
    function prepareOAuthParameterForHeader($contentType = "", $mnc = "", $mcc = "", $authorization = "", $oAuth = true,$accept,$wacSDKVersion="dot2",$xsource_ip)
    {
        $result = array();
        if($wacSDKVersion=="dot1"){
        	/**	check contentType */
        	if($contentType != ""){
        		/**	add contentType */
        		$result[] = "Content-Type: $contentType";
        	}
        	/**	check mnc */
        	if($mnc != ""){
        		/**	add contentType */
        		$result[] = "x-mnc: $mnc";
        	}
        	/**	check mcc */
        	if($mcc != ""){
        		/**	add contentType */
        		$result[] = "x-mcc: $mcc";
        	}
        	/**	check authorization */
        	if($authorization != ""){
        		/**	check OAuth Authorization */
        		if($oAuth)
        		{
        			/**	add OAuth Authorization */
        			$result[] = "Authorization: OAuth $authorization";
        		}
        		else
        		{
        			/**	add Authorization */
        			$result[] = "Authorization: $authorization";
        		}
        	}
        }else{
        	if($accept != ""){
        		/**	add contentType */
        		$result[] = "Accept: $accept";
        	}
        	if($authorization != ""){
        		/**	check OAuth Authorization */
        		if($oAuth){
        			/**	add OAuth Authorization */
        			$result[] = "Authorization: OAuth $authorization";
        		}
        		else{
        			/**	add Authorization */
        			$result[] = "Authorization: Signature $authorization";
        		}
        	}
        	@session_start();
        	if(isset($_SESSION["spoofedIP"])){
        		$userIP = $_SESSION["spoofedIP"];
        	}else{
        		$userIP = $_SERVER['REMOTE_ADDR'];
        	}
        	if($xsource_ip == "query"){
        		$result[] = "x-source-ip: $userIP";
        	}
        }
        return $result;
    }

    /** Send HTTP Request and catch the response using cURL */
    function httpRequest($url, $getParams = '', $postParams = '', $headerParams = array(), $method = "GET", $timeout = 30, $debug = false)
    {	
        $ch = curl_init();
        if($getParams != "")
        {
            $url = $url."?".$getParams;
        }
        if($method == "POST")
        {
            curl_setopt($ch, CURLOPT_POST, true);					//	TRUE to do a regular HTTP POST. This POST is the normal application/x-www-form-urlencoded kind, most commonly used by HTML forms
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postParams);		//	The full data to post in a HTTP "POST" operation
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        @session_start();
        if(isset($_SESSION["debugLog"]) && $_SESSION["debugLog"]){
        	curl_setopt($ch, CURLOPT_VERBOSE, TRUE);
        }else{
        	curl_setopt($ch, CURLOPT_VERBOSE, FALSE);
        }
        curl_setopt($ch, CURLOPT_URL, $url);							//	The URL to fetch
        curl_setopt($ch, CURLOPT_HEADER, 0);							//	TRUE to include the header in the output
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);					//	The maximum number of seconds to allow cURL functions to execute
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headerParams);			//	An array of HTTP header fields to set, in the format array('Content-type: text/plain', 'Content-length: 100')
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");	//	The contents of the "User-Agent: " header to be used in a HTTP request
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);					//	TRUE to return the transfer as a string of the return value of curl_exec() instead of outputting it out directly
        $response = curl_exec($ch);
        curl_close($ch);
        if($debug)
        {
            
        }
        return $response;
    }
}

?>
