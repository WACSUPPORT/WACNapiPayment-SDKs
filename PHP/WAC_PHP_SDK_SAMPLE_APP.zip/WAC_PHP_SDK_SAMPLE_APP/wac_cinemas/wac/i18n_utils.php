<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/**
* Implementation of the I18nUtils for Internationalization
*/
class I18nUtils
{	
	public $locale="en-US";
	private $propertiesURL;
	private $enUS_path = "/messages/messages_en-US.properties";
	private $path = "/messages/messages_*****.properties";
	private $SDKBuiltOn = "1328352653";
	private $classPath = null;
	
	function I18nUtils(){
		$reflectionClass = new ReflectionClass(__CLASS__);
		$fn = $reflectionClass->getFileName();
		$path = dirname($fn);
		$this->classPath = $path;
		if(preg_match("#/#",$path)){
			$this->enUS_path = str_replace("'\'","/",$path.$this->enUS_path);
			$this->path = str_replace("'\'","/",$path.$this->path);
		}else{
			$this->enUS_path = $path.$this->enUS_path;
			$this->path = $path.$this->path;
		}
	}
	
	function setPropertiesURL($propertiesURL){
		$this->propertiesURL = $propertiesURL;
	}
	
	/**
	* Sets the locale for a given user
	* 
	* @param string locale locale for a given user
	*/
	public function setLocale($locale){
		if($locale){
			$this->locale=$locale;
		}else{
			$lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
			$lang = preg_split("/[,;]/", $lang);
			if(preg_match("#/#",$this->classPath)){
				$langFile = str_replace("'\'","/",$this->classPath.'/messages/messages_'.$lang[0].'.properties');
			}else{
				$langFile = $this->classPath.'/messages/messages_'.$lang[0].'.properties';
			}
			if(isset($lang[0]) && file_exists($langFile)){
				$this->locale=$lang[0];
			}else{
				$this->locale="en-US";
			}
		}
		@session_start();
		$_SESSION["locale"] = $this->locale;
		$this->propertiesURL = str_replace("*****",$this->locale,$this->propertiesURL);
		$this->path = str_replace("*****",$this->locale,$this->path);
	}

	/**
	* Gets message in locale language for server messages
	* @param string message message to be displayed
	*/
	public function getServerMessageForLocale($message){
		@session_start();
		if(isset($_SESSION["locale"])){
			$this->locale = $_SESSION["locale"];
		}
		$this->propertiesURL = str_replace("*****",$this->locale,$this->propertiesURL);
		$this->path = str_replace("*****",$this->locale,$this->path);
		$txtProperties = $this->getMessageData();
		$messageHash = $this->messageHASH($message);
		$result = array();
		$lines = preg_split("/\n/", $txtProperties);
		$key = "";

		$isWaitingOtherLine = false;
		foreach($lines as $i=>$line) {

			if(empty($line) || (!$isWaitingOtherLine && strpos($line,"#") === 0)) continue;

			if(!$isWaitingOtherLine) {
				$key = substr($line,0,strpos($line,'='));
				$value = substr($line,strpos($line,'=') + 1, strlen($line));
			}
			else {
				$value .= $line;
			}

			/** Check if ends with single '\' */
			if(strrpos($value,"\\") === strlen($value)-strlen("\\")) {
				$value = substr($value, 0, strlen($value)-1)."\n";
				$isWaitingOtherLine = true;
			}
			else {
				$isWaitingOtherLine = false;
			}

			$result[$key] = $value;
			unset($lines[$i]);
		}
		if(isset($result[$messageHash])){
			return $result[$messageHash];
		}else{
			return $message;
		}
	}
	
	
	/**
	* Gets message in locale language for SDK messages 
	* @param string message message to be displayed
	*/
	public function getSDKMessageForLocale($message){
		@session_start();
		if(isset($_SESSION["locale"])){
			$this->locale = $_SESSION["locale"];
		}
		$this->propertiesURL = str_replace("*****",$this->locale,$this->propertiesURL);
		$this->path = str_replace("*****",$this->locale,$this->path);
		$txtProperties = $this->getMessageData();
		$result = array();
		$lines = preg_split("/\n/", $txtProperties);
		$key = "";
		
		$isWaitingOtherLine = false;
		foreach($lines as $i=>$line) {
		
			if(empty($line) || (!$isWaitingOtherLine && strpos($line,"#") === 0)) continue;
		
			if(!$isWaitingOtherLine) {
				$key = substr($line,0,strpos($line,'='));
				$value = substr($line,strpos($line,'=') + 1, strlen($line));
			}
			else {
				$value .= $line;
			}
		
			/** Check if ends with single '\' */
			if(strrpos($value,"\\") === strlen($value)-strlen("\\")) {
				$value = substr($value, 0, strlen($value)-1)."\n";
				$isWaitingOtherLine = true;
			}
			else {
				$isWaitingOtherLine = false;
			}
		
			$result[$key] = $value;
			unset($lines[$i]);
		}
		return $result[$message];
	}
	
	/**
	* Generates sha1 Hash value for a given message string
	* @param string message to be hashed
	*/
	function messageHASH($message){
		$s = $this->stripAllNonAlphaNum($message);
		$s1 = sha1($s);
		return $s1;
	}

	/**
	* returns when the properties file in URL was last Modified 
	*/
	function getLastModified(){
		$this->header = @get_headers($this->propertiesURL);
		if(!empty($this->header)){
			$lastModified =  preg_split('/Last-Modified: /', $this->header[4]);
			if ($lastModified == null) {
				$lastModified =  preg_split('/last-Modified: /', $this->header[4]);
			}

			if (isset($lastModified[1])) {
				if($lastModified != null ||  !empty($lastModified[1])){
					return date(strtotime($lastModified[1]));
				}
			}else{
				return false;
			}
		}
		return false;
	}

	/**
	* checks if server has latest properties file
	*/
	function serverHasFreshGoods(){
		if($this->localFileExists()){
			$this->currentFileTimestamp = max(@filemtime($this->path), $this->SDKBuiltOn);
		}else{
			$this->currentFileTimestamp = 0;
		}
			
		$lastModified = $this->getLastModified();
		$filesize = @filesize($this->path);
		if(isset($lastModified)){
			if($filesize == 0 || ($lastModified > $this->currentFileTimestamp)){
				return true;
			}
		}
		return false;
	}

	/**
	* strips non alphanumeric values in string
	*/
	function stripAllNonAlphaNum($string) {
		if ($string != null) {
			$string = trim(preg_replace("/[^a-zA-Z0-9]/", "", strtolower($string)));
			return $string;
		}
	}

	/**
	* load the specified property file from server
	*/
	function loadPropertyFileFromServer() {
		$lastDownloaded = $this->currentFileTimestamp;
		$lastModified = 0;
		$filesize = @filesize($this->path);
		$this->response = @file_get_contents($this->propertiesURL);
		if(!isset($this->response)){
			return false;
		}
		if ((time() - $lastDownloaded) > 3600*24*1 || $filesize==0) {
			if ($this->header[0] != "HTTP/1.1 200 OK") {
				return false;
			}
			$lastModified = $this->getLastModified();
		}

		if ($filesize == 0 || ($lastModified > $lastDownloaded)) {
			if ($this->localFileExists()) {
				unlink($this->path);
			}
			if(!$this->createLocalFile()){
				return $this->response;
			}

			// If storage is possible, store it in the file
			if ($this->localFileExists() && is_writable($this->path)) {
				@file_put_contents($this->path, $this->response);
				return $this->response;
			}else{
				return $this->response;
			}
		}else{
			return $this->response;
		}
	}
	
	/**
	* get the data from local properties file
	*/
	function localFileData(){
		return @file_get_contents($this->path);
	}
	
	/**
	* check if local properties file exists
	*/
	function localFileExists(){
		if(file_exists($this->path)){
			return true;
		}
		return false;
	}
	
	/**
	* create a file in path specified, return false if unable to create a file
	*/
	function createLocalFile(){
		$ourFileHandle = @fopen($this->path, 'w');
		return $ourFileHandle;
	}
	
	/**
	* get data from default message_en-US.properties file
	*/
	function getUSdata(){
		return @file_get_contents($this->enUS_path);
	}
	
	function isWebsiteUp($url){
		if(function_exists("curl_init")){
			$agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";$ch=curl_init();
			curl_setopt ($ch, CURLOPT_URL,$url );
			curl_setopt($ch, CURLOPT_USERAGENT, $agent);
			curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt ($ch,CURLOPT_VERBOSE,false);
			curl_setopt($ch, CURLOPT_TIMEOUT, 5);
			$page=curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			if($httpcode>=200 && $httpcode<300) return true;
			else return false;
		}
	}

	/**
	* get the input stream of data from properties file
	*/
	function getMessageData(){
		if(!$this->localFileExists()){
			$this->createLocalFile();
		}
		
		if ((time() - max(@filemtime($this->path), $this->SDKBuiltOn)) > 3600*24*1 || (@filesize($this->path)==0)){
			if($this->isWebsiteUp($this->propertiesURL)){
				if($this->serverHasFreshGoods()){
					$propFile = $this->loadPropertyFileFromServer();
					if(!$propFile){
						return $this->getUSdata();
					}else{
						return $propFile;
					}
				}
			}else if($this->localFileExists() && (@filesize($this->path)>0)){
				return $this->localFileData();
			}else{
				return $this->getUSdata();
			}
		}else{
			if($this->localFileExists() && (@filesize($this->path)>0)){
				return $this->localFileData();
			}else{
				return $this->getUSdata();
			}
		}
	}
}
?>
