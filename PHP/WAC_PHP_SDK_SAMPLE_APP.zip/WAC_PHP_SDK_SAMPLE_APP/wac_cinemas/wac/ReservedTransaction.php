<?php 
/**
* Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
* The use of this SDK is subject to the terms and conditions in license.txt
*/

/**
 * Holds the data related to reserve/capture payment.
 */
class ReservedTransaction {

	public $consumer;
	public $accessToken;
	
	public function setReservedData($consumer, $accessToken){
		$this->consumer = $consumer;
		$this->accessToken = $accessToken;
		
		return base64_encode(serialize($this));
	}
	
	public function getReservedData($reserved){
		return unserialize(base64_decode($reserved));
	}
}


?>
