<?php
/**
 * Wrapper Class to extend SQLite3 base class in PHP
 */
class SQLite3DB extends SQLite3
{
    function __construct($dbName)
    {
        $this->open($dbName);
    }
}

?>