<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/** 
 * Defines the Endpoints of the WAC Gateway 
 */
class EndPoints
{	
	function EndPoints()
	{
		/** dot2 HTTP Staging URL */
		$baseStagingUrlHttpR2 = "http://staging.api.wacapps.net:8080/";
		
		/** dot2 HTTPS Staging URL */
		$baseStagingUrlHttpsR2 = "https://staging.api.wacapps.net/";
		
		/** dot2 HTTP Staging URL */
		$baseProUrlHttpR2 = "http://api.wacapps.net:8080/";
		
		/** dot2 HTTPS Staging URL */
		$baseProUrlHttpsR2 = "https://api.wacapps.net/";
		
		/** dot2 Query URL */
		$this->queryStagingPathR2 = $baseStagingUrlHttpsR2."products";
		
		/** dot2 Query URL */
		$this->queryProPathR2 = $baseProUrlHttpsR2."products";
		
		
		/** dot2 Authorize URL */
		$this->authorizationStagingChargePathR2 = $baseStagingUrlHttpsR2."/2/oauth/authorize";
		
		/** dot2 Access Token URL */
		$this->accessTokenStagingChargePathR2 = $baseStagingUrlHttpsR2."/2/oauth/access-token";
		
		/** dot2 Charge Payment URL */
		$this->chargePaymentStagingPathR2 = $baseStagingUrlHttpsR2."/2/payment/acr:Authorization/transactions/amount";
		
		/** dot2 Authorize URL */
		$this->authorizationProChargePathR2 = $baseProUrlHttpsR2."/2/oauth/authorize";
		
		/** dot2 Access Token URL */
		$this->accessTokenProChargePathR2 = $baseProUrlHttpsR2."/2/oauth/access-token";
		
		/** dot2 Charge Payment URL */
		$this->chargePaymentProPathR2 = $baseProUrlHttpsR2."/2/payment/acr:Authorization/transactions/amount";
		
		/** dot1 Default URL */
		$this->baseUrlHttpDefault = "http://pro1.api.wacapps.net";
		$this->baseUrlHttpsDefault = "https://pro1.api.wacapps.net";
		
		/** dot1 Production URL */
		$this->baseUrlHttpPro = "http://pro1.api.wacapps.net";
		$this->baseUrlHttpsPro = "https://pro1.api.wacapps.net";
		
		/** dot1 Staging URL */
		$this->baseUrlHttpStage = "http://prostage.api.wacapps.net";
		$this->baseUrlHttpsStage = "https://prostage.api.wacapps.net";
		
		/** dot1 Sandbox URL */
		$this->baseUrlHttpSandbox = "http://prosbx.api.wacapps.net";
		$this->baseUrlHttpsSandbox = "https://prosbx.api.wacapps.net";
		
		/** Localization server URLs */
		$this->i18nProductionPropertiesFile = "https://res.api.wacapps.net/i18n/messages_*****.properties";
		$this->i18nStagingPropertiesFile = "http://dev8.wacapps.net/i18n/messages_*****.properties";
	}
	
	/** returns dot2 Query URL */
	function getdot2queryURL($urlType){
		
		$queryURL = $this->queryProPathR2;
		
		switch ($urlType) {
			 
			case 'PRODUCTION':
				$queryURL = $this->queryProPathR2;
				break;
		
			case 'STAGING':
				$queryURL = $this->queryStagingPathR2;
				break;
		
			case 'DEFAULT': break;
		
			default:
				echo "Error : URL supplied is incorrect!";
				exit();
		}
		return $queryURL;
	}
	
	/** returns dot2 Authorize URL */
	function getdot2AuthorizeURL($urlType){
		
		$authURL = $this->authorizationProChargePathR2;
		
		switch ($urlType) {
			 
			case 'PRODUCTION':
				$authURL = $this->authorizationProChargePathR2;
				break;
		
			case 'STAGING':
				$authURL = $this->authorizationStagingChargePathR2;
				break;
		
			case 'DEFAULT': break;
		
			default:
				echo "Error : URL supplied is incorrect!";
				exit();
		}
		return $authURL;
	}
	
	/** returns dot2 Access Token URL */
	function getdot2AccessTokenURL($urlType){
		
		$accesstokenURL = $this->accessTokenProChargePathR2;
		
		switch ($urlType) {
			 
			case 'PRODUCTION':
				$accesstokenURL = $this->accessTokenProChargePathR2;
				break;
		
			case 'STAGING':
				$accesstokenURL = $this->accessTokenStagingChargePathR2;
				break;
		
			case 'DEFAULT': break;
		
			default:
				echo "Error : URL supplied is incorrect!";
				exit();
		}
		return $accesstokenURL;
	}
	
	/** returns dot2 Payment URL */
	function getdot2PaymentURL($urlType){
		
		$paymentURL = $this->chargePaymentProPathR2;
		
		switch ($urlType) {
			 
			case 'PRODUCTION':
				$paymentURL = $this->chargePaymentProPathR2;
				break;
		
			case 'STAGING':
				$paymentURL = $this->chargePaymentStagingPathR2;
				break;
		
			case 'DEFAULT': break;
		
			default:
				echo "Error : URL supplied is incorrect!";
				exit();
		}
		return $paymentURL;
	}
	
    /** Set Base URL for dot1 */
    function setBaseURL($urlType)
    {
        $wacURLDiscoverOperator = $this->baseUrlHttpDefault . "/discovery/operator/{application-id}";

        switch ($urlType) {
        	
        	case 'PRODUCTION':
        		$wacURLDiscoverOperator = $this->baseUrlHttpPro."/discovery/operator/{application-id}";
        		break;
        		
        	case 'STAGING':
        		$wacURLDiscoverOperator = $this->baseUrlHttpStage."/discovery/operator/{application-id}";
        		break;
        		
        	case 'SANDBOX':
        		$wacURLDiscoverOperator = $this->baseUrlHttpSandbox."/discovery/operator/{application-id}";
        		break;

            case 'DEFAULT': break;

            default:
                echo "Error : URL supplied is incorrect!";
                exit();
        }
        return $wacURLDiscoverOperator;
    }
    
    /** returns i18n Properties URL */
    function getPropertiesFileURL($urlType){
    
    	$i18nPropertiesFile = $this->i18nProductionPropertiesFile;
    
    	switch ($urlType) {
    
    		case 'PRODUCTION':
    			$i18nPropertiesFile = $this->i18nProductionPropertiesFile;
    			break;
    
    		case 'STAGING':
    			$i18nPropertiesFile = $this->i18nStagingPropertiesFile;
    			break;
    
    		case 'DEFAULT': break;
    
    		default:
    			echo "Error : URL supplied is incorrect!";
    		exit();
    	}
    	return $i18nPropertiesFile;
    }
}

?>
