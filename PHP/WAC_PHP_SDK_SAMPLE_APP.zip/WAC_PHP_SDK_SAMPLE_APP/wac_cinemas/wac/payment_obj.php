<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/**
 * stores products and their details
 */
class Products
{
	private $oAuthAppProductKey;
	private $wacProductCurrency;
	private $wacProductPrice;
	private $wacProductDescription;
	private $wacProductBillingReceipt;
	
	function Products($oAuthAppProductKey, $wacProductCurrency, $wacProductPrice, $wacProductDescription, $wacProductBillingReceipt){
		$this->oAuthAppProductKey = $oAuthAppProductKey;
		$this->wacProductCurrency = $wacProductCurrency;
		$this->wacProductPrice = $wacProductPrice;
		$this->wacProductDescription = $wacProductDescription;
		$this->wacProductBillingReceipt = $wacProductBillingReceipt;
	}
	
	function setProductKey($oAuthAppProductKey){
		$this->oAuthAppProductKey = $oAuthAppProductKey;
	}
	
	function setProductCurrency($wacProductCurrency){
		$this->wacProductCurrency = $wacProductCurrency;
	}
	
	function setProductPrice($wacProductPrice){
		$this->wacProductPrice = $wacProductPrice;
	}
	
	function setProductDescription($wacProductDescription){
		$this->wacProductDescription = $wacProductDescription;
	}
	
	function setProductBillingReceipt($wacProductBillingReceipt){
		$this->wacProductBillingReceipt = $wacProductBillingReceipt;
	}
	
	function getProductKey(){
		return $this->oAuthAppProductKey;
	}
	
	function getProductCurrency(){
		return $this->wacProductCurrency;
	}
	
	function getProductPrice(){
		return $this->wacProductPrice;
	}
	
	function getProductDescription(){
		return $this->wacProductDescription;
	}
	
	function getProductBillingReceipt(){
		return $this->wacProductBillingReceipt;
	}
}
?>
