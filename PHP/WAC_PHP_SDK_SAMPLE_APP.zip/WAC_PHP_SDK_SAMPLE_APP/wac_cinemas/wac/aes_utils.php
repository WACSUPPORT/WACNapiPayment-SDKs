<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

require_once 'http_utils.php';

/**
* Utiltiy functions to implement 
*/
class AES_Utils
{
	function AES_Utils(){
		$this->httpfunc  = new HTTPUtils();
	}
	
	private static $key = '1234567890123456';
	
	private static $iv =  '1234567890123456';
	
	function aesEncrypt($plainText){
		$cipher = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
		if (mcrypt_generic_init($cipher, self::$key, self::$iv) != -1)
		{
			$cipherText = mcrypt_generic($cipher,$plainText );
			return $cipherText;
		}
	}
	
	function aesDecrypt($cipherText){
		$cipher = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', MCRYPT_MODE_CBC, '');
		$decryptedData = mcrypt_decrypt( MCRYPT_RIJNDAEL_128 , self::$key , $cipherText , "cbc", self::$iv );
		return $decryptedData;
	}
}

?>
