<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

require_once 'OAuth.php';
require_once 'http_utils.php';
require_once 'utils.php';

class TokenUtils
{
	function TokenUtils()
	{
		$this->httpfunc  = new HTTPUtils();
		$this->utilsfunc = new Utils();
	}
	
    /** Prepare the header for Authorization */
    function authorize_header($consumer,$req_token)
    {
        $url = $consumer->oAuthURLAuthorizeToken;
        $mnc = $consumer->oAuthOperatorMNC;
        $mcc = $consumer->oAuthOperatorMCC;
        /**	Prepare an URL to redirect to Authorize page. */
        header(
                    'location:'.$url.
                    '?oauth_token='.$req_token.
                    '&x-mnc='.$mnc.
                    '&x-mcc='.$mcc
        );
    
    }
    
    /** Get Scope of Payment  */
    function getScope($type,$consumer)
    {
        /**	check for scope type */
        if($type == 'PAY')
        {
            /**	payment scope */
            $scope = $consumer->oAuthScopePay;
            /**	prepare scope */
            $scope = str_replace("{item-id}", $consumer->products->getProductKey(), $scope);
        }
        elseif($type == 'CHECK')
        {
            /**	check scope */
            $scope = $consumer->oAuthScopeCheck;
        }
        else
        {
            /**	list scope */
            $scope = $consumer->oAuthScopeList;
        }

        /**	return scope */
        return array($scope);
    }
    
    /**	Get a Request Token for oAuth 1 */
    function getRequestToken($scopeType,$consumer)
    {
    	/**	get scope */
    	$scopes = $this->getScope($scopeType,$consumer);
    	/**	separate the scopes with a space */
    	$scopes_str = implode(' ', $scopes);
    	/**	prepare the parameters as described in the document */
    	$params = array ();
    	parse_str("oauth_scope=".$scopes_str, $params);
    	/**	create OAuthRequest --> returns a Request Object that has params, method and URL */
    	$request = OAuthRequest::from_consumer_and_token(
    	$consumer->oauth,
    	NULL,
    	        "GET",
    	$consumer->oAuthURLRequestToken,
    	$params
    	);
    	
    	/**	create OAuthSignatureMethod_HMAC_SHA1 */
    	$signatureMethod = new OAuthSignatureMethod_HMAC_SHA1();
    	
    	/**	signed request */
    	$request->sign_request($signatureMethod, $consumer->oauth, NULL);
    	
    	/**	extract _url & _params */
    	$_urlTokens = parse_url($request->to_url());
    	$_url = $_urlTokens["scheme"]."://".$_urlTokens["host"].$_urlTokens["path"];
    	$_params = $_urlTokens["query"];
    	
    	/**	prepare oAuth authorization parameters */
    	$oAuthAuthorization = $this->httpfunc->prepareOAuthParameterForAuthorization(
    	$_params
    	);
    	
    	/**	prepare oAuth header parameters */
    	$headerParameters = $this->httpfunc->prepareOAuthParameterForHeader(
    	$consumer->oAuthContentType,
    	$consumer->oAuthOperatorMNC,
    	$consumer->oAuthOperatorMNC,
    	$oAuthAuthorization,
    	true,
    	false,
    	"dot1",
    	false
    	);
    	/**	get HTTP request */
    	$response = $this->httpfunc->httpRequest($_url, "", "",$headerParameters, "GET");
    	/**	convert from response to array */
    	parse_str($response, $responseArray);
    	/**	get oauth_token, oauth_token_secret & oauth_callback_confirmed */
    	if(isset($responseArray["oauth_token"])){
    		$tmp_oauth_token = $responseArray["oauth_token"];
    		$tmp_oauth_token_secret = $responseArray["oauth_token_secret"];
    		$tmp_oauth_callback_confirmed = $responseArray["oauth_callback_confirmed"];
    	}else{
    		return false;
    	}
    	/**	create token instance */
    	$token = new stdClass();
    	$token->value = $tmp_oauth_token;
    	$token->secret = $tmp_oauth_token_secret;
    	/** Save the RequestToken Value and Secret in a File */
    	$this->saveToken($token,$token->value);
    	/**	return token */
    	return $token->value;
    }

    /**	Get an Access Token for oAuth 1 */
    function getAccessToken($oauth_token, $oauth_verifier,$consumer)
    {
        $tokena = new stdClass();
        $tokena->value = $oauth_token;
        $tokena->secret = $oauth_verifier;

        /**	load token from then file */
        $tokenb = $this->readToken($tokena->value);
        $tokena->value = $tokenb->value;
        $tokena->secret = $tokenb->secret;
        /**	check for valid token */
        if(!$tokena)
        {
            return false;
        }
        /**	create oAuthConsumer */
        $consumer->token = new OAuthConsumer($tokena->value, $tokena->secret);
        /**	add oauth_verifier into parameter */
        $params = array ();
        $params['oauth_verifier'] = $oauth_verifier;
        /**	create OAuthRequest */
        $request = OAuthRequest::from_consumer_and_token(
        $consumer->oauth,
        $consumer->token,
        "POST",
        $consumer->oAuthURLAccessToken,
        $params
        );
        /**	create OAuthSignatureMethod_HMAC_SHA1 */
        $signatureMethod = new OAuthSignatureMethod_HMAC_SHA1();
        /**	signed request */
        $request->sign_request($signatureMethod, $consumer->oauth, $consumer->token);
        /**	extract _url & _params */
        $_urlTokens = parse_url($request->to_url());
        $_url = $_urlTokens["scheme"]."://".$_urlTokens["host"].$_urlTokens["path"];
        $_params = $_urlTokens["query"];
        /**	prepare oAuth authorization parameters */
        $oAuthAuthorization = $this->httpfunc->prepareOAuthParameterForAuthorization(
        $_params
        );

        /** prepare oAuth header parameters */
        $headerParameters = $this->httpfunc->prepareOAuthParameterForHeader(
        $consumer->oAuthContentType,
        $consumer->oAuthOperatorMNC,
        $consumer->oAuthOperatorMNC,
        $oAuthAuthorization,
        true,
        false,
        "dot1",
        false
        );

        /**	get HTTP request */
        $response = $this->httpfunc->httpRequest($_url, "", "", $headerParameters, "POST");
        /**	convert from response to array */
        parse_str($response, $responseArray);
        if(isset($responseArray["oauth_token"]))
        {
            /**	get oauth_token, oauth_token_secret & oauth_callback_confirmed */
            $tmp_oauth_token = $responseArray["oauth_token"];
            $tmp_oauth_token_secret = $responseArray["oauth_token_secret"];
            if(isset($responseArray["oauth_callback_confirmed"])){
            	$tmp_oauth_callback_confirmed = $responseArray["oauth_callback_confirmed"];
            }
            /**	create token instance */
            $token1 = new stdClass();
            $token1->value = $tmp_oauth_token;
            $token1->secret = $tmp_oauth_token_secret;
            return $token1;
        }
    }
    
    /** Fetch access token for oAuth 2 */
    function getAuth2AccessToken($code,$consumer)
    {
        /** Header of HTTP Post Request */
        $headerArray = array();
        if($consumer->wacSDKVersion == "dot2")
        {
            $headerArray[] = "Accept: application/json";
            $headerArray[] = "Content-Type: application/x-www-form-urlencoded";
            $headerArray[] = "x-client-request-id: 1234";
        }else{
        	$headerArray[] = "Content-Type:".$consumer->oAuthContentType;
        	$headerArray[] = "x-mnc: ".$consumer->oAuthOperatorMNC;
        	$headerArray[] = "x-mcc: ".$consumer->oAuthOperatorMCC;
        }
        
        /** Post Parameters */
        $data = "client_id=".$consumer->oAuthConsumerKey."&client_secret=".$consumer->oAuthConsumerSecret."&code=".$code."&grant_type=authorization_code&redirect_uri=".urlencode($consumer->app_callback);
        $url = $consumer->oAuth2URLAccessToken;
        
        $response = $this->httpfunc->httpRequest($url,"",$data,$headerArray,"POST");
        $res = $this->utilsfunc->decode_json($response);
        return $res;
    }
    
    function saveToken($token,$cookie_name)
    {
        /** Save tokens in a Cookie */
        $cookie_value = base64_encode( serialize( $token ));
        setcookie("wac_token_".$cookie_name,$cookie_value,time () + 3600,'/');
    }
    
    function readToken($cookie_name)
    {
    	if(isset($_COOKIE["wac_token_".$cookie_name])){
    		/** Read Token From a Cookie */
    		$cookie_value = $_COOKIE["wac_token_".$cookie_name];
	        $token = unserialize(base64_decode( $cookie_value ) );
        	setcookie("wac_token_".$cookie_name,$cookie_value,time ()-3600,'/');
        	return $token;
    	}
    }
}
?>
