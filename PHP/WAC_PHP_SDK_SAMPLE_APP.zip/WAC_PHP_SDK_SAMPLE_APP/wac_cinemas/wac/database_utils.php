<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

require_once 'i18n_utils.php';
require_once 'error_utils.php';

/**
* Database functions
*/

class databaseUtils
{	
	private $connect;
	
	function databaseUtils()
	{
		$this->i18nfunc = new I18nUtils();
	}
	
	function connector($db_host, $db_username, $db_password, $db_name, $use_names = '', $pconnect = true, $newlink = false)
	{
		global $lang_global;
		if(function_exists("sqlite_open")){
			if (!file_exists($db_name)){
				@touch($db_name);
				@chmod($db_name, 0666);
				if (!file_exists($db_name)) $this->error($lang_global['err_sql_conn_db']);
			}
			
			if ((!is_readable($db_name))||(!is_writable($db_name))) $this->error($lang_global['err_sql_conn_db']);
			
			if ($pconnect) $this->connect = @sqlite_popen($db_name, 0666, $this->sqlite_error);
			else $this->connect = @sqlite_open($db_name, 0666, $this->sqlite_error);			
		}else{
			require_once 'SQLite3DB_utils.php';
			$this->connect = new SQLite3DB($db_name);		
		}
		
		if ($this->connect) return $this->connect;
		else die($this->i18nfunc->getSDKMessageForLocale("UNABLE_TO_CREATE_DATABASE"));
	}
	
     function openDb($db_name)
     {
     	$reflectionClass = new ReflectionClass(__CLASS__);
     	$fn = $reflectionClass->getFileName();
     	$path = dirname($fn);
     	
     	if(preg_match("#/#",$path)){
     		$db_path = str_replace("'\'","/",$path.'/'.$db_name);
     	}else{
     		$db_path = $path.'/'.$db_name;
     	}
     	
     	$this->connector(NULL,NULL,NULL, $db_path, NULL);
     	return $this->connect;
     }
     
     function createTable()
     {
     	$query = "create table napiItems(Id INTEGER PRIMARY KEY, userID VARCHAR(20) NOT NULL, refCode VARCHAR(20) NOT NULL, payLoad BLOB NOT NULL, timeEnter TIMESTAMP)";
     	$this->sqlite_execute_query($query);    	
     }
     
     function insertDb($refCode, $payLoad = '', $userID=null)
     {
     	$timestamp = time();
     	$insertQuery = "INSERT INTO napiItems (Id, userID, refCode, payLoad, timeEnter) VALUES (null,'$userID','$refCode','$payLoad','$timestamp')";
     	if($userID!=null || trim($userID)!=""){
     		$this->sqlite_execute_query($insertQuery);
     	}
     }
     
     function listTransDbData($userID=null)
     {
     	if($userID!=null || trim($userID)!=""){
     		$listQuery = "select payLoad from napiItems where userID = '$userID'";
     		return $this->sqlite_execute_array_query($listQuery);
     	}else{
     		$error = $this->i18nfunc->getSDKMessageForLocale("NO_TRANSACTIONS_AVAILABLE");
			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
     	}
     }
     
     function checkTransDbData($ref_code, $userID=null)
     {
     	if($userID!=null || trim($userID)!=""){
     		$checkQuery = "select Id, payLoad, timeEnter from napiItems where refCode = '$ref_code' AND userID = '$userID' ";
     		return $this->sqlite_execute_array_query($checkQuery);
     	}else{
     		$error = $this->i18nfunc->getSDKMessageForLocale("NO_TRANSACTIONS_AVAILABLE");
     		ErrorUtils::handle_error(ErrorUtils::$tag, $error);
     	}
     }
     
     function sqlite_table_exists()
     {
     	if(function_exists("sqlite_open")){
     		$result = @sqlite_query($this->connect, "SELECT Id FROM napiItems");
     		return @sqlite_num_rows($result) > 0;
     	}else{
     		$rowID = @$this->connect->lastInsertRowID();
     		return $rowID > 0;
     	}     	
     }
     
     function sqlite_execute_query($query)
     {
     	if(function_exists("sqlite_open")){
     		$result = @sqlite_exec($this->connect, $query);
     	}else{
     		@$this->connect->exec($query);
     	}
     }
     
     function sqlite_execute_array_query($query)
     {
     	if(function_exists("sqlite_open")){
     		$result = @sqlite_array_query($query, $this->connect, SQLITE_ASSOC);
     		return $result;
     	}else{
     		$resultSet = @$this->connect->query($query);
     		$result = array();
     		$i = 0;
     		while($res = @$resultSet->fetchArray(SQLITE3_ASSOC)){
     			if(!isset($res['payLoad'])) continue;
     			$result[$i]['payLoad'] = $res['payLoad'];
     			$i++;
     		}
     		return $result;
     	}
     }
     
     function error()
     {
     	return @sqlite_error_string(sqlite_last_error($this->connect));
     }
}

?>
