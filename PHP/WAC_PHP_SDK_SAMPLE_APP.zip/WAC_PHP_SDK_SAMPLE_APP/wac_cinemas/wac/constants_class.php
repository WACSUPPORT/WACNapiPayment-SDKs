<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/**
* contains variables needed for SDK
*/

class Constants
{	
    /** oAuth Content Type */
    public $oAuthContentType = 'application/x-www-form-urlencoded';
    public $oAuthAccept = 'application/json';
    public $SuccessPage = "https://res.api.wacapps.net/payment/confirm";
    
    /** oAuth scope */
    public $oAuthScopePay = 'POST-/payment/acr:Authorization/transactions/amount?code={item-id}';
    public $oAuthScopeCheck = 'GET-/payment/acr:Authorization/transactions/amount';
    public $oAuthScopeList = 'GET-/payment/acr:Authorization/transactions/amount';
    
    public $oAuthdot2ScopePay = 'GET,POST-/payment/acr:Authorization/transactions/amount?code={item-id}';
    
    /** oAuth Operator Mobile Network Code & Mobile Country Code */
    public $oAuthOperatorMNC = null;
    public $oAuthOperatorMCC = null;
    public $oAuthOperatorName = null;
    
    /** oAuth Consumer Key & Secret [Developer Credentials] */
    public $oAuthConsumerKey = null; // Client ID
    public $oAuthConsumerSecret = null;  // Client secret
    
    /** Type of oAuth used by operator */
    public $oauth_type = null;
    
    /** oAuth Application settings [Application Details] */
    public $oAuthAppID = null;   //application ID
    public $oAuthAppProductKey = null;  // Item ID
    public $oAuthAppUserName = null;
    
    /** User Application Callback */
    public $app_callback = null;
    
    /** WAC product query URL */
    public $wacURLQueryProduct = null;
    
    /**	WAC Product Information */
    public $no_of_products = null;
    public $product_items = null;
    public $wacProductCurrency = null;
    public $wacProductPrice = null;
    public $wacProductDescription = null;
    public $wacProductBillingReceipt = null;
    
    /**	WAC URLs for OAuth 1 flow */
    public $oAuthURLRequestToken = null;
    public $oAuthURLAuthorizeToken = null;
    public $oAuthURLAccessToken = null;
    
    /** WAC URLs for OAuth 2 flow */
    public $oAuth2URLAuthorize = null;
    public $oAuth2URLAccessToken = null;
    
    /**	WAC Payment URLs */
    public $wacURLChargePayment = null;
    public $wacURLCheckTransaction = null;
    public $wacURLListTransactions = null;
    
    public $oauth_token=null;
    public $oauth_verifier=null;
    public $code=null;
    public $responseJSONForDot1 = null;
    
    public $oauth = null;
    public $token = null;	
}

?>
