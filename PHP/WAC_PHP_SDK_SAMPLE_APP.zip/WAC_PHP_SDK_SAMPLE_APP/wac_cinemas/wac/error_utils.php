<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

require_once 'i18n_utils.php';

/**
 * Implements Error Utilities
 */
class ErrorUtils
{	
	/** Tag to print in Logs */
	public static $tag="[WAC] ";
	
	function ErrorUtils()
	{
		$this->i18nfunc = new I18nUtils();
	}
	
	/*
	 * Check for response errors in the JSON
	 * @param json JSON Response JSON data 
	 */
	function checkForResponseErrors($json)
	{
		$resp = substr($json,0,17);
		$flag_error = strpos($resp,'error');
		$flag_request_error = strpos($resp,'requestError');
		if($flag_error)
		{
			$res = $this->handle_json($json);
			$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG");
			if(isset($res["error_description"])){
				$error = $error." ".$this->i18nfunc->getServerMessageForLocale($res["error_description"]);
			}else if(isset($res["error"])){
				$error = $error." ".$res["error"];
			}
			self::handle_error(self::$tag, $error, $json);
		}else if($flag_request_error){
			$res = $this->handle_json($json);
			$error = $this->i18nfunc->getSDKMessageForLocale("REQUEST_ERROR_TAG");
			if(isset($res["requestError"]["serviceException"]["text"])){
				$error = $error." ".$res["requestError"]["serviceException"]["text"];
			}
			if(isset($res["requestError"]["serviceException"]["variables"])){
				$error = $error." "."<br /> variables : ".$res["requestError"]["serviceException"]["variables"];
			}
			self::handle_error(self::$tag, $error, $json);
		}
	}
	
	/*
	 * * Check for response errors from server as a GET param
	*/
	public function checkForServerResponseErrors(){
		if(isset($_GET["error"]) && $_GET['error'] != "unrecognized_operator"){
			if(isset($_GET["error_description"])){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG")." ".$this->i18nfunc->getServerMessageForLocale($_GET["error_description"]);
			}else{
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG")." ".$_GET["error"];
			}
			self::handle_error(self::$tag, $error);
		}
	}
	
	/** Log in to the Apache Log
	 * 
	* @param json JSON Response JSON data
	*/
	public static function error_logger($tag, $error, $json=" "){
		$logValue = $tag.$error."  ".$json;
		error_log($logValue, 0);
	}
	
	/** Print error on Screen and Put it onto the logs
	*
	* @param json JSON Response JSON data
	*/
	public static function handle_error($tag, $error, $json=" "){
		echo $error;
		self::error_logger($tag, $error, $json);
		exit();
	}
	
	function handle_json($json){
		
			$comment = false;
			$out = '$x=';
	
			for ($i=0; $i<strlen($json); $i++)
			{
			if (!$comment)
			{
			if (($json[$i] == '{') || ($json[$i] == '['))
			$out.= ' array(';
						else if	 (($json[$i] == '}') || ($json[$i] == ']'))
						$out .= ')';
			else if ($json[$i] == ':')
			$out .= '=>';
			else
						$out .= $json[$i];
			}
			else
			$out .= $json[$i];
			if ($json[$i] == '"' && $json[($i-1)]!="\\")
			$comment = !$comment;
			}
			eval($out . ';');
			return $x;
	}
}
?>
