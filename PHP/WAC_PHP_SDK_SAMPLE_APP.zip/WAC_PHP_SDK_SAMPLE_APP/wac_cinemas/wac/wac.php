<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

require_once 'payment_service.php';
require_once 'token_utils.php';
require_once 'constants_class.php';
require_once 'endpoints.php';
require_once 'ReservedTransaction.php';
require_once 'i18n_utils.php';
require_once 'payment_obj.php';
require_once 'database_utils.php';
require_once 'aes_utils.php';

/**
 * Implementation of the WacPaymentService that implements PaymentService
 */
class WacPaymentService extends Constants implements PaymentService{

	/**
	 * Constructor for WacPaymentService to initialize the utility classes
	 */
	function WacPaymentService(){
		$this->httpfunc  = new HTTPUtils();
		$this->tokenfunc = new TokenUtils();
		$this->utilsfunc = new Utils();
		$this->endpointsfunc = new EndPoints();
		$this->i18nfunc = new I18nUtils();
		$this->products = null;
		$this->databasefunc = new databaseUtils();
		$this->aesfunc = new AES_Utils();
		$this->errorUtil = new ErrorUtils();
	}

	/**
	 * Initializes the objects required to process the payment (applicationID, secret, developerID, redirectURI and product information). This data is obtained when the application is registered with WAC.
	 *
	 * @param string Type of Environment URL
	 * @param string Developer ID/Consumer Key given by WAC
	 * @param string Developer Secret
	 * @param string Identifier for a given Application
	 * @param string Username of the developer registered with WAC
	 * @param string Callback URI for the application
	 */
	function initService($urlType, $consumerKey, $consumerSecret, $appID, $appUserName, $redirectURI){
		// Environment URL passed by developer
		$this->urlType = $urlType;
		
		$this->utilsfunc->checkFunctionExists();
			
		// Fetch the GET parameter values from callback
		$this->getParameterValues();
			
		// Set the wacSDKVersion, Default set to dot2
		$this->wacSDKVersion = "dot2";

		// WAC oAuthConsumer Key
		$this->oAuthConsumerKey = $consumerKey;

		// WAC oAuthConsumer Secret
		$this->oAuthConsumerSecret = $consumerSecret;

		// Application id.
		$this->oAuthAppID = $appID;

		// Item id of the product.
		$this->oAuthAppProductKey = null;

		// Application Developer username
		$this->oAuthAppUserName   = $appUserName;
		
		$this->errorUtil->checkForServerResponseErrors();
		
		$this->i18nfunc->setPropertiesURL($this->endpointsfunc->getPropertiesFileURL($urlType));

		@session_start();
		if(isset($_SESSION["locale"])){
			$this->i18nfunc->setLocale($_SESSION["locale"]);
		}else{
			$this->setUserLocale("");
		}
		
		$this->databasefunc->openDb("napi.db");
		if(!$this->databasefunc->sqlite_table_exists()){
			$this->databasefunc->createTable();
		}

		// Fetch Endpoint URLs
		$this->wacURLDiscoverOperator = $this->endpointsfunc->setBaseURL($urlType);

		// To check for Unrecognized operator error and get MNC and MCC for 0.1 operator
		$this->checkIsValidOperator();

		// Create a oAuth Consumer
		$this->wacConsumer($redirectURI);
		
		// Do a Operator Discovery
		return $this->wacDiscoverOperator();
	}

	/**
	 * Fetch token values from HTTP GET params after callback
	 */
	private function getParameterValues(){
		if(isset($_GET['oauth_verifier']))
		{
			$this->oauth_token = $_GET['oauth_token'];
			$this->oauth_verifier = $_GET['oauth_verifier'];
		}
			
		if(isset($_GET['code']))
		{
			$this->code = $_GET['code'];
		}
	}

	/**
	 * Check for unrecognized operator error in callback, and fetch MNC and MCC for operaotr
	 */
	private function checkIsValidOperator(){
		if(isset($_GET["error"])){
			if($_GET['error'] == "unrecognized_operator"){
				$error = "Error : Unrecognized Operator, MNC : ".$_GET['x-mnc'].", MCC :". $_GET['x-mcc'];
				ErrorUtils::error_logger(ErrorUtils::$tag, $error);
				$this->oAuthOperatorMNC = $_GET['x-mnc'];
				$this->oAuthOperatorMCC = $_GET['x-mcc'];
				@session_start();
				$_SESSION["x-mnc"] = $this->oAuthOperatorMNC;
				$_SESSION["x-mcc"] = $this->oAuthOperatorMCC;
				$_SESSION["wacSDKVersion"] = "dot1";
				$this->wacSDKVersion = "dot1";
			}
		}else{
			
			@session_start();
			if(isset($_SESSION["wacSDKVersion"])){
					$this->oAuthOperatorMNC = $_SESSION["x-mnc"];
					$this->oAuthOperatorMCC = $_SESSION["x-mcc"];
					$this->wacSDKVersion = $_SESSION["wacSDKVersion"];
			}else{
				$_SESSION["wacSDKVersion"] = "dot2";
				$_SESSION["x-mnc"] = "nnn";
				$_SESSION["x-mcc"] = "nnn";
			}
		}
	}

	/**
	 * Does a Operator Discovery using WAC Discovery NAPI for Dot1.
	 */
	private function wacDiscoverOperator()
	{
		// Check for valid MNC and MCC
		if(isset($this->code) || isset($this->oauth_token)){
			@session_start();
			if(isset($_SESSION["x-mnc"]) && isset($_SESSION["x-mcc"])){
				$this->oAuthOperatorMNC = $_SESSION["x-mnc"];
				$this->oAuthOperatorMCC = $_SESSION["x-mcc"];
			}
			$this->wacSDKVersion = $_SESSION["wacSDKVersion"];
		}
			
		if($this->wacSDKVersion == "dot1")
		{
			// prepare url for discovery of operator
			$url = $this->wacURLDiscoverOperator;
			$url = str_replace("{application-id}", $this->oAuthAppID, $url);
			// prepare header parameters
			$headerParameters = array(
                "Content-Type: $this->oAuthContentType",
                "x-mnc: $this->oAuthOperatorMNC",
                "x-mcc: $this->oAuthOperatorMCC"
			);

			// get HTTP request
			$jsonResponse = $this->httpfunc->httpRequest($url, "", "", $headerParameters);

			//	json decode to array
			$arrResponse = $this->utilsfunc->decode_json($jsonResponse);
			$this->utilsfunc->isValidJSON($arrResponse);

			if(!isset($this->oAuthOperatorMNC) || !isset($this->oAuthOperatorMCC) || $this->oAuthOperatorMNC=="" || $this->oAuthOperatorMCC=="")
			{
				return $arrResponse;
			}
			//	get settings
			$settings         = $arrResponse["response"]["operator"];
			$this->oauth_type = $settings["apis"]["authorization"]["type"];
			// Get Query URI
			$this->wacURLQueryProduct = $settings["apis"]["query"]["uri"];
			// Get Charge Payment URI
			$this->wacURLChargePayment    = $settings["apis"]["payment"]["uri"];
			// Get Charge CheckTransaction URI
			$this->wacURLCheckTransaction = $settings["apis"]["payment"]["uri"] . "/{transaction-id}";
			// Get Charge ListTransactions URI
			$this->wacURLListTransactions = $settings["apis"]["payment"]["uri"];

			if ($this->oauth_type == "oauth10a") {
				$this->oAuthURLRequestToken   = $settings["apis"]["authorization"]["uris"]["requestToken"];
				// Get Authorize URI
				$this->oAuthURLAuthorizeToken = $settings["apis"]["authorization"]["uris"]["authorize"];
				$this->oAuthURLAuthorizeToken = trim($this->oAuthURLAuthorizeToken);
				// Get Access Token URI
				$this->oAuthURLAccessToken    = $settings["apis"]["authorization"]["uris"]["accessToken"];
			} else {
				$this->oAuth2URLAuthorize   = $settings["apis"]["authorization"]["uris"]["authorize"];
				$this->oAuth2URLAccessToken = $settings["apis"]["authorization"]["uris"]["accessToken"];
			}

			//	check for correct format
			if (substr($this->wacURLChargePayment, -1) == "/") {
				$this->wacURLChargePayment = substr($this->wacURLChargePayment, 0, -1);
			}

			if (substr($this->wacURLListTransactions, -1) == "/") {
				$this->wacURLListTransactions = substr($this->wacURLListTransactions, 0, -1);
			}
		}else
		{
			$this->oAuth2URLAuthorize = $this->endpointsfunc->getdot2AuthorizeURL($this->urlType);
			$this->oAuth2URLAccessToken = $this->endpointsfunc->getdot2AccessTokenURL($this->urlType);
			$this->wacURLChargePayment = $this->endpointsfunc->getdot2PaymentURL($this->urlType);
		}
		$this->wacURLQueryProduct = $this->endpointsfunc->getdot2queryURL($this->urlType);
		// Get Details of a particular product
		$this->loadProductSetting();
	}

	/**
	 * Does a Query for Products using WAC Query NAPI. 
	 */
	private function loadProductSetting()
	{
		@session_start();
		if(!isset($_SESSION[$this->oAuthAppID])){
			$jsonResponse = $this->queryForProducts();
			$item = $this->utilsfunc->decode_json($jsonResponse);
			$this->utilsfunc->isValidJSON($item);
			$this->product_items = $item["response"]["product"]["items"];
			@session_start();
			$_SESSION[$this->oAuthAppID] = $this->product_items;
		}else{
			@session_start();
			$this->product_items = $_SESSION[$this->oAuthAppID];
		}
	}
	
	/**
	 * Query from server if not available in session
	 * @return array
	 */
	private function queryForProducts(){
		// prepare url for Query
		$url = $this->wacURLQueryProduct;
		$url = $url . "/" . $this->oAuthAppID;
		// Prepare get parameters
		$currentTimeStamp = time() * 1000;
		$hashHMACdata = $this->oAuthAppUserName . $this->oAuthAppID . $currentTimeStamp;
		$hashHMACkey  = $this->oAuthConsumerSecret;
		
		// Hash and Encode $hashHMACdata and $hashHMACkey
		if(function_exists("hash_hmac"))
		{
			$authorization = base64_encode(hash_hmac('sha256', $hashHMACdata, $hashHMACkey, true));
		}
		else
		{
			$authorization = base64_encode(mhash(MHASH_SHA256, $hashHMACdata, $hashHMACkey));
		}
		// Convert String to Hex
		$authorization = $this->httpfunc->strToHex($authorization);
		// Prepare URL
		$getParams = "client_id={client_id}&timestamp={timestamp}";
		$getParams = str_replace("{client_id}", $this->oAuthConsumerKey, $getParams);
		$getParams = str_replace("{timestamp}", $currentTimeStamp, $getParams);
		//	prepare header parameters
		$headerParameters = $this->httpfunc->prepareOAuthParameterForHeader($this->oAuthContentType, $this->oAuthOperatorMNC, $this->oAuthOperatorMCC, $authorization, false,$this->oAuthAccept,"dot2",true);
		//	get HTTP request
		$jsonResponse = $this->httpfunc->httpRequest($url, $getParams, "", $headerParameters);
		return $jsonResponse;
	}

	/**
	 * Returns the List Products for an Application. This can be used to fetch the list of products and their details available for the application.
	 * @return array
	 */
	public function listProductItems()
	{
		return $this->product_items;
	}
	
	/**
	* Sets the product details in a global variable.
	* @param string Product ID of the Item to be billed
	*/
	private function setProductDetails($appProductKey)
	{
		$this->oAuthAppProductKey = $appProductKey;
		$no_of_products    = count($this->product_items);
		for ($i = 0; $i < $no_of_products; $i++) {
			if($this->product_items[$i]["item-id"] == $this->oAuthAppProductKey){
				$temp = $i;
				break;
			}
		}
		if (isset($this->oAuthAppProductKey) && isset($temp)) {
			$this->products = new Products($this->product_items[$temp]["item-id"], $this->product_items[$temp]["currency"], $this->product_items[$temp]["price"], $this->product_items[$temp]["description"], $this->product_items[$temp]["billing-receipt"]);
		}
	}
	
	/**
	* Sets the locale for a user. This is used by SDK to display the messages in users locale.
	* @param string Locale chosen for a given user.
	*/
	public function setUserLocale($locale){
		if(isset($locale) && $locale!="" && $locale!=null){
			@session_start();
			$_SESSION["locale"] = $locale;
		}
		if(isset($locale)){
			$this->i18nfunc->setLocale($locale);
		}
	}
	
	/**
	* Sets the spoofed IP. This is an helper function provided to facilitate the developer for spoofing the IP address for testing the provisioned product details and prices for different countires.
	* @param string IP to be used to spoof server
	*/
	public function setSpoofedIP($ip){
		if(isset($ip) && $ip!="" && $ip!=null){
			@session_start();
			$_SESSION["spoofedIP"] = $ip;
		}
	}
	
	/**
	* Enable/Disable debug Logging for CURL.
	* @param boolean To enable logging, True otherwise False.
	*/
	public function debugLog($log){
		if(isset($log) && $log!="" && $log!=null){
			@session_start();
			$_SESSION["debugLog"] = $log;
		}
	}
	
	/**
	* Returns true if WAC billing is available else returns false
	* @return boolean True if wac billing is available
	*/

	public function checkBillingAvailability($environment, $consumerKey, $consumerSecret, $appID, $appUserName){

		$this->urlType = $environment;
		$this->oAuthConsumerKey = $consumerKey;
		$this->oAuthConsumerSecret = $consumerSecret;
		$this->oAuthAppID = $appID;
		$this->oAuthAppUserName   = $appUserName;
		
		$this->wacURLQueryProduct = $this->endpointsfunc->getdot2queryURL($this->urlType);
		
		$jsonResponse = $this->queryForProducts();
		if(!preg_match('~^({ ( (?>[^{}]+) | (?1) )* })$~x',$jsonResponse))
		{
			return false;
		}
		$item = $this->utilsfunc->errorfunc->handle_json($jsonResponse);
		
		if(isset($item["code"]) && $item["code"]=="ok")
		{
			return true;		
		}
		
		return false;
		
	}
	
	/**
	* Get Product Details for a given Product ID.
	* @param string Product ID of the item to be billed
	* @return Products Product Object with details of a given Item
	*/
	public function getProductDetails($appProductKey){
		$no_of_products    = count($this->product_items);
		for ($i = 0; $i < $no_of_products; $i++) {
			if($this->product_items[$i]["item-id"] == $appProductKey){
				$temp = $i;
				break;
			}
		}
		if (isset($appProductKey) && isset($temp)) {
			return new Products($this->product_items[$temp]["item-id"], $this->product_items[$temp]["currency"], $this->product_items[$temp]["price"], $this->product_items[$temp]["description"], $this->product_items[$temp]["billing-receipt"]);
		}
	}

	/**
	 * Initializes the charge payment process and starts the authorization flow.
	 * @param string Product ID of the item to be billed
	 */
	public function initChargePayment($appProductKey)
	{
		$this->setProductDetails($appProductKey);
		if($this->wacSDKVersion == "dot1"){
			if ($this->oauth_type == "oauth10a") {
				// Get request token from $this->getRequestToken()
				$oauth_token = $this->tokenfunc->getRequestToken('PAY', $this);

				// If Request Token Not Received
				if (!$oauth_token) {
					$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("REQUEST_TOKEN_ERROR");
					ErrorUtils::handle_error(ErrorUtils::$tag, $error);
				} else {
					// OAuth 1 Authorization Redirection
					$this->tokenfunc->authorize_header($this, $oauth_token);
				}
			} else {
				// OAuth 2 Authorization Redirection
				$this->oAuthScopePay = str_replace("{item-id}", $this->products->getProductKey(), $this->oAuthScopePay);
				header("location: " . $this->oAuth2URLAuthorize . "?scope=" . urlencode($this->oAuthScopePay) . "&response_type=code&client_id=" . $this->oAuthConsumerKey . "&x-mnc=" . $this->oAuthOperatorMNC . "&x-mcc=" . $this->oAuthOperatorMCC . "&redirect_uri=" . urlencode($this->app_callback));
			}
		}else{
			$this->oAuthdot2ScopePay = str_replace("{item-id}", $this->products->getProductKey(), $this->oAuthdot2ScopePay);
			header("location: " . $this->oAuth2URLAuthorize . "?scope=" . urlencode($this->oAuthdot2ScopePay) . "&response_type=code&client_id=" . $this->oAuthConsumerKey . "&redirect_uri=" . urlencode($this->app_callback));
		}
	}

	/**
	 * Initializes the Check Transactions process and starts the authorization flow.
	 * @param string Transaction ID
	 */
	public function initCheckTransactions($ref_code)
	{
		if(!isset($ref_code) || $ref_code==NULL || $ref_code=="" || strlen($ref_code)>250){
			echo $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("INVALID_TRANSACTION_ID");
			exit();
		}
			
		if($this->wacSDKVersion == "dot1"){
			if ($this->oauth_type == "oauth10a") {
				// Get request token from $this->getRequestToken()
				$oauth_token = $this->tokenfunc->getRequestToken('CHECK', $this);

				// If Request Token Not Received
				if (!$oauth_token) {
					$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("REQUEST_TOKEN_ERROR");
					ErrorUtils::handle_error(ErrorUtils::$tag, $error);
				} else {
					// OAuth 1 Authorization Redirection
					$this->tokenfunc->authorize_header($this, $oauth_token);
				}
			} else {
				// OAuth 2 Authorization Redirection
				header("location: " . $this->oAuth2URLAuthorize . "?scope=" . urlencode($this->oAuthScopeCheck) . "&response_type=code&client_id=" . $this->oAuthConsumerKey . "&x-mnc=" . $this->oAuthOperatorMNC . "&x-mcc=" . $this->oAuthOperatorMCC . "&redirect_uri=" . urlencode($this->app_callback));
			}
		}else{
			header("location: $this->app_callback");
		}
	}

	/**
	 * Initializes the List Transactions process and starts the authorization flow.
	 *
	 */
	public function initListTransactions()
	{
		if($this->wacSDKVersion == "dot1"){
			if ($this->oauth_type == "oauth10a") {
				// Get request token from $this->getRequestToken()
				$oauth_token = $this->tokenfunc->getRequestToken('LIST', $this);
				// If Request Token Not Received
				if (!$oauth_token) {
					$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("REQUEST_TOKEN_ERROR");
					ErrorUtils::handle_error(ErrorUtils::$tag, $error);
				} else {
					// OAuth 1 Authorization Redirection
					$this->tokenfunc->authorize_header($this, $oauth_token);
				}
			} else {
				// OAuth 2 Authorization Redirection
				header("location: " . $this->oAuth2URLAuthorize . "?scope=" . urlencode($this->oAuthScopeList) . "&response_type=code&client_id=" . $this->oAuthConsumerKey . "&x-mnc=" . $this->oAuthOperatorMNC . "&x-mcc=" . $this->oAuthOperatorMCC . "&redirect_uri=" . urlencode($this->app_callback));
			}
		}else{
			header("location: $this->app_callback");
		}
	}
	
	/**
	* Charge Payment with content delivery callback.
	*
	* @param string Product ID of the item to be billed
	* @param string callback content delivery callback
	* @param string To store transactions for a given user
	* @deprecated deprecated since version 1.0.1
	*/
	public function chargePayment($appProductKey, $callback, $userID)
	{
		$this->setProductDetails($appProductKey);
		if(isset($callback) && !$callback){
			$error = $this->i18nfunc->getSDKMessageForLocale("CONTENT_DELIVERY_CALLBACK_ERROR");;
			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
		}
			
		// Check for valid MNC and MCC
		if(isset($this->code) || isset($this->oauth_token)){
			@session_start();
			if(isset($_SESSION["x-mnc"]) && isset($_SESSION["x-mcc"])){
				$this->oAuthOperatorMNC = $_SESSION["x-mnc"];
				$this->oAuthOperatorMCC = $_SESSION["x-mcc"];
			}
			$this->wacSDKVersion = $_SESSION["wacSDKVersion"];
		}else{
			$this->initChargePayment($appProductKey);
			exit();
		}
			
		if (isset($this->oauth_verifier)) {
			// Get Access Token
			$access_token = $this->tokenfunc->getAccessToken($this->oauth_token, $this->oauth_verifier, $this);
			if (!$access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("ACCESS_TOKEN_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
		} else {
			$access_token = $this->tokenfunc->getAuth2AccessToken($this->code, $this);
			if (!$access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("ACCESS_TOKEN_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
		}

		if (isset($this->oauth_verifier)) {
			$url = $this->wacURLChargePayment;
			$token = $access_token;
			if (!$token) {
				return false;
			}
			//	create oAuthConsumer Object with Access Token value and secret as parameters
			$this->token = new OAuthConsumer($token->value, $token->secret);
			//	prepare data
			$currentTimeStamp = time() * 1000;
			$referenceCode    = md5($this->products->getProductKey() . $currentTimeStamp);
			$desc = str_replace("+", "%20", urlencode($this->products->getProductDescription()));
			//	prepare post params
			$postParameters =
			"endUserId=" . urlencode("acr:Authorization")
			. "&" . "referenceCode=" . urlencode($referenceCode)
			. "&" . "transactionOperationStatus=" . urlencode("Charged")
			. "&" . "description=" . $desc
			. "&" . "code=" . urlencode($this->products->getProductKey());
			$mt = microtime();
			$rand = mt_rand();
			$nonce = md5($mt . $rand); // md5s look nicer than numbers
			//	add oauth_verifier into parameter
			$params = array();
			$params["code"]                       = $this->products->getProductKey();
			$params["description"]                = $desc;
			$params["endUserId"]                  = urlencode("acr:Authorization");
			$params["oauth_consumer_key"] = $this->oAuthConsumerKey;
			$params["oauth_nonce"] = $nonce;
			$params["oauth_signature_method"] = "HMAC-SHA1";
			$params["oauth_timestamp"] = $currentTimeStamp;
			$params["oauth_token"] = $this->token->key;
			$params["oauth_verifier"] = $this->oauth_verifier;
			$params["oauth_version"] = "1.0";
			$params["referenceCode"] = $referenceCode;
			$params["transactionOperationStatus"] = "Charged";
			$signatureBaseString1 = "POST&".urlencode($url)."&";
			$sigBase = "";
			foreach ($params as $index => $value) {
				$sigBase = $sigBase.$index."=".$value."&";
			}
			$encStr = $this->utilsfunc->oEncode($sigBase);
			$encStr = trim($encStr,"%26");
			$sigBaseParameters = $signatureBaseString1.$encStr;

			$keyString = urlencode($this->oAuthConsumerSecret)."&".urlencode($this->token->secret);

			$oAuthAuthorization = "";
			if(function_exists("hash_hmac"))
			{
				$oAuthAuthorization = base64_encode(hash_hmac('sha1', $sigBaseParameters, $keyString, true));
			}
			else
			{
				$oAuthAuthorization = base64_encode(mhash(MHASH_SHA1, $sigBaseParameters, $keyString));
			}
			$oAuthAuthorization = urlencode($oAuthAuthorization);

			//	prepare oAuth authorization parameters
			$oAuthHeaderParams = array();
			$oAuthHeaderParams["oauth_consumer_key"] = $this->oAuthConsumerKey;
			$oAuthHeaderParams["oauth_nonce"] = urlencode($nonce);
			$oAuthHeaderParams["oauth_signature"] = $oAuthAuthorization;
			$oAuthHeaderParams["oauth_signature_method"] = "HMAC-SHA1";
			$oAuthHeaderParams["oauth_timestamp"] = $currentTimeStamp;
			$oAuthHeaderParams["oauth_token"] = $this->token->key;
			$oAuthHeaderParams["oauth_verifier"] = $this->oauth_verifier;
			$oAuthHeaderParams["oauth_version"] = "1.0";

			$oauthHeader = "";
			foreach ($oAuthHeaderParams as $index => $value) {
				$oauthHeader = $oauthHeader."$index=\"$value\",";
			}
			$oauthHeader = trim($oauthHeader,',');

			$headerParameters = $this->httpfunc->prepareOAuthParameterForHeader(
			$this->oAuthContentType,
			$this->oAuthOperatorMNC,
			$this->oAuthOperatorMNC,
			$oauthHeader,
			true,
			false,
			"dot1",
			false
			);

			$response = $this->httpfunc->httpRequest($url, "", $postParameters, $headerParameters, "POST", 30, true);
			$this->responseJSONForDot1 = $response;
			$response = $this->utilsfunc->decode_json($response);
			return $response;
		} else {
			// Fetch Payment data for OAuth 2
			$res = $this->chargePaymentForOAuth2($this, $access_token, $userID);
			return $res;
		}
	}

	/**
	 * Reserves the Payment. The payment is held until the capturePayment is made. This gives the option to pause the payment until the content is delivered to the user.
	 * @param string Product ID of the item to be billed
	 * @return ReservedTransaction Holds data related to reserve/capture payment
	 */
	public function reservePayment($appProductKey)
	{
		$this->setProductDetails($appProductKey);
		// Check for valid MNC and MCC
		if(isset($this->code) || isset($this->oauth_token)){
			@session_start();
			if(isset($_SESSION["x-mnc"]) && isset($_SESSION["x-mcc"])){
				$this->oAuthOperatorMNC = $_SESSION["x-mnc"];
				$this->oAuthOperatorMCC = $_SESSION["x-mcc"];
			}
			$this->wacSDKVersion = $_SESSION["wacSDKVersion"];
		}else{
			$this->initChargePayment($appProductKey);
			exit();
		}
			
		if (isset($this->oauth_verifier)) {
			// Get Access Token
			$access_token = $this->tokenfunc->getAccessToken($this->oauth_token, $this->oauth_verifier, $this);
			if (!$access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("RESERVE_PAYMENT_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
		} else {
			$access_token = $this->tokenfunc->getAuth2AccessToken($this->code, $this);
			if (!$access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("RESERVE_PAYMENT_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
		}
		$reserved = new ReservedTransaction();
		$reserved = $reserved->setReservedData($this, $access_token);
		return $reserved;
	}
	
	/**
	* Capture Payment after reserving a transaction by passing the serialized reserved transaction object. This makes the actual payment.
	*
	* @param string Serialized string to capture a payment.
	* @param string UserID to store transactions for a given user
	* @return array
	*/
	public function capturePayment($reserved,$userID)
	{
		$reservedData = new ReservedTransaction();
		$reserved = $reservedData->getReservedData($reserved);
		$consumer = $reserved->consumer;
		$access_token = $reserved->accessToken;
		if (isset($consumer->oauth_verifier)) {
			$url = $consumer->wacURLChargePayment;
			$token = $access_token;
			if (!$token) {
				return false;
			}
			//	create oAuthConsumer Object with Access Token value and secret as parameters
			$consumer->token = new OAuthConsumer($token->value, $token->secret);
			//	prepare data
			$currentTimeStamp = time() * 1000;
			$referenceCode    = md5($consumer->products->getProductKey() . $currentTimeStamp);
			$desc = str_replace("+", "%20", urlencode($consumer->products->getProductDescription()));
			//	prepare post params
			$postParameters =
	    		"endUserId=" . urlencode("acr:Authorization")
			. "&" . "referenceCode=" . urlencode($referenceCode)
			. "&" . "transactionOperationStatus=" . urlencode("Charged")
			. "&" . "description=" . $desc
			. "&" . "code=" . urlencode($consumer->products->getProductKey());
			$mt = microtime();
			$rand = mt_rand();
			$nonce = md5($mt . $rand); // md5s look nicer than numbers
			//	add oauth_verifier into parameter
			$params = array();
			$params["code"]                       = $consumer->products->getProductKey();
			$params["description"]                = $desc;
			$params["endUserId"]                  = urlencode("acr:Authorization");
			$params["oauth_consumer_key"] = $consumer->oAuthConsumerKey;
			$params["oauth_nonce"] = $nonce;
			$params["oauth_signature_method"] = "HMAC-SHA1";
			$params["oauth_timestamp"] = $currentTimeStamp;
			$params["oauth_token"] = $consumer->token->key;
			$params["oauth_verifier"] = $consumer->oauth_verifier;
			$params["oauth_version"] = "1.0";
			$params["referenceCode"] = $referenceCode;
			$params["transactionOperationStatus"] = "Charged";
			$signatureBaseString1 = "POST&".urlencode($url)."&";
			$sigBase = "";
			foreach ($params as $index => $value) {
				$sigBase = $sigBase.$index."=".$value."&";
			}
			$encStr = $this->utilsfunc->oEncode($sigBase);
			$encStr = trim($encStr,"%26");
			$sigBaseParameters = $signatureBaseString1.$encStr;
	
			$keyString = urlencode($consumer->oAuthConsumerSecret)."&".urlencode($consumer->token->secret);
	
			$oAuthAuthorization = "";
			if(function_exists("hash_hmac"))
			{
				$oAuthAuthorization = base64_encode(hash_hmac('sha1', $sigBaseParameters, $keyString, true));
			}
			else
			{
				$oAuthAuthorization = base64_encode(mhash(MHASH_SHA1, $sigBaseParameters, $keyString));
			}
			$oAuthAuthorization = urlencode($oAuthAuthorization);
	
			//	prepare oAuth authorization parameters
			$oAuthHeaderParams = array();
			$oAuthHeaderParams["oauth_consumer_key"] = $consumer->oAuthConsumerKey;
			$oAuthHeaderParams["oauth_nonce"] = urlencode($nonce);
			$oAuthHeaderParams["oauth_signature"] = $oAuthAuthorization;
			$oAuthHeaderParams["oauth_signature_method"] = "HMAC-SHA1";
			$oAuthHeaderParams["oauth_timestamp"] = $currentTimeStamp;
			$oAuthHeaderParams["oauth_token"] = $consumer->token->key;
			$oAuthHeaderParams["oauth_verifier"] = $consumer->oauth_verifier;
			$oAuthHeaderParams["oauth_version"] = "1.0";
	
			$oauthHeader = "";
			foreach ($oAuthHeaderParams as $index => $value) {
				$oauthHeader = $oauthHeader."$index=\"$value\",";
			}
			$oauthHeader = trim($oauthHeader,',');
	
			$headerParameters = $this->httpfunc->prepareOAuthParameterForHeader(
			$consumer->oAuthContentType,
			$consumer->oAuthOperatorMNC,
			$consumer->oAuthOperatorMNC,
			$oauthHeader,
			true,
			false,
	    		"dot1",
			false
			);
	
			$response = $this->httpfunc->httpRequest($url, "", $postParameters, $headerParameters, "POST", 30, true);
			$this->responseJSONForDot1 = $response;
			$response = $this->utilsfunc->decode_json($response);
			return $response;
		} else {
			// Fetch Payment data for OAuth 2
			$res = $this->chargePaymentForOAuth2($consumer, $access_token, $userID);
			return $res;
		}
	}
	
	/**
	 * Loads a payment success page with Transaction ID for dot1 payment
	 * @param string URL to be redirected to after success page is displayed
	 */
	public function showPaymentSuccessPage($callback){
		$responseJSON = $this->responseJSONForDot1;
		if($this->wacSDKVersion == "dot1"){
			$url = $this->SuccessPage;
			// Prepare get parameters
			$currentTimeStamp = time() * 1000;
			$hashHMACdata = $this->oAuthAppProductKey . $currentTimeStamp.$responseJSON;
			$hashHMACkey  = $this->oAuthAppProductKey;
			
			// Hash and Encode $hashHMACdata and $hashHMACkey
			if(function_exists("hash_hmac"))
			{
				$authorization = base64_encode(hash_hmac('sha256', $hashHMACdata, $hashHMACkey, true));
			}
			else
			{
				$authorization = base64_encode(mhash(MHASH_SHA256, $hashHMACdata, $hashHMACkey));
			}
			// Convert String to Hex
			$authorization = $this->httpfunc->strToHex($authorization);
			$responseVal = base64_encode($responseJSON);
			// Prepare URL
			$getParams = "amountTransactionJson=$responseVal&timeStamp=$currentTimeStamp&operatorMcc=$this->oAuthOperatorMCC&operatorMnc=$this->oAuthOperatorMNC&redirectUrl=$callback";
			//	prepare header parameters
			$header = array();
			$header[] = "Accept: $this->oAuthAccept";
			$header[] = "Content-Type: $this->oAuthContentType";
			$header[] = "Authorization: $authorization";
			//	get HTTP request
			$jsonResponse = $this->httpfunc->httpRequest($url, $getParams, "", $header);
			ob_end_clean();
			print_r($jsonResponse);exit();
		}else{
			return true;
		}
	}

	/**
	 * Check Transactions for a given Transaction ID after callback. Gets the access token to make a server call to verify the transaction.
	 *
	 * @param string Transaction ID
	 * @param string UserID to check transactions for a given user
	 * @return array
	 */
	public function checkTransactions($ref_code, $userID)
	{
		// Check for valid MNC and MCC
		if(isset($this->code) || isset($this->oauth_token)){
			@session_start();
			if(isset($_SESSION["x-mnc"]) && isset($_SESSION["x-mcc"])){
				$this->oAuthOperatorMNC = $_SESSION["x-mnc"];
				$this->oAuthOperatorMCC = $_SESSION["x-mcc"];
			}
			$this->wacSDKVersion = $_SESSION["wacSDKVersion"];
		}else if ($this->wacSDKVersion == "dot1"){
			$this->initCheckTransactions($ref_code);
			exit();
		}
			
		if (isset($this->oauth_verifier)) {
			// Get Access Token
			$access_token = $this->tokenfunc->getAccessToken($this->oauth_token, $this->oauth_verifier, $this);

			if (!$access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("ACCESS_TOKEN_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
			// Check Transaction
			$res = $this->checkTransactionForOAuth1($ref_code,$access_token);
			return $res;

		} else {
			// Fetch Check Transaction for OAuth 2
			$res = $this->checkTransactionForOAuth2($this->code,$ref_code, $userID);
			return $res;
		}
	}

	/**
	 * Process List Transactions after callback. Gets the access token to make a server call to fetch the transaction list
	 * 
	 * @param string userID to fetch transactions for a given user
	 * @return array
	 */
	public function listTransactions($userID)
	{
		// Check for valid MNC and MCC
		if(isset($this->code) || isset($this->oauth_token)){
			@session_start();
			if(isset($_SESSION["x-mnc"]) && isset($_SESSION["x-mcc"])){
				$this->oAuthOperatorMNC = $_SESSION["x-mnc"];
				$this->oAuthOperatorMCC = $_SESSION["x-mcc"];
			}
			$this->wacSDKVersion = $_SESSION["wacSDKVersion"];
		}else if ($this->wacSDKVersion == "dot1"){
			$this->initListTransactions();
			exit();
		}
			
		if (isset($this->oauth_verifier)) {
			//Get Access Token
			$access_token = $this->tokenfunc->getAccessToken($this->oauth_token, $this->oauth_verifier, $this);
			if (!$access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("ACCESS_TOKEN_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
			// Get List Transactions
			$res = $this->getListTransactionsForOAuth1($access_token);
			return $res;
		} else {
			// Fetch List Transactions for OAuth 2
			$res = $this->getListTransactionsForOAuth2($this->code, $userID);
			return $res;
		}
	}

	/**
	 * Performs Check Transaction for oAuth1. Verifes if the transaction with the given teansactionID is valid.
	 *
	 * @param string Transaction ID
	 * @param string Access Token used to check transaction after a authorized request
	 * @return array
	 */
	private function checkTransactionForOAuth1($transactionID = '',$access_token)
	{
		$url = $this->wacURLCheckTransaction;
		$url = str_replace("{transaction-id}", $transactionID, $url);
		$token = $access_token;
		if (!$token) {
			return false;
		}
		$this->token = new OAuthConsumer($token->value, $token->secret);
		$mt = microtime();
		$rand = mt_rand();
		$nonce = md5($mt . $rand);
		$currentTimeStamp = time() * 1000;
			
		$params = array();
		$params["oauth_consumer_key"] = $this->oAuthConsumerKey;
		$params["oauth_nonce"] = $nonce;
		$params["oauth_signature_method"] = "HMAC-SHA1";
		$params["oauth_timestamp"] = $currentTimeStamp;
		$params["oauth_token"] = $this->token->key;
		$params["oauth_verifier"] = $this->oauth_verifier;
		$params["oauth_version"] = "1.0";
			
		$signatureBaseString1 = "GET&".urlencode($url)."&";
		$sigBase = "";
		foreach ($params as $index => $value) {
			$sigBase = $sigBase.$index."=".$value."&";
		}
		$encStr = $this->utilsfunc->oEncode($sigBase);
		$encStr = trim($encStr,"%26");
		$sigBaseParameters = $signatureBaseString1.$encStr;
		$keyString = urlencode($this->oAuthConsumerSecret)."&".urlencode($this->token->secret);
		$oAuthAuthorization = "";
		if(function_exists("hash_hmac"))
		{
			$oAuthAuthorization = base64_encode(hash_hmac('sha1', $sigBaseParameters, $keyString, true));
		}
		else
		{
			$oAuthAuthorization = base64_encode(mhash(MHASH_SHA1, $sigBaseParameters, $keyString));
		}
		$oAuthAuthorization = urlencode($oAuthAuthorization);
		$oAuthHeaderParams = array();
		$oAuthHeaderParams["oauth_signature"] = $oAuthAuthorization;
		$oAuthHeaderParams["oauth_version"] = "1.0";
		$oAuthHeaderParams["oauth_nonce"] = urlencode($nonce);
		$oAuthHeaderParams["oauth_signature_method"] = "HMAC-SHA1";
		$oAuthHeaderParams["oauth_consumer_key"] = $this->oAuthConsumerKey;
		$oAuthHeaderParams["oauth_timestamp"] = $currentTimeStamp;
		$oAuthHeaderParams["oauth_token"] = $this->token->key;
		$oAuthHeaderParams["oauth_verifier"] = $this->oauth_verifier;
			
		$oauthHeader = "";
		foreach ($oAuthHeaderParams as $index => $value) {
			$oauthHeader = $oauthHeader."$index=\"$value\",";
		}
		$oauthHeader = trim($oauthHeader,',');

		$headerParameters = $this->httpfunc->prepareOAuthParameterForHeader(
		$this->oAuthContentType,
		$this->oAuthOperatorMNC,
		$this->oAuthOperatorMNC,
		$oauthHeader,
		true,
		false,
    	"dot1",
		false
		);
		$response = $this->httpfunc->httpRequest($url, "", "", $headerParameters, "GET", 30, true);
		$response = $this->utilsfunc->decode_json($response);
		return $response;
	}

	/**
	 * Performs List Transactions for oAuth 1. Fetches the liast of all transactions.
	 *
	 * @param string Access Token used to check transaction after a authorized request
	 * @return array
	 */
	private function getListTransactionsForOAuth1($access_token)
	{
		$url = $this->wacURLListTransactions;
		$token = $access_token;
		if (!$token) {
			return false;
		}
		$this->token = new OAuthConsumer($token->value, $token->secret);
		$mt = microtime();
		$rand = mt_rand();
		$nonce = md5($mt . $rand);
		$currentTimeStamp = time() * 1000;
			
		$params = array();
		$params["oauth_consumer_key"] = $this->oAuthConsumerKey;
		$params["oauth_nonce"] = $nonce;
		$params["oauth_signature_method"] = "HMAC-SHA1";
		$params["oauth_timestamp"] = $currentTimeStamp;
		$params["oauth_token"] = $this->token->key;
		$params["oauth_verifier"] = $this->oauth_verifier;
		$params["oauth_version"] = "1.0";
		$signatureBaseString1 = "GET&".urlencode($url)."&";
		$sigBase = "";
		foreach ($params as $index => $value) {
			$sigBase = $sigBase.$index."=".$value."&";
		}
		$encStr = $this->utilsfunc->oEncode($sigBase);
		$encStr = trim($encStr,"%26");
		$sigBaseParameters = $signatureBaseString1.$encStr;
		$keyString = urlencode($this->oAuthConsumerSecret)."&".urlencode($this->token->secret);
			
		$oAuthAuthorization = "";
		if(function_exists("hash_hmac"))
		{
			$oAuthAuthorization = base64_encode(hash_hmac('sha1', $sigBaseParameters, $keyString, true));
		}
		else
		{
			$oAuthAuthorization = base64_encode(mhash(MHASH_SHA1, $sigBaseParameters, $keyString));
		}
		$oAuthAuthorization = urlencode($oAuthAuthorization);
		$oAuthHeaderParams = array();
		$oAuthHeaderParams["oauth_signature"] = $oAuthAuthorization;
		$oAuthHeaderParams["oauth_version"] = "1.0";
		$oAuthHeaderParams["oauth_nonce"] = urlencode($nonce);
		$oAuthHeaderParams["oauth_signature_method"] = "HMAC-SHA1";
		$oAuthHeaderParams["oauth_consumer_key"] = $this->oAuthConsumerKey;
		$oAuthHeaderParams["oauth_timestamp"] = $currentTimeStamp;
		$oAuthHeaderParams["oauth_token"] = $this->token->key;
		$oAuthHeaderParams["oauth_verifier"] = $this->oauth_verifier;
		$oauthHeader = "";
		foreach ($oAuthHeaderParams as $index => $value) {
			$oauthHeader = $oauthHeader."$index=\"$value\",";
		}
		$oauthHeader = trim($oauthHeader,',');
			
		$headerParameters = $this->httpfunc->prepareOAuthParameterForHeader(
		$this->oAuthContentType,
		$this->oAuthOperatorMNC,
		$this->oAuthOperatorMNC,
		$oauthHeader,
		true,
		false,
    	    "dot1",
		false
		);
		$response = $this->httpfunc->httpRequest($url, "", "", $headerParameters, "GET", 45, true);
		$response = $this->utilsfunc->decode_json($response);
		return $response;
	}

	/**
	 * Performs Charge Payment for 0.2
	 *
	 * @param WacPaymentService An object of WacPaymentService initialized by developer
	 * @param string Access Token through which payment can be done for the reserved transaction
	 * @param string userID to charge for a given user
	 * @return array
	 */
	private function chargePaymentForOAuth2($consumer, $auth2_access_token, $userID)
	{
		if($consumer->wacSDKVersion == "dot1"){
			$headerArray = array();
			$headerArray[] = "Accept: application/json";
			$headerArray[] = "x-mnc: " . $consumer->oAuthOperatorMNC;
			$headerArray[] = "x-mcc: " . $consumer->oAuthOperatorMCC;
			if (isset($auth2_access_token["access_token"])) {
				$headerArray[] = "Authorization: BEARER " . $auth2_access_token["access_token"];
			}
			$url = $consumer->wacURLChargePayment;
			$currentTimeStamp = time() * 1000;
			$referenceCode    = md5($consumer->products->getProductKey() . $currentTimeStamp);
			if($consumer->wacSDKVersion == "dot1")
			{
				$data = "endUserId=" . urlencode("acr:Authorization") . "&" . "referenceCode=" . urlencode($referenceCode) . "&" . "transactionOperationStatus=" . urlencode("Charged") . "&" . "description=" . urlencode($consumer->products->getProductDescription()) . "&" . "code=" . urlencode($consumer->products->getProductKey()) . "&" . "productID=" . urlencode($consumer->oAuthAppID);
			}else
			{
				$data = "endUserId=" . urlencode("acr:Authorization") . "&" . "referenceCode=" . urlencode($referenceCode) . "&" . "transactionOperationStatus=" . urlencode("Charged") . "&" . "description=" . urlencode($consumer->products->getProductDescription()) . "&" . "code=" . urlencode($consumer->products->getProductKey()) . "&" . "productID=" . urlencode($consumer->oAuthAppID)."&currency=".$consumer->products->getProductCurrency() ."&amount=".$consumer->products->getProductPrice() ."&serverReferenceCode=".urlencode($referenceCode);
			}
			$response = $this->httpfunc->httpRequest($url, "", $data, $headerArray, "POST");
			$this->responseJSONForDot1 = $response;
			$response = $this->utilsfunc->decode_json($response);
			return $response;
		}else{
			$headerArray = array();
			if (isset($auth2_access_token["access_token"])) {
				$headerArray[] = "Authorization:BEARER ".$auth2_access_token["access_token"];
			}
			$headerArray[] = "Accept:application/json";
			$headerArray[] = "Content-Type:application/x-www-form-urlencoded";

			$url = $consumer->wacURLChargePayment;

			$currentTimeStamp = time() * 1000;
			$referenceCode    = md5($consumer->products->getProductKey() . $currentTimeStamp);
			$data = "endUserId=".urlencode("acr:Authorization")."&referenceCode=".urlencode($referenceCode)."&serverReferenceCode=".urlencode($auth2_access_token["server_reference_code"])."&transactionOperationStatus=" . urlencode("Charged")."&description=".urlencode($consumer->products->getProductDescription())."&code=".urlencode($consumer->products->getProductKey())."&currency=".urlencode($consumer->wacProductCurrency)."&amount=".urlencode($consumer->wacProductPrice);

			$response = $this->httpfunc->httpRequest($url, "", $data, $headerArray, "POST");
			$payLoad = base64_encode($this->aesfunc->aesEncrypt(serialize($response)));
			$response = $this->utilsfunc->decode_json($response);
			$refCode = $response["amountTransaction"]["serverReferenceCode"];
			$this->databasefunc->insertDb($refCode, $payLoad, $userID);
			return $response;
		}
	}

	/**
	 * Performs Check Transactions for 0.2
	 *
	 * @param string Authorization code given by gateway to get Access token and check transaction
	 * @param string Transaction ID
	 * @param string userID
	 * @return array
	 */
	private function checkTransactionForOAuth2($code,$ref_code, $userID)
	{
		if($this->wacSDKVersion == "dot1"){
			$auth2_access_token = $this->tokenfunc->getAuth2AccessToken($code, $this);
			if (!$auth2_access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("ACCESS_TOKEN_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
			$url = $this->wacURLCheckTransaction;
			$url = str_replace("{transaction-id}", $ref_code, $url);
			$headerArray = array();
			$headerArray[] = "Accept: application/json";
			$headerArray[] = "x-mnc: " . $this->oAuthOperatorMNC;
			$headerArray[] = "x-mcc: " . $this->oAuthOperatorMCC;

			if (isset($auth2_access_token["access_token"])) {
				$headerArray[] = "Authorization: BEARER " . $auth2_access_token["access_token"];
			}
			$response = $this->httpfunc->httpRequest($url, "", "", $headerArray, "GET");
			$response = $this->utilsfunc->decode_json($response);
			return $response;
		}else{
			$transactions = $this->databasefunc->checkTransDbData($ref_code, $userID);
			if(isset($transactions[0])){
				$dbCheckResult = $this->utilsfunc->decode_json(unserialize($this->aesfunc->aesDecrypt(base64_decode($transactions[0]["payLoad"]))));
			}else{
				$error = $this->i18nfunc->getSDKMessageForLocale("NO_TRANSACTIONS_AVAILABLE");
     			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
			
			if(isset($dbCheckResult) && $dbCheckResult){
				return $dbCheckResult;
			}else{
				$error = $this->i18nfunc->getSDKMessageForLocale("NO_TRANSACTIONS_AVAILABLE");
     			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
		}
	}

	/**
	 * Performs List Transactions for oAuth 2
	 *
	 * @param string Authorization code given by gateway to get Access token and check transaction
	 * @param string userID
	 * @return array
	 */
	private function getListTransactionsForOAuth2($code, $userID)
	{
		if($this->wacSDKVersion == "dot1"){
			$auth2_access_token = $this->tokenfunc->getAuth2AccessToken($code, $this);
			if (!$auth2_access_token){
				$error = $this->i18nfunc->getSDKMessageForLocale("ERROR_TAG").$this->i18nfunc->getSDKMessageForLocale("ACCESS_TOKEN_ERROR");
				ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
			$url = $this->wacURLListTransactions;
			$headerArray = array();
			$headerArray[] = "Accept: application/json";
			$headerArray[] = "x-mnc: " . $this->oAuthOperatorMNC;
			$headerArray[] = "x-mcc: " . $this->oAuthOperatorMCC;

			if (isset($auth2_access_token["access_token"])) {
				$headerArray[] = "Authorization: BEARER " . $auth2_access_token["access_token"];
			}

			$response = $this->httpfunc->httpRequest($url, "", "", $headerArray, "GET");
			$response = $this->utilsfunc->decode_json($response);
			return $response;
		}else{
			$transactions = $this->databasefunc->listTransDbData($userID);
			if(!isset($transactions[0])){
				$error = $this->i18nfunc->getSDKMessageForLocale("NO_TRANSACTIONS_AVAILABLE");
     			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
			$transList = array();
			$transList["paymentTransactionList"]["resourceURL"] = $this->wacURLChargePayment;
			for($i=0;$i<sizeof($transactions);$i++){
				$decodedJSON = $this->utilsfunc->decode_json(unserialize($this->aesfunc->aesDecrypt(base64_decode($transactions[$i]["payLoad"]))));
				$transList["paymentTransactionList"]["amountTransaction"][$i] = $decodedJSON["amountTransaction"];
			}
			if(isset($transList["paymentTransactionList"]["amountTransaction"][0])){
				return $transList;
			}else{
				$error = $this->i18nfunc->getSDKMessageForLocale("NO_TRANSACTIONS_AVAILABLE");
     			ErrorUtils::handle_error(ErrorUtils::$tag, $error);
			}
		}
	}

	/**
	 * Initialize a WAC Consumer with present Application details and Callback
	 *
	 * @param string Redirect URI registered with a given application
	 */
	public function wacConsumer($callBackURL = null)
	{
		$this->app_callback = $callBackURL;
		//	create OAuthConsumer instance
		$this->oauth = new OAuthConsumer($this->oAuthConsumerKey, $this->oAuthConsumerSecret, $callBackURL);
	}
}

?>