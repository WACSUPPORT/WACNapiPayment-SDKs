<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/**
* interface for payment functions
* 
*/
interface PaymentService
{
   /**
    * Initializes the application credentials to process the payment (environment, consumerKey, consumerSecret, appID, appUserName,redirectURI).
	* This data is obtained when the application is registered with WAC.
	*
	* @param string Type of Environment URL
	* @param string Developer ID/Consumer Key given by WAC
	* @param string Developer Secret
	* @param string Identifier for a given Application
	* @param string Username of the developer registered with WAC
	* @param string Callback URI for the application
    */	
    public function initService($urlType,$consumerKey,$consumerSecret,$appID,$appUserName,$redirectURI);

   /**
    * Returns the list of items for a given application
    * @return JSON parameters	
    */	
    public function listProductItems();
    
    /**
    * Initialize Make payment for a specific Item ID
    * @param string product key
    */
    public function initChargePayment($appProductKey);
    
    /**
    * Initialize Check Transactions for a Transaction ID
    * @param string reference code / transaction ID
    */
    public function initCheckTransactions($ref_code);
    
    /**
    * Initialize List Transactions
    */
    public function initListTransactions();
    
    /**
    * Reserves the Payment.
    * @param string product key 
    */
    public function reservePayment($appProductKey);
    
    /**
    * Capture the payment for a reserved transaction.
    * @param string reserved object containing details of the payment to be captured
    */
    public function capturePayment($reserved, $userID);
    
    /**
     * Make payment using the content delivery callback
     * @param string appProductKey
     * @param boolen callback for content delivery flag
	 * @deprecated deprecated since version 1.0.1
     */	
    public function chargePayment($appProductKey, $callback, $userID);
    
   /**
    * Check Transactions for a Transaction ID
    * @param string reference code / transaction ID
    */
    public function checkTransactions($ref_code, $userID);
    
   /**
    * List Transactions
    */
    public function listTransactions($userID);
    
    /**
    * Set the locale of the user
    * @param string locale of the user to be set by developer
    */
    public function setUserLocale($locale);
    
    /**
    * Set the spoofed IP
    * @param string IP spoofed IP
    */
    public function setSpoofedIP($ip);
    
    /**
	* Get detail of a particular ItemID
	*
	*  @param string Product ID
	*/
    public function getProductDetails($appProductKey);
    
    /**
    * Enable/Disable Logging
    *
    *  @param boolean log
    */
    public function debugLog($log);
    
    /**
    * URL to be redirected once payment successfull page is displayed.
    *
    *  @param string URL 
    */
    public function showPaymentSuccessPage($callback);
    
    /**
    * Function that returns true if WAC billing is available else returns false
    * @param string Type of Environment URL
	* @param string Developer ID/Consumer Key given by WAC
	* @param string Developer Secret
	* @param string Application string Identifier for a given Application
	* @param string Username of the developer registered with WAC
    * @return boolean
    */
    public function checkBillingAvailability($environment, $consumerKey, $consumerSecret, $appID, $appUserName);
}

?>
