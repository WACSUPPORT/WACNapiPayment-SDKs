<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title> WAC-Cinemas </title>
    <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
	<meta name="apple-mobile-web-app-capable" content="yes" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="icon" type="image/png" href="modules/wac_logo.png" />
    <link href="modules/stylesheet.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="modules/script.js"> </script>
</head>
<body>
	<img class="logo" src="modules/wac_logo.png" /><br /><br /><br />
	<h2 class="heading1">WAC Cinemas</h2><h4 class="heading"><br /> (Sample Application to demonstrate PHP NAPI SDK)</h4><br /><br />
    <div class="homeBtn"><a href="index.php" id="links"> Home </a></div>
    <br /><br />

<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
 */

/**
 *
 * WAC Cinemas is a sample application that demonstrates in-application billing/payment with
 * WAC NAPI SDK.
 * 
 * Funtionality:
 * WAC Cinemas has a simple UI that allows users to choose from a list of shows and then 
 * make a purchase using the WAC Payment option
 * 
 * Initialization:
 * - Load the app_constants.php file with the application details obtained from developer registration.
 * - Create an WacPaymentService object when the payment is required.
 * - Initialize the object with the information from app_constants.php (initService(...))
 * - Initialize the respective api's for authorization (initChargePayment(), initCheckTransactions(), initListTransactions())
 * 
 * Making a Payment using WAC using Reserve & Capture payment
 * 		- First reserve the payment - call reservePayment() on WacPaymentService - (See wac_billing_callback.php)
 * 		- Once the purchase is done, get the reserved payment transaction and use
 * 		it to capture the payment (See wac_billing_callback.php)
 * 
 */

/** Include SDK files in application */
require_once 'wac/wac.php';

/** Include Application files */
require_once 'app_constants.php';
require_once 'modules/app_ui.php';

$func = 1;
/** Get the selected function by the user. */
if (isset($_GET['pay']) || isset($_GET['check']) || isset($_GET['list'])) {
    if (isset($_GET['pay'])) {
        $func = "pay";
    } else if (isset($_GET['check'])) {
        $func     = "check";
        $ref_code = $_GET['refer_code'];
        /** Save reference code in a cookie, so as to use it for CheckTransaction() */
        setcookie('ref_code', $ref_code, time() + 3600, '/');
    } else if (isset($_GET['list'])) {
        $func = "list";
    }
    setcookie('payment_function',$func, time() + 3600, '/');
}

/** if set, Save product key identifier [ItemID for List Transactions] in cookie */
if (isset($_GET['product_key'])) {
    $appProductKey = $_GET['product_key'];
    /** Save product key in a cookie */
    setcookie('pro_key', base64_encode($_GET['product_key']), time() + 3600, '/');
} else {
    $appProductKey = null;
}

/**
 * Specify WAC Environment URL to be used by library [DEFAULT,PRODUCTION,STAGING] 
 */
$environment = 'PRODUCTION';

/** Create a Application UI instance */
$ui = new app_ui();

/** Create a WacPaymentService instance */
$consumer = new WacPaymentService();

/**
* Sets the Locale for a user. This will be used to show the error/info/warn messages in the user preffered language.
*
*  @param string Locale for a given user
*/
$consumer->setUserLocale("en-US");

// In order to test the application in a different geography, it is
// necessary for the NAPI invocation to originate from an IP in that
// geography.
   
// Use the following statement to spoof IP address to get German DT pricing by default
//$consumer->setSpoofedIP('80.187.110.132');
   
// Alternately, use the following statement to spoof IP address to get US AT&T pricing by default
$consumer->setSpoofedIP('12.207.19.228');

/**
* Enable/Disable Debug Logging
*
*  @param boolean True to enable logging, False otherwise
*/
/* $consumer->debugLog('true'); */

/**
* Initializes the application credentials to process the payment (environment, consumerKey, consumerSecret, appID, appUserName,redirectURI).
* This data is obtained when the application is registered with WAC.
*
* @param string Type of Environment URL
* @param string Developer ID/Consumer Key given by WAC
* @param string Developer Secret
* @param string Application string Identifier for a given Application
* @param string Username of the developer registered with WAC
* @param string Callback URI for the application
*/
$consumer->initService($environment, $consumerKey, $consumerSecret, $appID, $appUserName,$redirectURI);

/**
* Get detail of a particular ItemID
*
*  @param string Product ID for which details are to be fetched
*/
/* if(isset($appProductKey) && $appProductKey!=null){
	print_r($consumer->getProductDetails($appProductKey));exit();
} */

switch ($func) {
    case 'pay':
        
        try {
            // Initialize the Make/Charge Payment process
            $consumer->initChargePayment($appProductKey);
        }
        catch (Exception $e) {
            echo '<pre>';
            var_dump($e);
        }
        break;
    
    case 'check':

        try {
            // Initialize the Check Transaction process
            $consumer->initCheckTransactions($ref_code);
        }
        catch (Exception $e) {
            echo '<pre>';
            var_dump($e);
        }
        break;
    
    case 'list':

        try {
            // Initialize the List Transaction process
            $consumer->initListTransactions();
        }
        catch (Exception $e) {
            echo '<pre>';
            var_dump($e);
        }
        break;

    default:
    	// Query API - Fetches a list products and their details for a given AppID
    	$drop_down_options = $consumer->listProductItems();
        /** Default page -- Main page with options */
        $ui->ui_default($drop_down_options);
        break;
}
?>
</body>
</html>
