<?php
/**
 * Copyright (c) 2011, WAC Application Services Ltd. All Rights Reserved.
 * The use of this SDK is subject to the terms and conditions in license.txt
*/

class app_ui
{
    // To create UI for the Application
    function ui_default($drop_down_options)
    {
    	$this->navMenu("make");
    	$this->chargePayUI($drop_down_options, "reset");
    	$this->checkPayUI();
    	$this->listTransUI();
    	$this->endNavMenu();
    }
    
    // To create UI for the Application
    function ui_app_result($consumer, $r, $transaction_type)
    {
    	$drop_down_options = $consumer->listProductItems();
    	switch($transaction_type){
    		case "PAY":
    			$this->navMenu("make");
    			$this->displayPayResult($r);
    			$this->checkPayUI();
    			$this->listTransUI();
    			$this->endNavMenu();
    			break;
    		
    		case "CHECK":
    			$this->navMenu("check");
    			$this->chargePayUI($drop_down_options);
    			$this->displayCheckResult($r);
    			$this->listTransUI();
    			$this->endNavMenu();
    			break;
    		
    		case "LIST":
    			$this->navMenu("list");
    			$this->chargePayUI($drop_down_options);
    			$this->checkPayUI();
    			$this->displayListResult($r);
    			$this->endNavMenu();
    			break;
    			
    		default: break;
    	}
    }
    
    function chargePayUI($drop_down_options, $setApp=""){
    	if($setApp=="reset"){
    		echo '<div id="pay_data" style="display:block;">';
    	}else{
    		echo '<div id="pay_data">';
    	}
    	
    	   echo '<br />
    	    	&nbsp;&nbsp; Choose Product : 
    			<select name="product_key">';
					// Fetch the list of products and their details for an Application in the form of an array.
    				//This data needs to be stored by the application. ProductId is required for making a payment.
    	    		$no_of_products    = count($drop_down_options);
    	
    	    		for ($i = 0; $i < $no_of_products; $i++) {
    	    			echo '<option value="' . $drop_down_options[$i]["item-id"] . '">' . $drop_down_options[$i]["description"] . '</option>';
    	    		}
		      echo '</select> 
		      <input type="submit" class="buy" name="pay" value=""/>
    	      <br /><br /><br />
    	    </div>';
    }
    
    function checkPayUI(){
    	echo '<div id="check_data">
                            <br />
                            &nbsp;&nbsp; ReferenceCode : 
                            <input type="textbox" name="refer_code"/>
                            <input type="submit" name="check" value="Check Transaction"/>
                            <br /><br /><br />
                        </div>';
    }
    
    function listTransUI(){
    	echo '<div id="list_data">
    	
    	<br/>
    	Transactions Loading ...
    	<input type="hidden" name="list" value=0/>
    	<br /><br /><br />
    	</div>';
    }
    
    function navMenu($func){
    	echo '
    	<table border="0px" width="33%">
    		<tr align="center">';
    	switch($func){
    		case "make":
    			echo '<td id="1" class="gray_menu"><a href="#" id="links">  <div> Make Payment </div> </a> </td>
    			<td id="2" class="red_menu"><a href="#" id="links">  <div> Check Payment </div> </a> </td>
    			<td id="3" class="red_menu"><a href="#" id="links">  <div> List Transactions </div> </a></td>';
    			break;
    		case "check":
    			echo '<td id="1" class="red_menu"><a href="#" id="links">  <div> Make Payment </div> </a> </td>
    			<td id="2" class="gray_menu"><a href="#" id="links">  <div> Check Payment </div> </a> </td>
    			<td id="3" class="red_menu"><a href="#" id="links">  <div> List Transactions </div> </a></td>';
    			break;
    		case "list":
    			echo '<td id="1" class="red_menu"><a href="#" id="links">  <div> Make Payment </div> </a> </td>
    			<td id="2" class="red_menu"><a href="#" id="links">  <div> Check Payment </div> </a> </td>
    			<td id="3" class="gray_menu"><a href="#" id="links">  <div> List Transactions </div> </a></td>';
    			break;
    		default: break;
    	}
    	echo '</tr>
    		<tr>
   		 		<td id="data" colspan="3" style="background:#FFFFFF;">
   			 	<form method="GET" name="func" id="func" action="index.php">';
    }
    
    function endNavMenu(){
    	echo '</form>
    			</td> </tr>
    	        </table>';
    }
    
    function displayPayResult($r){
    	echo '
    	     <div id="pay_data" style="display:block"> ';

    	if (isset($r['amountTransaction'])) {
    		echo "<table border='1' bgcolor=\"#FFFFFF\"> <tr> <th> serverReferenceCode </th> <th> Description </th> <th> ItemID </th> <th> Amount </th> </tr>";
    		echo "<tr>";
    		echo "<td>" . $r['amountTransaction']['serverReferenceCode'] . "</td>";
    		echo "<td>" . $r['amountTransaction']['paymentAmount']['chargingInformation']['description'] . "</td>";
    		echo "<td>" . $r['amountTransaction']['paymentAmount']['chargingInformation']['code'] . "</td>";
    		echo "<td>" . $r['amountTransaction']['paymentAmount']['chargingInformation']['amount'] . " " . $r['amountTransaction']['paymentAmount']['chargingInformation']['currency'] . "</td>";
    		echo "</tr>";
    		echo "</table>";
    		 
    	}

    	echo '</div>';
    }
    
    function displayCheckResult($r){
    	echo '<div id="check_data" style="display:block">';
    	 
    	if (isset($r['amountTransaction'])) {
    		echo "<table border='1' bgcolor=\"#FFFFFF\"> <tr> <th> serverReferenceCode </th> <th> Description </th> <th> ItemID </th> <th> Amount </th> </tr>";
    		echo "<tr>";
    		echo "<td>" . $r['amountTransaction']['serverReferenceCode'] . "</td>";
    		echo "<td>" . $r['amountTransaction']['paymentAmount']['chargingInformation']['description'] . "</td>";
    		echo "<td>" . $r['amountTransaction']['paymentAmount']['chargingInformation']['code'] . "</td>";
    		echo "<td>" . $r['amountTransaction']['paymentAmount']['chargingInformation']['amount'] . " " . $r['amountTransaction']['paymentAmount']['chargingInformation']['currency'] . "</td>";
    		echo "</tr>";
    		echo "</table>";
    	}
    	 
    	echo '</div>';
    }
    
    function displayListResult($r){

    	echo '<div id="list_data" style="display:block">
    	      <input type="hidden" name="list" value=0/>';
    	
    		if (isset($r['paymentTransactionList'])) {
    			$no_of_transactions = count($r['paymentTransactionList']['amountTransaction']);
    			echo "<table border='1' bgcolor=\"#FFFFFF\"> <tr> <th> serverReferenceCode </th> <th> Description </th> <th> ItemID </th> <th> Amount </th> </tr>";
    			for ($i = 0; $i < $no_of_transactions; $i++) {
    				echo "<tr>";
    				echo "<td>" . $r['paymentTransactionList']['amountTransaction'][$i]['serverReferenceCode'] . "</td>";
    				echo "<td>" . $r['paymentTransactionList']['amountTransaction'][$i]['paymentAmount']['chargingInformation']['description'] . "</td>";
    				echo "<td>" . $r['paymentTransactionList']['amountTransaction'][$i]['paymentAmount']['chargingInformation']['code'] . "</td>";
    				echo "<td>" . $r['paymentTransactionList']['amountTransaction'][$i]['paymentAmount']['chargingInformation']['amount'] . " " . $r['paymentTransactionList']['amountTransaction'][$i]['paymentAmount']['chargingInformation']['currency'] . "</td>";
    				echo "</tr>";
    			}
    			echo "</table>";
    		}
    	echo '</div>';
    }
}

?>

