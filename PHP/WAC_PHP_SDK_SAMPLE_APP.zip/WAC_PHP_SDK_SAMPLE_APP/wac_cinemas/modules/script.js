window.onload = init;

function init() {
	var el = document.getElementById("1");
	if (el.addEventListener) {
		el.addEventListener('click', swapMakePay, false);
	} else if (el.attachEvent) {
		el.attachEvent('onclick', swapMakePay);
	}
	
	var em = document.getElementById("2");
	if (em.addEventListener) {
		em.addEventListener('click', swapCheckTrans, false);
	} else if (em.attachEvent) {
		em.attachEvent('onclick', swapCheckTrans);
	}
	
	var en = document.getElementById("3");
	if (en.addEventListener) {
		en.addEventListener('click', swapListTrans, false);
	} else if (en.attachEvent) {
		en.attachEvent('onclick', swapListTrans);
	}
}

function swapMakePay(){
	change_form('pay_data',1);
}

function swapCheckTrans(){
	change_form('check_data',2);
}

function swapListTrans(){
	change_form('list_data',3);
	submit_form();
}


function submit_form(){
    document.forms["func"].list.value=1;
    document.forms["func"].submit();
}

function change_form(form_name,tab){
    document.getElementById(1).style.background = "#BF2E25";
    document.getElementById(2).style.background = "#BF2E25";
    document.getElementById(3).style.background = "#BF2E25";
    
    document.getElementById(tab).style.background = "#58585A";
    
    document.getElementById("pay_data").style.display = "none";
    document.getElementById("check_data").style.display = "none";
    document.getElementById("list_data").style.display = "none";
    
    
    document.getElementById(form_name).style.display = "block";
    document.getElementById(form_name).style.zIndex = "3";
}
