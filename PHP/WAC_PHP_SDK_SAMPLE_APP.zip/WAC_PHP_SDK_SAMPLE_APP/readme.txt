﻿************************
PHP SDK for WAC Payments:
************************

**********************************
About the PHP SDK for WAC NAPI:
**********************************
The WAC's PHP Software Developer Kit (SDK) makes the process of integrating WAC's payment services into PHP application easy.
This software is intended for use by PHP application developers.

************
Prerequisite:
************
1. Register with WAC as a developer: http://www.wacapps.net/register
2. Create Applications: http://www.wacapps.net/napi-application
3. Manage Applications: http://www.wacapps.net/manage-payment-api
4. Cookies must be enabled on browser to run the sample application.

*****************************************
WAC API Integration with PHP applications:
*****************************************
Whats new in NAPI SDK beta 1.0 ?

* Support for In band and out of band transactions.
* Improved End user identification flow for out of band transaction.
* Fast in band transactions
* Query prices based on country
* Support for reserve and capture model for payments, in additions to quick pay.
* SQLite based and encrypted PHP data store for storing previous transactions.
* Basic authorization support
* User friendly error messages
* Localization support for all major markets and locales.

Whats new in NAPI SDK beta 1.0.1 ?

* Added new API for checking the WAC billing availability  “checkBillingAvailability”
* Fixed issues related to error handling.
* Documentation updates
* Deprecated the Express Pay

Whats new in NAPI SDK beta 1.0.2 ?

* Fixed issues related to SQLLite creation.
* More error handling.
* Documentation updates

*****************
Required Software:
*****************
PHP Version 5.1.2 or above
Apache/2.2 or above
Extensions to be enabled : libcURL3 with cURL, SQLite, mcrypt.
mhash should be enabled in php.ini for versions <= 5.1.2

******************************
Running the sample application:
******************************
- Place the sample application (wac_cinemas directory) in root directory of web server.
- The directory "wac" inside the wac_cinemas directory contains SDK libraries.
- Launch the sample application using http://localhost/wac_cinemas
- The sample application redirect URL is provisioned as "http://localhost/wac_cinemas/wac_billing_callback.php". Hence the usage of the above mentioned URL (http://localhost/wac_cinemas) is mandatory for running the sample application. This is specified in "app_constants.php". 
- The credentials in "app_constants.php" can be replaced by the developer after obtaining the credentials from WAC for testing purpose.

**********************************************************************
Running the sample application using the credentials obtained from WAC:
**********************************************************************
- Place the sample application (wac_cinemas directory) in root directory of web server.
- Replace the application credentials in "app_constants.php" obtained from WAC after registration.
- "$redirectURI" in "app_constants.php" should be same as that the redirect URI specified during registration with WAC.
- Launch the application. For example: <Base URL>/wac_cinemas/index.php

***************************************************
Integrating WAC in-application payments/billing API:
***************************************************
1. Modify workspace to include the WAC PHP-SDK files.
       Add "wac" directory from the sample application to your application directory.

2. Include necessary PHP-SDK files:
       In Application file where you are using PHP-SDK include the following SDK file.
           - require_once "wac/wac.php";

3. Modify application code to call the WacPaymentService which contains all the API's for making payment and other related tasks
	   - The details are similar to the steps explained in "WAC SDK-PHP Sample application" section 

******************************
WAC SDK-PHP Sample application:
******************************
The sample application demonstrates the usage of WAC in-application payment. 
Usage of WAC-SDK in sample application is as follows:

The following APIs are exposed by PHP SDK for NAPI interaction:

*******************************
Initializing WacPaymentService:
*******************************
To access WAC-PHP-SDK library, 
Initialize WacPaymentService in the file where you have included "wac/wac.php".

// Create a WacPaymentService instance
$consumer = new WacPaymentService();

/**
* Initializes the application credentials to process the payment (environment, consumerKey, consumerSecret, appID, appUserName,redirectURI).
* This data is obtained when the application is registered with WAC.
*
* @param urlType string Type of Environment URL
* @param consumerKey string Developer ID/Consumer Key given by WAC
* @param consumerSecret string Developer Secret
* @param appID Application string Identifier for a given Application
* @param appUserName string Username of the developer registered with WAC
* @param redirectURI string Callback URI for the application
*/
$consumer->initService($environment, $consumerKey, $consumerSecret, $appID, $appUserName,$redirectURI);

Get List of Products for a particular application ID:
*****************************************************
 // Fetch the list of products and their details for an Application in the form of an array.
 //This data needs to be stored by the application. ProductId is required for making a payment.
    	$drop_down_options = $consumer->listProductItems();

***********************
Initializing functions:
***********************

Payment Initialization
**********************
To start the authorization process for various functions, please initialize.

 // Initialize the Make/Charge Payment process
            $consumer->initChargePayment($appProductKey);       

 // Initialize the Check Transaction process
            $consumer->initCheckTransactions($ref_code);
 
 // Initialize the List Transaction process
            $consumer->initListTransactions();
	
*******************
Handling callbacks:
*******************
The authorization flow will call back the redirect URI provided while registering the application with WAC.
Callbacks are handled in wac_billing_callback.php, for payment/check/list transactions in sample application
Sample code for payment callback:

Make Payment
************
Reserve and capture payment
	After authorization, reserve the payment using reservePayment(). This returns the complete details required to make a payment which can be used later to make the actual payment.
	Example:
    // Reserve the payment
        $reserved = $consumer->reservePayment($appProductKey);

	To capture the previously reserved fund, developer can invoke capturePayment after fulfillment of purchase (service or content delivery) is successful.
    // Capture the reserved payment
        $res = $consumer->capturePayment($reserved, $userID);

Check Transaction
*****************
$res = $consumer->checkTransactions($ref_code, $userID);

List Transaction
****************
$res = $consumer->listTransactions($userID);

*********
Utilities
*********

Set user locale
***************
The below line Sets the Locale for a user. This will be used to show the error/info/warn messages in the user preffered language.

$consumer->setUserLocale("en-US");

Debugging
*********
All the errors are logged to apache log with tag as "WAC".
To enable debug logs for Http debugging please add the below line

$consumer->debugLog('true');

Get product details for a particular product ID
***********************************************
// Get detail of a particular ItemID
$consumer->getProductDetails($appProductKey)

IP spoofing for testing the application for different geographies
*****************************************************************
In order to test the application in a different geography, it is necessary for the NAPI invocation to originate from an IP in that geography.
The following line can be used to achieve this.
// Sets a spoofed IP
$consumer->setSpoofedIP('<IP_ADDRESS>');

Show payment successful page
****************************
The following line of code can be added to the application to show a payment successful page to the user.
The function takes a callback URL as a parameter to which the control should be returned after user leave the payment successful page.

$consumer->showPaymentSuccessPage($callback="<Callback URL to return to the application>");

WAC Billing Availability
************************
This API can be used to check if WAC Billing service is available.
It returns true if WAC billing is available else returns false.

/** 
* @param string Type of Environment URL
* @param string Developer ID/Consumer Key given by WAC
* @param string Developer Secret
* @param string Application string Identifier for a given Application
* @param string Username of the developer registered with WAC
* @return boolean True if wac billing is available
*/

$status = $consumer->checkBillingAvailability($environment, $consumerKey, $consumerSecret, $appID, $appUserName);

Limitations of this method: At the point of calling this method WAC have not yet checked the individual user. In the case the user is out-of-band (e.g. WiFi), we have not yet identified the operator either because we want to avoid having to ask the user for their phone number when this method is called. This means that this method behaves as follows:
• In-band flow, app not LIVE or not published to this operator: will return "false"
• Out-of-band flow, app not LIVE or not published in the country of the access point IP address: will return "false"
• Out-of-band flow, app published in the country of the access point IP address but not the operator of the user: will return "true"
• Individual user can't use WAC even if other users of this operator can, e.g. user blacklisted, user doesn't have enough credit etc.: will return "false"
• App is LIVE, published to this operator and individual user can use WAC: will return "true"

*******************
Transaction Storage
*******************
Transaction data is stored on the server in SQLite.
User ID is passed as a parameter to the API's (chargePayment, capturePayment, checkTransactions and listTransactions) is used for unique identification of the user to store and retrieve transaction data.

*****************************************************************************
Configuring the sample application to work with a different test environment:
*****************************************************************************
The sample app is currently configured to work with the WAC Production environment.  
Testing against an operator endpoint can be done but will require approval from both WAC and the operator in question.

Sandbox Availability
********************
While WAC Operations and Support works hard to keep the Developer Sandbox available 24 hours a day, 7 days a week, occasional system downtime may occur. 
To check the real-time status of the sandbox at any time, just click here - http://status.wacapps.net/19627/228798/0.2-Payment-API-Service---Dev-Sandbox
